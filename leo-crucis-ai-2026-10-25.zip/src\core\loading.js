// Laadscherm: laat duidelijk zien dat de app bezig is (laden, opslaan, exporteren, zoeken).
// Gebruik:  const klaar = await withLoading(promise, 'Boek openen…')   of   withLoading(() => iets(), 'Opslaan…')
// Het scherm verschijnt pas na een korte vertraging, zodat snelle acties niet flikkeren.

const SHOW_DELAY = 180;   // ms voordat het scherm zichtbaar wordt
const MIN_VISIBLE = 350;  // ms minimaal zichtbaar als het eenmaal getoond is (voorkomt knipperen)

let root = null, labelEl = null, detailEl = null, barEl = null, barFill = null, etaEl = null;
const stack = [];         // lopende taken (genest gebruik mogelijk)
let showTimer = null, shownAt = 0, hideTimer = null;

function build() {
  if (root) return;
  root = document.createElement('div');
  root.id = 'loading-overlay';
  root.className = 'loading-overlay';
  root.setAttribute('role', 'status');
  root.setAttribute('aria-live', 'polite');
  root.hidden = true;
  const box = document.createElement('div');
  box.className = 'loading-box';
  const spin = document.createElement('div');
  spin.className = 'loading-spinner';
  spin.setAttribute('aria-hidden', 'true');
  labelEl = document.createElement('p');
  labelEl.className = 'loading-label';
  detailEl = document.createElement('p');
  detailEl.className = 'loading-detail';
  barEl = document.createElement('div');
  barEl.className = 'loading-bar';
  barEl.setAttribute('role', 'progressbar');
  barEl.setAttribute('aria-valuemin', '0'); barEl.setAttribute('aria-valuemax', '100');
  barFill = document.createElement('div');
  barFill.className = 'loading-bar-fill';
  barEl.append(barFill);
  etaEl = document.createElement('p');
  etaEl.className = 'loading-eta';
  box.append(spin, labelEl, detailEl, barEl, etaEl);
  root.append(box);
  document.body.append(root);
}

function render() {
  const top = stack[stack.length - 1];
  if (!top) return;
  labelEl.textContent = top.label;
  detailEl.textContent = top.detail || '';
  detailEl.hidden = !top.detail;
  const has = top.total > 0;
  barEl.hidden = !has; etaEl.hidden = !has;
  if (has) {
    const frac = Math.max(0, Math.min(1, top.done / top.total));
    const pct = Math.round(frac * 100);
    barFill.style.width = pct + '%';
    barEl.setAttribute('aria-valuenow', String(pct));
    etaEl.textContent = pct + '% · ' + etaText(top, frac);
  }
}

// Geschatte resterende tijd: gladgestreken snelheid (bytes of stappen per seconde).
function etaText(t, frac) {
  if (frac >= 1) return 'bijna klaar…';
  const elapsed = (Date.now() - t.startedAt) / 1000;
  if (elapsed < 1.5 || frac < 0.02 || !t.rate) return 'tijd wordt berekend…';
  const secs = Math.ceil((t.total - t.done) / t.rate);
  return 'nog ' + fmtTime(secs);
}
export function fmtTime(secs) {
  if (secs < 5) return 'een paar seconden';
  if (secs < 60) return 'ongeveer ' + (Math.ceil(secs / 5) * 5) + ' seconden';
  const m = Math.floor(secs / 60), r = secs % 60;
  if (m < 5) return 'ongeveer ' + m + ' min ' + String(Math.round(r / 10) * 10 % 60).padStart(2, '0') + ' s';
  if (m < 60) return 'ongeveer ' + m + ' minuten';
  return 'ongeveer ' + Math.floor(m / 60) + ' u ' + (m % 60) + ' min';
}

function reveal() {
  showTimer = null;
  if (!stack.length) return;
  build(); render();
  root.hidden = false;
  document.body.classList.add('is-loading');
  shownAt = Date.now();
}

function conceal() {
  hideTimer = null;
  if (stack.length || !root) return;
  root.hidden = true;
  document.body.classList.remove('is-loading');
}

export function startLoading(label = 'Laden…') {
  const task = { label, detail: '', done: 0, total: 0, rate: 0, startedAt: Date.now(), lastT: Date.now(), lastDone: 0 };
  stack.push(task);
  if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
  if (root && !root.hidden) render();
  else if (!showTimer) showTimer = setTimeout(reveal, SHOW_DELAY);
  let done = false;
  // Voortgang doorgeven: stop.update({ done, total, label?, detail? })
  const update = (p = {}) => {
    if (p.label != null) task.label = p.label;
    if (p.detail != null) task.detail = p.detail;
    if (p.total != null && p.total !== task.total) { task.total = p.total; task.startedAt = Date.now(); task.lastT = task.startedAt; task.lastDone = p.done || 0; task.rate = 0; }
    if (p.done != null) {
      const now = Date.now(), dt = (now - task.lastT) / 1000;
      if (dt >= 0.4) {
        const inst = (p.done - task.lastDone) / dt;
        if (inst > 0) task.rate = task.rate ? task.rate * 0.7 + inst * 0.3 : inst;
        task.lastT = now; task.lastDone = p.done;
      }
      task.done = p.done;
    }
    if (root && !root.hidden && stack[stack.length - 1] === task) render();
  };
  const stop = () => {
    if (done) return; done = true;
    const i = stack.indexOf(task); if (i >= 0) stack.splice(i, 1);
    if (stack.length) { if (root && !root.hidden) render(); return; }
    if (showTimer) { clearTimeout(showTimer); showTimer = null; return; }   // nooit getoond
    const wait = Math.max(0, MIN_VISIBLE - (Date.now() - shownAt));
    hideTimer = setTimeout(conceal, wait);
  };
  stop.update = update;
  return stop;
}

export async function withLoading(work, label) {
  const stop = startLoading(label);
  try { return await (typeof work === 'function' ? work(stop.update) : work); }
  finally { stop(); }
}

let _splashStarted = 0;
export function setSplashProgress(pct, label, detail) {
  if (!_splashStarted) _splashStarted = Date.now();
  const labelEl = document.getElementById('splash-label');
  const fill = document.getElementById('splash-bar-fill');
  const bar = document.getElementById('splash-bar');
  const meta = document.getElementById('splash-meta');
  const p = Math.max(0, Math.min(100, Math.round(Number(pct) || 0)));
  if (labelEl && label) labelEl.textContent = label;
  if (fill) fill.style.width = p + '%';
  if (bar) bar.setAttribute('aria-valuenow', String(p));
  let eta = '';
  if (p > 2 && p < 100 && _splashStarted) {
    const elapsed = (Date.now() - _splashStarted) / 1000;
    const rate = p / Math.max(elapsed, 0.5);
    const remain = Math.ceil((100 - p) / Math.max(rate, 0.01));
    if (remain < 5) eta = 'nog een paar seconden';
    else if (remain < 60) eta = 'nog circa ' + remain + ' s';
    else eta = 'nog circa ' + Math.ceil(remain / 60) + ' min';
  } else if (p >= 100) {
    eta = 'klaar';
  }
  if (meta) {
    const parts = [p + '%'];
    if (detail) parts.push(detail);
    if (eta) parts.push(eta);
    meta.textContent = parts.join(' · ');
  }
}

// Opstartscherm weghalen als de app klaar is.
export function hideSplash() {
  const s = document.getElementById('splash');
  if (!s) return;
  try { setSplashProgress(100, 'Klaar', 'starten…'); } catch (_) {}
  s.classList.add('splash-out');
  setTimeout(() => { try { s.remove(); } catch (_) {} }, 400);
  try {
    document.body.classList.remove('is-loading');
    const ov = document.getElementById('loading-overlay');
    if (ov) ov.hidden = true;
  } catch (_) {}
}
