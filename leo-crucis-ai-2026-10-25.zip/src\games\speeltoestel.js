// Speeltoestel — retro handheld met meerdere spelletjes.
// Scherm 160×144 pixels, 4 tinten, eigen pixellettertype.
// Spellen: Blokken, Slang, Race, Muur.

const SW = 160, SH = 144;
const COLS = 10, ROWS = 18, CS = 8;
const FX = 8, PX = 96;

const PALETTES = [
  { id: 'groen', name: 'Groen', c: ['#e0f8d0', '#88c070', '#346856', '#081820'] },
  { id: 'grijs', name: 'Grijs', c: ['#f4f4f0', '#b4b4ae', '#606058', '#101010'] },
  { id: 'amber', name: 'Amber', c: ['#ffe6a8', '#e8a840', '#9a5a10', '#2a1604'] }
];

const SHAPES = {
  I: [[0,0,0,0],[1,1,1,1],[0,0,0,0],[0,0,0,0]],
  O: [[1,1],[1,1]],
  T: [[0,1,0],[1,1,1],[0,0,0]],
  S: [[0,1,1],[1,1,0],[0,0,0]],
  Z: [[1,1,0],[0,1,1],[0,0,0]],
  J: [[1,0,0],[1,1,1],[0,0,0]],
  L: [[0,0,1],[1,1,1],[0,0,0]]
};
const TYPES = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];

const edge = (x, y) => x === 0 || y === 0 || x === 7 || y === 7;
const TILE_FN = {
  I: (x, y) => edge(x, y) ? 3 : 2,
  O: (x, y) => edge(x, y) ? 3 : 1,
  T: (x, y) => edge(x, y) ? 3 : ((x + y) % 2 ? 3 : 1),
  S: (x, y) => edge(x, y) ? 3 : (x >= 2 && x <= 5 && y >= 2 && y <= 5 ? 3 : 1),
  Z: (x, y) => edge(x, y) ? 3 : (y % 2 ? 3 : 1),
  J: (x, y) => edge(x, y) ? 3 : (x === y || x + y === 7 ? 3 : 1),
  L: (x, y) => edge(x, y) ? 3 : (x >= 3 && x <= 4 && y >= 3 && y <= 4 ? 3 : 2),
  X: (x, y) => edge(x, y) ? 3 : ((x + y) % 2 ? 2 : 3),
  B: (x, y) => (y % 4 === 3 || x === (((y >> 2) & 1) ? 3 : 7)) ? 3 : 2
};

const FONT_SRC = {
  A: '01110/10001/10001/11111/10001/10001/10001', B: '11110/10001/10001/11110/10001/10001/11110',
  C: '01110/10001/10000/10000/10000/10001/01110', D: '11110/10001/10001/10001/10001/10001/11110',
  E: '11111/10000/10000/11110/10000/10000/11111', F: '11111/10000/10000/11110/10000/10000/10000',
  G: '01110/10001/10000/10111/10001/10001/01111', H: '10001/10001/10001/11111/10001/10001/10001',
  I: '01110/00100/00100/00100/00100/00100/01110', J: '00111/00010/00010/00010/00010/10010/01100',
  K: '10001/10010/10100/11000/10100/10010/10001', L: '10000/10000/10000/10000/10000/10000/11111',
  M: '10001/11011/10101/10101/10001/10001/10001', N: '10001/11001/10101/10011/10001/10001/10001',
  O: '01110/10001/10001/10001/10001/10001/01110', P: '11110/10001/10001/11110/10000/10000/10000',
  Q: '01110/10001/10001/10001/10101/10010/01101', R: '11110/10001/10001/11110/10100/10010/10001',
  S: '01111/10000/10000/01110/00001/00001/11110', T: '11111/00100/00100/00100/00100/00100/00100',
  U: '10001/10001/10001/10001/10001/10001/01110', V: '10001/10001/10001/10001/10001/01010/00100',
  W: '10001/10001/10001/10101/10101/10101/01010', X: '10001/10001/01010/00100/01010/10001/10001',
  Y: '10001/10001/01010/00100/00100/00100/00100', Z: '11111/00001/00010/00100/01000/10000/11111',
  0: '01110/10001/10011/10101/11001/10001/01110', 1: '00100/01100/00100/00100/00100/00100/01110',
  2: '01110/10001/00001/00010/00100/01000/11111', 3: '11110/00001/00001/01110/00001/00001/11110',
  4: '00010/00110/01010/10010/11111/00010/00010', 5: '11111/10000/11110/00001/00001/10001/01110',
  6: '00110/01000/10000/11110/10001/10001/01110', 7: '11111/00001/00010/00100/01000/01000/01000',
  8: '01110/10001/10001/01110/10001/10001/01110', 9: '01110/10001/10001/01111/00001/00010/01100',
  '<': '00010/00100/01000/10000/01000/00100/00010', '>': '01000/00100/00010/00001/00010/00100/01000',
  '-': '00000/00000/00000/11111/00000/00000/00000', '.': '00000/00000/00000/00000/00000/01100/01100',
  '!': '00100/00100/00100/00100/00100/00000/00100'
};
const GLYPHS = {};
Object.keys(FONT_SRC).forEach(k => { GLYPHS[k] = FONT_SRC[k].split('/').map(r => parseInt(r, 2)); });

const GRAVITY = [48,43,38,33,28,23,18,13,8,6,5,5,5,4,4,4,3,3,3,2,2,2,2,2,2,2,2,2,2,1];
const gravityMs = lvl => GRAVITY[Math.min(lvl, GRAVITY.length - 1)] * 1000 / 60;
const LINE_POINTS = [0, 40, 100, 300, 1200];
const DAS_DELAY = 267, DAS_RATE = 100, DOWN_RATE = 40;
const CLEAR_MS = 560, DIE_STEP = 45;

const GAMES = [
  { id: 'blokken', name: 'BLOKKEN' },
  { id: 'slang', name: 'SLANG' },
  { id: 'race', name: 'RACE' },
  { id: 'muur', name: 'MUUR' },
  { id: 'doolhof', name: 'DOOLHOF' },
  { id: 'flap', name: 'FLAP' }
];

const K_BEST = 'lc-tetris-best', K_LEVEL = 'lc-tetris-level', K_PAL = 'lc-tetris-pal', K_SND = 'lc-tetris-snd', K_KEYS = 'lc-tetris-keys';
const K_BEST_S = 'lc-slang-best', K_BEST_R = 'lc-race-best', K_BEST_M = 'lc-muur-best', K_BEST_D = 'lc-doolhof-best', K_BEST_F = 'lc-flap-best';

const DEFAULT_KEYS = {
  left: ['ArrowLeft', 'a'], right: ['ArrowRight', 'd'], down: ['ArrowDown', 's'], up: ['ArrowUp', 'w'],
  a: ['x'], b: ['z'], drop: [' '], start: ['Enter', 'p'], pause: ['Escape'], select: ['c'], sound: ['m']
};
const KEY_LABELS = {
  left: 'Links', right: 'Rechts', down: 'Omlaag', up: 'Omhoog',
  a: 'A-knop', b: 'B-knop', drop: 'Laten vallen / actie',
  start: 'Start / pauze', pause: 'Pauze / menu', select: 'Kleur', sound: 'Geluid'
};

const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : v; } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem(k, String(v)); } catch (_) {} }
};

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

function rot(m) {
  const n = m.length;
  const r = Array.from({ length: n }, () => Array(n).fill(0));
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) r[x][n - 1 - y] = m[y][x];
  return r;
}

function injectStyles() {
  let s = document.getElementById('tetris-retro-styles');
  if (!s) {
    s = document.createElement('style');
    s.id = 'tetris-retro-styles';
    document.head.append(s);
  }
  s.textContent = `
.tg-app{
  display:flex;flex-direction:column;align-items:center;justify-content:center;outline:none;
  background:#000 !important;flex:1 1 auto;min-height:0;
  padding:24px 12px 48px;box-sizing:border-box;position:relative;
  width:100% !important;max-width:none !important;margin:0 !important;
}
.tg-app.is-fs{
  position:fixed !important;inset:0 !important;z-index:99999 !important;
  width:100vw !important;height:100vh !important;min-height:100vh !important;
  max-width:none !important;padding:24px;overflow:auto;margin:0 !important;
  background:#000 !important;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
}
.tg-app.is-fs::before{
  content:'';position:fixed;inset:0;background:#000;z-index:-1;pointer-events:none;
}
.tg-stage{
  position:relative;display:flex;justify-content:center;align-items:flex-start;
  width:100%;
}
.tg-stage .tg-console{
  position:relative;z-index:1;flex:none;margin:0 auto;
}
.tg-stage .tg-settings{
  position:absolute;top:0;right:calc(50% + 230px);
  width:280px;max-width:calc(50vw - 250px);z-index:2;
}
.tg-stage .tg-settings:not(.is-open){display:none !important}
@media (max-width:900px){
  .tg-stage .tg-settings{
    position:static;right:auto;width:min(280px,100%);max-width:100%;
    margin:0 auto 16px;order:-1;
  }
  .tg-stage{flex-direction:column;align-items:center}
}
/* Zelfde full-bleed patroon als video/audio (cinema/deck) */
body.browser-open:has(.tg-app){
  background:#000 !important;
}
body.browser-open:has(.tg-app) #view{
  background:#000 !important;
  padding:0 !important;
}
body.browser-open:has(.tg-app) #view-content,
body.browser-open:has(.tg-app) #view .in{
  background:#000 !important;
  padding:0 !important;
  margin:0 !important;
  max-width:none !important;
  width:100% !important;
}
body.browser-open:has(.tg-app) .browser-head,
body.browser-open:has(.tg-app) .view-head{
  background:#000 !important;
  color:#eee !important;
  margin:0 !important;
  padding:12px 16px !important;
  border-bottom:1px solid #1a1a1a !important;
}
body.browser-open:has(.tg-app) .view-head h1,
body.browser-open:has(.tg-app) .browser-head h1{
  color:#eee !important;
}
body.browser-open:has(.tg-app) .view-head .back,
body.browser-open:has(.tg-app) .browser-head .back{
  background:rgba(255,255,255,.08) !important;
  border-color:rgba(255,255,255,.18) !important;
  color:#ddd !important;
}
body.browser-open:has(.tg-app) .view-head .back:hover,
body.browser-open:has(.tg-app) .browser-head .back:hover{
  border-color:#888 !important;color:#fff !important;
}
body.browser-open:has(.tg-app.is-fs) header,
body.browser-open:has(.tg-app.is-fs) .view-head,
body.browser-open:has(.tg-app.is-fs) .browser-head{
  visibility:hidden !important;pointer-events:none !important;
}
.tg-console{
  position:relative;width:min(100%,420px);box-sizing:border-box;padding:20px 22px 36px;
  background:linear-gradient(160deg,#dedbcf,#c3c0b2);
  border-radius:14px 14px 70px 14px;
  box-shadow:inset -3px -3px 0 rgba(0,0,0,.18),inset 3px 3px 0 rgba(255,255,255,.55),0 12px 30px rgba(0,0,0,.55);
  user-select:none;-webkit-user-select:none;
}
.tg-bezel{
  position:relative;background:#5a5c70;border-radius:10px 10px 44px 10px;
  padding:16px 26px 10px;box-shadow:inset 0 2px 7px rgba(0,0,0,.55);
}
.tg-led{position:absolute;left:7px;top:34%;display:flex;flex-direction:column;align-items:center;gap:3px}
.tg-led i{width:7px;height:7px;border-radius:50%;background:#d33;box-shadow:0 0 6px #f55}
.tg-led small{font:700 6px/1 system-ui,sans-serif;color:#b9bbd0;letter-spacing:.04em}
.tg-screen{
  display:block;width:100%;aspect-ratio:160/144;box-sizing:border-box;
  border:2px solid #1b1c27;border-radius:3px;outline:none;
  image-rendering:-moz-crisp-edges;image-rendering:crisp-edges;image-rendering:pixelated;
}
.tg-cap{margin:7px 0 0;text-align:center;font:700 9px/1 system-ui,sans-serif;letter-spacing:.14em;color:#b9bbd0}
.tg-brand{margin:12px 2px 6px;display:flex;align-items:baseline;gap:8px}
.tg-brand b{font:italic 800 19px/1 Georgia,serif;color:#27368c;letter-spacing:.01em}
.tg-brand span{font:italic 800 13px/1 Georgia,serif;color:#27368c;opacity:.75}
.tg-controls{display:flex;justify-content:space-between;align-items:center;padding:6px 6px 0}
.tg-dpad{position:relative;width:114px;height:114px;flex:none}
.tg-dp{
  position:absolute;width:38px;height:38px;border:0;padding:0;background:#2c2c30;color:#8a8a92;
  cursor:pointer;touch-action:none;font:700 12px/1 system-ui,sans-serif;
}
.tg-dp:active,.tg-dp.is-down{background:#17171a}
.tg-dp.u{left:38px;top:0;border-radius:5px 5px 0 0}
.tg-dp.l{left:0;top:38px;border-radius:5px 0 0 5px}
.tg-dp.r{left:76px;top:38px;border-radius:0 5px 5px 0}
.tg-dp.d{left:38px;top:76px;border-radius:0 0 5px 5px}
.tg-dpc{position:absolute;left:38px;top:38px;width:38px;height:38px;background:#2c2c30}
.tg-dpc::after{content:'';position:absolute;left:12px;top:12px;width:14px;height:14px;border-radius:50%;background:#222226;box-shadow:inset 0 1px 3px #000}
.tg-ab{position:relative;width:138px;height:84px;flex:none;transform:rotate(-24deg)}
.tg-ab button{
  position:absolute;width:52px;height:52px;border-radius:50%;border:0;padding:0;cursor:pointer;touch-action:none;
  background:radial-gradient(circle at 35% 30%,#b8305f,#841a45 70%);
  box-shadow:0 3px 0 #5c102f,0 5px 8px rgba(0,0,0,.35);
}
.tg-ab button:active,.tg-ab button.is-down{transform:translateY(2px);box-shadow:0 1px 0 #5c102f}
.tg-ab .b{left:4px;top:26px}
.tg-ab .a{left:76px;top:8px}
.tg-ab em{position:absolute;font:italic 800 13px/1 Georgia,serif;color:#27368c}
.tg-ab .lb{left:22px;top:82px}
.tg-ab .la{left:94px;top:64px}
.tg-meta{display:flex;justify-content:center;gap:30px;margin-top:12px;transform:rotate(-24deg);padding-right:40px}
.tg-pill{display:flex;flex-direction:column;align-items:center;gap:5px}
.tg-pill button{width:48px;height:12px;border:0;border-radius:6px;background:#8c8a84;box-shadow:0 2px 0 #66645e;cursor:pointer;touch-action:none;padding:0}
.tg-pill button:active,.tg-pill button.is-down{transform:translateY(1px);box-shadow:none}
.tg-pill span{font:italic 800 9px/1 Georgia,serif;color:#27368c;letter-spacing:.06em}
.tg-grill{
  position:absolute;right:26px;bottom:28px;width:62px;height:44px;transform:rotate(-24deg);
  background:repeating-linear-gradient(90deg,#8f8d80 0 5px,transparent 5px 11px);
  border-radius:3px;opacity:.85;
}
.tg-bar{
  width:min(100%,420px);display:flex;justify-content:center;align-items:center;
  gap:10px;margin-top:16px;flex:none;
}
.tg-tool{
  border:1px solid #333;background:#1a1a1a;color:#ddd;border-radius:50%;
  width:40px;height:40px;padding:0;font:inherit;font-size:18px;cursor:pointer;
  display:inline-flex;align-items:center;justify-content:center;line-height:1;
}
.tg-tool:hover{border-color:#888;color:#fff;background:#222}
.tg-tool.is-active{border-color:#888;background:#2a2a2a;color:#fff}
.tg-hint{max-width:420px;text-align:center;margin:10px 0 0;font-size:12px;line-height:1.5;color:#888}
.tg-settings{
  display:none;padding:14px 16px;flex:none;
  background:#141414;border:1px solid #2a2a2a;border-radius:12px;color:#ddd;
  box-sizing:border-box;max-height:min(70vh,560px);overflow-y:auto;
}
.tg-settings.is-open{display:block}
.tg-app.is-fs .tg-hint{color:#666}
.tg-settings h3{margin:0 0 10px;font-size:14px;color:#fff;letter-spacing:.04em}
.tg-settings h4{margin:14px 0 6px;font-size:12px;color:#aaa;text-transform:uppercase;letter-spacing:.06em}
.tg-set-row{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:4px 0;font-size:13px}
.tg-set-row span{flex:1;min-width:0}
.tg-set-row button,.tg-set-row .tg-keycap{
  border:1px solid #333;background:#1e1e1e;color:#eee;border-radius:6px;
  padding:4px 10px;font:inherit;font-size:12px;cursor:pointer;min-width:64px;text-align:center;
}
.tg-set-row button:hover{border-color:#666}
.tg-set-row button.is-listen{border-color:#c45;background:#2a1518;color:#f88;animation:tg-pulse 1s infinite}
@keyframes tg-pulse{50%{opacity:.6}}
.tg-pal-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:4px}
.tg-pal-btn{
  border:2px solid transparent;border-radius:8px;padding:4px 10px;cursor:pointer;
  font:inherit;font-size:12px;font-weight:600;background:#1e1e1e;color:#ddd;
}
.tg-pal-btn.is-active{border-color:#aaa}
.tg-pal-swatch{display:inline-block;width:12px;height:12px;border-radius:2px;margin-right:4px;vertical-align:-1px}
.tg-set-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}
.tg-set-actions button{
  border:1px solid #333;background:#1e1e1e;color:#ddd;border-radius:8px;
  padding:6px 12px;font:inherit;font-size:12px;cursor:pointer;
}
.tg-set-actions button:hover{border-color:#666}
`;
}

export function createSpeeltoestelApp() {
  injectStyles();

  const root = el('div', 'app-panel tg-app');
  root.tabIndex = -1;
  const shell = el('div', 'tg-console');
  const bezel = el('div', 'tg-bezel');
  const led = el('div', 'tg-led');
  led.append(el('i'), el('small', '', 'AAN'));
  const canvas = document.createElement('canvas');
  canvas.className = 'tg-screen';
  canvas.width = SW;
  canvas.height = SH;
  canvas.setAttribute('aria-label', 'Speelscherm');
  bezel.append(led, canvas, el('p', 'tg-cap', 'PIXELSCHERM · 4 TINTEN'));

  const brand = el('div', 'tg-brand');
  brand.append(el('b', '', 'Leo Crucis'), el('span', '', 'SPEL'));

  const controls = el('div', 'tg-controls');
  const dpad = el('div', 'tg-dpad');
  const mkDp = (cls, name, glyph) => {
    const b = el('button', 'tg-dp ' + cls, glyph);
    b.type = 'button'; b.tabIndex = -1; b.dataset.k = name;
    b.setAttribute('aria-label', { left: 'Links', right: 'Rechts', down: 'Omlaag', up: 'Omhoog' }[name]);
    return b;
  };
  dpad.append(mkDp('u', 'up', '▲'), mkDp('l', 'left', '◀'), el('div', 'tg-dpc'), mkDp('r', 'right', '▶'), mkDp('d', 'down', '▼'));
  const ab = el('div', 'tg-ab');
  const bB = el('button', 'b'); bB.type = 'button'; bB.tabIndex = -1; bB.dataset.k = 'b'; bB.setAttribute('aria-label', 'B');
  const bA = el('button', 'a'); bA.type = 'button'; bA.tabIndex = -1; bA.dataset.k = 'a'; bA.setAttribute('aria-label', 'A');
  ab.append(bB, bA, el('em', 'lb', 'B'), el('em', 'la', 'A'));
  controls.append(dpad, ab);

  const meta = el('div', 'tg-meta');
  const mkPill = (label, name) => {
    const wrap = el('div', 'tg-pill');
    const b = el('button'); b.type = 'button'; b.tabIndex = -1; b.dataset.k = name; b.setAttribute('aria-label', label);
    wrap.append(b, el('span', '', label));
    meta.append(wrap);
  };
  mkPill('SELECT', 'select');
  mkPill('START', 'start');
  shell.append(bezel, brand, controls, meta, el('div', 'tg-grill'));

  const stage = el('div', 'tg-stage');
  const settings = el('div', 'tg-settings');
  settings.innerHTML = `
    <h3>Instellingen</h3>
    <h4>Schermkleur</h4>
    <div class="tg-pal-row" data-pal></div>
    <h4>Geluid</h4>
    <div class="tg-set-row"><span>Geluidseffecten</span><button type="button" data-snd></button></div>
    <h4>Toetsen</h4>
    <div data-keys></div>
    <div class="tg-set-actions">
      <button type="button" data-reset-keys>Standaardtoetsen</button>
      <button type="button" data-close-set>Sluiten</button>
    </div>
  `;
  stage.append(settings, shell);

  const bar = el('div', 'tg-bar');
  const btnSettings = el('button', 'tg-tool', '⚙'); btnSettings.type = 'button'; btnSettings.tabIndex = -1;
  btnSettings.setAttribute('aria-label', 'Instellingen'); btnSettings.title = 'Instellingen';
  const btnFs = el('button', 'tg-tool', '⛶'); btnFs.type = 'button'; btnFs.tabIndex = -1;
  btnFs.setAttribute('aria-label', 'Volledig scherm'); btnFs.title = 'Volledig scherm';
  bar.append(btnSettings, btnFs);
  const hint = el('p', 'tg-hint', '');
  root.append(stage, bar, hint);

  const ctx = canvas.getContext('2d');
  let palIdx = Math.max(0, PALETTES.findIndex(p => p.id === store.get(K_PAL, 'groen')));
  let tiles = {};
  let soundOn = store.get(K_SND, '0') === '1';
  let keybinds = loadKeybinds();
  let listenAction = null;
  let isFullscreen = false;

  // mode: menu | blokken | slang | race | muur
  let mode = 'menu';
  let menuIdx = 0;
  let blinkOn = true;
  let dirty = true, lastTs = 0, raf = 0;
  const held = { left: false, right: false, down: false, up: false };
  const das = { left: 0, right: 0, down: 0, up: 0 };

  // --- shared best scores ---
  let bestBlok = parseInt(store.get(K_BEST, '0'), 10) || 0;
  let bestSlang = parseInt(store.get(K_BEST_S, '0'), 10) || 0;
  let bestRace = parseInt(store.get(K_BEST_R, '0'), 10) || 0;
  let bestMuur = parseInt(store.get(K_BEST_M, '0'), 10) || 0;
  let bestDool = parseInt(store.get(K_BEST_D, '0'), 10) || 0;
  let bestFlap = parseInt(store.get(K_BEST_F, '0'), 10) || 0;
  let startLevel = Math.min(9, Math.max(0, parseInt(store.get(K_LEVEL, '0'), 10) || 0));

  // --- blokken state ---
  let bk = null;
  function emptyBoard() { return Array.from({ length: ROWS }, () => Array(COLS).fill(null)); }
  function initBlokken() {
    bk = {
      state: 'title', board: emptyBoard(), cur: null, nextType: null, prevType: -1,
      score: 0, lines: 0, level: startLevel, acc: 0, clearT: 0, dieT: 0, clearRows: [],
      downBlocked: false
    };
  }

  // --- slang state ---
  let sn = null;
  function initSlang() {
    sn = {
      state: 'title', // title | play | pause | over
      body: [{ x: 5, y: 9 }, { x: 4, y: 9 }, { x: 3, y: 9 }],
      dir: { x: 1, y: 0 }, nextDir: { x: 1, y: 0 },
      food: { x: 10, y: 9 }, score: 0, acc: 0, stepMs: 140
    };
    placeFood();
  }
  function placeFood() {
    if (!sn) return;
    for (let n = 0; n < 200; n++) {
      const x = 1 + Math.floor(Math.random() * 18);
      const y = 1 + Math.floor(Math.random() * 16);
      if (!sn.body.some(s => s.x === x && s.y === y)) { sn.food = { x, y }; return; }
    }
  }

  // --- race state ---
  let rc = null;
  function initRace() {
    rc = {
      state: 'title', // title | play | pause | over
      carX: 2, lanes: [], score: 0, acc: 0, spawnAcc: 0, speed: 2.2, laneW: 3
    };
  }

  // --- muur (breakout) state ---
  let mw = null;
  function initMuur() {
    mw = {
      state: 'title',
      px: 60, py: 130, pw: 28, ph: 4,
      bx: 80, by: 100, bvx: 0.7, bvy: -0.85, br: 2,
      bricks: [], score: 0, lives: 3, acc: 0
    };
    resetBricks();
  }
  function resetBricks() {
    mw.bricks = [];
    for (let r = 0; r < 4; r++) for (let c = 0; c < 8; c++) {
      mw.bricks.push({ x: 8 + c * 18, y: 16 + r * 10, w: 16, h: 8, alive: true, shade: 1 + (r % 3) });
    }
  }

  function loadKeybinds() {
    try {
      const raw = store.get(K_KEYS, '');
      if (raw) {
        const o = JSON.parse(raw);
        const out = {};
        Object.keys(DEFAULT_KEYS).forEach(k => {
          out[k] = Array.isArray(o[k]) && o[k].length ? o[k].map(String) : DEFAULT_KEYS[k].slice();
        });
        return out;
      }
    } catch (_) {}
    return Object.fromEntries(Object.entries(DEFAULT_KEYS).map(([k, v]) => [k, v.slice()]));
  }
  function saveKeybinds() { store.set(K_KEYS, JSON.stringify(keybinds)); }
  function prettyKey(k) {
    if (k === ' ') return 'Spatie';
    if (k === 'ArrowLeft') return '←';
    if (k === 'ArrowRight') return '→';
    if (k === 'ArrowUp') return '↑';
    if (k === 'ArrowDown') return '↓';
    if (k === 'Escape') return 'Esc';
    if (k === 'Enter') return 'Enter';
    return k.length === 1 ? k.toUpperCase() : k;
  }
  function keyName(e) {
    const raw = e.key;
    const k = raw && raw.length === 1 ? raw.toLowerCase() : raw;
    for (const [action, keys] of Object.entries(keybinds)) {
      if (keys.some(x => x === k || x === raw || (x.length === 1 && x.toLowerCase() === k))) return action;
    }
    return null;
  }

  // --- audio ---
  let ac = null;
  function ensureAudio() {
    if (!soundOn) return;
    if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (_) { ac = null; } }
    if (ac && ac.state === 'suspended') { try { ac.resume(); } catch (_) {} }
  }
  function tone(freq, dur, when = 0, vol = 0.035) {
    if (!soundOn || !ac) return;
    try {
      const t = ac.currentTime + when;
      const o = ac.createOscillator(), g = ac.createGain();
      o.type = 'square';
      o.frequency.setValueAtTime(freq, t);
      g.gain.setValueAtTime(vol, t);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(ac.destination);
      o.start(t); o.stop(t + dur + 0.02);
    } catch (_) {}
  }
  const sfx = {
    move: () => tone(196, 0.04),
    rotate: () => tone(392, 0.06),
    lock: () => tone(98, 0.09),
    line: n => [523, 659, 784, 1047].slice(0, Math.max(2, n)).forEach((f, i) => tone(f, 0.12, i * 0.08)),
    level: () => [659, 784, 988, 1319].forEach((f, i) => tone(f, 0.1, i * 0.07)),
    over: () => [392, 330, 262, 196].forEach((f, i) => tone(f, 0.28, i * 0.2)),
    start: () => [523, 784].forEach((f, i) => tone(f, 0.1, i * 0.09)),
    eat: () => tone(660, 0.08),
    hit: () => tone(220, 0.1),
    point: () => tone(880, 0.05)
  };

  // --- draw helpers ---
  const C = () => PALETTES[palIdx].c;
  function R(x, y, w, h, s) { ctx.fillStyle = C()[s]; ctx.fillRect(x, y, w, h); }
  function T(name, x, y) { ctx.drawImage(tiles[name], x, y); }
  const textW = (s, sc = 1) => s.length * 6 * sc - sc;
  function text(str, x, y, shade, sc = 1) {
    ctx.fillStyle = C()[shade];
    let cx = x;
    for (const ch of String(str).toUpperCase()) {
      const g = GLYPHS[ch];
      if (g) for (let r = 0; r < 7; r++) for (let b = 0; b < 5; b++) {
        if (g[r] & (1 << (4 - b))) ctx.fillRect(cx + b * sc, y + r * sc, sc, sc);
      }
      cx += 6 * sc;
    }
  }
  const textC = (str, cx, y, shade, sc = 1) => text(str, Math.round(cx - textW(str, sc) / 2), y, shade, sc);
  const pad = (n, w) => String(n).padStart(w, '0');

  function drawBox(lns) {
    const gap = 6;
    const w = Math.max(...lns.map(l => textW(l.t, l.sc || 1))) + 16;
    const h = lns.reduce((a, l) => a + 7 * (l.sc || 1), 0) + gap * (lns.length - 1) + 16;
    const x = Math.round(SW / 2 - w / 2), y = Math.round(SH / 2 - h / 2);
    R(x, y, w, h, 3);
    R(x + 2, y + 2, w - 4, h - 4, 0);
    let ty = y + 8;
    lns.forEach(l => {
      if (!l.blink || blinkOn) textC(l.t, SW / 2, ty, 3, l.sc || 1);
      ty += 7 * (l.sc || 1) + gap;
    });
  }

  function buildTiles() {
    const c = PALETTES[palIdx].c;
    tiles = {};
    Object.keys(TILE_FN).forEach(k => {
      const t = document.createElement('canvas');
      t.width = t.height = CS;
      const tc = t.getContext('2d');
      for (let y = 0; y < CS; y++) for (let x = 0; x < CS; x++) {
        tc.fillStyle = c[TILE_FN[k](x, y)];
        tc.fillRect(x, y, 1, 1);
      }
      tiles[k] = t;
    });
    canvas.style.background = c[0];
    dirty = true;
    renderPalButtons();
  }
  function updateSndBtn() {
    const b = settings.querySelector('[data-snd]');
    if (b) b.textContent = soundOn ? 'Aan' : 'Uit';
  }
  function updateHint() {
    const g = action => (keybinds[action] || []).map(prettyKey).join(' / ') || '—';
    hint.textContent =
      g('left') + ' · ' + g('right') + ' bewegen · ' + g('up') + ' · ' + g('down') +
      ' · ' + g('a') + ' / ' + g('start') + ' = start · ' + g('pause') + ' = menu';
  }
  function renderPalButtons() {
    const row = settings.querySelector('[data-pal]');
    if (!row) return;
    row.replaceChildren();
    PALETTES.forEach((p, i) => {
      const b = el('button', 'tg-pal-btn' + (i === palIdx ? ' is-active' : ''));
      b.type = 'button';
      const sw = el('span', 'tg-pal-swatch');
      sw.style.background = p.c[1];
      b.append(sw, document.createTextNode(p.name));
      b.onclick = () => { palIdx = i; store.set(K_PAL, p.id); buildTiles(); };
      row.append(b);
    });
  }
  function renderKeyRows() {
    const host = settings.querySelector('[data-keys]');
    if (!host) return;
    host.replaceChildren();
    Object.keys(KEY_LABELS).forEach(action => {
      const row = el('div', 'tg-set-row');
      row.append(el('span', '', KEY_LABELS[action]));
      const btn = el('button', '', (keybinds[action] || []).map(prettyKey).join(' · ') || '—');
      btn.type = 'button'; btn.dataset.action = action;
      btn.onclick = () => startListen(action, btn);
      row.append(btn);
      host.append(row);
    });
  }
  function startListen(action, btn) {
    listenAction = action;
    settings.querySelectorAll('[data-action]').forEach(b => b.classList.remove('is-listen'));
    btn.classList.add('is-listen');
    btn.textContent = 'Druk een toets…';
  }
  function finishListen(key) {
    if (!listenAction) return;
    const action = listenAction;
    Object.keys(keybinds).forEach(a => {
      keybinds[a] = (keybinds[a] || []).filter(k => k !== key && (typeof k.toLowerCase !== 'function' || k.toLowerCase() !== key.toLowerCase()));
    });
    keybinds[action] = [key];
    saveKeybinds();
    listenAction = null;
    renderKeyRows();
    updateHint();
  }
  function toggleSettings() {
    const open = !settings.classList.contains('is-open');
    settings.classList.toggle('is-open', open);
    btnSettings.classList.toggle('is-active', open);
    if (open) { renderPalButtons(); renderKeyRows(); updateSndBtn(); listenAction = null; }
  }
  function toggleFullscreen() {
    isFullscreen = !isFullscreen;
    root.classList.toggle('is-fs', isFullscreen);
    document.body.classList.toggle('tg-tetris-fs', isFullscreen);
    btnFs.classList.toggle('is-active', isFullscreen);
    btnFs.title = isFullscreen ? 'Volledig scherm verlaten' : 'Volledig scherm';
    btnFs.setAttribute('aria-label', btnFs.title);
  }

  // ========== MENU ==========
  function drawMenu() {
    R(0, 0, SW, SH, 0);
    for (let x = 0; x < SW; x += CS) { T('B', x, 0); T('B', x, SH - CS); }
    for (let y = 0; y < SH; y += CS) { T('B', 0, y); T('B', SW - CS, y); }
    textC('SPEL', SW / 2, 14, 3, 2);
    R(40, 32, 80, 2, 3);
    GAMES.forEach((g, i) => {
      const y = 38 + i * 14;
      const sel = i === menuIdx;
      if (sel) R(22, y - 2, 116, 12, 1);
      textC((sel ? '>' : ' ') + g.name + (sel ? '<' : ''), SW / 2, y, 3);
    });
    if (blinkOn) textC('START', SW / 2, 128, 2);
  }

  function openGame(id) {
    mode = id;
    if (id === 'blokken') { initBlokken(); }
    else if (id === 'slang') { initSlang(); }
    else if (id === 'race') { initRace(); }
    else if (id === 'muur') { initMuur(); }
    else if (id === 'doolhof') { initDoolhof(); }
    else if (id === 'flap') { initFlap(); }
    sfx.start();
    dirty = true;
  }
  function backToMenu() {
    mode = 'menu';
    Object.keys(held).forEach(k => { held[k] = false; });
    dirty = true;
  }

  // ========== BLOKKEN ==========
  function bkCollides(m, px, py) {
    for (let y = 0; y < m.length; y++) for (let x = 0; x < m.length; x++) {
      if (!m[y][x]) continue;
      const nx = px + x, ny = py + y;
      if (nx < 0 || nx >= COLS || ny >= ROWS) return true;
      if (ny >= 0 && bk.board[ny][nx]) return true;
    }
    return false;
  }
  function bkRandom() {
    let i = Math.floor(Math.random() * 7);
    if (i === bk.prevType) i = Math.floor(Math.random() * 7);
    bk.prevType = i;
    return TYPES[i];
  }
  function bkMake(t) {
    const m = SHAPES[t].map(r => r.slice());
    const top = m.findIndex(r => r.some(Boolean));
    return { t, m, x: Math.floor((COLS - m.length) / 2), y: -top };
  }
  function bkSpawn() {
    bk.cur = bkMake(bk.nextType);
    bk.nextType = bkRandom();
    bk.acc = 0;
    if (bkCollides(bk.cur.m, bk.cur.x, bk.cur.y)) bkStartDying();
    dirty = true;
  }
  function bkNewGame() {
    bk.board = emptyBoard();
    bk.score = 0; bk.lines = 0; bk.level = startLevel;
    bk.prevType = -1; bk.nextType = bkRandom();
    bk.state = 'play';
    bk.downBlocked = held.down;
    sfx.start();
    bkSpawn();
  }
  function bkMove(dx) {
    if (bk.state !== 'play') return;
    if (!bkCollides(bk.cur.m, bk.cur.x + dx, bk.cur.y)) { bk.cur.x += dx; sfx.move(); dirty = true; }
  }
  function bkRotate(dir) {
    if (bk.state !== 'play' || bk.cur.t === 'O') return;
    const m = dir > 0 ? rot(bk.cur.m) : rot(rot(rot(bk.cur.m)));
    const kicks = bk.cur.t === 'I' ? [0, -1, 1, -2, 2] : [0, -1, 1];
    for (const dx of kicks) {
      if (!bkCollides(m, bk.cur.x + dx, bk.cur.y)) { bk.cur.m = m; bk.cur.x += dx; sfx.rotate(); dirty = true; return; }
    }
  }
  function bkStepDown(soft) {
    if (!bkCollides(bk.cur.m, bk.cur.x, bk.cur.y + 1)) {
      bk.cur.y++;
      if (soft) bk.score += 1;
      bk.acc = 0;
      dirty = true;
    } else {
      if (soft) bk.downBlocked = true;
      bkLock();
    }
  }
  function bkHardDrop() {
    if (bk.state !== 'play') return;
    let n = 0;
    while (!bkCollides(bk.cur.m, bk.cur.x, bk.cur.y + 1)) { bk.cur.y++; n++; }
    bk.score += n;
    bk.downBlocked = true;
    bkLock();
  }
  function bkLock() {
    bk.cur.m.forEach((row, y) => row.forEach((v, x) => {
      const by = bk.cur.y + y, bx = bk.cur.x + x;
      if (v && by >= 0 && by < ROWS) bk.board[by][bx] = bk.cur.t;
    }));
    const full = [];
    for (let y = 0; y < ROWS; y++) if (bk.board[y].every(Boolean)) full.push(y);
    bk.cur = null;
    if (full.length) {
      bk.state = 'clear'; bk.clearRows = full; bk.clearT = 0; sfx.line(full.length);
    } else { sfx.lock(); bkSpawn(); }
    dirty = true;
  }
  function bkFinishClear() {
    const n = bk.clearRows.length;
    bk.clearRows.slice().sort((a, b) => b - a).forEach(y => { bk.board.splice(y, 1); });
    for (let i = 0; i < n; i++) bk.board.unshift(Array(COLS).fill(null));
    const oldLevel = bk.level;
    bk.score += LINE_POINTS[n] * (bk.level + 1);
    bk.lines += n;
    bk.level = Math.min(29, startLevel + Math.floor(bk.lines / 10));
    if (bk.level > oldLevel) sfx.level();
    if (bk.score > bestBlok) { bestBlok = bk.score; store.set(K_BEST, bestBlok); }
    bk.clearRows = [];
    bk.state = 'play';
    bkSpawn();
  }
  function bkStartDying() {
    bk.state = 'dying'; bk.dieT = 0; bk.cur = null;
    if (bk.score > bestBlok) { bestBlok = bk.score; store.set(K_BEST, bestBlok); }
    sfx.over(); dirty = true;
  }
  function drawBlokken() {
    if (bk.state === 'title') {
      R(0, 0, SW, SH, 0);
      for (let x = 0; x < SW; x += CS) { T('B', x, 0); T('B', x, SH - CS); }
      for (let y = 0; y < SH; y += CS) { T('B', 0, y); T('B', SW - CS, y); }
      textC('BLOKKEN', SW / 2, 22, 3, 2);
      R(30, 42, 100, 2, 3);
      textC('NIVEAU', SW / 2, 52, 3);
      textC(String(startLevel), SW / 2, 66, 3, 2);
      text('<', 50, 68, 3); text('>', 102, 68, 3);
      textC('TOP ' + pad(bestBlok, 6), SW / 2, 96, 2);
      if (blinkOn) textC('DRUK START', SW / 2, 118, 3);
      return;
    }
    for (let r = 0; r < ROWS; r++) { T('B', 0, r * CS); T('B', FX + COLS * CS, r * CS); }
    R(FX, 0, COLS * CS, SH, 0);
    if (bk.state !== 'pause') {
      const hideRows = bk.state === 'clear' && Math.floor(bk.clearT / 112) % 2 === 1 ? bk.clearRows : [];
      for (let y = 0; y < ROWS; y++) {
        if (hideRows.includes(y)) continue;
        for (let x = 0; x < COLS; x++) if (bk.board[y][x]) T(bk.board[y][x], FX + x * CS, y * CS);
      }
      if (bk.cur && bk.state === 'play') {
        bk.cur.m.forEach((row, y) => row.forEach((v, x) => {
          if (v && bk.cur.y + y >= 0) T(bk.cur.t, FX + (bk.cur.x + x) * CS, (bk.cur.y + y) * CS);
        }));
      }
      if (bk.state === 'dying' || bk.state === 'over') {
        const n = bk.state === 'over' ? ROWS : Math.min(ROWS, Math.floor(bk.dieT / DIE_STEP));
        for (let i = 0; i < n; i++) for (let x = 0; x < COLS; x++) T('X', FX + x * CS, (ROWS - 1 - i) * CS);
      }
    }
    R(PX, 0, SW - PX, SH, 1);
    const x = 101;
    text('SCORE', x, 5, 3); text(pad(bk.score, 6), x, 14, 3);
    text('NIVEAU', x, 28, 3); text(pad(bk.level, 2), x, 37, 3);
    text('LIJNEN', x, 51, 3); text(pad(bk.lines, 3), x, 60, 3);
    text('TOP', x, 74, 3); text(pad(bestBlok, 6), x, 83, 3);
    text('VOLGEND', x, 96, 3);
    R(104, 105, 48, 28, 3); R(106, 107, 44, 24, 0);
    if (bk.nextType) {
      const m = SHAPES[bk.nextType];
      const rows = m.map((r, i) => r.some(Boolean) ? i : -1).filter(i => i >= 0);
      const top = rows[0], h = rows.length, w = m.length;
      const ox = 106 + Math.round((44 - w * CS) / 2);
      const oy = 107 + Math.round((24 - h * CS) / 2);
      m.forEach((row, y) => row.forEach((v, xx) => { if (v) T(bk.nextType, ox + xx * CS, oy + (y - top) * CS); }));
    }
    if (bk.state === 'pause') drawBox([{ t: 'PAUZE', sc: 2 }]);
    if (bk.state === 'over') drawBox([{ t: 'GAME OVER' }, { t: 'START', blink: true }]);
  }
  function updateBlokken(dt) {
    if (bk.state === 'play') {
      bk.acc += dt;
      const iv = gravityMs(bk.level);
      let guard = 0;
      while (bk.acc >= iv && bk.state === 'play' && guard++ < 5) { bk.acc -= iv; bkStepDown(false); }
    } else if (bk.state === 'clear') {
      bk.clearT += dt; dirty = true;
      if (bk.clearT >= CLEAR_MS) bkFinishClear();
    } else if (bk.state === 'dying') {
      bk.dieT += dt; dirty = true;
      if (bk.dieT >= ROWS * DIE_STEP + 450) { bk.state = 'over'; dirty = true; }
    }
  }

  // ========== SLANG ==========
  function drawSlang() {
    R(0, 0, SW, SH, 0);
    // border
    R(0, 0, SW, 8, 3); R(0, SH - 8, SW, 8, 3); R(0, 0, 8, SH, 3); R(SW - 8, 0, 8, SH, 3);
    if (sn.state === 'title') {
      textC('SLANG', SW / 2, 40, 3, 2);
      textC('TOP ' + pad(bestSlang, 4), SW / 2, 70, 2);
      if (blinkOn) textC('DRUK START', SW / 2, 100, 3);
      return;
    }
    // grid play area 18x16 cells of 8px starting at 8,8
    sn.body.forEach((s, i) => {
      R(s.x * 8, s.y * 8, 8, 8, i === 0 ? 3 : 2);
    });
    R(sn.food.x * 8, sn.food.y * 8, 8, 8, 1);
    text(pad(sn.score, 4), 12, 1, 0);
    if (sn.state === 'pause') drawBox([{ t: 'PAUZE', sc: 2 }]);
    if (sn.state === 'over') drawBox([{ t: 'GAME OVER' }, { t: 'START', blink: true }]);
  }
  function updateSlang(dt) {
    if (sn.state !== 'play') return;
    sn.acc += dt;
    while (sn.acc >= sn.stepMs) {
      sn.acc -= sn.stepMs;
      sn.dir = { ...sn.nextDir };
      const head = sn.body[0];
      const nx = head.x + sn.dir.x, ny = head.y + sn.dir.y;
      if (nx < 1 || nx > 18 || ny < 1 || ny > 16 || sn.body.some(s => s.x === nx && s.y === ny)) {
        sn.state = 'over';
        if (sn.score > bestSlang) { bestSlang = sn.score; store.set(K_BEST_S, bestSlang); }
        sfx.over(); dirty = true; return;
      }
      sn.body.unshift({ x: nx, y: ny });
      if (nx === sn.food.x && ny === sn.food.y) {
        sn.score++; sfx.eat();
        if (sn.score % 5 === 0) sn.stepMs = Math.max(70, sn.stepMs - 8);
        placeFood();
      } else sn.body.pop();
      dirty = true;
    }
  }
  function snStart() {
    sn.body = [{ x: 5, y: 9 }, { x: 4, y: 9 }, { x: 3, y: 9 }];
    sn.dir = { x: 1, y: 0 }; sn.nextDir = { x: 1, y: 0 };
    sn.score = 0; sn.acc = 0; sn.stepMs = 140; sn.state = 'play';
    placeFood(); sfx.start(); dirty = true;
  }

  // ========== RACE ==========
  function drawRace() {
    R(0, 0, SW, SH, 0);
    // road
    R(40, 0, 80, SH, 1);
    // lane marks
    for (let y = 0; y < SH; y += 12) R(78, y, 4, 6, 0);
    if (rc.state === 'title') {
      R(0, 0, SW, SH, 0);
      textC('RACE', SW / 2, 40, 3, 2);
      textC('TOP ' + pad(bestRace, 4), SW / 2, 70, 2);
      if (blinkOn) textC('DRUK START', SW / 2, 100, 3);
      return;
    }
    // player car (3 lanes: 0,1,2)
    const px = 48 + rc.carX * 24;
    R(px, 112, 16, 24, 3);
    R(px + 2, 116, 12, 8, 2);
    rc.cars.forEach(c => {
      const cx = 48 + c.lane * 24;
      R(cx, c.y, 16, 24, 2);
      R(cx + 2, c.y + 4, 12, 8, 3);
    });
    text(pad(rc.score, 4), 4, 4, 3);
    if (rc.state === 'pause') drawBox([{ t: 'PAUZE', sc: 2 }]);
    if (rc.state === 'over') drawBox([{ t: 'GAME OVER' }, { t: 'START', blink: true }]);
  }
  function updateRace(dt) {
    if (rc.state !== 'play') return;
    rc.acc += dt;
    const step = 16;
    while (rc.acc >= step) {
      rc.acc -= step;
      rc.score++;
      if (rc.score > bestRace) { bestRace = rc.score; store.set(K_BEST_R, bestRace); }
      rc.spawnAcc++;
      if (rc.spawnAcc > 20 + Math.random() * 15) {
        rc.spawnAcc = 0;
        let lane = Math.floor(Math.random() * 3);
        // avoid same lane as last
        rc.cars.push({ lane, y: -28 });
      }
      rc.cars.forEach(c => { c.y += rc.speed + Math.min(3, rc.score / 200); });
      rc.cars = rc.cars.filter(c => c.y < SH + 30);
      // collision
      for (const c of rc.cars) {
        if (c.lane === rc.carX && c.y > 90 && c.y < 136) {
          rc.state = 'over'; sfx.over(); dirty = true; return;
        }
      }
      if (rc.score % 100 === 0) rc.speed = Math.min(5, rc.speed + 0.15);
      dirty = true;
    }
  }
  function raceStart() {
    rc.carX = 1; rc.cars = []; rc.score = 0; rc.acc = 0; rc.spawnAcc = 0; rc.speed = 2.2;
    rc.state = 'play'; sfx.start(); dirty = true;
  }

  // ========== MUUR ==========
  function drawMuur() {
    R(0, 0, SW, SH, 0);
    if (mw.state === 'title') {
      textC('MUUR', SW / 2, 40, 3, 2);
      textC('TOP ' + pad(bestMuur, 4), SW / 2, 70, 2);
      if (blinkOn) textC('DRUK START', SW / 2, 100, 3);
      return;
    }
    mw.bricks.forEach(b => {
      if (!b.alive) return;
      R(b.x, b.y, b.w, b.h, b.shade);
      R(b.x + 1, b.y + 1, b.w - 2, b.h - 2, 0);
    });
    R(mw.px, mw.py, mw.pw, mw.ph, 3);
    R(Math.round(mw.bx - mw.br), Math.round(mw.by - mw.br), mw.br * 2, mw.br * 2, 2);
    text(pad(mw.score, 4), 4, 4, 3);
    text('x' + mw.lives, SW - 24, 4, 3);
    if (mw.state === 'pause') drawBox([{ t: 'PAUZE', sc: 2 }]);
    if (mw.state === 'over') drawBox([{ t: 'GAME OVER' }, { t: 'START', blink: true }]);
    if (mw.state === 'win') drawBox([{ t: 'KLAAR!' }, { t: 'START', blink: true }]);
  }
  function updateMuur(dt) {
    if (mw.state !== 'play') return;
    // paddle move via held
    if (held.left) mw.px = Math.max(4, mw.px - 2.4);
    if (held.right) mw.px = Math.min(SW - mw.pw - 4, mw.px + 2.4);
    mw.bx += mw.bvx; mw.by += mw.bvy;
    if (mw.bx < mw.br || mw.bx > SW - mw.br) { mw.bvx *= -1; mw.bx = Math.max(mw.br, Math.min(SW - mw.br, mw.bx)); sfx.hit(); }
    if (mw.by < mw.br) { mw.bvy = Math.abs(mw.bvy); sfx.hit(); }
    // paddle
    if (mw.bvy > 0 && mw.by + mw.br >= mw.py && mw.by - mw.br <= mw.py + mw.ph &&
        mw.bx >= mw.px - 2 && mw.bx <= mw.px + mw.pw + 2) {
      mw.bvy = -Math.abs(mw.bvy);
      const hit = (mw.bx - (mw.px + mw.pw / 2)) / (mw.pw / 2);
      mw.bvx = hit * 1.5;
      sfx.hit();
    }
    // bricks
    for (const b of mw.bricks) {
      if (!b.alive) continue;
      if (mw.bx + mw.br > b.x && mw.bx - mw.br < b.x + b.w &&
          mw.by + mw.br > b.y && mw.by - mw.br < b.y + b.h) {
        b.alive = false;
        mw.score += 10;
        if (mw.score > bestMuur) { bestMuur = mw.score; store.set(K_BEST_M, bestMuur); }
        sfx.point();
        // bounce
        const overlapX = Math.min(mw.bx + mw.br - b.x, b.x + b.w - (mw.bx - mw.br));
        const overlapY = Math.min(mw.by + mw.br - b.y, b.y + b.h - (mw.by - mw.br));
        if (overlapX < overlapY) mw.bvx *= -1; else mw.bvy *= -1;
        break;
      }
    }
    if (mw.bricks.every(b => !b.alive)) { mw.state = 'win'; sfx.level(); dirty = true; return; }
    if (mw.by > SH + 10) {
      mw.lives--;
      if (mw.lives <= 0) { mw.state = 'over'; sfx.over(); }
      else {
        mw.bx = 80; mw.by = 100; mw.bvx = 0.7 * (Math.random() < 0.5 ? 1 : -1); mw.bvy = -0.85;
        mw.px = 60; sfx.hit();
      }
    }
    dirty = true;
  }
  function muurStart() {
    mw.px = 60; mw.bx = 80; mw.by = 100; mw.bvx = 0.7; mw.bvy = -0.85;
    mw.score = 0; mw.lives = 3; mw.state = 'play';
    resetBricks(); sfx.start(); dirty = true;
  }

  // ========== DOOLHOF (pac-achtig, eigen naam) ==========
  // Eenvoudig doolhof: eet alle stippen, ontwijk spoken.
  let dh = null;
  const DH_W = 19, DH_H = 15, DH_CS = 8;
  // 1 = muur, 0 = pad met stip, 2 = pad leeg, 3 = power
  function dhDefaultMaze() {
    const rows = [
      '1111111111111111111',
      '1000000001000000001',
      '1011110101010111101',
      '1000000000000000001',
      '1011011110111101101',
      '1001000000000001001',
      '1111010111110101111',
      '0000010100000100000',
      '1111010111110101111',
      '1001000000000001001',
      '1011011110111101101',
      '1000000000000000001',
      '1011110101010111101',
      '1000000001000000001',
      '1111111111111111111'
    ];
    return rows.map(r => r.split('').map(c => +c));
  }
  function initDoolhof() {
    const maze = dhDefaultMaze();
    let dots = 0;
    for (let y = 0; y < DH_H; y++) for (let x = 0; x < DH_W; x++) if (maze[y][x] === 0) dots++;
    dh = {
      state: 'title',
      maze, dots, eaten: 0, score: 0,
      px: 9, py: 11, pDir: { x: 0, y: 0 }, nextDir: { x: 0, y: 0 },
      ghosts: [
        { x: 9, y: 7, dir: { x: 1, y: 0 }, color: 2 },
        { x: 8, y: 7, dir: { x: -1, y: 0 }, color: 3 }
      ],
      acc: 0, stepMs: 140, gAcc: 0
    };
  }
  function dhCan(x, y) {
    if (y < 0 || y >= DH_H) return false;
    // tunnel
    if (x < 0 || x >= DH_W) return y === 7;
    return dh.maze[y][x] !== 1;
  }
  function dhStart() {
    initDoolhof();
    dh.state = 'play';
    sfx.start(); dirty = true;
  }
  function drawDoolhof() {
    R(0, 0, SW, SH, 0);
    if (dh.state === 'title') {
      textC('DOOLHOF', SW / 2, 36, 3, 2);
      textC('TOP ' + pad(bestDool, 4), SW / 2, 70, 2);
      if (blinkOn) textC('DRUK START', SW / 2, 100, 3);
      return;
    }
    const ox = 4, oy = 8;
    for (let y = 0; y < DH_H; y++) for (let x = 0; x < DH_W; x++) {
      const c = dh.maze[y][x];
      const px = ox + x * DH_CS, py = oy + y * DH_CS;
      if (c === 1) R(px, py, DH_CS, DH_CS, 3);
      else if (c === 0) {
        R(px + 3, py + 3, 2, 2, 1);
      }
    }
    // speler: lichte ronde bol met "mond" (duidelijk anders dan spoken)
    {
      const px = ox + dh.px * DH_CS, py = oy + dh.py * DH_CS;
      R(px + 1, py + 1, 6, 6, 1);
      R(px + 2, py, 4, 8, 1);
      R(px, py + 2, 8, 4, 1);
      // mond-opening in de kijkrichting
      const dx = dh.pDir.x || dh.nextDir.x, dy = dh.pDir.y || dh.nextDir.y;
      if (dx > 0) R(px + 5, py + 3, 3, 2, 0);
      else if (dx < 0) R(px, py + 3, 3, 2, 0);
      else if (dy > 0) R(px + 3, py + 5, 2, 3, 0);
      else if (dy < 0) R(px + 3, py, 2, 3, 0);
      else R(px + 5, py + 3, 3, 2, 0);
      // oog
      R(px + 3, py + 2, 2, 2, 3);
    }
    // spoken: donker lichaam + witte ogen (herkenbaar als vijand)
    dh.ghosts.forEach(g => {
      const gx = ox + g.x * DH_CS, gy = oy + g.y * DH_CS;
      R(gx + 1, gy + 1, 6, 5, 3);
      R(gx, gy + 2, 8, 4, 3);
      // golvende onderkant
      R(gx + 1, gy + 6, 2, 2, 3);
      R(gx + 4, gy + 6, 2, 2, 3);
      // ogen
      R(gx + 2, gy + 2, 2, 2, 0);
      R(gx + 5, gy + 2, 2, 2, 0);
      R(gx + 2, gy + 3, 1, 1, 3);
      R(gx + 5, gy + 3, 1, 1, 3);
    });
    text(pad(dh.score, 4), 4, 1, 3);
    if (dh.state === 'pause') drawBox([{ t: 'PAUZE', sc: 2 }]);
    if (dh.state === 'over') drawBox([{ t: 'GAME OVER' }, { t: 'START', blink: true }]);
    if (dh.state === 'win') drawBox([{ t: 'KLAAR!' }, { t: 'START', blink: true }]);
  }
  function dhMoveGhost(g) {
    const opts = [];
    [[1,0],[-1,0],[0,1],[0,-1]].forEach(([dx, dy]) => {
      if (dx === -g.dir.x && dy === -g.dir.y && opts.length) return; // prefer not reverse
      const nx = g.x + dx, ny = g.y + dy;
      if (dhCan(nx, ny)) opts.push({ x: dx, y: dy });
    });
    if (!opts.length) {
      [[1,0],[-1,0],[0,1],[0,-1]].forEach(([dx, dy]) => {
        if (dhCan(g.x + dx, g.y + dy)) opts.push({ x: dx, y: dy });
      });
    }
    if (opts.length) {
      // bias toward player
      opts.sort((a, b) => {
        const da = Math.abs(g.x + a.x - dh.px) + Math.abs(g.y + a.y - dh.py);
        const db = Math.abs(g.x + b.x - dh.px) + Math.abs(g.y + b.y - dh.py);
        return da - db;
      });
      const pick = Math.random() < 0.7 ? opts[0] : opts[Math.floor(Math.random() * opts.length)];
      g.dir = pick;
    }
    let nx = g.x + g.dir.x, ny = g.y + g.dir.y;
    if (nx < 0) nx = DH_W - 1;
    if (nx >= DH_W) nx = 0;
    if (dhCan(nx, ny)) { g.x = nx; g.y = ny; }
  }
  function updateDoolhof(dt) {
    if (dh.state !== 'play') return;
    dh.acc += dt;
    while (dh.acc >= dh.stepMs) {
      dh.acc -= dh.stepMs;
      // try nextDir
      const nd = dh.nextDir;
      if (nd.x || nd.y) {
        const tx = dh.px + nd.x, ty = dh.py + nd.y;
        if (dhCan(tx, ty)) dh.pDir = { ...nd };
      }
      let nx = dh.px + dh.pDir.x, ny = dh.py + dh.pDir.y;
      if (nx < 0) nx = DH_W - 1;
      if (nx >= DH_W) nx = 0;
      if (dhCan(nx, ny)) { dh.px = nx; dh.py = ny; }
      // eat
      if (dh.maze[dh.py] && dh.maze[dh.py][dh.px] === 0) {
        dh.maze[dh.py][dh.px] = 2;
        dh.eaten++; dh.score += 10;
        if (dh.score > bestDool) { bestDool = dh.score; store.set(K_BEST_D, bestDool); }
        sfx.eat();
        if (dh.eaten >= dh.dots) { dh.state = 'win'; sfx.level(); dirty = true; return; }
      }
      // ghosts
      dh.ghosts.forEach(dhMoveGhost);
      for (const g of dh.ghosts) {
        if (g.x === dh.px && g.y === dh.py) {
          dh.state = 'over'; sfx.over(); dirty = true; return;
        }
      }
      dirty = true;
    }
  }

  // ========== FLAP (flappy-achtig, eigen naam) ==========
  let fl = null;
  function initFlap() {
    fl = {
      state: 'title',
      y: 72, vy: 0, score: 0, acc: 0,
      pipes: [], spawnAcc: 0,
      gap: 48, grav: 0.055, flapV: -1.55,
      pipeSpeed: 0.75, grace: 0
    };
  }
  function flapStart() {
    fl.y = 72; fl.vy = -0.4; fl.score = 0; fl.acc = 0;
    fl.pipes = []; fl.spawnAcc = 0; fl.state = 'play';
    fl.grace = 2000; // eerste 2 seconden: geen val-dood / geen botsing
    sfx.start(); dirty = true;
  }
  function drawFlap() {
    R(0, 0, SW, SH, 0);
    if (fl.state === 'title') {
      textC('FLAP', SW / 2, 40, 3, 2);
      textC('TOP ' + pad(bestFlap, 4), SW / 2, 70, 2);
      if (blinkOn) textC('DRUK A', SW / 2, 100, 3);
      return;
    }
    // pipes
    fl.pipes.forEach(p => {
      R(p.x, 0, 16, p.gapY, 3);
      R(p.x, p.gapY + fl.gap, 16, SH - (p.gapY + fl.gap), 3);
      R(p.x + 1, 0, 14, p.gapY, 2);
      R(p.x + 1, p.gapY + fl.gap, 14, SH - (p.gapY + fl.gap), 2);
    });
    // bird
    R(36, Math.round(fl.y), 10, 8, 2);
    R(38, Math.round(fl.y) + 2, 4, 3, 3);
    text(pad(fl.score, 3), 4, 4, 3);
    if (fl.state === 'pause') drawBox([{ t: 'PAUZE', sc: 2 }]);
    if (fl.state === 'over') drawBox([{ t: 'GAME OVER' }, { t: 'START', blink: true }]);
  }
  function updateFlap(dt) {
    if (fl.state !== 'play') return;
    if (fl.grace > 0) fl.grace -= dt;

    // Zachtere zwaartekracht; tijdens grace nog lichter en max-valsnelheid beperkt
    const g = fl.grace > 0 ? fl.grav * 0.35 : fl.grav;
    fl.vy += g;
    if (fl.grace > 0) fl.vy = Math.max(-1.2, Math.min(0.9, fl.vy));
    else fl.vy = Math.max(-2.2, Math.min(2.8, fl.vy));
    fl.y += fl.vy;

    // Tijdens grace: binnen scherm houden i.p.v. sterven
    if (fl.grace > 0) {
      if (fl.y < 8) { fl.y = 8; fl.vy = 0.2; }
      if (fl.y + 8 > SH - 8) { fl.y = SH - 16; fl.vy = -0.6; }
    }

    fl.spawnAcc += dt;
    // Eerste pipes pas na de grace-periode
    const spawnAfter = fl.grace > 0 ? 99999 : 1600;
    if (fl.spawnAcc > spawnAfter) {
      fl.spawnAcc = 0;
      const gapY = 24 + Math.floor(Math.random() * (SH - fl.gap - 48));
      fl.pipes.push({ x: SW, gapY, scored: false });
    }
    fl.pipes.forEach(p => { p.x -= fl.pipeSpeed; });
    fl.pipes = fl.pipes.filter(p => p.x > -20);

    fl.pipes.forEach(p => {
      if (!p.scored && p.x + 16 < 36) {
        p.scored = true; fl.score++;
        if (fl.score > bestFlap) { bestFlap = fl.score; store.set(K_BEST_F, bestFlap); }
        sfx.point();
      }
    });

    // Botsingen pas na grace
    if (fl.grace <= 0) {
      if (fl.y < 0 || fl.y + 8 > SH) {
        fl.state = 'over'; sfx.over(); dirty = true; return;
      }
      for (const p of fl.pipes) {
        if (36 + 10 > p.x && 36 < p.x + 16) {
          if (fl.y < p.gapY || fl.y + 8 > p.gapY + fl.gap) {
            fl.state = 'over'; sfx.over(); dirty = true; return;
          }
        }
      }
    }
    dirty = true;
  }
  function flapFlap() {
    if (fl.state === 'play') {
      fl.vy = fl.flapV;
      // geen opeenstapeling van te sterke omhoog-snelheid
      if (fl.vy < -1.8) fl.vy = -1.8;
      sfx.move();
    }
  }

  // ========== RENDER / UPDATE ==========
  function render() {
    if (!tiles.B) return;
    if (mode === 'menu') drawMenu();
    else if (mode === 'blokken') drawBlokken();
    else if (mode === 'slang') drawSlang();
    else if (mode === 'race') drawRace();
    else if (mode === 'muur') drawMuur();
    else if (mode === 'doolhof') drawDoolhof();
    else if (mode === 'flap') drawFlap();
  }

  function update(dt) {
    // DAS alleen in-game, niet in het keuzemenu (anders is omlaag veel te gevoelig)
    if (mode !== 'menu') {
      ['left', 'right', 'down', 'up'].forEach(n => {
        if (!held[n]) return;
        das[n] -= dt;
        let guard = 0;
        while (das[n] <= 0 && guard++ < 5) {
          das[n] += (n === 'down' ? DOWN_RATE : DAS_RATE);
          onDir(n);
        }
      });
    }
    if (mode === 'blokken' && bk) updateBlokken(dt);
    else if (mode === 'slang' && sn) updateSlang(dt);
    else if (mode === 'race' && rc) updateRace(dt);
    else if (mode === 'muur' && mw) updateMuur(dt);
    else if (mode === 'doolhof' && dh) updateDoolhof(dt);
    else if (mode === 'flap' && fl) updateFlap(dt);
  }

  function onDir(name) {
    if (mode === 'menu') {
      if (name === 'up' || name === 'left') { menuIdx = (menuIdx + GAMES.length - 1) % GAMES.length; dirty = true; }
      else if (name === 'down' || name === 'right') { menuIdx = (menuIdx + 1) % GAMES.length; dirty = true; }
      return;
    }
    if (mode === 'blokken' && bk) {
      if (bk.state === 'title') {
        if (name === 'left' || name === 'down') { startLevel = Math.max(0, startLevel - 1); store.set(K_LEVEL, startLevel); dirty = true; }
        else if (name === 'right' || name === 'up') { startLevel = Math.min(9, startLevel + 1); store.set(K_LEVEL, startLevel); dirty = true; }
        return;
      }
      if (bk.state !== 'play') return;
      if (name === 'left') bkMove(-1);
      else if (name === 'right') bkMove(1);
      else if (name === 'down' && !bk.downBlocked) bkStepDown(true);
      return;
    }
    if (mode === 'slang' && sn && sn.state === 'play') {
      const d = sn.dir;
      if (name === 'left' && d.x !== 1) sn.nextDir = { x: -1, y: 0 };
      else if (name === 'right' && d.x !== -1) sn.nextDir = { x: 1, y: 0 };
      else if (name === 'up' && d.y !== 1) sn.nextDir = { x: 0, y: -1 };
      else if (name === 'down' && d.y !== -1) sn.nextDir = { x: 0, y: 1 };
      return;
    }
    if (mode === 'race' && rc && rc.state === 'play') {
      if (name === 'left') { rc.carX = Math.max(0, rc.carX - 1); sfx.move(); dirty = true; }
      else if (name === 'right') { rc.carX = Math.min(2, rc.carX + 1); sfx.move(); dirty = true; }
      return;
    }
    if (mode === 'doolhof' && dh && dh.state === 'play') {
      if (name === 'left') dh.nextDir = { x: -1, y: 0 };
      else if (name === 'right') dh.nextDir = { x: 1, y: 0 };
      else if (name === 'up') dh.nextDir = { x: 0, y: -1 };
      else if (name === 'down') dh.nextDir = { x: 0, y: 1 };
      return;
    }
  }

  function press(name) {
    ensureAudio();
    if (name === 'left' || name === 'right' || name === 'down' || name === 'up') {
      if (held[name]) return;
      held[name] = true;
      das[name] = name === 'down' ? DOWN_RATE : DAS_DELAY;
      onDir(name);
      return;
    }
    if (name === 'select') {
      palIdx = (palIdx + 1) % PALETTES.length;
      store.set(K_PAL, PALETTES[palIdx].id);
      buildTiles();
      return;
    }
    if (name === 'sound') {
      soundOn = !soundOn;
      store.set(K_SND, soundOn ? '1' : '0');
      updateSndBtn();
      if (soundOn) { ensureAudio(); sfx.start(); }
      return;
    }
    if (name === 'pause') {
      if (mode !== 'menu') {
        // pause or back
        if (mode === 'blokken' && bk) {
          if (bk.state === 'play') { bk.state = 'pause'; dirty = true; }
          else if (bk.state === 'pause') { bk.state = 'play'; lastTs = 0; dirty = true; }
          else backToMenu();
        } else if (mode === 'slang' && sn) {
          if (sn.state === 'play') { sn.state = 'pause'; dirty = true; }
          else if (sn.state === 'pause') { sn.state = 'play'; lastTs = 0; dirty = true; }
          else backToMenu();
        } else if (mode === 'race' && rc) {
          if (rc.state === 'play') { rc.state = 'pause'; dirty = true; }
          else if (rc.state === 'pause') { rc.state = 'play'; lastTs = 0; dirty = true; }
          else backToMenu();
        } else if (mode === 'muur' && mw) {
          if (mw.state === 'play') { mw.state = 'pause'; dirty = true; }
          else if (mw.state === 'pause') { mw.state = 'play'; lastTs = 0; dirty = true; }
          else backToMenu();
        } else if (mode === 'doolhof' && dh) {
          if (dh.state === 'play') { dh.state = 'pause'; dirty = true; }
          else if (dh.state === 'pause') { dh.state = 'play'; lastTs = 0; dirty = true; }
          else backToMenu();
        } else if (mode === 'flap' && fl) {
          if (fl.state === 'play') { fl.state = 'pause'; dirty = true; }
          else if (fl.state === 'pause') { fl.state = 'play'; lastTs = 0; dirty = true; }
          else backToMenu();
        }
      }
      return;
    }
    if (name === 'start' || name === 'a') {
      if (mode === 'menu') { openGame(GAMES[menuIdx].id); return; }
      if (mode === 'blokken' && bk) {
        if (bk.state === 'title') bkNewGame();
        else if (bk.state === 'play' || bk.state === 'pause') {
          if (bk.state === 'play') { bk.state = 'pause'; dirty = true; }
          else { bk.state = 'play'; lastTs = 0; dirty = true; }
        } else if (bk.state === 'over') { bk.state = 'title'; dirty = true; }
        return;
      }
      if (mode === 'slang' && sn) {
        if (sn.state === 'title' || sn.state === 'over') snStart();
        else if (sn.state === 'play') { sn.state = 'pause'; dirty = true; }
        else if (sn.state === 'pause') { sn.state = 'play'; lastTs = 0; dirty = true; }
        return;
      }
      if (mode === 'race' && rc) {
        if (rc.state === 'title' || rc.state === 'over') raceStart();
        else if (rc.state === 'play') { rc.state = 'pause'; dirty = true; }
        else if (rc.state === 'pause') { rc.state = 'play'; lastTs = 0; dirty = true; }
        return;
      }
      if (mode === 'muur' && mw) {
        if (mw.state === 'title' || mw.state === 'over' || mw.state === 'win') muurStart();
        else if (mw.state === 'play') { mw.state = 'pause'; dirty = true; }
        else if (mw.state === 'pause') { mw.state = 'play'; lastTs = 0; dirty = true; }
        return;
      }
      if (mode === 'doolhof' && dh) {
        if (dh.state === 'title' || dh.state === 'over' || dh.state === 'win') dhStart();
        else if (dh.state === 'play') { dh.state = 'pause'; dirty = true; }
        else if (dh.state === 'pause') { dh.state = 'play'; lastTs = 0; dirty = true; }
        return;
      }
      if (mode === 'flap' && fl) {
        if (fl.state === 'title' || fl.state === 'over') flapStart();
        else if (fl.state === 'play') { flapFlap(); }
        else if (fl.state === 'pause') { fl.state = 'play'; lastTs = 0; dirty = true; }
        return;
      }
    }
    if (name === 'b') {
      if (mode === 'blokken' && bk && bk.state === 'play') bkRotate(-1);
      else if (mode !== 'menu') backToMenu();
      return;
    }
    if (name === 'drop' || name === 'up') {
      if (mode === 'blokken' && bk) {
        if (name === 'drop' && bk.state === 'play') bkHardDrop();
        else if (name === 'up' && bk.state === 'play') bkRotate(1);
        else if (name === 'up' && bk.state === 'title') { startLevel = Math.min(9, startLevel + 1); store.set(K_LEVEL, startLevel); dirty = true; }
      }
      if (mode === 'flap' && fl && fl.state === 'play') flapFlap();
      return;
    }
  }

  function release(name) {
    if (name in held) {
      held[name] = false;
      if (name === 'down' && bk) bk.downBlocked = false;
    }
  }
  function releaseAll() { Object.keys(held).forEach(release); }

  function onKeyDown(e) {
    if (!root.isConnected) { stop(); return; }
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (listenAction) {
      e.preventDefault();
      if (e.repeat) return;
      const raw = e.key;
      if (raw === 'Escape' && listenAction !== 'pause') { listenAction = null; renderKeyRows(); return; }
      const k = raw && raw.length === 1 ? raw.toLowerCase() : raw;
      if (!k || k === 'Shift' || k === 'Control' || k === 'Alt' || k === 'Meta') return;
      finishListen(k);
      return;
    }
    const name = keyName(e);
    if (!name) return;
    e.preventDefault();
    if (e.repeat) return;
    press(name);
  }
  function onKeyUp(e) {
    if (listenAction) return;
    const name = keyName(e);
    if (name) release(name);
  }
  function onHidden() { if (document.hidden) { releaseAll(); } }
  function onBlur() { releaseAll(); }

  function wire(btn, name) {
    btn.addEventListener('mousedown', e => e.preventDefault());
    btn.addEventListener('pointerdown', e => {
      e.preventDefault();
      try { btn.setPointerCapture(e.pointerId); } catch (_) {}
      btn.classList.add('is-down');
      press(name);
    });
    const up = () => { btn.classList.remove('is-down'); release(name); };
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => btn.addEventListener(ev, up));
  }
  root.querySelectorAll('[data-k]').forEach(b => wire(b, b.dataset.k));
  btnSettings.onclick = () => toggleSettings();
  btnFs.onclick = () => toggleFullscreen();
  settings.querySelector('[data-snd]').onclick = () => press('sound');
  settings.querySelector('[data-reset-keys]').onclick = () => {
    keybinds = Object.fromEntries(Object.entries(DEFAULT_KEYS).map(([k, v]) => [k, v.slice()]));
    saveKeybinds(); listenAction = null; renderKeyRows(); updateHint();
  };
  settings.querySelector('[data-close-set]').onclick = () => {
    settings.classList.remove('is-open'); btnSettings.classList.remove('is-active'); listenAction = null;
  };
  canvas.addEventListener('click', () => {
    root.focus({ preventScroll: true });
    if (mode === 'menu') press('start');
  });

  function frame(ts) {
    if (!root.isConnected) { stop(); return; }
    raf = requestAnimationFrame(frame);
    const dt = lastTs ? Math.min(100, ts - lastTs) : 0;
    lastTs = ts;
    update(dt);
    const b = Math.floor(ts / 500) % 2 === 0;
    if (b !== blinkOn) { blinkOn = b; dirty = true; }
    if (dirty) { dirty = false; render(); }
  }

  let stopped = false;
  const mo = new MutationObserver(() => { if (!root.isConnected) stop(); });
  function stop() {
    if (stopped) return;
    stopped = true;
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
    try { mo.disconnect(); } catch (_) {}
    document.body.classList.remove('tg-tetris-open', 'tg-tetris-fs');
    document.documentElement.classList.remove('tg-tetris-open');
    document.removeEventListener('keydown', onKeyDown);
    document.removeEventListener('keyup', onKeyUp);
    document.removeEventListener('visibilitychange', onHidden);
    window.removeEventListener('blur', onBlur);
    if (ac) { try { ac.close(); } catch (_) {} ac = null; }
  }

  document.addEventListener('keydown', onKeyDown);
  document.addEventListener('keyup', onKeyUp);
  document.addEventListener('visibilitychange', onHidden);
  window.addEventListener('blur', onBlur);
  mo.observe(document.body, { childList: true, subtree: true });

  document.body.classList.remove('tg-tetris-fs');
  document.body.classList.add('tg-tetris-open');
  document.documentElement.classList.add('tg-tetris-open');

  buildTiles();
  updateSndBtn();
  updateHint();
  dirty = true;
  render();
  raf = requestAnimationFrame(frame);
  setTimeout(() => { try { if (root.isConnected) { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); root.focus({ preventScroll: true }); } } catch (_) {} }, 0);

  return { root, destroy: stop };
}
