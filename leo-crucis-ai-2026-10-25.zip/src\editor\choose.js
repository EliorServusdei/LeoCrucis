// Keuzedialoog: type boek + eventueel documentontwerp.
import { DOC_STYLES, SKELETONS } from './docstyles.js';

const h = (tag, cls, text) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
};

/**
 * Kies type van een nieuw boek.
 * @returns {Promise<'doc'|'pdf'|'pptx'|'xlsx'|null>}
 */
export function chooseBookType() {
  return new Promise(resolve => {
    const back = h('div', 'dlg-back');
    const box = h('div', 'dlg dlg-wide');
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-label', 'Soort boek kiezen');
    box.append(h('p', 'dlg-title', 'Wat wil je maken?'));
    box.append(h('p', 'dlg-hint', 'Kies het type. Je kunt dit later niet meer wijzigen.'));

    const grid = h('div', 'type-grid');
    const types = [
      ['doc', '📝', 'Document', 'Geschreven tekst met Word-achtige editor en ontwerpen (artikel, brief, …)'],
      ['pdf', '📄', 'PDF', 'Bestaande PDF inlezen en bekijken in de bibliotheek'],
      ['pptx', '📊', 'PowerPoint', "Presentatie met dia's, titels en opsommingstekens"],
      ['xlsx', '📈', 'Excel', 'Rekenblad met rijen, kolommen en formules']
    ];
    types.forEach(([id, icon, title, desc]) => {
      const btn = h('button', 'type-card');
      btn.type = 'button';
      btn.innerHTML = `<span class="type-icon">${icon}</span><span class="type-name">${title}</span><span class="type-desc">${desc}</span>`;
      btn.onclick = () => { back.remove(); resolve(id); };
      grid.append(btn);
    });
    box.append(grid);

    const cancel = h('button', 'back', 'Annuleren');
    cancel.type = 'button';
    cancel.onclick = () => { back.remove(); resolve(null); };
    const row = h('div', 'dlg-row');
    row.append(cancel);
    box.append(row);
    back.append(box);
    document.body.append(back);
    back.addEventListener('keydown', e => { if (e.key === 'Escape') cancel.onclick(); });
    cancel.focus();
  });
}

/**
 * Kies een documentontwerp (alleen voor type doc).
 * @returns {Promise<string|null>} style id of '' voor standaard, null bij annuleren
 */
export function chooseDocDesign() {
  return new Promise(resolve => {
    const back = h('div', 'dlg-back');
    const box = h('div', 'dlg dlg-wide');
    box.setAttribute('role', 'dialog');
    box.append(h('p', 'dlg-title', 'Kies een ontwerp'));
    box.append(h('p', 'dlg-hint', 'Optioneel: start met een kant-en-klare structuur.'));

    const grid = h('div', 'type-grid');
    DOC_STYLES.forEach(([id, name, desc]) => {
      const btn = h('button', 'type-card type-card-sm');
      btn.type = 'button';
      btn.innerHTML = `<span class="type-name">${name}</span><span class="type-desc">${desc || ''}</span>`;
      btn.onclick = () => { back.remove(); resolve(id); };
      grid.append(btn);
    });
    box.append(grid);

    const cancel = h('button', 'back', 'Annuleren');
    cancel.type = 'button';
    cancel.onclick = () => { back.remove(); resolve(null); };
    const row = h('div', 'dlg-row');
    row.append(cancel);
    box.append(row);
    back.append(box);
    document.body.append(back);
    cancel.focus();
  });
}

/** Start-HTML voor een documentstijl. */
export function initialDocHtml(styleId) {
  if (styleId && SKELETONS[styleId]) return SKELETONS[styleId]();
  return '<div class="box"><h3>Nieuw boek</h3><p>Schrijf hier je tekst.</p></div>';
}

/** Label + icoon voor weergave op de plank. */
export function typeMeta(type) {
  const m = {
    doc: { icon: '📝', label: 'Document' },
    pdf: { icon: '📄', label: 'PDF' },
    pptx: { icon: '📊', label: 'Presentatie' },
    xlsx: { icon: '📈', label: 'Rekenblad' }
  };
  return m[type] || m.doc;
}
