/**
 * Worldbuilding Studio — opslag in src/apps/worldbuilding/projecten/
 *
 * Bron van waarheid (meegeleverd + bewerkbaar):
 *   apps/worldbuilding/projecten/index.json
 *   apps/worldbuilding/projecten/{id}.json
 *
 * Laden: fetch van die paden, daarna Tauri user-files, daarna localStorage.
 * Opslaan: Tauri writeFile + localStorage; bij ontbreken van I/O blijft
 * localStorage + export beschikbaar.
 */

import { inTauri, readFile, writeFile, deleteFile } from '../../core/edit.js';

/** Relatief t.o.v. de app-root (src/) — map naast de worldbuilding-code */
const DATA_DIR = 'apps/worldbuilding/projecten';
const FILE_INDEX = `${DATA_DIR}/index.json`;
const FILE_PROJECT = (id) => `${DATA_DIR}/${id}.json`;

/** Tauri-gebruikerspaden (zelfde structuur) */
const USER_INDEX = 'apps/worldbuilding/projecten/index.json';
const USER_PROJECT = (id) => `apps/worldbuilding/projecten/${id}.json`;

const LS_INDEX = 'lc-wb-index-v1';
const LS_PREFIX = 'lc-wb-project-';

export function emptyCollections() {
  return {
    continents: [], locations: [], cities: [], maps: [], biomes: [],
    events: [], eras: [], wars: [], dynasties: [],
    characters: [], races: [], cultures: [], factions: [], organizations: [],
    religions: [], languages: [],
    magic: [], creatures: [], floraFauna: [], artifacts: [], technology: [], laws: [],
    plots: [], chapters: [], books: [], themes: [], ideas: [], notes: [], concepts: [],
    relations: [], activity: [], favorites: [],
  };
}

function uid() {
  return 'wb_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
}

export function createProjectMeta(opts = {}) {
  const now = new Date().toISOString();
  return {
    id: uid(),
    name: opts.name || 'Nieuwe wereld',
    subtitle: opts.subtitle || '',
    description: opts.description || '',
    worldType: opts.worldType || 'high-fantasy',
    status: opts.status || 'concept',
    accent: opts.accent || '#b8922a',
    symbol: opts.symbol || '✦',
    coverImage: opts.coverImage || '',
    createdAt: now,
    updatedAt: now,
  };
}

export function createFullProject(meta = {}) {
  const m = createProjectMeta(meta);
  return {
    ...m,
    ...emptyCollections(),
    calendar: {
      name: 'Standaardkalender',
      months: [
        { name: 'Voorjaar', days: 30 },
        { name: 'Zomer', days: 30 },
        { name: 'Herfst', days: 30 },
        { name: 'Winter', days: 30 },
      ],
      yearPrefix: 'Jaar',
      epochName: 'Eerste Tijdperk',
    },
  };
}

export function createItem(collection, data = {}) {
  const now = new Date().toISOString();
  const id = data.id || uid();
  return {
    id,
    name: data.name || 'Naamloos',
    description: data.description || '',
    tags: data.tags || [],
    favorite: false,
    image: data.image || '',
    customFields: data.customFields || {},
    links: data.links || [],
    createdAt: now,
    updatedAt: now,
    ...data,
    id,
  };
}

function normalizeProject(p) {
  const base = emptyCollections();
  const out = { ...base, ...p };
  for (const k of Object.keys(base)) if (!Array.isArray(out[k])) out[k] = [];
  if (!out.calendar) {
    out.calendar = {
      name: 'Standaardkalender',
      months: [
        { name: 'Voorjaar', days: 30 },
        { name: 'Zomer', days: 30 },
        { name: 'Herfst', days: 30 },
        { name: 'Winter', days: 30 },
      ],
      yearPrefix: 'Jaar',
      epochName: '',
    };
  }
  return out;
}

function countItems(p) {
  const keys = Object.keys(emptyCollections()).filter(
    (k) => !['activity', 'favorites', 'relations'].includes(k)
  );
  const out = {};
  let total = 0;
  for (const k of keys) {
    const n = Array.isArray(p[k]) ? p[k].length : 0;
    out[k] = n;
    total += n;
  }
  out.total = total;
  return out;
}

function projectMeta(p) {
  return {
    id: p.id,
    name: p.name,
    subtitle: p.subtitle || '',
    description: p.description || '',
    worldType: p.worldType || 'high-fantasy',
    status: p.status || 'concept',
    accent: p.accent || '#b8922a',
    symbol: p.symbol || '',
    coverImage: p.coverImage || '',
    createdAt: p.createdAt,
    updatedAt: p.updatedAt,
    counts: countItems(p),
  };
}

async function lsGet(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch {
    return fallback;
  }
}

function lsSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.error(e);
    return false;
  }
}

/**
 * Fetch JSON — probeert meerdere paden:
 * 1) naast deze module: ./projecten/…
 * 2) vanaf src/: apps/worldbuilding/projecten/…
 * 3) kale relative URL
 */
async function fetchJson(relPath) {
  const candidates = [];
  // Als pad al onder projecten/ valt, ook korte vorm naast store.js
  const fileName = relPath.split('/').pop();
  try {
    candidates.push(new URL('./projecten/' + fileName, import.meta.url).href);
  } catch (_) {}
  try {
    candidates.push(new URL('../../' + relPath, import.meta.url).href);
  } catch (_) {}
  candidates.push(relPath);
  candidates.push('/' + relPath.replace(/^\/+/, ''));

  for (const url of candidates) {
    try {
      const res = await fetch(url, { cache: 'no-store' });
      if (res.ok) return await res.json();
    } catch (_) {}
  }
  return null;
}

async function tauriRead(path) {
  if (!inTauri) return null;
  try {
    const text = await readFile(path);
    if (text == null || text === '') return null;
    return JSON.parse(text);
  } catch {
    return null;
  }
}

async function tauriWrite(path, value) {
  if (!inTauri) return false;
  try {
    await writeFile(path, JSON.stringify(value, null, 2));
    return true;
  } catch (e) {
    console.warn('tauriWrite failed', path, e);
    return false;
  }
}

/**
 * Kies nieuwste object op basis van updatedAt.
 */
function newer(a, b) {
  if (!a) return b;
  if (!b) return a;
  const ta = Date.parse(a.updatedAt || a.createdAt || 0) || 0;
  const tb = Date.parse(b.updatedAt || b.createdAt || 0) || 0;
  return tb > ta ? b : a;
}

export async function loadIndex() {
  const fromSrc = await fetchJson(FILE_INDEX);
  const fromUser = await tauriRead(USER_INDEX);
  const fromUserAlt = fromUser || (await tauriRead(FILE_INDEX));
  const fromLs = await lsGet(LS_INDEX, null);

  // Merge: bundled/src-projecten blijven zichtbaar; nieuwere user/LS-meta wint per id
  const byId = new Map();
  for (const src of [fromSrc, fromUserAlt, fromLs]) {
    if (!src || !Array.isArray(src.projects)) continue;
    for (const meta of src.projects) {
      if (!meta || !meta.id) continue;
      const prev = byId.get(meta.id);
      byId.set(meta.id, prev ? newer(prev, meta) : meta);
    }
  }
  const projects = Array.from(byId.values()).sort((a, b) => {
    const ta = Date.parse(a.updatedAt || a.createdAt || 0) || 0;
    const tb = Date.parse(b.updatedAt || b.createdAt || 0) || 0;
    return tb - ta;
  });
  const updatedAt = projects.reduce((max, p) => {
    const t = p.updatedAt || p.createdAt || '';
    return t > max ? t : max;
  }, '');
  return { version: 1, projects, updatedAt: updatedAt || null };
}

export async function saveIndex(index) {
  const payload = {
    version: 1,
    projects: index.projects || [],
    updatedAt: new Date().toISOString(),
    note: 'Index van worldbuilding-projecten. Elk project staat als {id}.json in apps/worldbuilding/projecten/',
  };

  let ok = false;
  // Probeer zowel data/-pad als user-pad (Tauri)
  ok = (await tauriWrite(FILE_INDEX, payload)) || ok;
  ok = (await tauriWrite(USER_INDEX, payload)) || ok;
  ok = lsSet(LS_INDEX, payload) || ok;
  if (!ok) throw new Error('Index opslaan mislukt');
  return true;
}

export async function loadProject(id) {
  if (!id) return null;

  const fromSrc = await fetchJson(FILE_PROJECT(id));
  const fromUser = (await tauriRead(USER_PROJECT(id))) || (await tauriRead(FILE_PROJECT(id)));
  const fromLs = await lsGet(LS_PREFIX + id, null);

  let best = null;
  // Bronbestanden eerst als basis; nieuwere user/LS-kopie wint
  for (const c of [fromSrc, fromUser, fromLs]) {
    if (c && c.id) best = newer(best, c);
  }
  if (!best && fromSrc) best = fromSrc;
  return best ? normalizeProject(best) : null;
}

export async function saveProject(project) {
  if (!project || !project.id) throw new Error('Project zonder id');
  project.updatedAt = new Date().toISOString();
  const normalized = normalizeProject(project);

  let ok = false;
  ok = (await tauriWrite(FILE_PROJECT(normalized.id), normalized)) || ok;
  ok = (await tauriWrite(USER_PROJECT(normalized.id), normalized)) || ok;
  ok = lsSet(LS_PREFIX + normalized.id, normalized) || ok;
  if (!ok) throw new Error('Opslaan van project mislukt');

  const index = await loadIndex();
  const meta = projectMeta(normalized);
  const i = index.projects.findIndex((p) => p.id === meta.id);
  if (i >= 0) index.projects[i] = meta;
  else index.projects.push(meta);
  await saveIndex(index);

  return normalized;
}

export async function deleteProject(id) {
  if (!id) return false;
  if (inTauri) {
    try { await deleteFile(USER_PROJECT(id)); } catch (_) {}
    try { await deleteFile(FILE_PROJECT(id)); } catch (_) {}
  }
  try { localStorage.removeItem(LS_PREFIX + id); } catch (_) {}

  const index = await loadIndex();
  index.projects = index.projects.filter((p) => p.id !== id);
  await saveIndex(index);
  return true;
}

export async function duplicateProject(id) {
  const src = await loadProject(id);
  if (!src) throw new Error('Project niet gevonden');
  const copy = JSON.parse(JSON.stringify(src));
  copy.id = uid();
  copy.name = (src.name || 'Wereld') + ' (kopie)';
  copy.createdAt = new Date().toISOString();
  copy.updatedAt = copy.createdAt;
  await saveProject(copy);
  return copy;
}

export function logActivity(project, action, label, ref = null) {
  if (!project.activity) project.activity = [];
  project.activity.unshift({
    id: uid(),
    action,
    label,
    ref,
    at: new Date().toISOString(),
  });
  if (project.activity.length > 100) project.activity = project.activity.slice(0, 100);
}

export function searchProject(project, query, filters = {}) {
  if (!project || !query || !query.trim()) return [];
  const q = query.trim().toLowerCase();
  const results = [];
  const collections = filters.collection
    ? [filters.collection]
    : Object.keys(emptyCollections()).filter(
        (k) => !['activity', 'favorites', 'relations'].includes(k)
      );
  for (const col of collections) {
    for (const item of project[col] || []) {
      const hay = [
        item.name,
        item.description,
        item.title,
        ...(item.tags || []),
        ...Object.values(item).filter((v) => typeof v === 'string'),
      ]
        .join(' ')
        .toLowerCase();
      if (hay.includes(q)) results.push({ collection: col, item });
    }
  }
  return results;
}

export function exportProjectJson(project) {
  return JSON.stringify(project, null, 2);
}

export function parseImport(text) {
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error('Ongeldige JSON');
  }
  if (!data || typeof data !== 'object') throw new Error('Geen projectobject');
  if (!data.name && !data.id) throw new Error('Project mist naam of id');
  return normalizeProject({
    ...data,
    id: data.id || uid(),
    name: data.name || 'Geïmporteerde wereld',
    createdAt: data.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });
}

/**
 * Bouw een complete map-structuur voor download / AI:
 * { 'index.json': '...', 'projects/id.json': '...' }
 */
export async function buildDataBundle() {
  const index = await loadIndex();
  const files = {
    'index.json': JSON.stringify(
      {
        version: 1,
        projects: index.projects || [],
        updatedAt: new Date().toISOString(),
        note: 'Index van worldbuilding-projecten. Elk project staat als {id}.json in apps/worldbuilding/projecten/',
      },
      null,
      2
    ),
  };
  for (const meta of index.projects || []) {
    const p = await loadProject(meta.id);
    if (p) files[`projects/${p.id}.json`] = JSON.stringify(p, null, 2);
  }
  return files;
}

/** Download alle projecten als losse JSON-bestanden (browser). */
export async function downloadDataBundle() {
  const files = await buildDataBundle();
  for (const [name, content] of Object.entries(files)) {
    const blob = new Blob([content], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name.includes('/') ? name.replace(/\//g, '__') : name;
    a.click();
    URL.revokeObjectURL(a.href);
  }
  return Object.keys(files).length;
}

export { FILE_INDEX, FILE_PROJECT, DATA_DIR };
