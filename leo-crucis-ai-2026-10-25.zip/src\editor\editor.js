// Mini-Word voor boeken: ribbon met Start / Invoegen / Indeling / Ontwerp / Controleren / Bestand
// (zoals Microsoft Word) + documentstijlen, thema's, PDF/Word-export.
import {
  PARA_STYLES, DOC_STYLES, THEMES, FONT_THEMES, FONTS, SIZES,
  PALETTE, HILITES, SYMBOLS, EMOJI, SKELETONS
} from './docstyles.js';
import { exportPdf, printDoc, exportWord, parseDoc } from './pdf.js';

const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

async function imageToDataUrl(file, max = 1200) {
  if (/svg|gif/.test(file.type)) return new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(file); });
  const url = URL.createObjectURL(file), img = new Image();
  try {
    await new Promise((ok, no) => { img.onload = ok; img.onerror = no; img.src = url; });
    const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
    const c = h('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL(file.type === 'image/png' ? 'image/png' : 'image/jpeg', 0.82);
  } finally { URL.revokeObjectURL(url); }
}

export function createEditor(initialHtml, { ask }) {
  const imgs = new Map();
  const pack = t => t.replace(/src="(data:image\/[^"]+)"/g, (m, d) => { if (!imgs.has(d)) imgs.set(d, 'afbeelding:' + (imgs.size + 1)); return `src="${imgs.get(d)}"`; });
  const unpack = t => { for (const [d, k] of imgs) t = t.split(`src="${k}"`).join(`src="${d}"`); return t; };

  let mode = 'visual', selImg = null, lastRange = null, paintStyle = null, showMarks = false;
  let docAttrs = { page: 'a4', orient: 'portrait', margin: 'normaal', cols: '1', theme: '', font: '', hyphen: '0' };

  const ed = h('div', 'wysiwyg book'); ed.contentEditable = 'true'; ed.spellcheck = true; ed.setAttribute('aria-label', 'Tekst van het boek');
  const src = h('textarea', 'html-src'); src.spellcheck = false; src.setAttribute('aria-label', 'HTML van het boek');
  const prev = h('div', 'html-prev book');
  const split = h('div', 'editor-split'); split.append(src, prev);
  const area = h('div'); area.append(ed, split);
  const bar = h('div', 'editor-bar');
  const note = h('span', 'editor-note');
  const flash = t => { note.textContent = t; setTimeout(() => { if (note.textContent === t) note.textContent = ''; }, 3500); };

  const clean = () => {
    const c = ed.cloneNode(true);
    c.querySelectorAll('img').forEach(i => { i.classList.remove('sel'); if (!i.getAttribute('class')) i.removeAttribute('class'); });
    c.querySelectorAll('.show-marks').forEach(n => n.classList.remove('show-marks'));
    const inner = c.innerHTML.trim();
    const hasExtra = docAttrs.header || docAttrs.footer || docAttrs.pagenum || docAttrs.watermark ||
      (docAttrs.theme && docAttrs.theme !== '') || (docAttrs.font && docAttrs.font !== '') ||
      (docAttrs.page && docAttrs.page !== 'a4') || (docAttrs.orient && docAttrs.orient !== 'portrait') ||
      (docAttrs.margin && docAttrs.margin !== 'normaal') || (docAttrs.cols && docAttrs.cols !== '1');
    if (!hasExtra) return inner;
    const wrap = document.createElement('div');
    wrap.className = 'doc' + (docAttrs.theme ? ' doc-' + docAttrs.theme : '') + (docAttrs.font ? ' font-' + docAttrs.font : '');
    Object.entries(docAttrs).forEach(([k, v]) => { if (v != null && v !== '') wrap.setAttribute('data-' + k, v); });
    wrap.innerHTML = inner;
    return wrap.outerHTML;
  };
  const getHtml = () => unpack(mode === 'html' ? src.value : clean());
  const setHtml = html => {
    const parsed = parseDoc(html || '');
    if (parsed.attrs && Object.keys(parsed.attrs).length) {
      docAttrs = { page: 'a4', orient: 'portrait', margin: 'normaal', cols: '1', theme: '', font: '', hyphen: '0', ...parsed.attrs };
    }
    const inner = parsed.inner || html || '';
    let u = unpack(inner);
    for (const [d, k] of imgs) u = u.split(`src="${k}"`).join(`src="${d}"`);
    ed.innerHTML = u || '<p><br></p>';
    src.value = u || '';
    applyDocClasses();
    ed.dataset.init = '1';
  };
  const applyDocClasses = () => {
    ed.className = 'wysiwyg book doc' +
      (docAttrs.theme ? ' doc-' + docAttrs.theme : '') +
      (docAttrs.font ? ' font-' + docAttrs.font : '') +
      (showMarks ? ' show-marks' : '');
    if (docAttrs.cols === '2') ed.classList.add('cols-2-page');
    else ed.classList.remove('cols-2-page');
  };
  const livePrev = () => { prev.innerHTML = src.value; };

  document.addEventListener('selectionchange', () => {
    const s = getSelection();
    if (s.rangeCount && ed.contains(s.anchorNode)) {
      lastRange = s.getRangeAt(0).cloneRange();
      syncStyle();
      syncFontSize();
      syncFontFamily();
    }
  });
  const restore = () => { ed.focus(); if (lastRange) { const s = getSelection(); s.removeAllRanges(); s.addRange(lastRange); } };
  const exec = (cmd, val) => { restore(); document.execCommand(cmd, false, val); };
  try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) {}

  const tool = (label, title, fn, cls = '', into = bar) => {
    const b = h('button', cls, label); b.type = 'button'; b.title = title; b.setAttribute('aria-label', title);
    b.onmousedown = e => e.preventDefault(); b.onclick = fn; into.append(b); return b;
  };
  const group = (label, parent) => {
    const g = h('div', 'tb-group');
    const row = h('div', 'tb-group-row');
    const lbl = h('span', 'tb-group-label', label);
    g.append(row, lbl);
    parent.append(g);
    return row;
  };
  const visualTools = [];
  const vt = (into, label, title, fn, cls = '') => tool(label, title, fn, cls, into);

  // ========== TABBLADEN ==========
  const tabsRow = h('div', 'tb-tabs');
  const tabDefs = [
    ['start', 'Start'],
    ['insert', 'Invoegen'],
    ['layout', 'Indeling'],
    ['design', 'Ontwerp'],
    ['review', 'Controleren'],
    ['file', 'Bestand']
  ];
  const tabBtns = {};
  const panels = {};
  tabDefs.forEach(([id, label], i) => {
    const btn = h('button', 'tb-tab' + (i === 0 ? ' active' : ''), label); btn.type = 'button';
    tabBtns[id] = btn;
    tabsRow.append(btn);
    const panel = h('div', 'tb-panel'); if (i > 0) panel.hidden = true;
    panels[id] = panel;
    bar.append(panel);
  });
  bar.insertBefore(tabsRow, panels.start);
  visualTools.push(tabsRow, ...Object.values(panels));

  let activeTab = 'start';
  const setTab = name => {
    activeTab = name;
    tabDefs.forEach(([id]) => {
      tabBtns[id].classList.toggle('active', id === name);
      panels[id].hidden = id !== name;
    });
  };
  tabDefs.forEach(([id]) => { tabBtns[id].onclick = () => setTab(id); });

  // ========== START ==========
  const clipGrp = group('Klembord', panels.start);
  vt(clipGrp, '📋', 'Plakken (Ctrl+V)', async () => {
    restore();
    try {
      const t = await navigator.clipboard.readText();
      if (t) exec('insertText', t);
    } catch (e) {
      flash('Plakken via Ctrl+V (clipboard-toegang geweigerd)');
    }
  });
  vt(clipGrp, '✂', 'Knippen (Ctrl+X)', () => exec('cut'));
  vt(clipGrp, '📄', 'Kopiëren (Ctrl+C)', () => exec('copy'));
  const paintBtn = vt(clipGrp, '🖌', 'Opmaak kopiëren/plakken (Format Painter)', () => {
    restore();
    const s = getSelection();
    if (!paintStyle) {
      let n = s.anchorNode; if (n && n.nodeType === 3) n = n.parentElement;
      if (!n || !ed.contains(n)) { flash('Selecteer eerst tekst met opmaak'); return; }
      paintStyle = {
        bold: document.queryCommandState('bold'),
        italic: document.queryCommandState('italic'),
        underline: document.queryCommandState('underline'),
        strike: document.queryCommandState('strikeThrough'),
        color: document.queryCommandValue('foreColor'),
        size: document.queryCommandValue('fontSize'),
        face: document.queryCommandValue('fontName')
      };
      paintBtn.classList.add('tb-active');
      flash('Opmaak gekopieerd — selecteer doeltekst en klik opnieuw');
    } else {
      if (paintStyle.bold) exec('bold');
      if (paintStyle.italic) exec('italic');
      if (paintStyle.underline) exec('underline');
      if (paintStyle.strike) exec('strikeThrough');
      if (paintStyle.color) exec('foreColor', paintStyle.color);
      if (paintStyle.size) exec('fontSize', paintStyle.size);
      if (paintStyle.face) exec('fontName', paintStyle.face);
      paintStyle = null;
      paintBtn.classList.remove('tb-active');
      flash('Opmaak toegepast');
    }
  });
  vt(clipGrp, '↩', 'Ongedaan maken (Ctrl+Z)', () => exec('undo'));
  vt(clipGrp, '↪', 'Opnieuw (Ctrl+Y)', () => exec('redo'));

  // --- Lettertype ---
  const fontGrp = group('Lettertype', panels.start);
  const fontFamily = h('select', 'style-pick font-family-pick');
  fontFamily.title = 'Lettertype'; fontFamily.setAttribute('aria-label', 'Lettertype');
  FONTS.forEach(([name, stack]) => {
    const o = h('option', '', name); o.value = stack; fontFamily.append(o);
  });
  fontFamily.onchange = () => exec('fontName', fontFamily.value);
  const syncFontFamily = () => {
    try {
      const v = document.queryCommandValue('fontName');
      if (!v) return;
      const norm = v.replace(/['"]/g, '').toLowerCase();
      for (const opt of fontFamily.options) {
        if (opt.value.toLowerCase().includes(norm.split(',')[0].trim()) || norm.includes(opt.text.toLowerCase())) {
          fontFamily.value = opt.value; return;
        }
      }
    } catch (e) {}
  };
  fontGrp.append(fontFamily);

  const fontSize = h('select', 'style-pick'); fontSize.title = 'Lettergrootte'; fontSize.setAttribute('aria-label', 'Lettergrootte');
  [['1', '8'], ['2', '10'], ['3', '12'], ['4', '14'], ['5', '18'], ['6', '24'], ['7', '36']].forEach(([v, t]) => {
    const o = h('option', '', t + ' pt'); o.value = v; fontSize.append(o);
  });
  fontSize.value = '3';
  fontSize.onchange = () => exec('fontSize', fontSize.value);
  const syncFontSize = () => {
    try {
      const v = document.queryCommandValue('fontSize');
      if (v && [...fontSize.options].some(o => o.value === v)) fontSize.value = v;
    } catch (e) {}
  };
  fontGrp.append(fontSize);

  vt(fontGrp, 'A^', 'Lettertype vergroten', () => {
    restore();
    const cur = parseInt(fontSize.value, 10) || 3;
    fontSize.value = String(Math.min(7, cur + 1));
    exec('fontSize', fontSize.value);
  });
  vt(fontGrp, 'A˅', 'Lettertype verkleinen', () => {
    restore();
    const cur = parseInt(fontSize.value, 10) || 3;
    fontSize.value = String(Math.max(1, cur - 1));
    exec('fontSize', fontSize.value);
  });
  vt(fontGrp, 'Aa', 'Hoofdlettergebruik wijzigen', () => {
    restore();
    const s = getSelection(); if (!s.rangeCount) return;
    const t = s.toString(); if (!t) return;
    let next;
    if (t === t.toUpperCase()) next = t.toLowerCase();
    else if (t === t.toLowerCase()) next = t.replace(/\b\w/g, c => c.toUpperCase());
    else next = t.toUpperCase();
    exec('insertText', next);
  });
  vt(fontGrp, '✖', 'Alle opmaak wissen', () => exec('removeFormat'));

  vt(fontGrp, 'B', 'Vet (Ctrl+B)', () => exec('bold'), 'tb-b');
  vt(fontGrp, 'I', 'Cursief (Ctrl+I)', () => exec('italic'), 'tb-i');
  vt(fontGrp, 'U', 'Onderstrepen (Ctrl+U)', () => exec('underline'), 'tb-u');
  vt(fontGrp, 'abc', 'Doorhalen', () => exec('strikeThrough'), 'tb-s');
  vt(fontGrp, 'x₂', 'Subscript', () => exec('subscript'));
  vt(fontGrp, 'x²', 'Superscript', () => exec('superscript'));

  const hilite = h('input'); hilite.type = 'color'; hilite.value = '#fff1a8'; hilite.title = 'Tekst markeren'; hilite.className = 'tb-color'; hilite.setAttribute('aria-label', 'Markeren');
  hilite.oninput = () => exec('hiliteColor', hilite.value); fontGrp.append(hilite);
  const color = h('input'); color.type = 'color'; color.value = '#7a1f2b'; color.title = 'Tekstkleur'; color.className = 'tb-color'; color.setAttribute('aria-label', 'Tekstkleur');
  color.oninput = () => exec('foreColor', color.value); fontGrp.append(color);

  const paletteWrap = h('div', 'tb-palette');
  PALETTE.slice(0, 12).forEach(c => {
    const sw = h('button', 'tb-swatch'); sw.type = 'button'; sw.style.background = c; sw.title = c;
    sw.onmousedown = e => e.preventDefault();
    sw.onclick = () => exec('foreColor', c);
    paletteWrap.append(sw);
  });
  fontGrp.append(paletteWrap);

  // --- Alineastijlen ---
  const styleGrp = group('Stijlen', panels.start);
  const stylePick = h('select', 'style-pick style-para');
  stylePick.title = 'Alineastijl'; stylePick.setAttribute('aria-label', 'Alineastijl');
  PARA_STYLES.forEach(([id, name]) => {
    const o = h('option', '', name); o.value = id; stylePick.append(o);
  });
  const applyParaStyle = id => {
    restore();
    const def = PARA_STYLES.find(p => p[0] === id);
    if (!def) return;
    const [, , tag, cls] = def;
    if (tag === 'blockquote') exec('formatBlock', '<blockquote>');
    else if (tag === 'h2' || tag === 'h3' || tag === 'h4') exec('formatBlock', '<' + tag + '>');
    else exec('formatBlock', '<p>');
    requestAnimationFrame(() => {
      const s = getSelection();
      let n = s.anchorNode;
      if (n && n.nodeType === 3) n = n.parentElement;
      while (n && n !== ed && !/^(P|H2|H3|H4|BLOCKQUOTE|DIV)$/i.test(n.tagName)) n = n.parentElement;
      if (n && n !== ed) {
        [...n.classList].filter(c => c.startsWith('s-')).forEach(c => n.classList.remove(c));
        if (cls) n.classList.add(cls);
      }
      syncStyle();
    });
  };
  stylePick.onchange = () => applyParaStyle(stylePick.value);
  styleGrp.append(stylePick);

  const syncStyle = () => {
    let n = getSelection().anchorNode;
    while (n && n !== ed) {
      if (n.nodeType === 1) {
        const cls = [...(n.classList || [])].find(c => c.startsWith('s-'));
        if (cls) {
          const found = PARA_STYLES.find(p => p[3] === cls);
          if (found) { stylePick.value = found[0]; return; }
        }
        const tag = n.tagName;
        if (tag === 'H2') { stylePick.value = 'kop1'; return; }
        if (tag === 'H3') { stylePick.value = 'kop2'; return; }
        if (tag === 'H4') { stylePick.value = 'kop3'; return; }
        if (tag === 'BLOCKQUOTE') { stylePick.value = 'citaat'; return; }
        if (tag === 'P') { stylePick.value = 'normaal'; return; }
      }
      n = n.parentNode;
    }
    stylePick.value = 'normaal';
  };

  [['kop1', 'Kop 1'], ['intro', 'Intro'], ['kern', 'Kern'], ['tip', 'Tip'], ['belangrijk', '!'], ['citaat', '\u201C\u201D']].forEach(([id, label]) => {
    vt(styleGrp, label, (PARA_STYLES.find(p => p[0] === id) || [])[1] || id, () => {
      stylePick.value = id;
      applyParaStyle(id);
    });
  });

  // --- Alinea ---
  const paraGrp = group('Alinea', panels.start);
  vt(paraGrp, '\u2022', 'Opsommingstekens', () => exec('insertUnorderedList'));
  vt(paraGrp, '1.', 'Nummering', () => exec('insertOrderedList'));
  vt(paraGrp, '\u2611', 'Checklist', () => {
    restore();
    exec('insertHTML', '<ul class="checklist"><li>Item</li></ul><p></p>');
  });
  vt(paraGrp, '\u21E4', 'Inspringing verkleinen', () => exec('outdent'));
  vt(paraGrp, '\u21E5', 'Inspringing vergroten', () => exec('indent'));
  vt(paraGrp, '\u2261\u2190', 'Links uitlijnen', () => exec('justifyLeft'));
  vt(paraGrp, '\u2261\u2194', 'Centreren', () => exec('justifyCenter'));
  vt(paraGrp, '\u2261\u2192', 'Rechts uitlijnen', () => exec('justifyRight'));
  vt(paraGrp, '\u2261\u2630', 'Uitvullen', () => exec('justifyFull'));
  vt(paraGrp, '\u00B6', 'Verborgen tekens tonen/verbergen', () => {
    showMarks = !showMarks;
    ed.classList.toggle('show-marks', showMarks);
    flash(showMarks ? 'Verborgen tekens zichtbaar' : 'Verborgen tekens verborgen');
  });
  vt(paraGrp, '\u2191', 'Regelafstand groter', () => {
    restore();
    const s = getSelection(); let n = s.anchorNode; if (n && n.nodeType === 3) n = n.parentElement;
    while (n && n !== ed && !/^(P|H2|H3|H4|BLOCKQUOTE|DIV|LI)$/i.test(n.tagName)) n = n.parentElement;
    if (n && n !== ed) {
      const cur = parseFloat(getComputedStyle(n).lineHeight) / parseFloat(getComputedStyle(n).fontSize) || 1.5;
      n.style.lineHeight = (Math.min(3, cur + 0.25)).toFixed(2);
    }
  });
  vt(paraGrp, '\u2193', 'Regelafstand kleiner', () => {
    restore();
    const s = getSelection(); let n = s.anchorNode; if (n && n.nodeType === 3) n = n.parentElement;
    while (n && n !== ed && !/^(P|H2|H3|H4|BLOCKQUOTE|DIV|LI)$/i.test(n.tagName)) n = n.parentElement;
    if (n && n !== ed) {
      const cur = parseFloat(getComputedStyle(n).lineHeight) / parseFloat(getComputedStyle(n).fontSize) || 1.5;
      n.style.lineHeight = (Math.max(1, cur - 0.25)).toFixed(2);
    }
  });

  // ========== INVOEGEN ==========
  const insertGrp = group('Invoegen', panels.insert);
  vt(insertGrp, '\uD83D\uDD17', 'Hyperlink', async () => {
    const keep = lastRange;
    const url = await ask('URL van de link', { input: true, value: 'https://', yes: 'Invoegen' });
    lastRange = keep;
    if (!url) return;
    restore();
    const s = getSelection();
    if (s.toString()) exec('createLink', url);
    else {
      const txt = await ask('Tekst van de link', { input: true, value: url, yes: 'Invoegen' });
      lastRange = keep; restore();
      exec('insertHTML', '<a href="' + url.replace(/"/g, '&quot;') + '" target="_blank" rel="noopener">' + (txt || url).replace(/</g, '&lt;') + '</a>');
    }
  });
  vt(insertGrp, '\uD83D\uDD17\u2716', 'Link verwijderen', () => exec('unlink'));
  vt(insertGrp, '\uD83D\uDCC5', 'Datum invoegen', () => {
    const d = new Date().toLocaleDateString('nl-BE', { day: 'numeric', month: 'long', year: 'numeric' });
    exec('insertText', d);
  });
  vt(insertGrp, '\u23F0', 'Tijd invoegen', () => {
    const t = new Date().toLocaleTimeString('nl-BE', { hour: '2-digit', minute: '2-digit' });
    exec('insertText', t);
  });
  vt(insertGrp, '\uD83D\uDCC4\u2193', 'Pagina-einde', () => exec('insertHTML', '<div class="page-break" contenteditable="false">\u2014 pagina-einde \u2014</div><p><br></p>'));
  vt(insertGrp, '\u2015', 'Horizontale lijn', () => exec('insertHorizontalRule'));
  vt(insertGrp, '+ Vak', 'Tekstvak / kader', () => exec('insertHTML', '<div class="box"><h3>Nieuwe titel</h3><p>Tekst\u2026</p></div><p></p>'));
  vt(insertGrp, '\u2020', 'Voetnoot', () => {
    restore();
    const n = (ed.querySelectorAll('.footnote').length + 1);
    exec('insertHTML', '<sup class="footnote" title="Noot ' + n + '">[' + n + ']</sup>');
  });
  vt(insertGrp, '\uD83C\uDFF7', 'Bijschrift', async () => {
    const keep = lastRange;
    const t = await ask('Bijschrift (bijv. Figuur 1: Overzicht)', { input: true, value: 'Figuur 1: ', yes: 'Invoegen' });
    lastRange = keep;
    if (t) exec('insertHTML', '<p class="caption"><em>' + t.replace(/</g, '&lt;') + '</em></p>');
  });

  const tableGrp = group('Tabel', panels.insert);
  vt(tableGrp, '\u25A6+', 'Tabel invoegen (3\u00D73)', () => {
    let html = '<table><tbody>';
    for (let r = 0; r < 3; r++) {
      html += '<tr>';
      for (let c = 0; c < 3; c++) html += r === 0 ? '<th>Kop</th>' : '<td>Tekst</td>';
      html += '</tr>';
    }
    html += '</tbody></table><p></p>';
    exec('insertHTML', html);
  });
  vt(tableGrp, '\u25A6\u2195+', 'Rij onder invoegen', () => {
    restore();
    const s = getSelection(); let n = s.anchorNode; if (n && n.nodeType === 3) n = n.parentElement;
    const tr = n && n.closest && n.closest('tr');
    if (!tr) { flash('Plaats de cursor in een tabelrij'); return; }
    const cells = tr.children.length;
    const nrow = document.createElement('tr');
    for (let i = 0; i < cells; i++) { const td = document.createElement('td'); td.textContent = 'Tekst'; nrow.append(td); }
    tr.parentNode.insertBefore(nrow, tr.nextSibling);
  });
  vt(tableGrp, '\u25A6\u2212', 'Rij verwijderen', () => {
    restore();
    const s = getSelection(); let n = s.anchorNode; if (n && n.nodeType === 3) n = n.parentElement;
    const tr = n && n.closest && n.closest('tr');
    if (!tr) { flash('Plaats de cursor in een tabelrij'); return; }
    tr.remove();
  });
  vt(tableGrp, '\u25A6\u2192+', 'Kolom rechts invoegen', () => {
    restore();
    const s = getSelection(); let n = s.anchorNode; if (n && n.nodeType === 3) n = n.parentElement;
    const td = n && n.closest && n.closest('td,th');
    const table = td && td.closest('table');
    if (!table) { flash('Plaats de cursor in een tabelcel'); return; }
    const idx = [...td.parentNode.children].indexOf(td);
    table.querySelectorAll('tr').forEach((tr, ri) => {
      const cell = document.createElement(ri === 0 && tr.querySelector('th') ? 'th' : 'td');
      cell.textContent = ri === 0 ? 'Kop' : 'Tekst';
      const ref = tr.children[idx];
      if (ref) ref.after(cell); else tr.append(cell);
    });
  });
  vt(tableGrp, '\u25A6\u2190\u2212', 'Kolom verwijderen', () => {
    restore();
    const s = getSelection(); let n = s.anchorNode; if (n && n.nodeType === 3) n = n.parentElement;
    const td = n && n.closest && n.closest('td,th');
    const table = td && td.closest('table');
    if (!table) { flash('Plaats de cursor in een tabelcel'); return; }
    const idx = [...td.parentNode.children].indexOf(td);
    table.querySelectorAll('tr').forEach(tr => { if (tr.children[idx]) tr.children[idx].remove(); });
  });

  const symGrp = group('Symbolen', panels.insert);
  const symPick = h('select', 'style-pick');
  symPick.title = 'Symbool invoegen';
  const symOpt = h('option', '', '\u2014 symbool \u2014'); symOpt.value = ''; symPick.append(symOpt);
  (Array.isArray(SYMBOLS) ? SYMBOLS : String(SYMBOLS).split(/\s+/).filter(Boolean)).slice(0, 60)
    .forEach(s => { const o = h('option', '', s); o.value = s; symPick.append(o); });
  symPick.onchange = () => { if (symPick.value) { exec('insertText', symPick.value); symPick.value = ''; } };
  symGrp.append(symPick);
  const emojiPick = h('select', 'style-pick');
  emojiPick.title = 'Emoji invoegen';
  const emOpt = h('option', '', '\u2014 emoji \u2014'); emOpt.value = ''; emojiPick.append(emOpt);
  EMOJI.forEach(s => { const o = h('option', '', s); o.value = s; emojiPick.append(o); });
  emojiPick.onchange = () => { if (emojiPick.value) { exec('insertText', emojiPick.value); emojiPick.value = ''; } };
  symGrp.append(emojiPick);

  // Foto's
  const file = h('input'); file.type = 'file'; file.accept = 'image/*'; file.multiple = true; file.hidden = true;
  const insertImages = async files => {
    for (const f of files) {
      if (!f.type.startsWith('image/')) continue;
      try {
        const data = await imageToDataUrl(f), alt = (f.name || '').replace(/\.[^.]+$/, '');
        if (mode === 'html') {
          const t = '<img src="' + data + '" alt="' + alt + '">';
          src.setRangeText(t, src.selectionStart, src.selectionEnd, 'end'); livePrev();
        } else exec('insertHTML', '<img src="' + data + '" alt="' + alt + '" style="width:60%">');
      } catch (e) { flash('Deze afbeelding kon niet gelezen worden'); }
    }
  };
  file.onchange = async () => { await insertImages([...file.files]); file.value = ''; };
  ed.addEventListener('paste', e => {
    const f = [...(e.clipboardData ? e.clipboardData.files : [])];
    if (f.some(x => x.type.startsWith('image/'))) { e.preventDefault(); insertImages(f); }
  });
  ed.addEventListener('drop', e => {
    const f = [...(e.dataTransfer ? e.dataTransfer.files : [])];
    if (f.some(x => x.type.startsWith('image/'))) { e.preventDefault(); insertImages(f); }
  });
  ed.addEventListener('dragover', e => { if (e.dataTransfer && [...e.dataTransfer.types].includes('Files')) e.preventDefault(); });

  const fotoGrp = group("Foto's", panels.insert);
  vt(fotoGrp, '\uD83D\uDDBC Toevoegen', 'Afbeelding invoegen vanaf computer', () => file.click());
  const fotoBtns = [];
  const fotoTool = (label, title, fn) => { const b = vt(fotoGrp, label, title, fn); fotoBtns.push(b); return b; };
  fotoTool('25%', 'Klein (1/4 breedte)', () => { if (selImg) selImg.style.width = '25%'; });
  fotoTool('50%', 'Middelgroot', () => { if (selImg) selImg.style.width = '50%'; });
  fotoTool('75%', 'Groot', () => { if (selImg) selImg.style.width = '75%'; });
  fotoTool('100%', 'Volle breedte', () => { if (selImg) selImg.style.width = '100%'; });
  fotoTool('\u2190', 'Links', () => { if (selImg) { selImg.style.cssText += ';display:block;margin:8px auto 8px 0;float:none'; } });
  fotoTool('\u2194', 'Centreren', () => { if (selImg) { selImg.style.cssText += ';display:block;margin:8px auto;float:none'; } });
  fotoTool('In tekst', 'In tekstregel', () => { if (selImg) { selImg.style.cssText += ';display:inline;float:none;margin:0 4px;vertical-align:middle;width:auto;max-width:40%'; } });
  fotoTool('Float', 'Tekstomloop links', () => { if (selImg) { selImg.style.cssText += ';display:block;float:left;margin:4px 12px 4px 0;width:40%'; } });
  fotoTool('Alt\u2026', 'Alternatieve tekst', async () => {
    if (!selImg) return;
    const v = await ask('Korte beschrijving van de foto', { input: true, value: selImg.alt || '', yes: 'Opslaan' });
    if (v !== null) selImg.alt = v;
  });
  fotoTool('\uD83D\uDDD1', 'Foto verwijderen', () => { if (selImg) { selImg.remove(); select(null); } });
  const setFotoEnabled = on => fotoBtns.forEach(b => { b.disabled = !on; b.classList.toggle('tb-disabled', !on); });
  setFotoEnabled(false);

  function select(img) {
    if (selImg) selImg.classList.remove('sel');
    selImg = img || null;
    if (selImg) selImg.classList.add('sel');
    setFotoEnabled(!!selImg);
    if (selImg && mode === 'visual') setTab('insert');
  }
  ed.addEventListener('click', e => {
    const img = e.target.closest('img');
    select(img && ed.contains(img) ? img : null);
  });

  // ========== INDELING ==========
  const pageGrp = group('Pagina', panels.layout);
  const pageSize = h('select', 'style-pick');
  [['a4', 'A4'], ['a5', 'A5'], ['a3', 'A3'], ['letter', 'Letter'], ['legal', 'Legal']].forEach(([v, t]) => {
    const o = h('option', '', t); o.value = v; pageSize.append(o);
  });
  pageSize.value = docAttrs.page || 'a4';
  pageSize.onchange = () => { docAttrs.page = pageSize.value; flash('Papierformaat: ' + pageSize.options[pageSize.selectedIndex].text); };
  pageGrp.append(pageSize);

  const orient = h('select', 'style-pick');
  [['portrait', 'Staand'], ['landscape', 'Liggend']].forEach(([v, t]) => {
    const o = h('option', '', t); o.value = v; orient.append(o);
  });
  orient.value = docAttrs.orient || 'portrait';
  orient.onchange = () => { docAttrs.orient = orient.value; flash(orient.value === 'landscape' ? 'Liggend' : 'Staand'); };
  pageGrp.append(orient);

  const margin = h('select', 'style-pick');
  [['geen', 'Geen marge'], ['smal', 'Smal'], ['normaal', 'Normaal'], ['breed', 'Breed']].forEach(([v, t]) => {
    const o = h('option', '', t); o.value = v; margin.append(o);
  });
  margin.value = docAttrs.margin || 'normaal';
  margin.onchange = () => { docAttrs.margin = margin.value; flash('Marge: ' + margin.options[margin.selectedIndex].text); };
  pageGrp.append(margin);

  const cols = h('select', 'style-pick');
  [['1', '1 kolom'], ['2', '2 kolommen']].forEach(([v, t]) => {
    const o = h('option', '', t); o.value = v; cols.append(o);
  });
  cols.value = docAttrs.cols || '1';
  cols.onchange = () => { docAttrs.cols = cols.value; applyDocClasses(); flash(cols.value === '2' ? 'Twee kolommen' : 'Een kolom'); };
  pageGrp.append(cols);

  const headFootGrp = group('Kop- & voettekst', panels.layout);
  vt(headFootGrp, 'Kop\u2026', 'Koptekst instellen', async () => {
    const t = await ask('Koptekst (bovenaan elke pagina)', { input: true, value: docAttrs.header || '', yes: 'OK' });
    if (t != null) { docAttrs.header = t; flash(t ? 'Koptekst ingesteld' : 'Koptekst gewist'); }
  });
  vt(headFootGrp, 'Voet\u2026', 'Voettekst instellen', async () => {
    const t = await ask('Voettekst (onderaan links)', { input: true, value: docAttrs.footer || '', yes: 'OK' });
    if (t != null) { docAttrs.footer = t; flash(t ? 'Voettekst ingesteld' : 'Voettekst gewist'); }
  });
  vt(headFootGrp, '\u2116', 'Paginanummers aan/uit', () => {
    docAttrs.pagenum = docAttrs.pagenum ? '' : '1';
    flash(docAttrs.pagenum ? 'Paginanummers aan' : 'Paginanummers uit');
  });
  vt(headFootGrp, '\uD83D\uDCA7', 'Watermerk', async () => {
    const t = await ask('Watermerktekst (bijv. Concept)', { input: true, value: docAttrs.watermark || 'Concept', yes: 'OK' });
    if (t == null) return;
    docAttrs.watermark = t.trim();
    ed.querySelectorAll('.watermark').forEach(w => w.remove());
    if (t.trim()) {
      const w = h('div', 'watermark', t.trim());
      ed.prepend(w);
      flash('Watermerk toegevoegd');
    } else flash('Watermerk gewist');
  });

  const spaceGrp = group('Spatiering', panels.layout);
  vt(spaceGrp, '\u00B6+', 'Meer ruimte voor alinea', () => {
    restore();
    const s = getSelection(); let n = s.anchorNode; if (n && n.nodeType === 3) n = n.parentElement;
    while (n && n !== ed && !/^(P|H2|H3|H4|BLOCKQUOTE|DIV)$/i.test(n.tagName)) n = n.parentElement;
    if (n && n !== ed) n.style.marginTop = ((parseInt(n.style.marginTop) || 0) + 8) + 'px';
  });
  vt(spaceGrp, '\u00B6\u2212', 'Minder ruimte voor alinea', () => {
    restore();
    const s = getSelection(); let n = s.anchorNode; if (n && n.nodeType === 3) n = n.parentElement;
    while (n && n !== ed && !/^(P|H2|H3|H4|BLOCKQUOTE|DIV)$/i.test(n.tagName)) n = n.parentElement;
    if (n && n !== ed) n.style.marginTop = Math.max(0, (parseInt(n.style.marginTop) || 0) - 8) + 'px';
  });
  vt(spaceGrp, '\u2194+', 'Meer ruimte na alinea', () => {
    restore();
    const s = getSelection(); let n = s.anchorNode; if (n && n.nodeType === 3) n = n.parentElement;
    while (n && n !== ed && !/^(P|H2|H3|H4|BLOCKQUOTE|DIV)$/i.test(n.tagName)) n = n.parentElement;
    if (n && n !== ed) n.style.marginBottom = ((parseInt(n.style.marginBottom) || 0) + 8) + 'px';
  });

  // ========== ONTWERP ==========
  const docStyleGrp = group('Documentstijl', panels.design);
  const docStylePick = h('select', 'style-pick');
  DOC_STYLES.forEach(([id, name, desc]) => {
    const o = h('option', '', name); o.value = id; o.title = desc || name; docStylePick.append(o);
  });
  docStylePick.onchange = () => {
    const id = docStylePick.value;
    if (!id) { flash('Standaard opmaak'); return; }
    const sk = SKELETONS[id];
    if (sk) {
      ask('Structuur voor \u201C' + (DOC_STYLES.find(d => d[0] === id) || [])[1] + '\u201D invoegen? Bestaande tekst blijft behouden als je annuleert.', { yes: 'Invoegen', no: 'Alleen stijl' }).then(ok => {
        if (ok) {
          const html = sk();
          if (!ed.innerText.trim()) ed.innerHTML = html;
          else ed.innerHTML = html + ed.innerHTML;
          flash('Structuur ingevoegd');
        } else flash('Documentstijl geselecteerd (geen structuur)');
      });
    }
  };
  docStyleGrp.append(docStylePick);

  vt(docStyleGrp, '\uD83D\uDCCB Structuur', 'Structuur van gekozen documentstijl invoegen', () => {
    const id = docStylePick.value;
    if (!id || !SKELETONS[id]) { flash('Kies eerst een documentstijl'); return; }
    const html = SKELETONS[id]();
    if (!ed.innerText.trim()) ed.innerHTML = html;
    else exec('insertHTML', html);
    flash('Structuur ingevoegd');
  });

  DOC_STYLES.filter(d => d[0]).slice(0, 6).forEach(([id, name]) => {
    vt(docStyleGrp, name.slice(0, 8), name + ' \u2014 structuur invoegen', () => {
      docStylePick.value = id;
      if (SKELETONS[id]) {
        const html = SKELETONS[id]();
        if (!ed.innerText.trim()) ed.innerHTML = html;
        else exec('insertHTML', html);
        flash(name + ' structuur ingevoegd');
      }
    });
  });

  const themeGrp = group('Thema', panels.design);
  const themePick = h('select', 'style-pick');
  THEMES.forEach(([id, name]) => {
    const o = h('option', '', name); o.value = id; themePick.append(o);
  });
  themePick.value = docAttrs.theme || '';
  themePick.onchange = () => {
    docAttrs.theme = themePick.value;
    applyDocClasses();
    flash('Thema: ' + themePick.options[themePick.selectedIndex].text);
  };
  themeGrp.append(themePick);

  THEMES.forEach(([id, name, color]) => {
    if (!color) return;
    const sw = h('button', 'tb-swatch tb-theme-swatch'); sw.type = 'button';
    sw.style.background = color; sw.title = name;
    sw.onmousedown = e => e.preventDefault();
    sw.onclick = () => {
      themePick.value = id;
      docAttrs.theme = id;
      applyDocClasses();
      flash('Thema: ' + name);
    };
    themeGrp.append(sw);
  });

  const fontThemeGrp = group('Lettertype-thema', panels.design);
  const fontThemePick = h('select', 'style-pick');
  FONT_THEMES.forEach(([id, name]) => {
    const o = h('option', '', name); o.value = id; fontThemePick.append(o);
  });
  fontThemePick.value = docAttrs.font || '';
  fontThemePick.onchange = () => {
    docAttrs.font = fontThemePick.value;
    applyDocClasses();
    flash('Lettertype: ' + fontThemePick.options[fontThemePick.selectedIndex].text);
  };
  fontThemeGrp.append(fontThemePick);

  // ========== CONTROLEREN ==========
  const findGrp = group('Zoeken', panels.review);
  vt(findGrp, '\uD83D\uDD0D Zoeken', 'Zoeken in de tekst', async () => {
    const q = await ask('Zoeken naar\u2026', { input: true, yes: 'Zoeken' });
    if (!q) return;
    restore();
    if (window.find) { window.find(q, false, false, true); flash('Gevonden (of einde bereikt)'); }
    else flash('Zoekfunctie niet beschikbaar in deze browser');
  });
  vt(findGrp, '\uD83D\uDD00 Vervangen', 'Zoeken en vervangen', async () => {
    const q = await ask('Zoeken naar\u2026', { input: true, yes: 'Volgende' });
    if (!q) return;
    const r = await ask('Vervangen door\u2026', { input: true, yes: 'Vervangen' });
    if (r == null) return;
    restore();
    const walker = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT);
    let node, count = 0;
    const nodes = [];
    while ((node = walker.nextNode())) nodes.push(node);
    nodes.forEach(n => {
      if (n.nodeValue && n.nodeValue.includes(q)) {
        const parts = n.nodeValue.split(q);
        count += parts.length - 1;
        n.nodeValue = parts.join(r);
      }
    });
    flash(count ? count + '\u00D7 vervangen' : 'Niets gevonden');
  });
  vt(findGrp, '\uD83D\uDD00 Alles', 'Alles vervangen', async () => {
    const q = await ask('Zoeken naar\u2026', { input: true, yes: 'Volgende' });
    if (!q) return;
    const r = await ask('Vervangen door\u2026', { input: true, yes: 'Alles vervangen' });
    if (r == null) return;
    const walker = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT);
    let node, count = 0;
    const nodes = [];
    while ((node = walker.nextNode())) nodes.push(node);
    nodes.forEach(n => {
      if (n.nodeValue && n.nodeValue.includes(q)) {
        const parts = n.nodeValue.split(q);
        count += parts.length - 1;
        n.nodeValue = parts.join(r);
      }
    });
    flash(count ? count + '\u00D7 vervangen' : 'Niets gevonden');
  });

  const spellGrp = group('Taal', panels.review);
  vt(spellGrp, 'ABC\u2713', 'Spellingscontrole (browser)', () => {
    ed.spellcheck = true;
    ed.focus();
    flash('Browser-spellingscontrole actief (rood onderstreept)');
  });
  vt(spellGrp, '\uD83D\uDCCA', 'Woorden tellen', () => {
    const text = (ed.innerText || '').trim();
    const words = text ? text.split(/\s+/).filter(Boolean).length : 0;
    const chars = text.length;
    const paras = ed.querySelectorAll('p, h2, h3, h4, li').length;
    flash(words + ' woorden \u00B7 ' + chars + ' tekens \u00B7 ' + paras + ' alinea\u2019s');
  });
  vt(spellGrp, '\uD83D\uDD24', 'Tekst selecteren', () => {
    const range = document.createRange();
    range.selectNodeContents(ed);
    const s = getSelection(); s.removeAllRanges(); s.addRange(range);
  });

  // ========== BESTAND ==========
  const exportGrp = group('Exporteren', panels.file);
  let lastTitle = 'document';

  vt(exportGrp, '\uD83D\uDCC4 PDF', 'Downloaden als PDF (afbeelding-PDF)', async () => {
    try {
      flash('PDF wordt gemaakt\u2026');
      await exportPdf(lastTitle, getHtml());
      flash('PDF gedownload');
    } catch (e) {
      flash('PDF mislukt: ' + (e.message || e));
      console.error(e);
    }
  });
  vt(exportGrp, '\uD83D\uDDA8 Afdrukken', 'Afdrukken / Opslaan als PDF (scherpe tekst)', () => {
    try {
      printDoc(lastTitle, getHtml());
      flash('Afdrukvenster geopend');
    } catch (e) {
      flash('Afdrukken mislukt: ' + (e.message || e));
    }
  });
  vt(exportGrp, '\uD83D\uDCDD Word', 'Downloaden als Word (.doc)', () => {
    try {
      exportWord(lastTitle, getHtml());
      flash('Word-bestand gedownload');
    } catch (e) {
      flash('Word-export mislukt: ' + (e.message || e));
    }
  });
  vt(exportGrp, '\u2B07 HTML', 'Downloaden als HTML-bestand', () => {
    const a = document.createElement('a');
    const html = '<!DOCTYPE html><html lang="nl"><head><meta charset="utf-8"><title>' + lastTitle.replace(/</g, '') + '</title></head><body>' + getHtml() + '</body></html>';
    a.href = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
    a.download = (lastTitle || 'document').toLowerCase().replace(/[^a-z0-9]+/gi, '-') + '.html';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    flash('HTML gedownload');
  });

  const infoGrp = group('Info', panels.file);
  vt(infoGrp, '\u2139', 'Documentinstellingen tonen', () => {
    const a = docAttrs;
    flash('Pagina: ' + a.page + ' ' + a.orient + ' \u00B7 marge ' + a.margin + ' \u00B7 kolommen ' + a.cols +
      (a.header ? ' \u00B7 kop' : '') + (a.footer ? ' \u00B7 voet' : '') + (a.pagenum ? ' \u00B7 n\u00BA' : '') +
      (a.theme ? ' \u00B7 thema ' + a.theme : '') + (a.watermark ? ' \u00B7 watermark' : ''));
  });

  // ========== MODE SWITCH ==========
  const switchBtn = h('button', 'mode-switch', '</> HTML tonen');
  switchBtn.type = 'button';
  switchBtn.title = 'Toon de HTML erachter';
  const setMode = m => {
    mode = m;
    ed.hidden = m === 'html';
    split.hidden = m !== 'html';
    visualTools.forEach(b => { b.hidden = m === 'html'; });
    htmlTools.forEach(b => { b.hidden = m !== 'html'; });
    if (m === 'visual') {
      if (src.value !== undefined) {
        const parsed = parseDoc(src.value);
        ed.innerHTML = parsed.inner || src.value;
        if (parsed.attrs) docAttrs = { ...docAttrs, ...parsed.attrs };
        applyDocClasses();
      }
      setTab(activeTab);
    } else {
      src.value = clean();
      livePrev();
    }
    switchBtn.textContent = m === 'html' ? '\u270E Terug naar schrijven' : '</> HTML tonen';
    switchBtn.title = m === 'html' ? 'Terug naar gewoon schrijven' : 'Toon de HTML erachter';
    const focusEl = m === 'html' ? src : ed;
    focusEl.focus();
    if (ed.dataset.init) {
      requestAnimationFrame(() => {
        const top = bar.getBoundingClientRect().top + window.scrollY - 12;
        window.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
      });
    }
  };
  const htmlTools = [];
  switchBtn.onclick = () => setMode(mode === 'html' ? 'visual' : 'html');
  bar.append(switchBtn);

  const addTool = (label, title, fn, { htmlOnly = false, cls = '', last = false } = {}) => {
    const b = tool(label, title, fn, cls);
    if (htmlOnly) { htmlTools.push(b); b.hidden = mode !== 'html'; }
    if (last) { b.style.marginLeft = 'auto'; bar.insertBefore(note, b); }
    return b;
  };
  bar.append(file);
  bar.append(note);

  ed.addEventListener('keydown', e => {
    if (e.ctrlKey || e.metaKey) {
      if (e.key === 'b') { e.preventDefault(); exec('bold'); }
      else if (e.key === 'i') { e.preventDefault(); exec('italic'); }
      else if (e.key === 'u') { e.preventDefault(); exec('underline'); }
      else if (e.key === 'z' && !e.shiftKey) { e.preventDefault(); exec('undo'); }
      else if (e.key === 'y' || (e.key === 'z' && e.shiftKey)) { e.preventDefault(); exec('redo'); }
    }
  });

  setHtml(initialHtml);
  const risky = /<script|<style|\son\w+=/i.test(initialHtml || '');
  setMode(risky ? 'html' : 'visual');
  if (risky) flash('Dit boek bevat code of eigen stijl; daarom opent het in de HTML-weergave.');

  const wrap = h('div', 'editor-ribbon'); wrap.append(bar);
  const spacer = h('div', 'editor-ribbon-spacer');
  const syncRibbonH = () => {
    const hgt = Math.ceil(wrap.getBoundingClientRect().height);
    if (hgt > 0) {
      spacer.style.height = hgt + 'px';
      document.documentElement.style.setProperty('--ribbon-h', hgt + 'px');
    }
  };
  requestAnimationFrame(syncRibbonH);
  window.addEventListener('resize', syncRibbonH);
  tabDefs.forEach(([id]) => {
    const prevFn = tabBtns[id].onclick;
    tabBtns[id].onclick = () => { prevFn(); requestAnimationFrame(syncRibbonH); };
  });
  const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(syncRibbonH) : null;
  if (ro) ro.observe(wrap);

  return {
    bar: wrap,
    spacer,
    area,
    getHtml,
    setHtml,
    flash,
    addTool,
    focus: () => (mode === 'html' ? src : ed).focus(),
    syncRibbonH,
    setTitle: t => { lastTitle = t || 'document'; }
  };
}
