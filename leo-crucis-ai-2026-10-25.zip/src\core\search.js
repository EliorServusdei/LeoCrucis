// Zoeken in de bibliotheek: volledig offline, werkt op data/search-index.json.
// Index opnieuw bouwen na elke inhoudswijziging:  npm run index
// Extra: woordenboek + bijbel (losse data, async).
const norm = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const squash = s => norm(s).replace(/æ/g, 'ae').replace(/œ/g, 'oe').replace(/j/g, 'i').replace(/v/g, 'u');
// Nederlandse bijbel: "Jezus" en "Jesus" moeten elkaar vinden; geen Latijnse i/j-vermenging.
function bibleNorm(s, lang) {
  let t = norm(String(s || '')).replace(/æ/g, 'ae').replace(/œ/g, 'oe');
  // veelvoorkomende spellingvarianten
  t = t.replace(/\bjezus\b/g, 'jesus').replace(/\bjézus\b/g, 'jesus');
  t = t.replace(/\bchristus\b/g, 'christus'); // blijft
  if (lang === 'la') {
    t = t.replace(/j/g, 'i').replace(/v/g, 'u');
  }
  return t;
}

let docs = null;
let extra = {}, removed = new Set();   // wijzigingen uit de ontwikkelaarsmodus
export function setOverlay(x, r) { extra = x || {}; removed = new Set(r || []); }
export function isIndexLoaded() { return !!docs; }

/** Status van zoek-caches (voor developer-paneel). */
export function getSearchCacheStats() {
  return {
    indexLoaded: !!docs,
    indexDocs: docs ? docs.length : 0,
    bijbelIndex: !!bijbelIdx,
    bijbelVerses: bijbelVerseCache ? bijbelVerseCache.length : 0,
    wbIndex: !!wbIndex,
  };
}

export async function loadIndex() {
  if (docs) return docs;
  const res = await fetch('data/search-index.json');
  if (!res.ok) throw new Error(`Zoekindex niet gevonden (${res.status}). Draai: npm run index`);
  docs = (await res.json()).map(d => ({ ...d, n: norm(d.text), nh: norm(d.heading + ' ' + d.title) }));
  return docs;
}

/** Voorwarmen op de achtergrond (negeert fouten). */
export function preloadIndexQuiet() {
  loadIndex().catch(() => {});
}

// Alle woorden moeten voorkomen (EN). Treffers in titel/kop wegen zwaarder.
// Geen limiet: alle passende groepen worden teruggegeven.
export function search(query, _limit) {
  const terms = norm(query).split(/\s+/).filter(t => t.length > 1);
  if (!terms.length || !docs) return [];
  const best = new Map();                      // per boek/app alleen de beste fragmenten
  const all = docs.filter(d => !removed.has(d.id) && !extra[d.id]).concat(...Object.values(extra).map(e => e.map(d => ({ ...d, n: norm(d.text), nh: norm(d.heading + ' ' + d.title) }))));
  for (const d of all) {
    if (!terms.every(t => d.n.includes(t) || d.nh.includes(t))) continue;
    let score = 0;
    for (const t of terms) {
      if (d.nh.includes(t)) score += 5;
      if (d.title && norm(d.title).startsWith(t)) score += 3;
      score += Math.min(3, d.n.split(t).length - 1);
    }
    const arr = best.get(d.id) || [];
    arr.push({ ...d, score });
    best.set(d.id, arr);
  }
  const groups = [...best.values()].map(a => {
    a.sort((x, y) => y.score - x.score);
    return { id: a[0].id, title: a[0].title, where: a[0].where, score: a[0].score + a.length, hits: a.slice(0, 3), kind: 'library', type: a[0].type || 'doc' };
  });
  return groups.sort((a, b) => b.score - a.score);
}

export function snippet(d, query, len = 160) {
  const terms = norm(query).split(/\s+/).filter(t => t.length > 1);
  const i = Math.max(0, Math.min(...terms.map(t => { const p = d.n.indexOf(t); return p < 0 ? 1e9 : p; })));
  const start = Math.max(0, i - 40);
  return (start ? '… ' : '') + d.text.slice(start, start + len) + (start + len < d.text.length ? ' …' : '');
}

// ---------- Woordenboek ----------
let wbIndex = null;
function wbFirstLetter(word) {
  let c = (word[0] || '#').toLowerCase();
  c = c.replace(/[äáàâ]/g, 'a').replace(/[ëéèê]/g, 'e')
       .replace(/[ïíìî]/g, 'i').replace(/[öóòô]/g, 'o')
       .replace(/[üúùû]/g, 'u').replace(/ç/g, 'c').replace(/ñ/g, 'n');
  if (c < 'a' || c > 'z') return '#';
  return c;
}

async function loadWbIndex() {
  if (wbIndex) return wbIndex;
  const res = await fetch('data/woordenboek/index.json');
  if (!res.ok) throw new Error('woordenboek-index');
  wbIndex = await res.json();
  return wbIndex;
}

async function loadWbLetter(L) {
  // Geen JS-heap-cache: opnieuw parsen bij elke zoekactie (browser HTTP-cache mag)
  const res = await fetch('data/woordenboek/' + encodeURIComponent(L) + '.json', { cache: 'force-cache' });
  if (!res.ok) throw new Error('letter ' + L);
  const data = await res.json();
  return Array.isArray(data) ? data : (data.words || data.entries || []);
}

/** Zoek in het offline woordenboek. Geeft resultaatgroepen in hetzelfde formaat als search().
 *  Geen limiet: alle treffers worden teruggegeven.
 */
export async function searchWoordenboek(query, _limit) {
  const nq = norm(query).trim();
  if (nq.length < 2) return [];
  try {
    await loadWbIndex();
  } catch {
    return [];
  }
  const startL = wbFirstLetter(nq);
  const order = [startL, ...Object.keys(wbIndex.letters || {}).filter(l => l !== startL)];
  const found = [];
  for (const L of order) {
    try {
      const data = await loadWbLetter(L);
      for (const e of data) {
        const nw = norm(e.w || e.word || '');
        if (!nw) continue;
        if (nw === nq || nw.startsWith(nq) || (nq.length >= 3 && nw.includes(nq))) {
          found.push(e);
        }
      }
    } catch { /* letter ontbreekt */ }
  }
  found.sort((a, b) => {
    const na = norm(a.w), nb = norm(b.w);
    const score = n => n === nq ? 0 : n.startsWith(nq) ? 1 : 2;
    const sa = score(na), sb = score(nb);
    if (sa !== sb) return sa - sb;
    return na.localeCompare(nb, 'nl');
  });
  if (!found.length) return [];
  return found.map((e, i) => {
    const defs = (e.d || e.defs || []).slice(0, 2);
    const text = defs.length ? defs.join(' · ') : '';
    const w = e.w || '';
    const nw = norm(w);
    const nq = norm(query).trim();
    let score = 25;
    if (nw === nq) score = 55;
    else if (nw.startsWith(nq)) score = 45;
    else score = 30;
    return {
      id: 'wb:' + w,
      title: w,
      where: 'Woordenboek',
      score: score - i * 0.01,
      kind: 'woordenboek',
      query: w, // open dit lemma
      hits: [{
        heading: '',
        title: w,
        text: text || w,
        n: norm(w + ' ' + text)
      }]
    };
  });
}

// ---------- Bijbel ----------
let bijbelIdx = null;
let bijbelVerseCache = null; // [{b, c, v, text, s}]
const BIJBEL_CACHE_VER = 2;
let bijbelCacheVer = 0;

async function loadBijbelIndex() {
  if (bijbelIdx) return bijbelIdx;
  const res = await fetch('data/bijbel/index.json');
  if (!res.ok) throw new Error('bijbel-index');
  bijbelIdx = await res.json();
  return bijbelIdx;
}

function defaultTranslation(idx) {
  const list = idx.translations || [];
  return list.find(t => t.id === 'canisius') || list.find(t => t.language === 'nl') || list[0];
}

async function ensureBijbelVerses(onProgress) {
  if (bijbelVerseCache && bijbelCacheVer === BIJBEL_CACHE_VER) return bijbelVerseCache;
  const idx = await loadBijbelIndex();
  const tr = defaultTranslation(idx);
  if (!tr) return [];
  const books = idx.books || [];
  const allowed = idx.booksByTranslation && idx.booksByTranslation[tr.id];
  const set = allowed ? new Set(allowed) : null;
  const list = set ? books.filter(b => set.has(b.osis)) : books;
  const out = [];
  let done = 0;
  for (let i = 0; i < list.length; i += 6) {
    const batch = list.slice(i, i + 6);
    await Promise.all(batch.map(async b => {
      try {
        const res = await fetch(`data/bijbel/${tr.id}/${b.osis}.json`);
        if (!res.ok) return;
        const data = await res.json();
        const chapters = Array.isArray(data) ? data : (data.c || data.chapters || []);
        chapters.forEach((verses, ci) => {
          (verses || []).forEach((text, vi) => {
            if (!text) return;
            out.push({
              b,
              c: ci + 1,
              v: vi + 1,
              text: String(text),
              s: bibleNorm(String(text), tr.language || 'nl')
            });
          });
        });
      } catch { /* skip */ }
      done++;
      if (onProgress) onProgress(done, list.length);
    }));
  }
  bijbelVerseCache = out;
  bijbelCacheVer = BIJBEL_CACHE_VER;
  return out;
}

/** Zoek in de bijbel (boeknamen + tekst). Geen limiet: alle treffers. */
export async function searchBijbel(query, _limit, onProgress) {
  const raw = String(query || '').trim();
  let idx;
  try {
    idx = await loadBijbelIndex();
  } catch {
    return [];
  }
  const tr = defaultTranslation(idx);
  const lang = (tr && tr.language) || 'nl';
  const words = bibleNorm(raw, lang).split(/[^a-z0-9]+/).filter(w => w.length >= 2);
  if (!words.length) return [];
  const groups = [];
  // 1) boeknamen
  const bookHits = (idx.books || []).filter(b => {
    const keys = [b.nl, b.la, b.osis].filter(Boolean).map(x => bibleNorm(x, lang).replace(/[^a-z0-9]/g, ''));
    const q = words.join('');
    return keys.some(k => k.includes(q) || words.every(w => k.includes(w)));
  });
  bookHits.forEach((b, i) => {
    groups.push({
      id: 'bijbel-book:' + b.osis,
      title: b.nl,
      where: 'Bijbel · ' + (b.t === 'NT' ? 'Nieuwe Testament' : 'Oude Testament'),
      score: 38 - i * 0.01,
      kind: 'bijbel',
      query: raw,
      osis: b.osis,
      book: b.nl,
      testament: b.t === 'NT' ? 'NT' : 'OT',
      hits: [{
        heading: '',
        title: b.nl,
        text: `${b.ch} hoofdstukken`,
        n: bibleNorm(b.nl + ' ' + (b.la || ''), lang),
        osis: b.osis,
        chapter: 1
      }]
    });
  });
  // 2) tekst — alle verzen in alle boeken
  try {
    const verses = await ensureBijbelVerses(onProgress);
    const hits = [];
    for (const r of verses) {
      if (words.every(w => r.s.includes(w))) hits.push(r);
    }
    hits.forEach((r, i) => {
      groups.push({
        id: 'bijbel:' + r.b.osis + ':' + r.c + ':' + r.v,
        title: `${r.b.nl} ${r.c},${r.v}`,
        where: 'Bijbel · vers',
        score: 32 - Math.min(i, 1000) * 0.001,
        kind: 'bijbel',
        query: raw,
        osis: r.b.osis,
        book: r.b.nl,
        testament: r.b.t === 'NT' ? 'NT' : 'OT',
        hits: [{
          heading: '',
          title: `${r.b.nl} ${r.c},${r.v}`,
          text: r.text,
          n: r.s,
          osis: r.b.osis,
          chapter: r.c,
          verse: r.v
        }]
      });
    });
  } catch {
    /* tekstzoeken optioneel */
  }
  return groups;
}

// ---------- Foto's (Kunstgalerij: titels en bestandsnamen uit de metadata) ----------
export function searchFotos(query, _limit) {
  const terms = norm(query).split(/\s+/).filter(t => t.length > 1);
  if (!terms.length) return [];
  let list = [];
  try { const raw = JSON.parse(localStorage.getItem('lc-gallery-meta-v1') || '[]'); if (Array.isArray(raw)) list = raw; } catch (_) {}
  const out = [];
  for (const m of list) {
    const hay = norm([m.title, m.fileName, m.desc, m.description, ...(Array.isArray(m.tags) ? m.tags : [])].filter(Boolean).join(' '));
    if (!terms.every(t => hay.includes(t))) continue;
    out.push({
      id: 'foto:' + m.id, title: m.title || m.fileName || 'Foto', where: 'Kunstgalerij · foto',
      score: 34, kind: 'foto', type: 'foto',
      hits: [{ heading: '', title: m.title || '', text: m.fileName || '', n: hay }]
    });
  }
  return out;
}


/** Suggesties terwijl je typt: titels, woordenboek, bijbelboeken. */
export async function suggest(query, limit = 7) {
  const q = norm(String(query || '')).trim();
  if (q.length < 1) return [];
  const out = [];
  const seen = new Set();

  const push = (text, kind, where, score) => {
    const key = norm(text);
    if (!key || seen.has(key)) return;
    seen.add(key);
    out.push({ text, kind, where, score });
  };

  // Bibliotheek-titels
  try {
    await loadIndex();
    const all = (docs || []).filter(d => !removed.has(d.id));
    for (const d of all) {
      const title = (d.title || '').trim();
      if (!title) continue;
      const nt = norm(title);
      if (nt.startsWith(q) || (q.length >= 3 && nt.includes(q))) {
        push(title, 'library', d.where || 'Bibliotheek', nt.startsWith(q) ? 50 : 30);
      }
    }
  } catch { /* index nog niet geladen */ }

  // Woordenboek (prefix / bevat)
  try {
    const wb = await searchWoordenboek(query, Math.max(7, limit));
    for (const g of wb) {
      push(g.title, 'woordenboek', 'Woordenboek', g.score || 40);
    }
  } catch { /* optioneel */ }

  // Bijbelboeken
  try {
    const idx = await loadBijbelIndex();
    for (const b of (idx.books || [])) {
      const name = (b.nl || '').trim();
      if (!name) continue;
      const nt = norm(name);
      if (nt.startsWith(q) || (q.length >= 2 && nt.includes(q))) {
        push(name, 'bijbel', 'Bijbel', nt.startsWith(q) ? 48 : 28);
      }
    }
  } catch { /* optioneel */ }

  // Apps (Atlas, Codex, Bijbelgrafieken, …)
  try {
    for (const g of searchApps(query)) {
      push(g.title, 'app', g.where || 'App', g.score || 70);
    }
  } catch { /* optioneel */ }

  // Kortere, sterkere matches eerst (minder ruis)
  out.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    const la = a.text.length, lb = b.text.length;
    if (la !== lb) return la - lb;
    return a.text.localeCompare(b.text, 'nl');
  });
  return out.slice(0, limit);
}


/** Mini-apps en tools die je via zoeken moet kunnen openen.
 *  Aliassen: ook “canoniek recht”, “atlas”, “grafieken”, … moeten matchen.
 */
/** Soorten die als spel (niet als app) worden getoond in zoeken. */
const GAME_KINDS = new Set(['memory', 'snake', 'bke', 'tetris', 'mastermind', 'connect4', 'speeltoestel']);

const LEO_APPS = [
  { kind: 'bible', title: 'Bijbel', aliases: ['bijbel', 'bible', 'heilige schrift', 'schrift'], where: 'App · studie' },
  { kind: 'codex', title: 'Canoniek Recht', aliases: ['canoniek recht', 'codex', 'codex 1917', 'cic', 'canoniek', 'kerkelijk recht', 'ius canonicum'], where: 'App · studie' },
  { kind: 'xref-map', title: 'Bijbelgrafieken', aliases: ['bijbelgrafieken', 'kruisverwijzingen', 'xref', 'grafieken', 'bijbel kaart', 'verwijzingenkaart'], where: 'App · studie' },
  { kind: 'verse-study', title: 'Verdieping', aliases: ['verdieping', 'woordstudie', 'versstudie'], where: 'App · studie' },
  { kind: 'woordenboek', title: 'Woordenboek', aliases: ['woordenboek', 'dictionary', 'lexicon'], where: 'App · taal' },
  { kind: 'maps', title: 'Atlas', aliases: ['atlas', 'kaarten', 'maps', 'kaart', 'geografie'], where: 'App · kaart' },
  { kind: 'gallery', title: 'Kunstgalerij', aliases: ['kunstgalerij', 'galerij', 'gallery', 'kunst'], where: 'App · beeld' },
  { kind: 'album', title: 'Fotoalbum', aliases: ['fotoalbum', 'album', 'fotos', "foto's"], where: 'App · beeld' },
  { kind: 'calendar', title: 'Kalender', aliases: ['kalender', 'agenda', 'calendar', 'feestdagen', 'liturgische kalender'], where: 'App · agenda' },
  { kind: 'notes', title: 'Notities', aliases: ['notities', 'notes', 'notitie'], where: 'App · productiviteit' },
  { kind: 'audio', title: 'Audiospeler', aliases: ['audiospeler', 'audio', 'muziek', 'luisteren'], where: 'App · media' },
  { kind: 'video', title: 'Videospeler', aliases: ['videospeler', 'video', 'film'], where: 'App · media' },
  { kind: 'memory', title: 'Memory', aliases: ['memory', 'memorie', 'memoryspel'], where: 'Spel' },
  { kind: 'snake', title: 'Slang', aliases: ['slang', 'snake'], where: 'Spel' },
  { kind: 'bke', title: 'BKE', aliases: ['bke', 'boter kaas eieren', 'tic tac toe', 'tictactoe'], where: 'Spel' },
  { kind: 'tetris', title: 'Tetris', aliases: ['tetris', 'blokken'], where: 'Spel' },
  { kind: 'mastermind', title: 'Mastermind', aliases: ['mastermind', 'kleurencode'], where: 'Spel' },
  { kind: 'connect4', title: '4 op een rij', aliases: ['4 op een rij', 'vier op een rij', 'connect4', 'connect four'], where: 'Spel' },
  { kind: 'speeltoestel', title: 'Speeltoestel', aliases: ['speeltoestel', 'console', 'handheld', 'gameboy'], where: 'Spel' },
  { kind: 'focus', title: 'Focusblok', aliases: ['focusblok', 'focus', 'studieblok', 'pomodoro'], where: 'App · studie' },
  { kind: 'doc', title: 'Editor', aliases: ['editor', 'nieuw document', 'schrijven'], where: 'App · maken' },
  { kind: 'pptx', title: 'Presentatiemaker', aliases: ['presentatiemaker', 'presentatie', 'powerpoint', 'pptx', 'dia'], where: 'App · maken' },
  { kind: 'xlsx', title: 'Spreadsheetmaker', aliases: ['spreadsheetmaker', 'spreadsheet', 'excel', 'xlsx', 'rekenblad'], where: 'App · maken' },
];

/** Zoek apps op titel en aliassen. */
export function searchApps(query) {
  const terms = norm(query).split(/\s+/).filter(t => t.length > 1);
  if (!terms.length) {
    // één kort woord (bijv. "atlas", "codex") mag ook
    const one = norm(String(query || '').trim());
    if (one.length < 2) return [];
    terms.push(one);
  }
  const out = [];
  for (const app of LEO_APPS) {
    const hay = norm([app.title, ...(app.aliases || [])].join(' '));
    if (!terms.every(t => hay.includes(t))) continue;
    // score: exacte titel-match hoger
    const nt = norm(app.title);
    let score = 70;
    if (terms.some(t => nt === t || nt.startsWith(t))) score = 95;
    else if (terms.some(t => (app.aliases || []).some(a => norm(a) === t))) score = 88;
    else if (terms.some(t => nt.includes(t))) score = 80;
    const isGame = GAME_KINDS.has(app.kind);
    out.push({
      id: (isGame ? 'game:' : 'app:') + app.kind,
      title: app.title,
      where: app.where || (isGame ? 'Spel' : 'App'),
      score,
      kind: isGame ? 'game' : 'app',
      appKind: app.kind,
      type: isGame ? 'game' : 'app',
      hits: [{
        heading: isGame ? 'Spel' : 'App',
        title: app.title,
        text: isGame
          ? ('Open het spel “' + app.title + '”')
          : ('Open de app “' + app.title + '”'),
        n: hay
      }]
    });
  }
  return out;
}

/** Gecombineerd zoeken: apps + bibliotheek + woordenboek + bijbel + foto's.
 *  Geen limieten: alle treffers uit elke bron.
 */
export async function searchAll(query, opts = {}) {
  const onBijbelProgress = opts.onBijbelProgress;
  const lib = search(query);
  const apps = searchApps(query);
  const [wb, bb] = await Promise.all([
    searchWoordenboek(query).catch(() => []),
    searchBijbel(query, undefined, onBijbelProgress).catch(() => [])
  ]);
  return [...apps, ...wb, ...bb, ...lib, ...searchFotos(query)].sort((a, b) => b.score - a.score);
}
