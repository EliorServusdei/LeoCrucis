/**
 * Slim Budgetter — Leo Crucis (uitgebreid)
 * Gepland vs werkelijk, schulddetail, doelen↔sparen, trends, undo,
 * dialogen, sjablonen-menu, print, a11y, profiel.
 * Opslag: apps/budgetter/budget.json
 */

import { inTauri, readFile, writeFile } from '../core/edit.js';

const USER_BUDGET = 'apps/budgetter/budget.json';
const CURRENCIES = ['EUR', 'USD', 'GBP', 'CHF'];
const UNDO_MAX = 25;

const TEMPLATES = {
  standaard: {
    label: 'Standaard',
    income: [
      { label: 'Netto Salaris', amount: 2850, planned: 2850 },
      { label: 'Toeslagen / Bijverdiensten', amount: 150, planned: 150 }
    ],
    needs: [
      { label: 'Huur / Hypotheek', amount: 950, planned: 950, category: 'wonen', dueDay: 1 },
      { label: 'Boodschappen', amount: 400, planned: 400, category: 'voeding' },
      { label: 'Energiekosten & Water', amount: 160, planned: 160, category: 'wonen', dueDay: 15 },
      { label: 'Zorgverzekering & Overige', amount: 150, planned: 150, category: 'zorg', dueDay: 1 },
      { label: 'Vervoer (OV / Benzine)', amount: 140, planned: 140, category: 'vervoer' }
    ],
    wants: [
      { label: 'Abonnementen', amount: 35, planned: 35, category: 'abonnementen', dueDay: 5 },
      { label: 'Uitgaan & Horeca', amount: 150, planned: 150, category: 'vrije tijd' },
      { label: 'Kleding & Winkelen', amount: 100, planned: 100, category: 'shopping' },
      { label: 'Hobby & Sport', amount: 50, planned: 50, category: 'vrije tijd' }
    ],
    savings: [
      { label: 'Spaarrekening Buffer', amount: 300, planned: 300, category: 'buffer' },
      { label: 'Beleggen / Pensioen', amount: 150, planned: 150, category: 'beleggen' }
    ],
    debts: []
  },
  student: {
    label: 'Student',
    income: [
      { label: 'Studiefinanciering', amount: 450, planned: 450 },
      { label: 'Bijbaan', amount: 400, planned: 400 }
    ],
    needs: [
      { label: 'Huur / Kamer', amount: 450, planned: 450, category: 'wonen', dueDay: 1 },
      { label: 'Boodschappen', amount: 200, planned: 200, category: 'voeding' },
      { label: 'OV-kaart', amount: 100, planned: 100, category: 'vervoer' },
      { label: 'Zorgverzekering', amount: 120, planned: 120, category: 'zorg', dueDay: 1 }
    ],
    wants: [
      { label: 'Uitgaan', amount: 80, planned: 80, category: 'vrije tijd' },
      { label: 'Abonnementen', amount: 20, planned: 20, category: 'abonnementen' }
    ],
    savings: [{ label: 'Spaarpot', amount: 50, planned: 50, category: 'buffer' }],
    debts: [{ label: 'Studieschuld', amount: 50, planned: 50, category: 'studie', remaining: 15000, interest: 2.5, endDate: '' }]
  },
  gezin: {
    label: 'Gezin',
    income: [
      { label: 'Salaris partner 1', amount: 3200, planned: 3200 },
      { label: 'Salaris partner 2', amount: 2400, planned: 2400 },
      { label: 'Kindgebonden budget', amount: 200, planned: 200 }
    ],
    needs: [
      { label: 'Hypotheek / Huur', amount: 1400, planned: 1400, category: 'wonen', dueDay: 1 },
      { label: 'Boodschappen', amount: 650, planned: 650, category: 'voeding' },
      { label: 'Energie & water', amount: 250, planned: 250, category: 'wonen' },
      { label: 'Zorgverzekeringen', amount: 320, planned: 320, category: 'zorg' },
      { label: 'Kinderopvang / school', amount: 400, planned: 400, category: 'gezin' },
      { label: 'Vervoer', amount: 280, planned: 280, category: 'vervoer' }
    ],
    wants: [
      { label: 'Uitjes & hobby', amount: 200, planned: 200, category: 'vrije tijd' },
      { label: 'Abonnementen', amount: 50, planned: 50, category: 'abonnementen' }
    ],
    savings: [
      { label: 'Buffer', amount: 400, planned: 400, category: 'buffer' },
      { label: 'Pensioen / beleggen', amount: 300, planned: 300, category: 'beleggen' }
    ],
    debts: [{ label: 'Extra aflossing hypotheek', amount: 100, planned: 100, category: 'wonen', remaining: 0, interest: 0, endDate: '' }]
  },
  zzp: {
    label: 'ZZP',
    income: [
      { label: 'Omzet / facturen (netto)', amount: 4500, planned: 4500 },
      { label: 'Overig', amount: 0, planned: 0 }
    ],
    needs: [
      { label: 'Zakelijke kosten', amount: 200, planned: 200, category: 'werk' },
      { label: 'Huur / hypotheek', amount: 1100, planned: 1100, category: 'wonen', dueDay: 1 },
      { label: 'Boodschappen', amount: 350, planned: 350, category: 'voeding' },
      { label: 'Zorgverzekering', amount: 150, planned: 150, category: 'zorg' },
      { label: 'AOV / verzekeringen', amount: 250, planned: 250, category: 'zorg' },
      { label: 'Vervoer', amount: 180, planned: 180, category: 'vervoer' }
    ],
    wants: [
      { label: 'Vrije tijd', amount: 150, planned: 150, category: 'vrije tijd' },
      { label: 'Abonnementen', amount: 40, planned: 40, category: 'abonnementen' }
    ],
    savings: [
      { label: 'Belastingreservering', amount: 900, planned: 900, category: 'belasting' },
      { label: 'Buffer', amount: 300, planned: 300, category: 'buffer' },
      { label: 'Pensioen', amount: 200, planned: 200, category: 'beleggen' }
    ],
    debts: []
  }
};

function monthKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function monthLabel(key) {
  const [y, m] = key.split('-').map(Number);
  if (!y || !m) return key;
  const name = new Date(y, m - 1, 1).toLocaleDateString('nl-NL', { month: 'long', year: 'numeric' });
  return name.charAt(0).toUpperCase() + name.slice(1);
}

function uid(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
}

function itemFrom(partial, isDebt = false) {
  const amount = Number(partial.amount) || 0;
  const planned = partial.planned != null ? Number(partial.planned) || 0 : amount;
  const base = {
    id: partial.id || uid('i'),
    label: String(partial.label || 'Onbenoemd'),
    amount,
    planned,
    note: String(partial.note || ''),
    category: String(partial.category || ''),
    dueDay: partial.dueDay ? Math.min(28, Math.max(1, Number(partial.dueDay) || 0)) : ''
  };
  if (isDebt) {
    base.remaining = Number(partial.remaining) || 0;
    base.interest = Number(partial.interest) || 0;
    base.endDate = String(partial.endDate || '');
  }
  return base;
}

function emptyMonthFromTemplate(tplKey = 'standaard') {
  const t = TEMPLATES[tplKey] || TEMPLATES.standaard;
  return {
    income: (t.income || []).map((x) => itemFrom(x)),
    needs: (t.needs || []).map((x) => itemFrom(x)),
    wants: (t.wants || []).map((x) => itemFrom(x)),
    savings: (t.savings || []).map((x) => itemFrom(x)),
    debts: (t.debts || []).map((x) => itemFrom(x, true)),
    monthNote: ''
  };
}

function defaultStore() {
  const key = monthKey();
  return {
    version: 3,
    currency: 'EUR',
    profile: 'Standaard',
    activeMonth: key,
    months: { [key]: emptyMonthFromTemplate('standaard') },
    goals: [
      { id: 'goal_1', label: 'Noodbuffer', target: 5000, current: 1200, note: '3–6 maanden lasten', linkedCategory: 'buffer' },
      { id: 'goal_2', label: 'Vakantie', target: 1500, current: 400, note: '', linkedCategory: '' }
    ],
    onboardingDone: false
  };
}

function normalizeStore(raw) {
  if (raw && !raw.months && (raw.income || raw.needs)) {
    const key = monthKey();
    return normalizeStore({
      version: 3,
      currency: 'EUR',
      profile: 'Standaard',
      activeMonth: key,
      months: {
        [key]: {
          income: raw.income || [],
          needs: raw.needs || [],
          wants: raw.wants || [],
          savings: raw.savings || [],
          debts: raw.debts || [],
          monthNote: ''
        }
      },
      goals: raw.goals || defaultStore().goals,
      onboardingDone: true
    });
  }
  const base = defaultStore();
  if (!raw || typeof raw !== 'object') return base;
  const out = {
    version: 3,
    currency: CURRENCIES.includes(raw.currency) ? raw.currency : 'EUR',
    profile: String(raw.profile || 'Standaard').slice(0, 40),
    activeMonth: raw.activeMonth || monthKey(),
    months: {},
    goals: [],
    onboardingDone: !!raw.onboardingDone
  };
  const months = raw.months && typeof raw.months === 'object' ? raw.months : {};
  for (const [k, m] of Object.entries(months)) {
    if (!m || typeof m !== 'object') continue;
    out.months[k] = {
      income: (m.income || []).map((x) => itemFrom(x)),
      needs: (m.needs || []).map((x) => itemFrom(x)),
      wants: (m.wants || []).map((x) => itemFrom(x)),
      savings: (m.savings || []).map((x) => itemFrom(x)),
      debts: (m.debts || []).map((x) => itemFrom(x, true)),
      monthNote: String(m.monthNote || '')
    };
  }
  if (!Object.keys(out.months).length) {
    out.months[out.activeMonth] = emptyMonthFromTemplate('standaard');
  }
  if (!out.months[out.activeMonth]) {
    out.activeMonth = Object.keys(out.months).sort().pop();
  }
  out.goals = Array.isArray(raw.goals)
    ? raw.goals.map((g) => ({
        id: g.id || uid('goal'),
        label: String(g.label || 'Doel'),
        target: Number(g.target) || 0,
        current: Number(g.current) || 0,
        note: String(g.note || ''),
        linkedCategory: String(g.linkedCategory || '')
      }))
    : defaultStore().goals;
  return out;
}

async function fetchBundled() {
  const candidates = [];
  try {
    candidates.push(new URL('./budgetter/budget.json', import.meta.url).href);
  } catch (_) {}
  candidates.push('apps/budgetter/budget.json', '/apps/budgetter/budget.json');
  for (const url of candidates) {
    try {
      const res = await fetch(url, { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data && typeof data === 'object') return data;
      }
    } catch (_) {}
  }
  return null;
}

async function loadStore() {
  if (inTauri) {
    try {
      const text = await readFile(USER_BUDGET);
      if (text) return normalizeStore(JSON.parse(text));
    } catch (_) {}
  }
  const bundled = await fetchBundled();
  if (bundled) return normalizeStore(bundled);
  return defaultStore();
}

async function saveStore(data) {
  const json = JSON.stringify(data, null, 2);
  if (inTauri) {
    try {
      await writeFile(USER_BUDGET, json);
      return { ok: true, via: 'file' };
    } catch (e) {
      return { ok: false, via: 'file', error: String(e && e.message || e) };
    }
  }
  return { ok: false, via: 'memory', error: 'Geen bestandsopslag buiten Tauri — gebruik Export.' };
}

function el(tag, className, text) {
  const n = document.createElement(tag);
  if (className) n.className = className;
  if (text != null) n.textContent = text;
  return n;
}

function formatMoney(val, currency) {
  try {
    return new Intl.NumberFormat('nl-NL', { style: 'currency', currency: currency || 'EUR' }).format(val || 0);
  } catch {
    return `€ ${(Number(val) || 0).toFixed(2)}`;
  }
}

function sumField(arr, field) {
  return (arr || []).reduce((s, i) => s + (Number(i[field]) || 0), 0);
}

function shiftMonth(key, delta) {
  const [y, m] = key.split('-').map(Number);
  return monthKey(new Date(y, m - 1 + delta, 1));
}

function downloadBlob(filename, text, mime) {
  const blob = new Blob([text], { type: mime || 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

function monthToCsv(month) {
  const rows = [['groep', 'label', 'categorie', 'gepland', 'werkelijk', 'verschil', 'betaaldag', 'restant', 'rente', 'einddatum', 'notitie']];
  for (const g of ['income', 'needs', 'wants', 'savings', 'debts']) {
    for (const it of month[g] || []) {
      const planned = Number(it.planned) || 0;
      const amount = Number(it.amount) || 0;
      rows.push([
        g, it.label, it.category || '', String(planned), String(amount), String(amount - planned),
        it.dueDay || '', it.remaining != null ? String(it.remaining) : '',
        it.interest != null ? String(it.interest) : '', it.endDate || '',
        (it.note || '').replace(/\n/g, ' ')
      ]);
    }
  }
  return rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
}

function monthBalance(m) {
  if (!m) return null;
  const inc = sumField(m.income, 'amount');
  const out = sumField(m.needs, 'amount') + sumField(m.wants, 'amount') + sumField(m.savings, 'amount') + sumField(m.debts, 'amount');
  return inc - out;
}

export function createBudgetterApp() {
  const root = el('div', 'app-panel mini-app-root budget-app');
  root.setAttribute('data-kind', 'budgetter');
  root.setAttribute('role', 'main');
  root.setAttribute('aria-label', 'Slim Budgetter');

  let store = defaultStore();
  let saveTimer = null;
  let destroyed = false;
  const undoStack = [];

  const GROUP_META = {
    income: { title: 'Inkomsten', desc: 'Gepland en werkelijk (netto)', add: 'Inkomstenbron' },
    needs: { title: 'Vaste lasten & noodzakelijk', desc: 'Behoeften · optioneel betaaldag', add: 'Vaste last' },
    wants: { title: 'Variabel & wensen', desc: 'Levensstijl', add: 'Variabele post' },
    savings: { title: 'Sparen & beleggen', desc: 'Koppelbaar aan doelen via categorie', add: 'Spaarpost' },
    debts: { title: 'Schulden & aflossing', desc: 'Maandbedrag, restant, rente, einddatum', add: 'Schuldpost' }
  };

  /* —— Modal —— */
  const modal = el('div', 'budget-modal');
  modal.hidden = true;
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');
  const modalBackdrop = el('div', 'budget-modal-backdrop');
  const modalBox = el('div', 'budget-modal-box');
  const modalTitle = el('h2', 'budget-modal-title', '');
  const modalBody = el('div', 'budget-modal-body');
  const modalActions = el('div', 'budget-modal-actions');
  modalBox.append(modalTitle, modalBody, modalActions);
  modal.append(modalBackdrop, modalBox);
  root.append(modal);

  function closeModal() {
    modal.hidden = true;
    modalBody.replaceChildren();
    modalActions.replaceChildren();
  }

  function openModal(title, bodyNode, actions) {
    modalTitle.textContent = title;
    modalBody.replaceChildren(bodyNode);
    modalActions.replaceChildren();
    (actions || []).forEach((a) => modalActions.append(a));
    modal.hidden = false;
    const focusable = modalBox.querySelector('button, [href], input, select, textarea');
    if (focusable) focusable.focus();
  }

  function confirmDialog(message) {
    return new Promise((resolve) => {
      const p = el('p', 'budget-modal-text', message);
      const ok = el('button', 'budget-btn budget-btn-primary', 'Bevestigen');
      ok.type = 'button';
      const cancel = el('button', 'budget-btn budget-btn-ghost', 'Annuleren');
      cancel.type = 'button';
      ok.onclick = () => { closeModal(); resolve(true); };
      cancel.onclick = () => { closeModal(); resolve(false); };
      openModal('Bevestigen', p, [cancel, ok]);
    });
  }

  modalBackdrop.onclick = closeModal;

  /* —— Toolbar —— */
  const toolbar = el('div', 'budget-toolbar');
  const titleWrap = el('div', 'budget-title-wrap');
  titleWrap.append(el('h1', 'budget-title', 'Slim Budgetter'));
  const sub = el('p', 'budget-sub', '');
  titleWrap.append(sub);

  const tools = el('div', 'budget-tools');
  const profileIn = el('input', 'budget-profile');
  profileIn.type = 'text';
  profileIn.placeholder = 'Profiel / huishouden';
  profileIn.setAttribute('aria-label', 'Profielnaam');
  profileIn.title = 'Profiel of huishouden';

  const currencySel = el('select', 'budget-select');
  currencySel.setAttribute('aria-label', 'Valuta');
  CURRENCIES.forEach((c) => {
    const o = el('option', '', c);
    o.value = c;
    currencySel.append(o);
  });

  function toolBtn(label, title) {
    const b = el('button', 'budget-btn budget-btn-ghost', label);
    b.type = 'button';
    if (title) b.title = title;
    return b;
  }

  const btnUndo = toolBtn('Ongedaan', 'Laatste wijziging terug (Ctrl+Z)');
  const btnExport = toolBtn('Export', 'JSON exporteren (Ctrl+E)');
  const btnImport = toolBtn('Import', 'JSON importeren');
  const importFile = el('input', '');
  importFile.type = 'file';
  importFile.accept = '.json,application/json';
  importFile.hidden = true;
  const btnCsv = toolBtn('CSV', 'Huidige maand als CSV');
  const btnPrint = toolBtn('Print', 'Afdrukken');
  const btnTemplate = toolBtn('Sjabloon', 'Maand vullen met sjabloon');

  tools.append(profileIn, currencySel, btnUndo, btnExport, btnImport, importFile, btnCsv, btnPrint, btnTemplate);
  toolbar.append(titleWrap, tools);
  root.append(toolbar);

  /* —— Periode —— */
  const periodBar = el('div', 'budget-period');
  const prevBtn = el('button', 'budget-nav', '‹');
  prevBtn.type = 'button';
  prevBtn.setAttribute('aria-label', 'Vorige maand');
  const nextBtn = el('button', 'budget-nav', '›');
  nextBtn.type = 'button';
  nextBtn.setAttribute('aria-label', 'Volgende maand');
  const periodLabel = el('div', 'budget-period-label', '');
  const periodMeta = el('div', 'budget-period-meta', '');
  const periodCenter = el('div', 'budget-period-center');
  periodCenter.append(periodLabel, periodMeta);
  const copyBtn = toolBtn('Kopieer vorige', 'Posten van vorige maand overnemen');
  periodBar.append(prevBtn, periodCenter, nextBtn, copyBtn);
  root.append(periodBar);

  /* —— Onboarding —— */
  const onboard = el('div', 'budget-onboard');
  onboard.hidden = true;
  onboard.innerHTML = `
    <h2>Welkom bij Slim Budgetter</h2>
    <p>Plan <strong>gepland vs werkelijk</strong>, volg doelen, schulden en maanden. Data in <code>apps/budgetter/budget.json</code>. Buiten Tauri: <strong>Export</strong>.</p>
    <ul>
      <li>Gepland en werkelijk per post · betaaldagen bij lasten</li>
      <li>Schulden: restant, rente, einddatum</li>
      <li>Doelen koppelen aan spaarcategorie · trends over maanden</li>
      <li><kbd>Ctrl</kbd>+<kbd>S</kbd> opslaan · <kbd>Ctrl</kbd>+<kbd>E</kbd> export · <kbd>Ctrl</kbd>+<kbd>Z</kbd> ongedaan</li>
    </ul>
  `;
  const onboardBtn = el('button', 'budget-btn budget-btn-primary', 'Aan de slag');
  onboardBtn.type = 'button';
  onboard.append(onboardBtn);
  root.append(onboard);

  /* —— KPI —— */
  const kpiGrid = el('div', 'budget-kpi');
  const kpiDefs = [
    { key: 'income', label: 'Inkomsten' },
    { key: 'expenses', label: 'Lasten' },
    { key: 'savings', label: 'Sparen' },
    { key: 'debts', label: 'Aflossing' },
    { key: 'balance', label: 'Vrij besteedbaar' },
    { key: 'variance', label: 'Vs gepland' }
  ];
  const kpiEls = {};
  for (const d of kpiDefs) {
    const card = el('div', 'budget-kpi-card');
    card.dataset.kpi = d.key;
    const lab = el('div', 'budget-kpi-label', d.label);
    const val = el('div', 'budget-kpi-value', '—');
    const hint = el('div', 'budget-kpi-hint', '');
    card.append(lab, val, hint);
    kpiGrid.append(card);
    kpiEls[d.key] = { card, val, hint };
  }
  root.append(kpiGrid);

  /* —— Analyse —— */
  const analysis = el('div', 'budget-analysis');

  const ruleCard = el('div', 'budget-card');
  ruleCard.append(el('h2', 'budget-card-title', '50/30/20 (werkelijk)'));
  ruleCard.append(el('p', 'budget-card-desc', 'Behoeften + aflossing · wensen · sparen'));
  const ruleRows = {};
  for (const [key, label, tone] of [
    ['needs', 'Behoeften + aflossing (~50%)', 'needs'],
    ['wants', 'Wensen (~30%)', 'wants'],
    ['savings', 'Sparen (~20%)', 'savings']
  ]) {
    const row = el('div', 'budget-rule');
    const head = el('div', 'budget-rule-head');
    const name = el('span', '', label);
    const pct = el('span', 'budget-rule-pct', '0%');
    head.append(name, pct);
    const track = el('div', 'budget-bar-track');
    const fill = el('div', `budget-bar-fill budget-bar-${tone}`);
    track.append(fill);
    row.append(head, track);
    ruleCard.append(row);
    ruleRows[key] = { pct, fill };
  }
  const ruleTip = el('div', 'budget-tip', '');
  ruleCard.append(ruleTip);

  const goalsCard = el('div', 'budget-card');
  goalsCard.append(el('h2', 'budget-card-title', 'Spaardoelen'));
  goalsCard.append(el('p', 'budget-card-desc', 'Optioneel: categorie = spaarposten meetellen'));
  const goalsList = el('div', 'budget-goals');
  const goalAdd = el('button', 'budget-btn budget-btn-dashed', '+ Doel toevoegen');
  goalAdd.type = 'button';
  goalsCard.append(goalsList, goalAdd);

  const yearCard = el('div', 'budget-card');
  yearCard.append(el('h2', 'budget-card-title', 'Trends & jaar'));
  yearCard.append(el('p', 'budget-card-desc', 'Saldo per maand · statistiek over archief'));
  const trendsStats = el('div', 'budget-trends-stats');
  const yearChart = el('div', 'budget-year');
  yearCard.append(trendsStats, yearChart);

  const dueCard = el('div', 'budget-card budget-due-card');
  dueCard.append(el('h2', 'budget-card-title', 'Betaaldagen deze maand'));
  dueCard.append(el('p', 'budget-card-desc', 'Posten met een vaste betaaldag (1–28)'));
  const dueList = el('ul', 'budget-due-list');
  dueCard.append(dueList);

  analysis.append(ruleCard, goalsCard, yearCard);
  root.append(analysis);
  root.append(dueCard);

  /* —— Maandnotitie —— */
  const noteCard = el('div', 'budget-card budget-month-note-card');
  noteCard.append(el('h2', 'budget-card-title', 'Notitie bij deze maand'));
  const monthNoteIn = el('textarea', 'budget-month-note');
  monthNoteIn.rows = 2;
  monthNoteIn.placeholder = 'Vakantie, bonus, eenmalige kosten…';
  monthNoteIn.setAttribute('aria-label', 'Maandnotitie');
  noteCard.append(monthNoteIn);
  root.append(noteCard);

  /* —— Formulieren —— */
  const forms = el('div', 'budget-forms');
  const groupContainers = {};
  for (const key of ['income', 'needs', 'wants', 'savings', 'debts']) {
    const card = el('div', 'budget-card budget-form-card');
    card.dataset.group = key;
    const head = el('div', 'budget-form-head');
    head.append(el('h2', 'budget-card-title', GROUP_META[key].title));
    head.append(el('p', 'budget-card-desc', GROUP_META[key].desc));
    const list = el('div', 'budget-fields');
    groupContainers[key] = list;
    const addBtn = el('button', 'budget-btn budget-btn-dashed', `+ ${GROUP_META[key].add}`);
    addBtn.type = 'button';
    addBtn.dataset.add = key;
    card.append(head, list, addBtn);
    forms.append(card);
  }
  root.append(forms);

  const statusLine = el('div', 'budget-status');
  statusLine.setAttribute('role', 'status');
  statusLine.setAttribute('aria-live', 'polite');
  root.append(statusLine);

  /* —— Core helpers —— */
  function activeMonth() {
    if (!store.months[store.activeMonth]) {
      store.months[store.activeMonth] = emptyMonthFromTemplate('standaard');
    }
    return store.months[store.activeMonth];
  }

  function setStatus(msg, kind) {
    statusLine.textContent = msg || '';
    statusLine.className = 'budget-status' + (kind ? ` is-${kind}` : '');
  }

  function pushUndo() {
    try {
      undoStack.push(JSON.stringify(store));
      if (undoStack.length > UNDO_MAX) undoStack.shift();
      btnUndo.disabled = false;
    } catch (_) {}
  }

  function undo() {
    if (!undoStack.length) {
      setStatus('Niets om ongedaan te maken', 'warn');
      return;
    }
    try {
      store = normalizeStore(JSON.parse(undoStack.pop()));
      persistSoon();
      renderAll();
      setStatus('Laatste wijziging ongedaan gemaakt', 'ok');
    } catch (_) {
      setStatus('Ongedaan maken mislukt', 'warn');
    }
    btnUndo.disabled = !undoStack.length;
  }

  function persistSoon() {
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      const res = await saveStore(store);
      if (res.ok) setStatus('Opgeslagen in budgetbestand', 'ok');
      else if (res.via === 'memory') setStatus('Niet naar bestand — gebruik Export', 'warn');
      else setStatus('Opslaan mislukt: ' + (res.error || ''), 'warn');
      if (res.ok) {
        setTimeout(() => {
          if (!destroyed && statusLine.classList.contains('is-ok')) setStatus('');
        }, 2200);
      }
    }, 450);
  }

  function ensureMonth(key) {
    if (!store.months[key]) store.months[key] = emptyMonthFromTemplate('standaard');
  }

  function goMonth(delta) {
    pushUndo();
    const next = shiftMonth(store.activeMonth, delta);
    ensureMonth(next);
    store.activeMonth = next;
    persistSoon();
    renderAll();
  }

  function savingsForCategory(cat) {
    if (!cat) return sumField(activeMonth().savings, 'amount');
    return (activeMonth().savings || [])
      .filter((s) => (s.category || '').toLowerCase() === cat.toLowerCase())
      .reduce((s, i) => s + (Number(i.amount) || 0), 0);
  }

  function renderPeriod() {
    periodLabel.textContent = monthLabel(store.activeMonth);
    const keys = Object.keys(store.months).sort();
    periodMeta.textContent = `${keys.length} maand${keys.length === 1 ? '' : 'en'} · profiel ${store.profile || '—'}`;
    currencySel.value = store.currency;
    profileIn.value = store.profile || '';
    sub.textContent = `Gepland vs werkelijk · ${store.profile || 'Profiel'} · 50/30/20`;
    btnUndo.disabled = !undoStack.length;
  }

  function renderDue() {
    dueList.replaceChildren();
    const items = [];
    for (const g of ['needs', 'wants', 'savings', 'debts', 'income']) {
      for (const it of activeMonth()[g] || []) {
        if (it.dueDay) items.push({ group: g, ...it });
      }
    }
    items.sort((a, b) => Number(a.dueDay) - Number(b.dueDay));
    if (!items.length) {
      dueList.append(el('li', 'budget-empty', 'Geen betaaldagen ingesteld. Vul “dag” in bij een post.'));
      return;
    }
    for (const it of items) {
      const li = el('li', 'budget-due-item');
      li.textContent = `Dag ${it.dueDay} — ${it.label} (${formatMoney(it.amount, store.currency)})`;
      dueList.append(li);
    }
  }

  function renderGoals() {
    goalsList.replaceChildren();
    if (!store.goals.length) {
      goalsList.append(el('p', 'budget-empty', 'Nog geen doelen.'));
      return;
    }
    store.goals.forEach((g, index) => {
      const row = el('div', 'budget-goal');
      const top = el('div', 'budget-goal-top');
      const labelIn = el('input', 'budget-field-label');
      labelIn.value = g.label;
      labelIn.placeholder = 'Doelnaam';
      labelIn.setAttribute('aria-label', 'Doelnaam');
      const del = el('button', 'budget-del', '×');
      del.type = 'button';
      del.setAttribute('aria-label', 'Doel verwijderen');
      top.append(labelIn, del);

      const nums = el('div', 'budget-goal-nums');
      const curWrap = el('label', 'budget-goal-field');
      curWrap.append(el('span', '', 'Nu'));
      const curIn = el('input', 'budget-field-amount');
      curIn.type = 'number';
      curIn.min = '0';
      curIn.step = '10';
      curIn.value = String(g.current);
      curIn.setAttribute('aria-label', 'Huidig bedrag');
      curWrap.append(curIn);
      const tgtWrap = el('label', 'budget-goal-field');
      tgtWrap.append(el('span', '', 'Doel'));
      const tgtIn = el('input', 'budget-field-amount');
      tgtIn.type = 'number';
      tgtIn.min = '0';
      tgtIn.step = '10';
      tgtIn.value = String(g.target);
      tgtIn.setAttribute('aria-label', 'Doelbedrag');
      tgtWrap.append(tgtIn);
      nums.append(curWrap, tgtWrap);

      const linkRow = el('div', 'budget-goal-link');
      const catIn = el('input', 'budget-field-cat');
      catIn.type = 'text';
      catIn.placeholder = 'Gekoppelde spaarcategorie (bijv. buffer)';
      catIn.value = g.linkedCategory || '';
      catIn.setAttribute('aria-label', 'Gekoppelde spaarcategorie');
      const syncBtn = el('button', 'budget-btn budget-btn-ghost budget-btn-tiny', 'Tel maand-sparen bij');
      syncBtn.type = 'button';
      syncBtn.title = 'Tel spaarbedrag van deze maand (categorie of alles) bij de huidige stand';
      linkRow.append(catIn, syncBtn);

      const pct = g.target > 0 ? Math.min(100, Math.round((g.current / g.target) * 100)) : 0;
      const track = el('div', 'budget-bar-track');
      const fill = el('div', 'budget-bar-fill budget-bar-savings');
      fill.style.width = `${pct}%`;
      track.append(fill);
      const pctLab = el('div', 'budget-goal-pct', `${pct}% · ${formatMoney(g.current, store.currency)} / ${formatMoney(g.target, store.currency)}`);
      const monthSav = savingsForCategory(g.linkedCategory);
      const hint = el('div', 'budget-goal-hint', g.linkedCategory
        ? `Deze maand in “${g.linkedCategory}”: ${formatMoney(monthSav, store.currency)}`
        : `Alle sparen deze maand: ${formatMoney(monthSav, store.currency)}`);

      const noteIn = el('input', 'budget-field-note');
      noteIn.type = 'text';
      noteIn.placeholder = 'Notitie…';
      noteIn.value = g.note || '';

      row.append(top, nums, linkRow, track, pctLab, hint, noteIn);
      goalsList.append(row);

      const refreshPct = () => {
        const p = g.target > 0 ? Math.min(100, Math.round((g.current / g.target) * 100)) : 0;
        fill.style.width = `${p}%`;
        pctLab.textContent = `${p}% · ${formatMoney(g.current, store.currency)} / ${formatMoney(g.target, store.currency)}`;
      };
      const sync = () => {
        g.label = labelIn.value.trim() || 'Doel';
        g.current = parseFloat(curIn.value) || 0;
        g.target = parseFloat(tgtIn.value) || 0;
        g.note = noteIn.value;
        g.linkedCategory = catIn.value.trim();
        refreshPct();
        hint.textContent = g.linkedCategory
          ? `Deze maand in “${g.linkedCategory}”: ${formatMoney(savingsForCategory(g.linkedCategory), store.currency)}`
          : `Alle sparen deze maand: ${formatMoney(savingsForCategory(''), store.currency)}`;
        persistSoon();
      };
      labelIn.onchange = sync;
      curIn.oninput = sync;
      tgtIn.oninput = sync;
      noteIn.onchange = sync;
      catIn.onchange = sync;
      syncBtn.onclick = () => {
        pushUndo();
        const add = savingsForCategory(g.linkedCategory);
        g.current = (Number(g.current) || 0) + add;
        curIn.value = String(g.current);
        refreshPct();
        persistSoon();
        setStatus(`+${formatMoney(add, store.currency)} bij doel “${g.label}”`, 'ok');
      };
      del.onclick = async () => {
        if (!(await confirmDialog(`Doel “${g.label}” verwijderen?`))) return;
        pushUndo();
        store.goals.splice(index, 1);
        persistSoon();
        renderGoals();
      };
    });
  }

  function renderTrends() {
    trendsStats.replaceChildren();
    const keys = Object.keys(store.months).sort();
    const bals = keys.map((k) => ({ k, b: monthBalance(store.months[k]) })).filter((x) => x.b != null);
    if (bals.length < 1) {
      trendsStats.append(el('p', 'budget-empty', 'Nog te weinig maanden voor statistiek.'));
    } else {
      const avg = bals.reduce((s, x) => s + x.b, 0) / bals.length;
      const best = bals.reduce((a, x) => (x.b > a.b ? x : a), bals[0]);
      const worst = bals.reduce((a, x) => (x.b < a.b ? x : a), bals[0]);
      const avgInc = keys.reduce((s, k) => s + sumField(store.months[k].income, 'amount'), 0) / keys.length;
      const avgExp = keys.reduce((s, k) => {
        const m = store.months[k];
        return s + sumField(m.needs, 'amount') + sumField(m.wants, 'amount');
      }, 0) / keys.length;
      const line = el('div', 'budget-trends-line');
      line.innerHTML = '';
      const parts = [
        `Gem. saldo ${formatMoney(avg, store.currency)}`,
        `Gem. inkomen ${formatMoney(avgInc, store.currency)}`,
        `Gem. lasten ${formatMoney(avgExp, store.currency)}`,
        `Beste ${monthLabel(best.k)}`,
        `Zwaarst ${monthLabel(worst.k)}`
      ];
      parts.forEach((t, i) => {
        if (i) line.append(el('span', 'budget-trends-sep', '·'));
        line.append(el('span', '', t));
      });
      trendsStats.append(line);
    }

    yearChart.replaceChildren();
    const year = Number(store.activeMonth.slice(0, 4));
    const bars = el('div', 'budget-year-bars');
    let maxAbs = 1;
    const points = [];
    for (let m = 1; m <= 12; m++) {
      const key = `${year}-${String(m).padStart(2, '0')}`;
      const bal = store.months[key] ? monthBalance(store.months[key]) : null;
      if (bal != null) maxAbs = Math.max(maxAbs, Math.abs(bal));
      points.push({ key, m, bal });
    }
    for (const p of points) {
      const col = el('div', 'budget-year-col' + (p.key === store.activeMonth ? ' is-active' : ''));
      col.title = p.bal == null ? `${monthLabel(p.key)}: geen data` : `${monthLabel(p.key)}: ${formatMoney(p.bal, store.currency)}`;
      col.setAttribute('role', 'button');
      col.tabIndex = 0;
      const stack = el('div', 'budget-year-stack');
      if (p.bal != null) {
        const h = Math.max(4, Math.round((Math.abs(p.bal) / maxAbs) * 72));
        const bar = el('div', 'budget-year-bar' + (p.bal < 0 ? ' is-neg' : ' is-pos'));
        bar.style.height = `${h}px`;
        stack.append(bar);
      } else {
        stack.append(el('div', 'budget-year-empty'));
      }
      col.append(stack, el('div', 'budget-year-m', String(p.m)));
      const go = () => {
        pushUndo();
        ensureMonth(p.key);
        store.activeMonth = p.key;
        persistSoon();
        renderAll();
      };
      col.onclick = go;
      col.onkeydown = (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); }
      };
      bars.append(col);
    }
    yearChart.append(bars);
  }

  function moneyInput(value, aria) {
    const wrap = el('div', 'budget-amount');
    wrap.append(el('span', '', store.currency === 'EUR' ? '€' : store.currency));
    const input = el('input', 'budget-field-amount');
    input.type = 'number';
    input.min = '0';
    input.step = '1';
    input.value = String(value || 0);
    if (aria) input.setAttribute('aria-label', aria);
    wrap.append(input);
    return { wrap, input };
  }

  function renderSection(groupKey) {
    const container = groupContainers[groupKey];
    container.replaceChildren();
    const isDebt = groupKey === 'debts';
    const items = activeMonth()[groupKey] || [];
    items.forEach((item, index) => {
      const row = el('div', 'budget-field');
      const top = el('div', 'budget-field-top');
      const labelIn = el('input', 'budget-field-label');
      labelIn.type = 'text';
      labelIn.value = item.label || '';
      labelIn.placeholder = 'Naam…';
      labelIn.setAttribute('aria-label', 'Naam post');

      const plannedUI = moneyInput(item.planned, 'Gepland');
      const actualUI = moneyInput(item.amount, 'Werkelijk');
      plannedUI.wrap.title = 'Gepland';
      actualUI.wrap.title = 'Werkelijk';
      plannedUI.wrap.classList.add('is-planned');
      actualUI.wrap.classList.add('is-actual');

      const delBtn = el('button', 'budget-del', '×');
      delBtn.type = 'button';
      delBtn.setAttribute('aria-label', 'Verwijderen');
      top.append(labelIn, plannedUI.wrap, actualUI.wrap, delBtn);

      const labels = el('div', 'budget-field-money-labels');
      labels.append(el('span', '', ''), el('span', '', 'Gepland'), el('span', '', 'Werkelijk'), el('span', '', ''));

      const mid = el('div', 'budget-field-mid');
      const catIn = el('input', 'budget-field-cat');
      catIn.type = 'text';
      catIn.placeholder = 'Categorie';
      catIn.value = item.category || '';
      catIn.setAttribute('aria-label', 'Categorie');
      const dueIn = el('input', 'budget-field-due');
      dueIn.type = 'number';
      dueIn.min = '1';
      dueIn.max = '28';
      dueIn.placeholder = 'Dag';
      dueIn.title = 'Betaaldag (1–28)';
      dueIn.value = item.dueDay || '';
      dueIn.setAttribute('aria-label', 'Betaaldag');
      mid.append(catIn, dueIn);

      let debtRow = null;
      if (isDebt) {
        debtRow = el('div', 'budget-debt-row');
        const rem = moneyInput(item.remaining, 'Restant schuld');
        rem.wrap.title = 'Restant';
        const intIn = el('input', 'budget-field-interest');
        intIn.type = 'number';
        intIn.min = '0';
        intIn.step = '0.1';
        intIn.placeholder = 'Rente %';
        intIn.value = item.interest != null ? String(item.interest) : '';
        intIn.setAttribute('aria-label', 'Rentepercentage');
        const endIn = el('input', 'budget-field-end');
        endIn.type = 'month';
        endIn.value = item.endDate || '';
        endIn.setAttribute('aria-label', 'Einddatum schuld');
        debtRow.append(el('span', 'budget-debt-lab', 'Restant'), rem.wrap, el('span', 'budget-debt-lab', 'Rente %'), intIn, el('span', 'budget-debt-lab', 'Einde'), endIn);
        rem.input.oninput = () => {
          item.remaining = parseFloat(rem.input.value) || 0;
          persistSoon();
        };
        intIn.oninput = () => {
          item.interest = parseFloat(intIn.value) || 0;
          persistSoon();
        };
        endIn.onchange = () => {
          item.endDate = endIn.value;
          persistSoon();
        };
      }

      const noteIn = el('input', 'budget-field-note');
      noteIn.type = 'text';
      noteIn.placeholder = 'Notitie…';
      noteIn.value = item.note || '';
      noteIn.setAttribute('aria-label', 'Notitie');

      const variance = (Number(item.amount) || 0) - (Number(item.planned) || 0);
      const varEl = el('div', 'budget-field-var' + (variance > 0 ? ' is-over' : variance < 0 ? ' is-under' : ''), variance === 0 ? '' : `Verschil: ${formatMoney(variance, store.currency)}`);

      row.append(labels, top, mid);
      if (debtRow) row.append(debtRow);
      row.append(noteIn, varEl);
      container.append(row);

      labelIn.onchange = () => {
        item.label = labelIn.value.trim() || 'Onbenoemd';
        persistSoon();
      };
      catIn.onchange = () => {
        item.category = catIn.value.trim();
        persistSoon();
        renderGoals();
      };
      dueIn.onchange = () => {
        const v = parseInt(dueIn.value, 10);
        item.dueDay = v >= 1 && v <= 28 ? v : '';
        dueIn.value = item.dueDay || '';
        persistSoon();
        renderDue();
      };
      noteIn.onchange = () => {
        item.note = noteIn.value;
        persistSoon();
      };
      plannedUI.input.oninput = () => {
        item.planned = parseFloat(plannedUI.input.value) || 0;
        const v = (Number(item.amount) || 0) - item.planned;
        varEl.textContent = v === 0 ? '' : `Verschil: ${formatMoney(v, store.currency)}`;
        varEl.className = 'budget-field-var' + (v > 0 ? ' is-over' : v < 0 ? ' is-under' : '');
        persistSoon();
        calculate();
      };
      actualUI.input.oninput = () => {
        item.amount = parseFloat(actualUI.input.value) || 0;
        const v = item.amount - (Number(item.planned) || 0);
        varEl.textContent = v === 0 ? '' : `Verschil: ${formatMoney(v, store.currency)}`;
        varEl.className = 'budget-field-var' + (v > 0 ? ' is-over' : v < 0 ? ' is-under' : '');
        persistSoon();
        calculate();
        renderGoals();
      };
      delBtn.onclick = async () => {
        if (!(await confirmDialog(`“${item.label}” verwijderen?`))) return;
        pushUndo();
        activeMonth()[groupKey].splice(index, 1);
        persistSoon();
        renderSection(groupKey);
        calculate();
        renderDue();
      };
    });
  }

  function renderForms() {
    for (const k of Object.keys(GROUP_META)) renderSection(k);
    monthNoteIn.value = activeMonth().monthNote || '';
  }

  function calculate() {
    if (destroyed) return;
    const m = activeMonth();
    const cur = store.currency;
    const sumIncome = sumField(m.income, 'amount');
    const sumNeeds = sumField(m.needs, 'amount');
    const sumWants = sumField(m.wants, 'amount');
    const sumSavings = sumField(m.savings, 'amount');
    const sumDebts = sumField(m.debts, 'amount');
    const totalExpenses = sumNeeds + sumWants;
    const balance = sumIncome - totalExpenses - sumSavings - sumDebts;

    const pIncome = sumField(m.income, 'planned');
    const pOut = sumField(m.needs, 'planned') + sumField(m.wants, 'planned') + sumField(m.savings, 'planned') + sumField(m.debts, 'planned');
    const aOut = totalExpenses + sumSavings + sumDebts;
    const varTotal = (sumIncome - aOut) - (pIncome - pOut);

    kpiEls.income.val.textContent = formatMoney(sumIncome, cur);
    kpiEls.expenses.val.textContent = formatMoney(totalExpenses, cur);
    kpiEls.savings.val.textContent = formatMoney(sumSavings, cur);
    kpiEls.debts.val.textContent = formatMoney(sumDebts, cur);
    kpiEls.balance.val.textContent = formatMoney(balance, cur);
    kpiEls.variance.val.textContent = formatMoney(varTotal, cur);

    const pct = (n) => (sumIncome > 0 ? Math.round((n / sumIncome) * 100) : 0);
    kpiEls.income.hint.textContent = `Gepland ${formatMoney(pIncome, cur)}`;
    kpiEls.expenses.hint.textContent = `${pct(totalExpenses)}% · gepland ${formatMoney(sumField(m.needs, 'planned') + sumField(m.wants, 'planned'), cur)}`;
    kpiEls.savings.hint.textContent = `${pct(sumSavings)}% van inkomsten`;
    kpiEls.debts.hint.textContent = `${pct(sumDebts)}% van inkomsten`;
    kpiEls.balance.card.classList.toggle('is-deficit', balance < 0);
    kpiEls.balance.hint.textContent = balance < 0 ? 'Tekort' : 'Overschot';
    kpiEls.variance.card.classList.toggle('is-deficit', varTotal < 0);
    kpiEls.variance.hint.textContent = varTotal < 0 ? 'Slechter dan gepland' : 'Beter of gelijk aan gepland';

    const needsAll = sumNeeds + sumDebts;
    const needsPct = pct(needsAll);
    const wantsPct = pct(sumWants);
    const savingsPct = pct(sumSavings);
    ruleRows.needs.pct.textContent = `${needsPct}% · ${formatMoney(needsAll, cur)}`;
    ruleRows.needs.fill.style.width = `${Math.min(needsPct, 100)}%`;
    ruleRows.wants.pct.textContent = `${wantsPct}% · ${formatMoney(sumWants, cur)}`;
    ruleRows.wants.fill.style.width = `${Math.min(wantsPct, 100)}%`;
    ruleRows.savings.pct.textContent = `${savingsPct}% · ${formatMoney(sumSavings, cur)}`;
    ruleRows.savings.fill.style.width = `${Math.min(savingsPct, 100)}%`;

    if (sumIncome === 0) {
      ruleTip.textContent = 'Vul werkelijke inkomsten in voor de 50/30/20-verhouding.';
      ruleTip.className = 'budget-tip';
    } else if (needsPct > 55) {
      ruleTip.textContent = `Behoeften + aflossing ${needsPct}% (richtlijn ~50%).`;
      ruleTip.className = 'budget-tip is-warn';
    } else if (savingsPct < 15) {
      ruleTip.textContent = `Sparen ${savingsPct}%. Streef naar ~20%.`;
      ruleTip.className = 'budget-tip is-info';
    } else {
      ruleTip.textContent = 'Verdeling past bij de 50/30/20-richtlijn.';
      ruleTip.className = 'budget-tip is-ok';
    }
  }

  function renderAll() {
    const showOnboarding = !store.onboardingDone;
    onboard.hidden = !showOnboarding;
    kpiGrid.hidden = showOnboarding;
    analysis.hidden = showOnboarding;
    dueCard.hidden = showOnboarding;
    noteCard.hidden = showOnboarding;
    forms.hidden = showOnboarding;
    renderPeriod();
    if (!showOnboarding) {
      renderGoals();
      renderTrends();
      renderDue();
      renderForms();
      calculate();
    }
  }

  /* —— Events —— */
  prevBtn.onclick = () => goMonth(-1);
  nextBtn.onclick = () => goMonth(1);
  btnUndo.onclick = undo;

  copyBtn.onclick = async () => {
    const prev = shiftMonth(store.activeMonth, -1);
    if (!store.months[prev]) {
      setStatus('Geen vorige maand om te kopiëren', 'warn');
      return;
    }
    if (!(await confirmDialog(`Posten van ${monthLabel(prev)} overnemen in ${monthLabel(store.activeMonth)}?`))) return;
    pushUndo();
    const src = store.months[prev];
    const dest = activeMonth();
    for (const g of ['income', 'needs', 'wants', 'savings', 'debts']) {
      dest[g] = (src[g] || []).map((x) => itemFrom({ ...x, id: uid('i') }, g === 'debts'));
    }
    dest.monthNote = src.monthNote || '';
    persistSoon();
    renderAll();
    setStatus('Vorige maand gekopieerd', 'ok');
  };

  currencySel.onchange = () => {
    pushUndo();
    store.currency = currencySel.value;
    persistSoon();
    renderAll();
  };

  profileIn.onchange = () => {
    pushUndo();
    store.profile = profileIn.value.trim() || 'Standaard';
    persistSoon();
    renderPeriod();
  };

  monthNoteIn.onchange = () => {
    activeMonth().monthNote = monthNoteIn.value;
    persistSoon();
  };

  forms.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-add]');
    if (!btn) return;
    pushUndo();
    const g = btn.getAttribute('data-add');
    activeMonth()[g].push(itemFrom({
      label: g === 'income' ? 'Nieuwe inkomst' : 'Nieuwe post',
      amount: 0,
      planned: 0
    }, g === 'debts'));
    persistSoon();
    renderSection(g);
    calculate();
  });

  goalAdd.onclick = () => {
    pushUndo();
    store.goals.push({ id: uid('goal'), label: 'Nieuw doel', target: 1000, current: 0, note: '', linkedCategory: '' });
    persistSoon();
    renderGoals();
  };

  onboardBtn.onclick = () => {
    store.onboardingDone = true;
    persistSoon();
    renderAll();
  };

  btnExport.onclick = () => {
    downloadBlob(`slim-budgetter-${store.activeMonth}.json`, JSON.stringify(store, null, 2), 'application/json');
    setStatus('JSON-export gedownload', 'ok');
  };
  btnCsv.onclick = () => {
    downloadBlob(`budget-${store.activeMonth}.csv`, monthToCsv(activeMonth()), 'text/csv');
    setStatus('CSV-export gedownload', 'ok');
  };
  btnImport.onclick = () => importFile.click();
  importFile.onchange = async () => {
    const file = importFile.files && importFile.files[0];
    importFile.value = '';
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      pushUndo();
      store = normalizeStore(data);
      store.onboardingDone = true;
      persistSoon();
      renderAll();
      setStatus('Import geslaagd', 'ok');
    } catch (_) {
      setStatus('Import mislukt: ongeldig JSON', 'warn');
    }
  };

  btnPrint.onclick = () => {
    root.classList.add('budget-print');
    window.print();
    setTimeout(() => root.classList.remove('budget-print'), 800);
  };

  btnTemplate.onclick = () => {
    const list = el('div', 'budget-tpl-list');
    Object.entries(TEMPLATES).forEach(([key, t]) => {
      const b = el('button', 'budget-btn budget-tpl-btn', t.label);
      b.type = 'button';
      b.onclick = async () => {
        closeModal();
        if (!(await confirmDialog(`Maand ${monthLabel(store.activeMonth)} vullen met “${t.label}”? Bestaande posten worden overschreven.`))) return;
        pushUndo();
        store.months[store.activeMonth] = emptyMonthFromTemplate(key);
        persistSoon();
        renderAll();
        setStatus(`Sjabloon “${t.label}” toegepast`, 'ok');
      };
      list.append(b);
    });
    const cancel = el('button', 'budget-btn budget-btn-ghost', 'Annuleren');
    cancel.type = 'button';
    cancel.onclick = closeModal;
    openModal('Kies een sjabloon', list, [cancel]);
  };

  function onKey(e) {
    if (destroyed) return;
    if (e.key === 'Escape' && !modal.hidden) {
      closeModal();
      return;
    }
    const mod = e.ctrlKey || e.metaKey;
    if (!mod) return;
    if (e.key === 's' || e.key === 'S') {
      e.preventDefault();
      saveStore(store).then((res) => {
        if (res.ok) setStatus('Opgeslagen (Ctrl+S)', 'ok');
        else setStatus(res.error || 'Gebruik Export', 'warn');
      });
    } else if (e.key === 'e' || e.key === 'E') {
      e.preventDefault();
      btnExport.click();
    } else if (e.key === 'z' || e.key === 'Z') {
      e.preventDefault();
      undo();
    }
  }
  window.addEventListener('keydown', onKey);

  loadStore().then((data) => {
    if (destroyed) return;
    store = data;
    renderAll();
  });

  return {
    root,
    el: root,
    kind: 'budgetter',
    close() {
      destroyed = true;
      if (saveTimer) clearTimeout(saveTimer);
      window.removeEventListener('keydown', onKey);
    },
    getState() {
      return { store, activeMonth: store.activeMonth };
    },
    setState(state) {
      if (!state) return;
      if (state.store) store = normalizeStore(state.store);
      if (state.activeMonth) {
        ensureMonth(state.activeMonth);
        store.activeMonth = state.activeMonth;
      }
      renderAll();
    },
    navigate(pos) {
      if (pos && pos.month) {
        ensureMonth(pos.month);
        store.activeMonth = pos.month;
        store.onboardingDone = true;
        renderAll();
      }
    }
  };
}
