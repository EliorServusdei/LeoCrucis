// Gegevens voor de editor: alineastijlen, documentstijlen (met startstructuur), kleuren en symbolen.
// De bijbehorende opmaak staat in styles.css (".s-…" voor alineastijlen, ".doc-…" voor documentstijlen).

// [id, naam, tag, klasse]
export const PARA_STYLES = [
  ['normaal', 'Normaal', 'p', ''],
  ['titel', 'Titel', 'p', 's-titel'],
  ['ondertitel', 'Ondertitel', 'p', 's-ondertitel'],
  ['kop1', 'Kop 1', 'h2', ''],
  ['kop2', 'Kop 2', 'h3', ''],
  ['kop3', 'Kop 3', 'h4', ''],
  ['intro', 'Inleiding (lead)', 'p', 's-intro'],
  ['auteur', 'Auteursregel', 'p', 's-auteur'],
  ['citaat', 'Citaat', 'blockquote', ''],
  ['pull', 'Opvallend citaat', 'p', 's-pull'],
  ['schrift', 'Schriftcitaat', 'p', 's-schrift'],
  ['kern', 'Kernpunt', 'p', 's-kern'],
  ['def', 'Definitie', 'p', 's-def'],
  ['voorbeeld', 'Voorbeeld', 'p', 's-voorbeeld'],
  ['tip', 'Tip', 'p', 's-tip'],
  ['letop', 'Let op', 'p', 's-let-op'],
  ['belangrijk', 'Belangrijk', 'p', 's-belangrijk'],
  ['opdracht', 'Opdracht', 'p', 's-opdracht'],
  ['lijn', 'Antwoordlijn', 'p', 's-lijn'],
  ['bron', 'Bronvermelding', 'p', 's-bron'],
  ['code', 'Code', 'p', 's-code'],
  ['afzender', 'Afzender (brief)', 'p', 's-afzender']
];

// Documentstijlen: [id, naam, korte omschrijving]
export const DOC_STYLES = [
  ['', 'Standaard', 'Gewone boekopmaak'],
  ['artikel', 'Artikel', 'Titel, intro en tussenkoppen in een rustige leeskolom'],
  ['samenvatting', 'Samenvatting', 'Compact, met gekleurde koppen en kernpunten'],
  ['krant', 'Krantenartikel', 'Grote kop, kolommen en een initiaal'],
  ['verslag', 'Verslag', 'Genummerde koppen, abstract en bronnen'],
  ['brief', 'Brief', 'Afzender, datum, aanhef en groet'],
  ['werkblad', 'Werkblad', 'Genummerde opdrachten met antwoordlijnen'],
  ['klassiek', 'Klassiek boek', 'Klassiek lettertype, kleine hoofdletters, sierinitiaal'],
  ['nieuwsbrief', 'Nieuwsbrief', 'Kleurige banner en twee kolommen']
];

export const THEMES = [
  ['', 'Bordeaux', '#7a1f2b'],
  ['marine', 'Marine', '#2d5fa8'],
  ['bos', 'Bos', '#2f7a45'],
  ['goud', 'Goud', '#b8922a'],
  ['slate', 'Leisteen', '#5f6b7a'],
  ['paars', 'Paars', '#7a4a9a']
];

export const FONT_THEMES = [
  ['', 'Standaard'],
  ['serif', 'Klassiek (serif)'],
  ['sans', 'Modern (schreefloos)'],
  ['mono', 'Typemachine']
];

export const FONTS = [
  ['Georgia', 'Georgia, "Times New Roman", serif'],
  ['Times New Roman', '"Times New Roman", Times, serif'],
  ['Palatino', '"Palatino Linotype", Palatino, "Book Antiqua", serif'],
  ['Garamond', 'Garamond, "EB Garamond", "Times New Roman", serif'],
  ['Cambria', 'Cambria, Georgia, serif'],
  ['Arial', 'Arial, Helvetica, sans-serif'],
  ['Calibri', 'Calibri, Carlito, "Segoe UI", sans-serif'],
  ['Verdana', 'Verdana, Geneva, sans-serif'],
  ['Trebuchet MS', '"Trebuchet MS", Tahoma, sans-serif'],
  ['Tahoma', 'Tahoma, Geneva, sans-serif'],
  ['Courier New', '"Courier New", Courier, monospace'],
  ['Consolas', 'Consolas, Menlo, monospace']
];

export const SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 72];

export const PALETTE = [
  '#000000', '#434343', '#666666', '#999999', '#cccccc', '#ffffff',
  '#7a1f2b', '#b8922a', '#c0392b', '#e67e22', '#f1c40f', '#27ae60',
  '#16a085', '#2980b9', '#1f3a5f', '#8e44ad', '#d35400', '#795548'
];
export const HILITES = ['#fff1a8', '#ffe066', '#ffd6a5', '#ffadad', '#caffbf', '#9bf6ff', '#a0c4ff', '#bdb2ff', '#ffc6ff', '#e0e0e0'];

export const SYMBOLS = ('€ £ $ ¥ ¢ © ® ™ § ¶ † ‡ • · … – — « » " " „ \' \' ° ± × ÷ ≠ ≈ ≤ ≥ ∞ √ ∑ ∏ ∫ ∂ ∆ ∈ ∩ ∪ ⊂ ⊆ ∀ ∃ ∅ ∴ ∵ ‰ µ ' +
  'α β γ δ ε ζ η θ ι κ λ μ ν ξ ο π ρ σ τ υ φ χ ψ ω Α Β Γ Δ Ε Ζ Η Θ Ι Κ Λ Μ Ν Ξ Ο Π Ρ Σ Τ Υ Φ Χ Ψ Ω ' +
  '← → ↑ ↓ ↔ ⇒ ⇐ ⇔ ★ ☆ ✓ ✔ ✕ ✖ ● ○ ■ □ ▲ ▼ ◆ ♠ ♣ ♥ ♦ ☀ ☁ ☂ ☃ ☎ ✉ ♪ ♫').split(' ').filter(Boolean);


export const EMOJI = ('✅ ❌ ⭐ ❤ 💡 ⚠ ❓ ❗ ➡ ⬅ ⬆ ⬇ ✔ ✘ 📖 📚 ✍ 📝 📌 📎 🔔 🕯 🙏 ⛪ ✝ ☀ ☁ ☂ 🌱 🌳 🍎 🎵 🎨 🔬 🧮 🌍 ⏰ 👍 😀 🙂 😉').split(' ');

const today = () => new Date().toLocaleDateString('nl-BE', { day: 'numeric', month: 'long', year: 'numeric' });

// Startstructuur per documentstijl (wordt ingevoegd in een leeg document of via "Structuur invoegen").
export const SKELETONS = {
  artikel: () => `<p class="s-titel">Titel van je artikel</p>
<p class="s-ondertitel">Een korte ondertitel die de lezer nieuwsgierig maakt</p>
<p class="s-auteur">Door Naam Auteur · ${today()}</p>
<p class="s-intro">Schrijf hier een pakkende inleiding van twee of drie zinnen: waar gaat dit artikel over en waarom is het belangrijk?</p>
<h2>Eerste tussenkop</h2>
<p>Begin hier met de tekst van je artikel.</p>
<h2>Tweede tussenkop</h2>
<p>Werk je tweede punt uit.</p>
<p class="s-pull">Een opvallende zin uit de tekst, groot uitgelicht.</p>
<h2>Besluit</h2>
<p>Sluit af met een duidelijke conclusie.</p>
<p class="s-bron">Bron: …</p>`,

  samenvatting: () => `<p class="s-titel">Samenvatting: onderwerp</p>
<p class="s-kern">In één zin: waar gaat dit hoofdstuk over?</p>
<h2>Kernbegrippen</h2>
<p class="s-def"><b>Begrip:</b> korte, duidelijke omschrijving.</p>
<p class="s-def"><b>Begrip:</b> korte, duidelijke omschrijving.</p>
<h2>Belangrijkste inhoud</h2>
<h3>Deel 1</h3>
<ul><li>Eerste punt</li><li>Tweede punt</li><li>Derde punt</li></ul>
<h3>Deel 2</h3>
<ul><li>Eerste punt</li><li>Tweede punt</li></ul>
<p class="s-voorbeeld">Een voorbeeld dat de leerstof verduidelijkt.</p>
<h2>Te onthouden</h2>
<p class="s-belangrijk">Schrijf hier de drie belangrijkste dingen om te onthouden.</p>
<p class="s-tip">Controleer jezelf: kan je dit uitleggen zonder je notities?</p>`,

  krant: () => `<p class="s-titel">Grote krantenkop op de voorpagina</p>
<p class="s-ondertitel">Onderkop met de belangrijkste nieuwsfeiten in één regel</p>
<p class="s-auteur">Door onze redactie — Plaats, ${today()}</p>
<p class="s-intro">Het intro vat het nieuws samen: wie, wat, waar, wanneer en waarom. Dit is de eerste alinea die de lezer te zien krijgt.</p>
<p>Hier begint de eigenlijke tekst van het artikel. In een krantenartikel loopt de tekst in smalle kolommen, met de belangrijkste informatie bovenaan en de details verderop.</p>
<p>Een tweede alinea geeft meer achtergrond bij het nieuws en laat getuigen of betrokkenen aan het woord.</p>
<h2>Tussenkop</h2>
<p>Verdere uitleg, cijfers en reacties. Voeg gerust meer alinea's toe; de tekst verdeelt zich vanzelf over de kolommen.</p>
<p class="s-pull">"Een opvallend citaat uit het artikel."</p>
<p>Sluit af met wat er hierna gebeurt of wat de lezer nog kan verwachten.</p>`,

  verslag: () => `<p class="s-titel">Titel van het verslag</p>
<p class="s-ondertitel">Ondertitel of opdracht</p>
<p class="s-auteur">Naam auteur · ${today()}</p>
<p class="s-intro">Samenvatting (abstract): vat in vier of vijf zinnen de vraag, de aanpak, de belangrijkste resultaten en de conclusie samen.</p>
<h2>Inleiding</h2>
<p>Beschrijf het onderwerp, de aanleiding en de onderzoeksvraag.</p>
<h2>Werkwijze</h2>
<p>Leg uit hoe je te werk bent gegaan.</p>
<h2>Resultaten</h2>
<p>Presenteer wat je gevonden hebt. Gebruik eventueel een tabel of figuur.</p>
<h3>Deelresultaat</h3>
<p>Werk een onderdeel verder uit.</p>
<h2>Bespreking</h2>
<p>Interpreteer de resultaten en vergelijk ze met de verwachtingen.</p>
<h2>Besluit</h2>
<p>Geef antwoord op de onderzoeksvraag.</p>
<h2>Bronnen</h2>
<p class="s-bron">Auteur (jaar). Titel. Uitgever.</p>`,

  brief: () => `<p class="s-afzender">Voornaam Achternaam<br>Straat 1<br>8500 Kortrijk<br>${today()}</p>
<p>Geachte heer/mevrouw,</p>
<p>In deze brief wil ik u graag mijn vraag voorleggen. Schrijf hier de eerste alinea met de reden van je brief.</p>
<p>In de tweede alinea geef je meer uitleg of de nodige details.</p>
<p>Ik dank u bij voorbaat voor uw antwoord en blijf graag beschikbaar voor bijkomende vragen.</p>
<p>Met vriendelijke groeten,</p>
<p><br></p>
<p>Voornaam Achternaam</p>`,

  werkblad: () => `<p class="s-titel">Werkblad: onderwerp</p>
<p>Naam: ________________________ &nbsp;&nbsp; Datum: ______________</p>
<h2>Deel 1: Lezen</h2>
<p>Lees de tekst aandachtig en beantwoord daarna de vragen.</p>
<p class="s-opdracht">Eerste opdracht of vraag.</p>
<p class="s-lijn"><br></p>
<p class="s-lijn"><br></p>
<p class="s-opdracht">Tweede opdracht of vraag.</p>
<p class="s-lijn"><br></p>
<p class="s-lijn"><br></p>
<h2>Deel 2: Oefenen</h2>
<p class="s-opdracht">Derde opdracht of vraag.</p>
<p class="s-lijn"><br></p>
<p class="s-tip">Tip: lees de vraag twee keer voor je antwoordt.</p>`,

  klassiek: () => `<p class="s-titel">Titel van het werk</p>
<p class="s-ondertitel">Ondertitel of auteur</p>
<h2>Eerste hoofdstuk</h2>
<p>Begin hier met de eerste alinea. In een klassiek boek springt de eerste regel van een alinea licht in en het hoofdstuk opent met een sierinitiaal.</p>
<p>De volgende alinea's volgen elkaar op zonder witregel, zoals in een gedrukt boek.</p>
<h2>Tweede hoofdstuk</h2>
<p>Hier begint het tweede hoofdstuk.</p>`,

  nieuwsbrief: () => `<p class="s-titel">Nieuwsbrief</p>
<p class="s-ondertitel">${today()}</p>
<h2>Wat is er nieuw?</h2>
<p>Vertel kort het belangrijkste nieuws van deze editie.</p>
<h2>Agenda</h2>
<ul><li><b>Datum:</b> activiteit en plaats</li><li><b>Datum:</b> activiteit en plaats</li></ul>
<p class="s-tip">Tip: noteer hier een handige tip voor de lezers.</p>
<h2>Terugblik</h2>
<p>Een korte terugblik op een recente gebeurtenis.</p>
<h2>Contact</h2>
<p>Vragen of opmerkingen? Stuur ons gerust een bericht.</p>`
};
