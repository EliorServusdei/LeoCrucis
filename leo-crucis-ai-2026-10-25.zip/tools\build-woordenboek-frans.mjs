#!/usr/bin/env node
// Bouwt Nederlands → Frans (src/data/woordenboek-frans/nl-fr.json).
//
// Bronnen:
//   1. FreeDict nld-fra + fra-nld (direct) — GPL v2+  → score 3
//   2. FreeDict nld-eng + eng-fra (pivot) — GPL v2+   → score 2
//   3. Wikidata interwiki fr-nl (omgekeerd) — CC0    → score 1
//   4. Geslacht: tools/french_nouns.tsv
//
// Entry = [nederlands, [[frans, score, geslacht?, woordsoort?, notitie?], …]]

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.resolve(process.argv[2] || path.join(here, 'freedict'));
const OUT = path.resolve(here, '../src/data/woordenboek-frans/nl-fr.json');
const GENDER_FILE = path.join(here, 'french_nouns.tsv');
const WIKI_FR = path.join(here, 'fr-nl_wikidict.dsl');

const unesc = s => s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/&apos;/g, "'").replace(/&quot;/g, '"').replace(/ĳ/g, 'ij').replace(/Ĳ/g, 'IJ').replace(/\s+/g, ' ').trim();
const key = s => unesc(s).toLowerCase();

function readEntries(pair) {
  const f = path.join(SRC, pair, pair + '.tei');
  if (!fs.existsSync(f)) { console.warn('Ontbreekt:', f); return []; }
  const s = fs.readFileSync(f, 'utf8');
  const out = [];
  for (const m of s.matchAll(/<entry\b[^>]*>([\s\S]*?)<\/entry>/g)) {
    const b = m[1];
    const o = b.match(/<orth>([\s\S]*?)<\/orth>/);
    if (!o) continue;
    const quotes = [...b.matchAll(/<quote>([\s\S]*?)<\/quote>/g)].map(q => unesc(q[1])).filter(Boolean);
    out.push({ orth: unesc(o[1]), quotes });
  }
  return out;
}

function addRoute(map, from, to, route) {
  if (!from || !to) return;
  const k = key(from);
  if (k.length < 1 || k.length > 60) return;
  const m = map.get(k) || map.set(k, new Map()).get(k);
  const routes = m.get(to) || m.set(to, new Set()).get(to);
  routes.add(route);
}

const gender = new Map();
if (fs.existsSync(GENDER_FILE)) {
  const votes = new Map();
  for (const raw of fs.readFileSync(GENDER_FILE, 'utf8').split(/\r?\n/)) {
    if (!raw || raw.startsWith('noun')) continue;
    const [noun, g] = raw.split('\t');
    if (!noun || !g) continue;
    const k = key(noun);
    const v = votes.get(k) || votes.set(k, { m: 0, f: 0 }).get(k);
    if (g === 'm') v.m++; else if (g === 'f') v.f++;
  }
  for (const [k, v] of votes) {
    if (v.m && v.f) gender.set(k, 'm./f.');
    else if (v.m) gender.set(k, 'm.');
    else if (v.f) gender.set(k, 'f.');
  }
  console.log('Geslacht:', gender.size);
}

function guessPos(fr) {
  const w = fr.toLowerCase();
  if (/(?:er|ir|re|oir)$/.test(w) && w.length > 3) return 'ww.';
  if (/ment$/.test(w)) return 'bw.';
  if (/(?:tion|sion|té|tude|ance|ence|ure|ade|ie)$/.test(w)) return 'zn.';
  if (/(?:eux|euse|able|ible|if|ive|al|ale|ique)$/.test(w)) return 'bn.';
  if (gender.has(key(fr))) return 'zn.';
  return '';
}

const perNl = new Map();

// FreeDict direct
for (const e of readEntries('nld-fra')) for (const q of e.quotes) addRoute(perNl, e.orth, q, 'D');
for (const e of readEntries('fra-nld')) for (const q of e.quotes) addRoute(perNl, q, e.orth, 'R');

// Pivot EN
const nlEn = new Map(), enFr = new Map();
for (const e of readEntries('nld-eng')) for (const q of e.quotes) {
  const k = key(e.orth); (nlEn.get(k) || nlEn.set(k, new Set()).get(k)).add(key(q));
}
for (const e of readEntries('eng-nld')) for (const q of e.quotes) {
  const k = key(q); (nlEn.get(k) || nlEn.set(k, new Set()).get(k)).add(key(e.orth));
}
for (const e of readEntries('eng-fra')) for (const q of e.quotes) {
  const k = key(e.orth); (enFr.get(k) || enFr.set(k, new Set()).get(k)).add(q);
}
for (const e of readEntries('fra-eng')) for (const q of e.quotes) {
  const k = key(q); (enFr.get(k) || enFr.set(k, new Set()).get(k)).add(e.orth);
}
let pivotAdds = 0;
for (const [nl, ens] of nlEn) for (const en of ens) {
  const frs = enFr.get(en); if (!frs) continue;
  for (const fr of frs) { addRoute(perNl, nl, fr, 'P'); pivotAdds++; }
}
console.log('Pivot-toevoegingen:', pivotAdds);

// Wikidata interwiki FR→NL inverted → NL→FR (score W)
if (fs.existsSync(WIKI_FR)) {
  const lines = fs.readFileSync(WIKI_FR, 'utf8').split(/\r?\n/);
  let wikiAdds = 0, i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line || line.startsWith('#') || line.startsWith('\t') || line.startsWith('[')) { i++; continue; }
    const fr = line.trim(); i++;
    while (i < lines.length && (lines[i].startsWith('\t') || lines[i].startsWith('[') || lines[i] === '')) i++;
    if (i >= lines.length) break;
    const nl = lines[i].trim();
    if (!nl || nl.startsWith('#') || nl.startsWith('[') || nl.startsWith('\t')) continue;
    // filter noisy multi-word
    if (nl.count && typeof nl === 'string' && (nl.match(/ /g) || []).length > 3) { i++; continue; }
    if ((nl.match(/ /g) || []).length > 3 || (fr.match(/ /g) || []).length > 3) { i++; continue; }
    if (nl.length > 50 || fr.length > 50) { i++; continue; }
    addRoute(perNl, nl, fr, 'W');
    wikiAdds++;
    i++;
  }
  console.log('Wikidata-paren toegevoegd:', wikiAdds);
} else {
  console.warn('Geen Wikidata-bestand:', WIKI_FR);
}

function scoreOf(routes) {
  if (routes.has('D')) return 3;
  if (routes.has('R') && routes.has('P')) return 3;
  if (routes.has('R') || routes.has('P')) return 2;
  if (routes.has('W')) return 1;
  return 1;
}

const out = [];
for (const nl of [...perNl.keys()].sort((a, b) => a.localeCompare(b, 'nl'))) {
  const found = perNl.get(nl);
  const rows = [...found.entries()]
    .map(([fr, routes]) => {
      const sc = scoreOf(routes);
      const g = gender.get(key(fr)) || '';
      const pos = guessPos(fr);
      let note = '';
      if (g === 'm.') note = 'le / un';
      else if (g === 'f.') note = 'la / une';
      else if (g === 'm./f.') note = 'le of la';
      return [fr, sc, g, pos, note];
    })
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'fr'))
    .slice(0, 10);
  if (rows.length) out.push([nl, rows]);
}

fs.mkdirSync(path.dirname(OUT), { recursive: true });
const meta = {
  source: 'FreeDict (GPL) + EN-pivot + Wikidata interwiki (CC0); geslacht: Google French Nouns',
  generated: new Date().toISOString().slice(0, 10),
  entries: out.length,
  note: 'Score 3 = FreeDict direct, 2 = via Engels, 1 = Wikidata (vaak eigennamen). Controleer bij twijfel.'
};
fs.writeFileSync(OUT, JSON.stringify({ meta, entries: out }));
console.log('Geschreven:', OUT);
console.log("Lemma's:", out.length);
