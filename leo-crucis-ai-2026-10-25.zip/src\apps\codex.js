// Canoniek Recht — CIC 1917
// Bovenbalk: [Versie] [Liber] [Zoeken] [opties]
// Zijbalk: alleen secties van het huidige Liber (geen Libri-lijst)

const BASE = 'data/codex-1917/';
const POS_KEY = 'lc-codex-pos-v1';

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function loadPos() {
  try { return JSON.parse(localStorage.getItem(POS_KEY) || 'null') || {}; } catch { return {}; }
}
function savePos(p) {
  try { localStorage.setItem(POS_KEY, JSON.stringify(p)); } catch (_) {}
}

export function createCodexApp(startPos) {
  const root = el('div', 'mini-app-root bijbel-app codex-root');
  const pos = loadPos();
  let sideOpen = pos.sideOpen !== false;
  let lang = pos.lang || 'la'; // 'la' | 'nl'

  // ——— Toolbar ———
  const bar = el('div', 'bb-bar');

  // 1. Versie (Latijn / Nederlands)
  const grpVer = el('div', 'bb-grp');
  const verSel = el('select', 'bb-select');
  verSel.setAttribute('aria-label', 'Versie van het wetboek');
  const optLa = el('option', '', 'Latijn (1917)');
  optLa.value = 'la';
  const optNl = el('option', '', 'Nederlands (Leo Crucis)');
  optNl.value = 'nl';
  // NL beschikbaar voor canones met veld `dutch` (nu 1–10); rest valt terug op Latijn
  verSel.append(optLa, optNl);
  verSel.value = (lang === 'nl') ? 'nl' : 'la';
  verSel.onchange = () => {
    lang = verSel.value;
    savePos({ ...loadPos(), lang });
    renderTitle();
  };
  grpVer.append(verSel);

  // 2. Liber (grote delen)
  const grpBook = el('div', 'bb-grp');
  const bookSel = el('select', 'bb-select codex-liber-sel');
  bookSel.setAttribute('aria-label', 'Liber kiezen');
  grpBook.append(bookSel);

  // 3. Zoeken: nummer + tekst (knop = icoon)
  const grpSearch = el('div', 'bb-grp bb-grp-grow');
  const searchForm = el('form', 'bb-form');
  const numIn = el('input', 'bb-input codex-num-in');
  numIn.type = 'number';
  numIn.placeholder = 'Can. nr.';
  numIn.setAttribute('aria-label', 'Canonnummer zoeken');
  numIn.min = '1';
  numIn.max = '2414';
  numIn.style.maxWidth = '6.5em';
  numIn.style.flex = '0 0 6.5em';
  const qIn = el('input', 'bb-input');
  qIn.type = 'search';
  qIn.placeholder = 'Zoek op woorden…';
  qIn.setAttribute('aria-label', 'Tekst zoeken');
  const qBtn = el('button', 'bb-btn bb-btn-icon');
  qBtn.type = 'submit';
  qBtn.title = 'Zoeken';
  qBtn.setAttribute('aria-label', 'Zoeken');
  // vergrootglas-icoon (SVG)
  qBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>';
  searchForm.append(numIn, qIn, qBtn);
  searchForm.onsubmit = (e) => {
    e.preventDefault();
    const num = numIn.value.trim();
    if (num) goToCanon(Number(num));
    else doSearch(qIn.value);
  };
  numIn.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); if (numIn.value.trim()) goToCanon(Number(numIn.value)); }
  });
  grpSearch.append(searchForm);

  // 4. Opties
  const grpOpts = el('div', 'bb-grp bb-grp-opts');
  const listBtn = el('button', 'bb-btn bb-btn-icon bb-ghost', '☰');
  listBtn.type = 'button';
  listBtn.title = 'Zijbalk tonen/verbergen';
  listBtn.onclick = () => {
    sideOpen = !sideOpen;
    layout.classList.toggle('bb-side-collapsed', !sideOpen);
    savePos({ ...loadPos(), sideOpen });
  };
  const prevBtn = el('button', 'bb-btn bb-btn-icon bb-ghost', '‹');
  prevBtn.type = 'button';
  prevBtn.title = 'Vorige sectie';
  prevBtn.onclick = () => stepTitle(-1);
  const nextBtn = el('button', 'bb-btn bb-btn-icon bb-ghost', '›');
  nextBtn.type = 'button';
  nextBtn.title = 'Volgende sectie';
  nextBtn.onclick = () => stepTitle(1);
  grpOpts.append(listBtn, prevBtn, nextBtn);

  bar.append(grpVer, grpBook, grpSearch, grpOpts);

  // ——— Layout ———
  const layout = el('div', 'bb-layout');
  if (!sideOpen) layout.classList.add('bb-side-collapsed');
  const side = el('nav', 'bb-side');
  side.id = 'codex-side-nav';
  listBtn.setAttribute('aria-controls', 'codex-side-nav');
  const main = el('div', 'bb-main');
  layout.append(side, main);
  root.append(bar, layout);

  // ——— State ———
  let index = null;
  let bookData = null;
  let bookId = null;
  let titleIdx = 0;
  const cache = new Map();
  const titleBtns = new Map();

  function shortTitle(t) {
    let s = String(t || '');
    // Strip alle "(cann. 87–110)" / "(87–110)" bereiken
    s = s.replace(/\s*[\(（](?:cann?\.?\s*)?\d+\s*[–—\-]\s*\d+[\)）]/giu, '');
    s = s.replace(/\s*[–—-]\s*/g, ' · ');
    s = s.replace(/\s+/g, ' ').trim();
    return s;
  }

  function canonRange(tit) {
    const cans = tit.canons || [];
    if (!cans.length) return '';
    const a = cans[0].n, b = cans[cans.length - 1].n;
    return a === b ? String(a) : a + '–' + b;
  }

  async function loadIndex() {
    main.replaceChildren(el('p', 'bb-status', 'Codex laden…'));
    try {
      const res = await fetch(BASE + 'index.json');
      if (!res.ok) throw new Error('index.json niet gevonden');
      index = await res.json();
      bookSel.replaceChildren();
      for (const b of index.books) {
        const o = el('option', '', shortTitle(b.title));
        o.value = b.id;
        o.title = b.title + (b.canons ? ' · can. ' + b.canons : '');
        bookSel.append(o);
      }
      const startBook = (startPos && startPos.book) || pos.book || index.books[0].id;
      bookSel.value = startBook;
      await openBook(startBook, (startPos && startPos.titleId) || pos.titleId || null);
    } catch (e) {
      main.replaceChildren(el('p', 'bb-status', 'Kon Codex niet laden: ' + e.message));
    }
  }

  async function openBook(id, preferTitleId) {
    bookId = id;
    savePos({ ...loadPos(), book: id });
    if (!cache.has(id)) {
      const meta = index.books.find(b => b.id === id);
      if (!meta) {
        main.replaceChildren(el('p', 'bb-status', 'Onbekend liber.'));
        return;
      }
      main.replaceChildren(el('p', 'bb-status', 'Laden…'));
      const res = await fetch(BASE + meta.file);
      if (!res.ok) throw new Error(meta.file + ' niet gevonden');
      cache.set(id, await res.json());
    }
    bookData = cache.get(id);
    const titles = bookData.titles || [];
    let idx = 0;
    if (preferTitleId) {
      const found = titles.findIndex(t => t.id === preferTitleId);
      if (found >= 0) idx = found;
    } else if (pos.book === id && typeof pos.titleIdx === 'number' && pos.titleIdx < titles.length) {
      idx = pos.titleIdx;
    }
    titleIdx = idx;
    buildSide();
    renderTitle();
  }

  /** Zijbalk: alleen secties van het huidige Liber */
  function buildSide() {
    side.replaceChildren();
    titleBtns.clear();
    const titles = (bookData && bookData.titles) || [];
    const meta = index.books.find(b => b.id === bookId);
    side.append(el('h3', 'bb-side-h', meta ? shortTitle(meta.title) : 'Secties'));

    if (!titles.length) {
      side.append(el('p', 'bb-note', 'Geen secties.'));
      return;
    }
    const ul = el('ul', 'bb-books');
    titles.forEach((t, i) => {
      const li = el('li');
      const range = canonRange(t);
      const btn = el('button', 'bb-book' + (i === titleIdx ? ' on' : ''), shortTitle(t.title));
      btn.type = 'button';
      btn.title = t.title + (range ? ' · can. ' + range : '');
      btn.onclick = () => {
        titleIdx = i;
        renderTitle();
      };
      li.append(btn);
      ul.append(li);
      titleBtns.set(i, btn);
    });
    side.append(ul);
  }

  function renderTitle() {
    const titles = (bookData && bookData.titles) || [];
    const tit = titles[titleIdx];
    main.replaceChildren();
    if (!tit) {
      main.append(el('p', 'bb-status', 'Geen sectie.'));
      return;
    }
    savePos({ ...loadPos(), book: bookId, titleId: tit.id, titleIdx, lang });

    titleBtns.forEach((btn, i) => btn.classList.toggle('on', i === titleIdx));

    const head = el('div', 'bb-head');
    head.append(el('h1', 'bb-title', shortTitle(tit.title)));
    const range = canonRange(tit);
    const meta = index.books.find(b => b.id === bookId);
    const subParts = [];
    if (meta) subParts.push(shortTitle(meta.title));
    if (range) subParts.push('can. ' + range);
    subParts.push((tit.canons || []).length + ' canones');
    subParts.push(lang === 'nl' ? 'NL' : 'Latijn');
    head.append(el('span', 'bb-sub', subParts.join(' · ')));
    main.append(head);

    const cans = tit.canons || [];
    if (cans.length > 1 && cans.length <= 80) {
      const chips = el('div', 'bb-chips');
      for (const c of cans) {
        const chip = el('button', 'bb-chip', String(c.n));
        chip.type = 'button';
        chip.title = 'Ga naar can. ' + c.n;
        chip.onclick = () => {
          const target = main.querySelector(`[data-can="${c.n}"]`);
          if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        };
        chips.append(chip);
      }
      main.append(chips);
    }

    const textBox = el('div', 'bb-text codex-text');
    for (const c of cans) {
      const art = el('article', 'codex-canon');
      art.dataset.can = c.n;
      const num = el('span', 'bb-vn codex-can-num', 'Can. ' + c.n);
      const body = el('div', 'codex-can-body');
      // Nederlands (Leo Crucis) indien aanwezig; anders Latijn
      const hasNl = !!(c.dutch && String(c.dutch).trim());
      const raw = (lang === 'nl' && hasNl) ? c.dutch : (c.text || '');
      for (const p of String(raw).split(/\n+/)) {
        if (p.trim()) body.append(el('p', '', p.trim()));
      }
      if (lang === 'nl' && !hasNl && (c.text || '').trim()) {
        const note = el('p', 'codex-nl-missing');
        note.style.cssText = 'font-size:.85em;color:var(--mute);font-style:italic;margin-top:.35em';
        note.textContent = 'Nederlandse vertaling nog niet beschikbaar — Latijnse tekst getoond.';
        body.append(note);
      }
      art.append(num, body);
      textBox.append(art);
    }
    main.append(textBox);

    prevBtn.disabled = titleIdx <= 0;
    nextBtn.disabled = titleIdx >= titles.length - 1;
  }

  function stepTitle(dir) {
    const titles = (bookData && bookData.titles) || [];
    const next = titleIdx + dir;
    if (next < 0 || next >= titles.length) return;
    titleIdx = next;
    renderTitle();
    main.scrollTop = 0;
  }


  /** Spring naar een canonnummer (in huidig liber of over alle geladen data). */
  function goToCanon(n) {
    if (!Number.isFinite(n) || n < 1) return;
    // Eerst in huidig liber
    if (bookData) {
      for (let ti = 0; ti < (bookData.titles || []).length; ti++) {
        const tit = bookData.titles[ti];
        if ((tit.canons || []).some(c => c.n === n)) {
          titleIdx = ti;
          renderTitle();
          requestAnimationFrame(() => {
            const target = main.querySelector(`[data-can="${n}"]`);
            if (target) {
              target.scrollIntoView({ behavior: 'smooth', block: 'start' });
              target.classList.add('codex-hit');
              setTimeout(() => target.classList.remove('codex-hit'), 2000);
            }
          });
          return;
        }
      }
    }
    // Zoek in andere libri via index (lazy load)
    if (!index) return;
    const ranges = [
      { id: 'liber-i', lo: 1, hi: 86 },
      { id: 'liber-ii', lo: 87, hi: 725 },
      { id: 'liber-iii', lo: 726, hi: 1551 },
      { id: 'liber-iv', lo: 1552, hi: 2194 },
      { id: 'liber-v', lo: 2195, hi: 2414 },
    ];
    const hit = ranges.find(r => n >= r.lo && n <= r.hi);
    if (!hit) {
      main.replaceChildren(el('p', 'bb-status', 'Canon ' + n + ' bestaat niet (1–2414).'));
      return;
    }
    bookSel.value = hit.id;
    openBook(hit.id, null).then(() => {
      for (let ti = 0; ti < (bookData.titles || []).length; ti++) {
        if ((bookData.titles[ti].canons || []).some(c => c.n === n)) {
          titleIdx = ti;
          renderTitle();
          requestAnimationFrame(() => {
            const target = main.querySelector(`[data-can="${n}"]`);
            if (target) {
              target.scrollIntoView({ behavior: 'smooth', block: 'start' });
              target.classList.add('codex-hit');
              setTimeout(() => target.classList.remove('codex-hit'), 2000);
            }
          });
          break;
        }
      }
    }).catch(err => {
      main.replaceChildren(el('p', 'bb-status', String(err.message || err)));
    });
  }

  function doSearch(q) {
    q = String(q || '').trim().toLowerCase();
    if (!q || !bookData) return;
    const hits = [];
    for (let ti = 0; ti < (bookData.titles || []).length; ti++) {
      const tit = bookData.titles[ti];
      for (const c of tit.canons || []) {
        const text = String(c.text || '').toLowerCase();
        const dutch = String(c.dutch || '').toLowerCase();
        if (String(c.n) === q || String(c.n).includes(q) || text.includes(q) || dutch.includes(q)) {
          hits.push({ ti, n: c.n, title: tit.title, snippet: snippet(c.text || c.dutch, q) });
          if (hits.length >= 40) break;
        }
      }
      if (hits.length >= 40) break;
    }
    main.replaceChildren();
    main.append(el('h1', 'bb-title', 'Zoekresultaten'));
    main.append(el('p', 'bb-sub', hits.length ? hits.length + ' treffer(s) in dit liber' : 'Geen treffers in dit liber.'));
    if (!hits.length) return;
    const list = el('div', 'bb-text');
    for (const h of hits) {
      const row = el('button', 'bb-book');
      row.type = 'button';
      row.style.display = 'block';
      row.style.width = '100%';
      row.style.textAlign = 'left';
      row.style.padding = '8px 10px';
      row.style.marginBottom = '4px';
      const strong = el('strong', '', 'Can. ' + h.n);
      row.append(strong);
      row.append(document.createTextNode(' · ' + shortTitle(h.title)));
      if (h.snippet) {
        const sn = el('div', 'bb-note');
        sn.style.margin = '2px 0 0';
        sn.textContent = h.snippet;
        row.append(sn);
      }
      row.onclick = () => {
        titleIdx = h.ti;
        renderTitle();
        requestAnimationFrame(() => {
          const target = main.querySelector(`[data-can="${h.n}"]`);
          if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            target.classList.add('codex-hit');
            setTimeout(() => target.classList.remove('codex-hit'), 2000);
          }
        });
      };
      list.append(row);
    }
    main.append(list);
  }

  function snippet(text, q) {
    const t = String(text || '');
    const low = t.toLowerCase();
    const i = low.indexOf(q);
    if (i < 0) return t.slice(0, 100) + (t.length > 100 ? '…' : '');
    const a = Math.max(0, i - 40);
    const b = Math.min(t.length, i + q.length + 60);
    return (a > 0 ? '…' : '') + t.slice(a, b) + (b < t.length ? '…' : '');
  }

  bookSel.onchange = () => {
    openBook(bookSel.value, null).catch(err => {
      main.replaceChildren(el('p', 'bb-status', String(err.message || err)));
    });
  };

  loadIndex().catch(err => {
    main.replaceChildren(el('p', 'bb-status', String(err.message || err)));
  });

  return root;
}
