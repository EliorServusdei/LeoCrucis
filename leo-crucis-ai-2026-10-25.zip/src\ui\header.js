/**
 * ui/header.js — header-menu's, Office-recent, favorieten, klok (fase 1)
 */

import { el } from '../core/dom.js';
import { miniAppIconSvg } from '../apps/registry.js';
import { MINI_APP_TITLES } from './mini-apps-view.js';

const OFFICE_RECENT_KEY = 'lc-office-recent-v1';
const OFFICE_RECENT_MAX = 5;
const OFFICE_TYPES = ['doc', 'pptx', 'xlsx', 'pdf'];
const APP_FAV_KEY = 'lc-app-favorites-v1';

/**
 * @param {object} deps
 * @param {() => object[]} deps.allItems
 * @param {() => { kind: string, run: Function }[]} deps.listLeoApps
 * @param {(type: string) => void|Promise<void>} deps.startCreate
 * @param {(kind: string, startPos?: *) => void} deps.showMiniApp
 * @param {(kind?: string) => void} [deps.showMediaPlayer]
 * @param {() => void} [deps.showFocus]
 * @param {(kind: string, openFn: Function) => Function} [deps.guardFocusBlock]
 * @param {() => void} [deps.applyFocusBlockLock]
 * @param {() => boolean} [deps.isStudyBlockActive]
 * @param {(type: string) => { icon?: string }} deps.typeMeta
 */
export function createHeaderApi(deps) {
  const {
    allItems,
    listLeoApps,
    startCreate,
    showMiniApp,
    showMediaPlayer = (k) => showMiniApp(k),
    showFocus = () => {},
    guardFocusBlock = (_k, fn) => fn,
    applyFocusBlockLock = () => {},
    isStudyBlockActive = () => false,
    typeMeta,
  } = deps;

  let hmenuEl = null;
  let hmenuBtn = null;

  function loadOfficeRecent() {
    try {
      const a = JSON.parse(localStorage.getItem(OFFICE_RECENT_KEY) || '[]');
      return Array.isArray(a) ? a.filter(x => typeof x === 'string') : [];
    } catch (_) { return []; }
  }

  function rememberOfficeRecent(id) {
    try {
      const it = allItems().find(i => i.id === id);
      if (!it || !OFFICE_TYPES.includes(it.type || 'doc')) return;
      const list = loadOfficeRecent().filter(x => x !== id);
      list.unshift(id);
      localStorage.setItem(OFFICE_RECENT_KEY, JSON.stringify(list.slice(0, 20)));
    } catch (_) {}
  }

  function closeHeaderMenu(focusBtn) {
    if (!hmenuEl) return;
    hmenuEl.remove();
    hmenuEl = null;
    document.removeEventListener('pointerdown', onHmenuOutside, true);
    document.removeEventListener('keydown', onHmenuKey, true);
    window.removeEventListener('resize', closeHeaderMenu);
    if (hmenuBtn) {
      hmenuBtn.setAttribute('aria-expanded', 'false');
      if (focusBtn === true) hmenuBtn.focus();
    }
    hmenuBtn = null;
  }

  function onHmenuOutside(e) {
    if (!hmenuEl) return;
    if (hmenuEl.contains(e.target) || (hmenuBtn && hmenuBtn.contains(e.target))) return;
    closeHeaderMenu();
  }

  function onHmenuKey(e) {
    if (!hmenuEl) return;
    if (e.key === 'Escape') { e.preventDefault(); closeHeaderMenu(true); return; }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Home' || e.key === 'End') {
      const items = [...hmenuEl.querySelectorAll('.hmenu-item:not(:disabled)')];
      if (!items.length) return;
      e.preventDefault();
      let i = items.indexOf(document.activeElement);
      if (e.key === 'Home') i = 0;
      else if (e.key === 'End') i = items.length - 1;
      else i = (i + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
      items[i].focus();
    }
  }

  function hmenuSvg(kind) {
    const svg = miniAppIconSvg(kind);
    if (svg) { svg.setAttribute('width', '18'); svg.setAttribute('height', '18'); }
    return svg;
  }

  function toggleHeaderMenu(btn, label, fill) {
    if (hmenuEl) { const same = hmenuBtn === btn; closeHeaderMenu(); if (same) return; }

    const menu = el('div', 'hmenu');
    menu.setAttribute('role', 'menu');
    menu.setAttribute('aria-label', label);

    const add = (icon, text, hint, onPick, opts = {}) => {
      const b = el('button', 'hmenu-item');
      b.type = 'button';
      b.setAttribute('role', 'menuitem');
      const ic = el('span', 'hmenu-item-icon');
      if (typeof icon === 'string') ic.textContent = icon; else if (icon) ic.append(icon);
      b.append(ic, el('span', 'hmenu-item-label', text));
      if (hint) b.append(el('span', 'hmenu-item-hint', hint));
      if (opts.disabled) {
        b.disabled = true;
        if (opts.title) b.title = opts.title;
      } else {
        b.onclick = () => { closeHeaderMenu(); onPick(); };
      }
      menu.append(b);
      return b;
    };
    fill(menu, add);

    document.body.append(menu);
    hmenuEl = menu;
    hmenuBtn = btn;
    btn.setAttribute('aria-expanded', 'true');

    const r = btn.getBoundingClientRect();
    const w = menu.offsetWidth;
    const h = menu.offsetHeight;
    menu.style.left = Math.max(8, Math.min(r.left, window.innerWidth - w - 8)) + 'px';
    const above = r.top - h - 8;
    menu.style.top = (above >= 8 ? above : Math.min(r.bottom + 8, window.innerHeight - h - 8)) + 'px';

    document.addEventListener('pointerdown', onHmenuOutside, true);
    document.addEventListener('keydown', onHmenuKey, true);
    window.addEventListener('resize', closeHeaderMenu);
    const first = menu.querySelector('.hmenu-item:not(:disabled)');
    if (first) first.focus();
  }

  function openOfficeMenu(btn) {
    toggleHeaderMenu(btn, 'Office', (menu, add) => {
      menu.append(el('div', 'hmenu-section', 'Nieuw'));
      add(typeMeta('doc').icon, 'Nieuw document', '', () => startCreate('doc'));
      add(typeMeta('pptx').icon, 'Nieuwe presentatie', '', () => startCreate('pptx'));
      add(typeMeta('xlsx').icon, 'Nieuw rekenblad', '', () => startCreate('xlsx'));

      const items = allItems();
      const recent = loadOfficeRecent()
        .map(id => items.find(i => i.id === id))
        .filter(Boolean)
        .slice(0, OFFICE_RECENT_MAX);
      if (recent.length) {
        menu.append(el('div', 'hmenu-section', 'Recent'));
        for (const it of recent) {
          const icon = typeMeta(it.type || 'doc').icon || '📄';
          add(icon, it.title || it.id, '', () => {
            try {
              const app = listLeoApps().find(a => a.kind === (it.type || 'doc'));
              // Open via showSection-achtige flow: caller kan id doorgeven via custom
              if (typeof deps.openItem === 'function') deps.openItem(it);
              else if (typeof deps.showSection === 'function') deps.showSection(it.id);
            } catch (e) { console.warn(e); }
          });
        }
      }
    });
  }

  const HEADER_GROUPS = {
    media: {
      title: 'Media',
      items: [
        { kind: 'audio', lock: true, run: () => showMediaPlayer('audio') },
        { kind: 'video', lock: true, run: () => showMediaPlayer('video') }
      ]
    },
    studiehulp: {
      title: 'Studiehulp',
      items: [
        { kind: 'focus', run: () => showFocus() },
        { kind: 'notes', run: () => showMiniApp('notes') },
        { kind: 'budgetter', run: () => showMiniApp('budgetter') },
        { kind: 'todo', run: () => showMiniApp('todo') },
        { kind: 'timer', run: () => showMiniApp('timer') },
        { kind: 'calculator', run: () => showMiniApp('calculator') },
        { kind: 'browser', run: () => showMiniApp('browser') },
        { kind: 'woordenboek', run: () => showMiniApp('woordenboek') }
      ]
    },
    devotionalia: {
      title: 'Devotionalia',
      items: [
        { kind: 'bible', run: () => showMiniApp('bible') },
        { kind: 'codex', run: () => showMiniApp('codex') },
        { kind: 'xref-map', run: () => showMiniApp('xref-map') }
      ]
    },
    beeld: {
      title: 'Beeld',
      items: [
        { kind: 'gallery', run: () => showMiniApp('gallery') },
        { kind: 'album', run: () => showMiniApp('album') },
        { kind: 'maps', run: () => showMiniApp('maps') }
      ]
    }
  };

  function openGroupMenu(btn, key) {
    const g = HEADER_GROUPS[key];
    if (!g) return;
    toggleHeaderMenu(btn, g.title, (menu, add) => {
      const locked = isStudyBlockActive();
      for (const it of g.items) {
        const name = MINI_APP_TITLES[it.kind] || it.kind;
        const off = locked && it.lock;
        add(hmenuSvg(it.kind), name, off ? 'Focusblok' : '', it.run, {
          disabled: off,
          title: 'Niet beschikbaar tijdens een focusblok'
        });
      }
    });
  }

  function loadAppFavorites() {
    try {
      const a = JSON.parse(localStorage.getItem(APP_FAV_KEY) || '[]');
      return Array.isArray(a) ? a.filter(x => typeof x === 'string') : [];
    } catch (_) { return []; }
  }

  function saveAppFavorites(list) {
    try { localStorage.setItem(APP_FAV_KEY, JSON.stringify(list.slice(0, 20))); } catch (_) {}
  }

  function isAppFavorite(kind) {
    return loadAppFavorites().includes(kind);
  }

  function toggleAppFavorite(kind) {
    const cur = loadAppFavorites();
    const was = cur.includes(kind);
    const next = was ? cur.filter(x => x !== kind) : [kind, ...cur.filter(x => x !== kind)];
    saveAppFavorites(next);
    try { renderHeaderFavorites(); } catch (_) {}
    return !was;
  }

  /** Header toont geen app-icoontjes; favorieten blijven opgeslagen voor elders. */
  function renderHeaderFavorites() {
    const host = document.getElementById('header-favorites');
    if (host) host.replaceChildren();
  }

  function initHeaderClock() {
    const timeEl = document.getElementById('header-clock-time');
    const dateEl = document.getElementById('header-clock-date');
    const btn = document.getElementById('btn-clock');
    if (!timeEl || !dateEl) return;
    const days = ['zo', 'ma', 'di', 'wo', 'do', 'vr', 'za'];
    const months = ['jan', 'feb', 'mrt', 'apr', 'mei', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'dec'];
    function pad(n) { return n < 10 ? '0' + n : '' + n; }
    function tick() {
      const now = new Date();
      timeEl.textContent = pad(now.getHours()) + ':' + pad(now.getMinutes());
      dateEl.textContent = days[now.getDay()] + ' ' + now.getDate() + ' ' + months[now.getMonth()];
      if (btn) {
        const full = now.toLocaleString('nl-BE', {
          weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
          hour: '2-digit', minute: '2-digit'
        });
        btn.title = full + ' — open kalender';
      }
    }
    tick();
    const ms = 60000 - (Date.now() % 60000);
    setTimeout(function() {
      tick();
      setInterval(tick, 60000);
    }, ms);
    if (btn) btn.onclick = () => showMiniApp('calendar');
  }

  function wireHeaderTools() {
    // Header blijft leeg van app-knoppen (media, studiehulp, devotionalia, beeld, office, …).
    // Apps open je via het startscherm / menu — niet via vaste icoontjes in de header.
    ['tool-office', 'tool-media', 'tool-studiehulp', 'tool-devotionalia', 'tool-beeld', 'tool-games', 'tool-tetris', 'btn-study'].forEach(id => {
      const node = document.getElementById(id);
      if (node) { node.hidden = true; node.style.display = 'none'; }
    });
    const statusDd = document.getElementById('btn-status-dd');
    if (statusDd) { statusDd.hidden = true; statusDd.style.display = 'none'; }

    // Geen favoriet-apps in de header
    const favHost = document.getElementById('header-favorites');
    if (favHost) favHost.replaceChildren();

    initHeaderClock();
    applyFocusBlockLock();
  }

  return {
    wireHeaderTools,
    renderHeaderFavorites,
    rememberOfficeRecent,
    loadOfficeRecent,
    loadAppFavorites,
    saveAppFavorites,
    isAppFavorite,
    toggleAppFavorite,
    closeHeaderMenu,
    openOfficeMenu,
    openGroupMenu,
  };
}
