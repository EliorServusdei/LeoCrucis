// Memory — zelfstandige mini-app.
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

function memoryGame(host) {
  host.replaceChildren();

  let styleEl = document.getElementById('mem-revamp-styles');
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'mem-revamp-styles';
    document.head.append(styleEl);
  }
  styleEl.textContent = `
.mem-app{
  display:flex;flex-direction:column;align-items:center;gap:0;
  width:100%;height:100%;min-height:0;box-sizing:border-box;
  background:var(--bg);color:var(--ink);
  font-family:"Courier New",Courier,ui-monospace,monospace;
  border-radius:0;overflow:hidden;transition:background .45s ease;
  position:relative;
}
/* CRT scanlines */
.mem-app::before{
  content:'';pointer-events:none;position:absolute;inset:0;z-index:20;
  background:repeating-linear-gradient(
    0deg,
    transparent 0px,
    transparent 2px,
    rgba(0,0,0,.18) 2px,
    rgba(0,0,0,.18) 4px
  );
  opacity:.55;
}
/* Subtle vignette */
.mem-app::after{
  content:'';pointer-events:none;position:absolute;inset:0;z-index:19;
  background:radial-gradient(ellipse at center,transparent 50%,rgba(0,0,0,.55) 100%);
}
.mem-app.p1{background:#0c1a2e;}
.mem-app.p2{background:#2a100c;}
.mem-app.p3{background:#0c2412;}
.mem-app.p4{background:#241a0c;}
.mem-app.p5{background:#1a0c28;}
.mem-app.p6{background:#0c2220;}

/* ── Setup screen ── */
.mem-setup{
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  gap:20px;padding:32px 20px;width:100%;max-width:520px;margin:auto;box-sizing:border-box;
  position:relative;z-index:2;
}
.mem-setup-title{
  margin:0;font-size:clamp(1.8rem,5vw,2.4rem);font-weight:800;letter-spacing:.22em;
  text-transform:uppercase;color:var(--acc);
  text-shadow:0 0 12px rgba(155,188,15,.45),0 0 28px rgba(155,188,15,.2);
  animation:mem-glow 2.8s ease-in-out infinite alternate;
}
@keyframes mem-glow{
  from{text-shadow:0 0 8px rgba(155,188,15,.35),0 0 18px rgba(155,188,15,.12);}
  to{text-shadow:0 0 16px rgba(155,188,15,.6),0 0 36px rgba(155,188,15,.3);}
}
.mem-setup-sub{
  margin:0;font-size:.78rem;opacity:.65;text-align:center;letter-spacing:.08em;
  text-transform:uppercase;color:var(--mute);
}
.mem-setup-section{width:100%;display:flex;flex-direction:column;gap:8px;}
.mem-setup-label{
  font-size:.65rem;text-transform:uppercase;letter-spacing:.16em;
  opacity:.5;font-weight:700;color:var(--mute);text-align:center;
}
.mem-chip-row{display:flex;flex-wrap:wrap;gap:7px;justify-content:center;}
.mem-chip{
  border:2px solid var(--line);background:var(--panel);
  color:var(--mute);border-radius:4px;padding:9px 15px;font:inherit;font-size:12px;font-weight:700;
  cursor:pointer;transition:all .15s;letter-spacing:.04em;text-transform:uppercase;
  box-shadow:inset 0 0 0 1px rgba(155,188,15,.06);
}
.mem-chip:hover{border-color:var(--mute);background:var(--sel);color:var(--acc2);box-shadow:0 0 10px rgba(155,188,15,.2);}
.mem-chip.is-active{
  border-color:var(--acc);color:var(--bg);font-weight:800;
  background:var(--acc);
  box-shadow:0 0 14px rgba(155,188,15,.4),inset 0 1px 0 rgba(255,255,255,.25);
}
.mem-chip.pcol-1.is-active{background:#5a9fd4;border-color:#5a9fd4;color:var(--bg);box-shadow:0 0 14px rgba(90,159,212,.45);}
.mem-chip.pcol-2.is-active{background:#d46b5a;border-color:#d46b5a;color:var(--bg);box-shadow:0 0 14px rgba(212,107,90,.45);}
.mem-chip.pcol-3.is-active{background:#5ad48a;border-color:#5ad48a;color:var(--bg);box-shadow:0 0 14px rgba(90,212,138,.45);}
.mem-chip.pcol-4.is-active{background:#d4b05a;border-color:#d4b05a;color:var(--bg);box-shadow:0 0 14px rgba(212,176,90,.45);}
.mem-chip.pcol-5.is-active{background:#9b6bd4;border-color:#9b6bd4;color:var(--bg);box-shadow:0 0 14px rgba(155,107,212,.45);}
.mem-chip.pcol-6.is-active{background:#5ad4c8;border-color:#5ad4c8;color:var(--bg);box-shadow:0 0 14px rgba(90,212,200,.45);}
.mem-start-btn{
  margin-top:12px;border:3px solid var(--acc);border-radius:4px;padding:14px 44px;
  font:inherit;font-size:15px;font-weight:800;letter-spacing:.18em;cursor:pointer;
  text-transform:uppercase;background:var(--panel);color:var(--acc);
  box-shadow:0 0 20px rgba(155,188,15,.25),inset 0 0 12px rgba(155,188,15,.08);
  transition:transform .12s,box-shadow .15s,background .15s,color .15s;
  position:relative;z-index:2;
}
.mem-start-btn:hover{
  background:var(--acc);color:var(--bg);
  box-shadow:0 0 28px rgba(155,188,15,.5),inset 0 1px 0 rgba(255,255,255,.2);
  transform:translateY(-2px);
}
.mem-start-btn:active{transform:translateY(0);}

/* ── Play screen ── */
.mem-play{display:none;flex-direction:column;width:100%;height:100%;min-height:0;position:relative;z-index:2;}
.mem-play.is-on{display:flex;}
.mem-top{
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  padding:12px 16px 10px;flex-shrink:0;
  background:rgba(10,20,8,.75);border-bottom:2px solid var(--mute);
  box-shadow:0 2px 12px rgba(0,0,0,.3);
}
.mem-top-left{display:flex;align-items:center;gap:8px;}
.mem-back-hub{
  border:2px solid var(--mute);background:#1a2a12;
  color:var(--acc2);border-radius:4px;width:34px;height:34px;font-size:15px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;padding:0;font-weight:700;
  box-shadow:0 0 10px rgba(155,188,15,.2);
}
.mem-back-hub:hover{border-color:var(--acc2);color:#e8f0a0;background:#243818;box-shadow:0 0 14px rgba(155,188,15,.35);}
.mem-turn-badge{
  display:flex;align-items:center;gap:8px;padding:7px 16px;border-radius:4px;
  font-size:13px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;
  background:rgba(30,50,20,.9);border:2px solid var(--acc);
  transition:background .35s,border-color .35s,box-shadow .35s,color .35s;
  color:#d4e85a;
  box-shadow:0 0 12px rgba(155,188,15,.25);
}
.mem-turn-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0;box-shadow:0 0 8px currentColor;}
.mem-top-stats{
  display:flex;gap:16px;font-size:12px;font-weight:800;
  font-variant-numeric:tabular-nums;letter-spacing:.08em;text-transform:uppercase;color:#a8c820;
  text-shadow:0 0 6px rgba(155,188,15,.3);
}
.mem-top-stats b{color:#e8f060;font-size:1.05em;}

.mem-players-bar{
  display:flex;gap:6px;padding:8px 12px;flex-shrink:0;overflow-x:auto;
  justify-content:center;flex-wrap:wrap;
  border-bottom:1px solid rgba(155,188,15,.35);
}
.mem-player-pill{
  display:flex;align-items:center;gap:6px;padding:6px 14px 6px 10px;border-radius:4px;
  font-size:12px;font-weight:800;border:2px solid color-mix(in srgb, currentColor 35%, transparent);
  letter-spacing:.06em;text-transform:uppercase;
  background:color-mix(in srgb, currentColor 8%, rgba(0,0,0,.4));
  opacity:.55;transition:all .3s;white-space:nowrap;
}
.mem-player-pill.is-turn{
  opacity:1;border-color:currentColor;
  box-shadow:0 0 18px color-mix(in srgb, currentColor 45%, transparent);
  background:color-mix(in srgb, currentColor 22%, transparent);
  transform:scale(1.05);
}
.mem-player-pill .mp-dot{width:8px;height:8px;border-radius:50%;background:currentColor;}
.mem-player-pill .mp-score{font-variant-numeric:tabular-nums;min-width:1.2em;text-align:center;}

.mem-board-area{
  flex:1;min-height:0;overflow:auto;display:flex;align-items:center;justify-content:center;
  padding:14px;box-sizing:border-box;
}
.mem-board{display:grid;gap:8px;perspective:900px;}
.mem-board.cols-4{grid-template-columns:repeat(4,minmax(58px,84px));}
.mem-board.cols-5{grid-template-columns:repeat(5,minmax(52px,74px));}
.mem-board.cols-6{grid-template-columns:repeat(6,minmax(48px,68px));}
.mem-board.cols-8{grid-template-columns:repeat(8,minmax(40px,58px));}

.mem-card{
  aspect-ratio:1;border:none;padding:0;cursor:pointer;background:transparent;
  perspective:600px;outline:none;-webkit-tap-highlight-color:transparent;
}
.mem-card:focus-visible .mem-face{box-shadow:0 0 0 2px var(--acc),0 0 12px rgba(155,188,15,.5);}
.mem-inner{
  position:relative;width:100%;height:100%;transform-style:preserve-3d;
  transition:transform .38s cubic-bezier(.4,.15,.2,1);
}
.mem-card.is-open .mem-inner,
.mem-card.is-done .mem-inner{transform:rotateY(180deg);}
.mem-face{
  position:absolute;inset:0;backface-visibility:hidden;border-radius:6px;
  display:flex;align-items:center;justify-content:center;
  border:2px solid var(--line);
  transition:box-shadow .2s,border-color .2s,background .2s;
}
.mem-back{
  background:
    linear-gradient(145deg,var(--panel) 0%,var(--bg) 100%);
  box-shadow:inset 0 0 0 1px rgba(155,188,15,.08),0 2px 8px rgba(0,0,0,.5);
}
.mem-back::before{
  content:'';position:absolute;inset:5px;border-radius:3px;
  border:1px solid rgba(155,188,15,.12);
  background:
    repeating-linear-gradient(45deg,transparent 0,transparent 3px,rgba(155,188,15,.04) 3px,rgba(155,188,15,.04) 4px),
    repeating-linear-gradient(-45deg,transparent 0,transparent 3px,rgba(155,188,15,.03) 3px,rgba(155,188,15,.03) 4px);
}
.mem-back::after{
  content:'◆';position:relative;z-index:1;font-size:1rem;
  opacity:.35;color:var(--acc);text-shadow:0 0 6px rgba(155,188,15,.4);
}
.mem-card:hover:not(.is-open):not(.is-done):not(:disabled) .mem-back{
  border-color:var(--mute);
  box-shadow:inset 0 0 0 1px rgba(155,188,15,.15),0 0 14px rgba(155,188,15,.2),0 4px 12px rgba(0,0,0,.5);
}
.mem-front{
  background:linear-gradient(145deg,var(--panel),var(--panel));
  transform:rotateY(180deg);
  font-size:clamp(1.15rem,3.8vw,1.75rem);line-height:1;
  box-shadow:inset 0 0 0 1px rgba(155,188,15,.1),0 2px 8px rgba(0,0,0,.4);
  color:var(--acc2);
}
.mem-card.is-done .mem-front{
  background:linear-gradient(145deg,#1e3018,#142210);
  border-color:var(--acc);
  box-shadow:0 0 0 2px rgba(155,188,15,.35),0 0 18px rgba(155,188,15,.2);
}
.mem-card.is-mismatch .mem-front{
  background:linear-gradient(145deg,#2a1410,#1a0c0a);
  border-color:#c45c4a;
  animation:mem-shake .4s ease;
}
@keyframes mem-shake{
  0%,100%{transform:rotateY(180deg) translateX(0);}
  20%{transform:rotateY(180deg) translateX(-5px);}
  40%{transform:rotateY(180deg) translateX(5px);}
  60%{transform:rotateY(180deg) translateX(-3px);}
  80%{transform:rotateY(180deg) translateX(2px);}
}

/* ── Win overlay ── */
.mem-win{
  position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
  background:rgba(6,10,6,.88);backdrop-filter:blur(4px);z-index:10;
  animation:mem-fadein .4s ease;
}
@keyframes mem-fadein{from{opacity:0;}to{opacity:1;}}
.mem-win-card{
  background:linear-gradient(160deg,var(--panel),var(--bg));border:3px solid var(--acc);
  border-radius:6px;padding:28px 32px;text-align:center;
  box-shadow:0 0 40px rgba(155,188,15,.2),0 16px 48px rgba(0,0,0,.5);max-width:340px;width:90%;
}
.mem-win-card h2{
  margin:0 0 8px;font-size:1.35rem;color:var(--acc);letter-spacing:.12em;text-transform:uppercase;
  text-shadow:0 0 12px rgba(155,188,15,.4);
}
.mem-win-card p{margin:0 0 4px;font-size:12px;color:var(--mute);letter-spacing:.06em;opacity:.75;}
.mem-win-scores{display:flex;flex-direction:column;gap:6px;margin:16px 0;align-items:stretch;}
.mem-win-row{
  display:flex;align-items:center;justify-content:space-between;gap:12px;
  padding:8px 14px;border-radius:4px;background:rgba(0,0,0,.35);border:1px solid var(--line);
  font-size:13px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;
}
.mem-win-row.is-winner{border-color:var(--acc);box-shadow:0 0 12px rgba(155,188,15,.25);background:rgba(155,188,15,.08);}
.mem-win-actions{display:flex;gap:8px;justify-content:center;margin-top:10px;flex-wrap:wrap;}
.mem-btn{
  border:2px solid var(--line);background:var(--panel);color:var(--mute);
  border-radius:4px;padding:10px 18px;font:inherit;font-size:12px;font-weight:700;cursor:pointer;
  letter-spacing:.08em;text-transform:uppercase;transition:all .15s;
}
.mem-btn:hover{border-color:var(--acc);color:var(--acc2);background:var(--sel);}
.mem-btn.primary{
  background:var(--acc);color:var(--bg);border-color:var(--acc);font-weight:800;
  box-shadow:0 0 16px rgba(155,188,15,.3);
}
.mem-btn.primary:hover{filter:brightness(1.1);box-shadow:0 0 22px rgba(155,188,15,.45);}

.mem-board-wrap{position:relative;display:flex;justify-content:center;}

@media (max-width:480px){
  .mem-board.cols-4{grid-template-columns:repeat(4,minmax(52px,1fr));gap:6px;}
  .mem-board.cols-5{grid-template-columns:repeat(5,minmax(44px,1fr));gap:5px;}
  .mem-board.cols-6{grid-template-columns:repeat(6,minmax(40px,1fr));gap:5px;}
  .mem-board.cols-8{grid-template-columns:repeat(8,minmax(34px,1fr));gap:4px;}
  .mem-front{font-size:1.05rem;}
  .mem-setup-title{font-size:1.5rem;letter-spacing:.16em;}
}

`;

  const PLAYER_COLORS = [
    { id: 1, name: 'Blauw',   hex: '#5a9fd4', bg: '#0e1218' },
    { id: 2, name: 'Rood',    hex: '#d46b5a', bg: '#14100e' },
    { id: 3, name: 'Groen',   hex: '#5ad48a', bg: '#0e1410' },
    { id: 4, name: 'Goud',    hex: '#d4b05a', bg: '#14100e' },
    { id: 5, name: 'Paars',   hex: '#9b6bd4', bg: '#100e14' },
    { id: 6, name: 'Turquoise', hex: '#5ad4c8', bg: '#101410' },
  ];

  const THEMES = {
    dieren:  { label: 'Dieren',  symbols: ['🐶','🐱','🦊','🐻','🐼','🦁','🐸','🐵','🐰','🦉','🐢','🦋','🐧','🦄','🐙','🐝','🐞','🦀','🐬','🦈','🐦','🐤','🦇','🐺','🐗','🐴','🐮','🐷','🐹','🐻‍❄️','🦩','🦚'] },
    natuur:  { label: 'Natuur',  symbols: ['🌸','🍀','🌴','🌈','☀️','🌙','⭐','🌊','🍃','🍄','🌵','🌺','🌲','🌻','🌼','🌷','🌹','🌿','🌾','🌳','🌕','🌑','☁️','❄️','🔥','💧','🌍','🌪️','⚡','🌋','🏔️','🏝️'] },
    eten:    { label: 'Eten',    symbols: ['🍎','🍕','🍩','🍇','🧀','🌮','🍦','🍪','🥑','🍓','🧁','🍉','🍌','🥕','🌽','🥐','🍔','🍟','🍿','🍫','🍬','🍰','🎂','🍮','🍵','☕','🧃','🥤','🧋','🍒','🥝','🍑'] },
    ruimte:  { label: 'Ruimte',  symbols: ['🚀','🪐','🌍','☄️','👽','🛸','🌑','🌟','🔭','🌌','👾','🛰️','🌙','⭐','☀️','🌎','🌏','🌕','🌖','🌗','🌘','🌚','🌝','🌛','🌜','💫','✨','🌠','⚡','🔮','💎','🔮'] },
    sport:   { label: 'Sport',   symbols: ['⚽','🏀','🏈','⚾','🎾','🏐','🏉','🎱','🏓','🏸','🥊','🥋','⛳','🎯','🏆','🥇','🎳','⛸️','🎿','🏂','🏄','🚴','🏊','🤸','🧗','🤺','🏇','🧘','🎮','🎲','♟️','🧩'] },
    muziek:  { label: 'Muziek',  symbols: ['🎵','🎶','🎸','🎹','🥁','🎺','🎻','🎷','🎤','🎧','🎼','🔔','📻','💿','🎙️','🎚️','🎛️','🔊','📢','📯','🪕','🪘','🪗','🪄','💎','⭐','✨','🌟','💫','🔥','❤️','💜'] },
    vormen:  { label: 'Vormen',  symbols: ['★','◆','●','▲','■','♥','♠','♣','⬡','◈','◇','▣','⬡','⬠','⬢','⬣','⬤','◉','◎','◐','◑','◒','◓','◔','◕','◖','◗','◘','◙','◚','◛','◜'] },
  };

  const DIFFS = {
    easy:   { label: 'Makkelijk',  cols: 4, pairs: 8  },   // 4×4 = 16
    medium: { label: 'Normaal',    cols: 6, pairs: 12 },   // 6×4 = 24
    hard:   { label: 'Moeilijk',   cols: 6, pairs: 18 },   // 6×6 = 36
    expert: { label: 'Expert',     cols: 8, pairs: 24 },   // 8×6 = 48
    master: { label: 'Meester',    cols: 8, pairs: 32 },   // 8×8 = 64
  };

  let numPlayers = 1;
  let difficulty = 'medium';
  let themeKey = 'dieren';
  let cards = [];
  let first = null;
  let lock = false;
  let moves = 0;
  let matched = 0;
  let started = false;
  let startTime = 0;
  let timerId = null;
  let elapsed = 0;
  let currentPlayer = 0; // 0-based
  let scores = [];
  let playing = false;

  const root = el('div', 'mem-app');
  host.append(root);

  // ── Setup UI ──
  const setup = el('div', 'mem-setup');
  setup.append(el('h1', 'mem-setup-title', 'MEMORY'));
  setup.append(el('p', 'mem-setup-sub', 'Vind alle paren  ·  1–6 spelers'));

  function makeChipRow(label, items, activeKey, onPick, extraClsFn) {
    const sec = el('div', 'mem-setup-section');
    sec.append(el('div', 'mem-setup-label', label));
    const row = el('div', 'mem-chip-row');
    items.forEach(([key, text]) => {
      const cls = 'mem-chip' + (key === activeKey || key === String(activeKey) ? ' is-active' : '') + (extraClsFn ? ' ' + extraClsFn(key) : '');
      const b = el('button', cls, text);
      b.type = 'button';
      b.dataset.key = key;
      b.onclick = () => {
        row.querySelectorAll('.mem-chip').forEach(x => {
          x.classList.toggle('is-active', x.dataset.key === String(key));
        });
        onPick(key);
      };
      row.append(b);
    });
    sec.append(row);
    return sec;
  }

  const playersSec = makeChipRow(
    'Spelers',
    [[1,'1 speler'],[2,'2'],[3,'3'],[4,'4'],[5,'5'],[6,'6']],
    numPlayers,
    k => { numPlayers = Number(k); },
    k => 'pcol-' + k
  );
  const diffSec = makeChipRow(
    'Moeilijkheid',
    Object.entries(DIFFS).map(([k, d]) => [k, d.label + ' (' + (d.pairs * 2) + ')']),
    difficulty,
    k => { difficulty = k; }
  );
  const themeSec = makeChipRow(
    'Thema',
    Object.entries(THEMES).map(([k, t]) => [k, t.label]),
    themeKey,
    k => { themeKey = k; }
  );

  const startBtn = el('button', 'mem-start-btn', '▶  START');
  startBtn.type = 'button';
  startBtn.onclick = () => beginGame();

  setup.append(playersSec, diffSec, themeSec, startBtn);
  root.append(setup);

  // ── Play UI ──
  const play = el('div', 'mem-play');
  const top = el('div', 'mem-top');
  const topLeft = el('div', 'mem-top-left');
  const backHub = el('button', 'mem-back-hub', '←');
  backHub.type = 'button';
  backHub.title = 'Terug naar menu';
  backHub.onclick = () => showSetup();
  const turnBadge = el('div', 'mem-turn-badge');
  topLeft.append(backHub, turnBadge);
  const topStats = el('div', 'mem-top-stats');
  top.append(topLeft, topStats);

  const playersBar = el('div', 'mem-players-bar');
  const boardArea = el('div', 'mem-board-area');
  const boardWrap = el('div', 'mem-board-wrap');
  const board = el('div', 'mem-board');
  boardWrap.append(board);
  boardArea.append(boardWrap);
  play.append(top, playersBar, boardArea);
  root.append(play);

  function showSetup() {
    stopTimer();
    playing = false;
    play.classList.remove('is-on');
    setup.style.display = '';
    root.className = 'mem-app';
  }

  function beginGame() {
    setup.style.display = 'none';
    play.classList.add('is-on');
    playing = true;
    scores = Array.from({ length: numPlayers }, () => 0);
    currentPlayer = 0;
    startNewRound();
  }

  function loadBest(diff) {
    try {
      const raw = localStorage.getItem('mem-best-' + diff);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }
  function saveBest(diff, movesVal, secs) {
    const prev = loadBest(diff);
    if (!prev || secs < prev.secs || (secs === prev.secs && movesVal < prev.moves)) {
      try { localStorage.setItem('mem-best-' + diff, JSON.stringify({ moves: movesVal, secs })); } catch {}
      return true;
    }
    return false;
  }

  function formatTime(s) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return m + ':' + String(sec).padStart(2, '0');
  }

  function stopTimer() {
    if (timerId) { clearInterval(timerId); timerId = null; }
  }
  function startTimer() {
    if (timerId) return;
    startTime = Date.now() - elapsed * 1000;
    timerId = setInterval(() => {
      elapsed = Math.floor((Date.now() - startTime) / 1000);
      updateTopStats();
    }, 250);
  }

  function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  function applyPlayerTheme() {
    const pc = PLAYER_COLORS[currentPlayer];
    root.className = 'mem-app p' + (currentPlayer + 1);
    if (numPlayers === 1) {
      turnBadge.innerHTML = '<span class="mem-turn-dot" style="color:#a8b4c8;background:#a8b4c8"></span> Solo';
      turnBadge.style.borderColor = 'rgba(255,255,255,.15)';
      turnBadge.style.boxShadow = 'none';
    } else {
      turnBadge.innerHTML = `<span class="mem-turn-dot" style="color:${pc.hex};background:${pc.hex}"></span> ${pc.name}`;
      turnBadge.style.borderColor = pc.hex;
      turnBadge.style.boxShadow = `0 0 14px ${pc.hex}44`;
      turnBadge.style.color = '#fff';
    }
    // Update player pills
    playersBar.querySelectorAll('.mem-player-pill').forEach((pill, i) => {
      pill.classList.toggle('is-turn', i === currentPlayer);
    });
  }

  function renderPlayersBar() {
    playersBar.replaceChildren();
    if (numPlayers === 1) {
      playersBar.style.display = 'none';
      return;
    }
    playersBar.style.display = '';
    for (let i = 0; i < numPlayers; i++) {
      const pc = PLAYER_COLORS[i];
      const pill = el('div', 'mem-player-pill' + (i === currentPlayer ? ' is-turn' : ''));
      pill.style.color = pc.hex;
      pill.innerHTML = `<span class="mp-dot"></span><span>${pc.name}</span><span class="mp-score">${scores[i]}</span>`;
      playersBar.append(pill);
    }
  }

  function updateTopStats() {
    const pairs = DIFFS[difficulty].pairs;
    let html = `<span>Zetten <b>${moves}</b></span><span>Tijd <b>${formatTime(elapsed)}</b></span><span>Paren <b>${matched}/${pairs}</b></span>`;
    topStats.innerHTML = html;
  }

  function startNewRound() {
    stopTimer();
    boardWrap.querySelector('.mem-win')?.remove();
    const { cols, pairs } = DIFFS[difficulty];
    const theme = THEMES[themeKey];
    const pool = theme.symbols.slice(0, pairs);
    cards = shuffle([...pool, ...pool].map((s, i) => ({ id: i, s, open: false, done: false, mismatch: false })));
    first = null;
    lock = false;
    moves = 0;
    matched = 0;
    started = false;
    elapsed = 0;
    currentPlayer = 0;
    scores = Array.from({ length: numPlayers }, () => 0);
    board.className = 'mem-board cols-' + cols;
    renderPlayersBar();
    applyPlayerTheme();
    renderBoard();
    updateTopStats();
  }

  function nextTurn() {
    if (numPlayers <= 1) return;
    currentPlayer = (currentPlayer + 1) % numPlayers;
    applyPlayerTheme();
  }

  function showWin() {
    stopTimer();
    const win = el('div', 'mem-win');
    const card = el('div', 'mem-win-card');

    if (numPlayers === 1) {
      const isNew = saveBest(difficulty, moves, elapsed);
      card.append(el('h2', null, isNew ? 'Nieuw record! 🎉' : 'Goed gedaan! ✨'));
      card.append(el('p', null, `${moves} zetten · ${formatTime(elapsed)}`));
      const best = loadBest(difficulty);
      if (best && !isNew) card.append(el('p', null, `Record: ${best.moves}z · ${formatTime(best.secs)}`));
    } else {
      const maxScore = Math.max(...scores);
      const winners = scores.map((s, i) => s === maxScore ? i : -1).filter(i => i >= 0);
      if (winners.length === 1) {
        const w = PLAYER_COLORS[winners[0]];
        card.append(el('h2', null, `${w.name} wint! 🏆`));
      } else {
        card.append(el('h2', null, 'Gelijkspel! 🤝'));
      }
      const scoreList = el('div', 'mem-win-scores');
      const order = scores.map((s, i) => i).sort((a, b) => scores[b] - scores[a]);
      order.forEach(i => {
        const pc = PLAYER_COLORS[i];
        const row = el('div', 'mem-win-row' + (scores[i] === maxScore ? ' is-winner' : ''));
        row.style.color = pc.hex;
        row.innerHTML = `<span>${pc.name}</span><span>${scores[i]} paar${scores[i] === 1 ? '' : 'en'}</span>`;
        scoreList.append(row);
      });
      card.append(scoreList);
      card.append(el('p', null, `${moves} zetten · ${formatTime(elapsed)}`));
    }

    const actions = el('div', 'mem-win-actions');
    const again = el('button', 'mem-btn primary', 'Opnieuw');
    again.type = 'button';
    again.onclick = () => startNewRound();
    const menu = el('button', 'mem-btn', 'Menu');
    menu.type = 'button';
    menu.onclick = () => showSetup();
    actions.append(again, menu);
    card.append(actions);
    win.append(card);
    boardWrap.append(win);
  }

  function renderBoard() {
    board.replaceChildren();
    cards.forEach((c) => {
      const btn = el('button', 'mem-card'
        + (c.open || c.done ? ' is-open' : '')
        + (c.done ? ' is-done' : '')
        + (c.mismatch ? ' is-mismatch' : ''));
      btn.type = 'button';
      btn.disabled = c.done || lock;
      btn.setAttribute('aria-label', c.open || c.done ? c.s : 'Kaart');

      const inner = el('div', 'mem-inner');
      const back = el('div', 'mem-face mem-back');
      const front = el('div', 'mem-face mem-front', c.s);
      inner.append(back, front);
      btn.append(inner);

      btn.onclick = () => {
        if (c.open || c.done || lock || !playing) return;
        if (!started) { started = true; startTimer(); }
        c.open = true;
        moves++;
        updateTopStats();
        renderBoard();

        if (!first) { first = c; return; }

        if (first.s === c.s && first !== c) {
          // Match!
          first.done = c.done = true;
          first = null;
          matched++;
          scores[currentPlayer]++;
          renderPlayersBar();
          applyPlayerTheme();
          updateTopStats();
          renderBoard();
          // Same player continues on match
          if (matched === DIFFS[difficulty].pairs) {
            setTimeout(showWin, 500);
          }
        } else {
          // Mismatch → next player
          lock = true;
          const a = first;
          const b = c;
          a.mismatch = b.mismatch = true;
          renderBoard();
          setTimeout(() => {
            a.open = b.open = false;
            a.mismatch = b.mismatch = false;
            first = null;
            lock = false;
            nextTurn();
            renderBoard();
          }, 750);
        }
      };
      board.append(btn);
    });
  }
}


export function createMemoryApp() {
  const root = document.createElement('div');
  root.className = 'app-panel games-app';
  memoryGame(root);
  return { root };
}
