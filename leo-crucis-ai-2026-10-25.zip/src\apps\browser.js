/**
 * In-app browser — URL-balk + iframe.
 * Veel sites blokkeren iframes; knop “Extern” opent in systeembrowser.
 */

function el(tag, className, text) {
  const n = document.createElement(tag);
  if (className) n.className = className;
  if (text != null) n.textContent = text;
  return n;
}

function normalizeUrl(raw) {
  let u = String(raw || '').trim();
  if (!u) return '';
  if (!/^https?:\/\//i.test(u)) {
    if (/^[\w.-]+\.[a-z]{2,}([/:].*)?$/i.test(u) || u.startsWith('localhost')) {
      u = 'https://' + u;
    } else {
      u = 'https://duckduckgo.com/?q=' + encodeURIComponent(u);
    }
  }
  return u;
}

export function createBrowserApp(startUrl) {
  const root = el('div', 'app-panel mini-app-root browser-app');
  root.setAttribute('data-kind', 'browser');
  root.setAttribute('aria-label', 'Browser');

  const history = [];
  let histIndex = -1;
  let current = '';

  const bar = el('div', 'lc-browser-bar');
  const btnBack = el('button', 'lc-browser-nav', '←');
  btnBack.type = 'button';
  btnBack.title = 'Terug';
  btnBack.setAttribute('aria-label', 'Terug');
  const btnFwd = el('button', 'lc-browser-nav', '→');
  btnFwd.type = 'button';
  btnFwd.title = 'Vooruit';
  btnFwd.setAttribute('aria-label', 'Vooruit');
  const btnReload = el('button', 'lc-browser-nav', '↻');
  btnReload.type = 'button';
  btnReload.title = 'Herladen';
  btnReload.setAttribute('aria-label', 'Herladen');

  const form = el('form', 'lc-browser-form');
  const input = el('input', 'lc-browser-url');
  input.type = 'url';
  input.placeholder = 'https://… of zoekterm';
  input.setAttribute('aria-label', 'Adres of zoekterm');
  input.autocomplete = 'off';
  const goBtn = el('button', 'lc-browser-go', 'Ga');
  goBtn.type = 'submit';
  form.append(input, goBtn);

  const btnExt = el('button', 'lc-browser-ext', 'Extern');
  btnExt.type = 'button';
  btnExt.title = 'Open in systeembrowser';

  bar.append(btnBack, btnFwd, btnReload, form, btnExt);
  root.append(bar);

  const hint = el('p', 'lc-browser-hint', 'Sommige sites laden niet in de app (iframe-blokkade). Gebruik dan Extern.');
  root.append(hint);

  const frameWrap = el('div', 'lc-browser-frame-wrap');
  const frame = el('iframe', 'lc-browser-frame');
  frame.setAttribute('title', 'Webpagina');
  frame.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox');
  frame.referrerPolicy = 'no-referrer-when-downgrade';
  frameWrap.append(frame);
  root.append(frameWrap);

  function updateNav() {
    btnBack.disabled = histIndex <= 0;
    btnFwd.disabled = histIndex < 0 || histIndex >= history.length - 1;
  }

  function navigate(url, { push = true } = {}) {
    const u = normalizeUrl(url);
    if (!u) return;
    current = u;
    input.value = u;
    try {
      frame.src = u;
    } catch (_) {}
    if (push) {
      history.splice(histIndex + 1);
      history.push(u);
      histIndex = history.length - 1;
    }
    updateNav();
  }

  form.onsubmit = (e) => {
    e.preventDefault();
    navigate(input.value);
  };

  btnBack.onclick = () => {
    if (histIndex <= 0) return;
    histIndex -= 1;
    navigate(history[histIndex], { push: false });
  };
  btnFwd.onclick = () => {
    if (histIndex >= history.length - 1) return;
    histIndex += 1;
    navigate(history[histIndex], { push: false });
  };
  btnReload.onclick = () => {
    if (!current) return;
    try {
      frame.src = current;
    } catch (_) {}
  };
  btnExt.onclick = async () => {
    const u = normalizeUrl(input.value || current);
    if (!u) return;
    try {
      const inv = window.__TAURI__ && window.__TAURI__.core && window.__TAURI__.core.invoke;
      if (inv) await inv('open_url', { url: u });
      else window.open(u, '_blank', 'noopener,noreferrer');
    } catch (_) {
      window.open(u, '_blank', 'noopener,noreferrer');
    }
  };

  const initial = typeof startUrl === 'string' && startUrl ? startUrl : 'https://duckduckgo.com/';
  navigate(initial);

  return {
    root,
    el: root,
    kind: 'browser',
    navigate(pos) {
      if (typeof pos === 'string') navigate(pos);
      else if (pos && pos.url) navigate(pos.url);
    },
    getState() {
      return { url: current, history: history.slice(), histIndex };
    },
    setState(s) {
      if (!s) return;
      if (Array.isArray(s.history) && s.history.length) {
        history.length = 0;
        history.push(...s.history);
        histIndex = Math.min(s.histIndex ?? history.length - 1, history.length - 1);
        navigate(history[histIndex] || s.url, { push: false });
      } else if (s.url) navigate(s.url);
    },
    focus() {
      input.focus();
      input.select();
    }
  };
}
