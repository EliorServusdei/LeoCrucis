# Worldbuilding-data (Leo Crucis)

Alle worldbuilding-projecten staan hier als **leesbare JSON** in de broncode.

## Structuur

```
src/data/worldbuilding/
  index.json                 # overzicht van alle projecten (metadata)
  projects/
    {project-id}.json        # volledige inhoud van één wereld
  README.md                  # dit bestand
```

## Voor AI / bewerken buiten de app

1. Open `index.json` om te zien welke projecten er zijn.
2. Open het bijbehorende bestand in `projects/` om personages, locaties, enz. te bewerken.
3. Na handmatige of AI-wijzigingen: herlaad de Worldbuilding Studio (of herstart de app).

De app laadt deze bestanden bij voorkeur. Opslaan vanuit de app schrijft opnieuw naar dit pad
(wanneer bestands-I/O beschikbaar is) en houdt een browser-back-up bij.

## Projectbestand (schema)

Belangrijke velden in `projects/{id}.json`:

| Veld | Betekenis |
|------|-----------|
| `id` | Unieke id (bijv. `wb_…`) |
| `name`, `subtitle`, `description` | Wereldinfo |
| `worldType` | high-fantasy, dark-fantasy, sci-fi, … |
| `status` | concept, development, complete, archived |
| `accent`, `symbol` | Visueel |
| `calendar` | Fictieve kalender (maanden, epoch) |
| `characters`, `locations`, `cities`, … | Collecties (arrays van items) |
| `relations` | Verbanden tussen items (`fromId`, `toId`, `type`) |
| `activity` | Activiteitenlog |

### Item (voorbeeld personage)

```json
{
  "id": "wb_…",
  "name": "Naam",
  "description": "Korte tekst",
  "tags": ["tag1"],
  "favorite": false,
  "title": "Rang",
  "species": "Mens",
  "background": "…",
  "customFields": { "mapX": "45", "mapY": "60" },
  "createdAt": "ISO-datum",
  "updatedAt": "ISO-datum"
}
```

### Relatie

```json
{
  "id": "rel_…",
  "fromId": "item-id",
  "toId": "item-id",
  "type": "ally",
  "note": ""
}
```

Relatietypes o.a.: `family`, `ally`, `enemy`, `member`, `rules`, `owns`, `located`, `participated`, `related`, `rival`, `mentor`.

## Collecties

continents, locations, cities, maps, biomes, events, eras, wars, dynasties,
characters, races, cultures, factions, organizations, religions, languages,
magic, creatures, floraFauna, artifacts, technology, laws,
plots, chapters, themes, ideas, notes, concepts, relations, activity, favorites.


## Boeken & manuscripten

Collectie `books` in het projectbestand:

```json
{
  "id": "wb_book_…",
  "name": "Titel",
  "synopsis": "Korte samenvatting",
  "genre": "High fantasy",
  "status": "klad",
  "html": "<p>Volledige manuscript-HTML…</p>",
  "tags": ["manuscript"]
}
```

Worldbuilding-verwijzingen in HTML:

```html
<span data-wb-ref="item-id" data-wb-col="characters" class="wb-inline-ref">Naam</span>
```

Koppel boeken aan items via `relations` (`fromId` = boek-id).
