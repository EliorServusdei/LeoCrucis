// Mastermind — zelfstandige mini-app.
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}


function injectGameBaseStyles() {
  if (document.getElementById('lc-game-base-styles')) return;
  const s = document.createElement('style');
  s.id = 'lc-game-base-styles';
  s.textContent = `
.app-panel.games-app{
  display:flex;flex-direction:column;gap:0;min-height:0;height:100%;
  background:var(--bg);color:var(--ink);
  font-family:"Courier New",Courier,ui-monospace,monospace;
  position:relative;overflow:auto;
  padding:12px;box-sizing:border-box;
}
.games-app .game-status{
  font-weight:800;font-size:13px;letter-spacing:.1em;text-transform:uppercase;
  color:var(--acc);text-align:center;padding:10px 12px 4px;
  text-shadow:0 0 8px rgba(155,188,15,.3);
}
.games-app .game-hint{
  margin:0;font-size:11px;color:var(--mute);opacity:.65;text-align:center;
  letter-spacing:.06em;padding:0 12px 8px;
}
.games-app .game-reset{
  border:2px solid var(--line);background:var(--panel);color:var(--acc);
  border-radius:4px;padding:8px 16px;cursor:pointer;font:inherit;
  font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
  align-self:center;margin-top:8px;
}
.games-app .game-reset:hover{border-color:var(--acc);background:var(--sel);color:var(--acc2);}
.games-app .ttt-board{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:240px;margin:12px auto;width:100%;}
.games-app .ttt-cell{
  aspect-ratio:1;border:1px solid var(--line);border-radius:4px;
  background:var(--panel);color:var(--acc);font-weight:800;font-size:1.6rem;
  cursor:pointer;font-family:inherit;
}
.games-app .ttt-cell:hover:not(:disabled){
  border-color:var(--acc);background:var(--sel);
  box-shadow:0 0 10px rgba(155,188,15,.2);
}
.games-app .ttt-cell:disabled{cursor:default;opacity:.9;}
.games-app .mm-board{display:flex;flex-direction:column;gap:6px;max-width:360px;margin:8px auto;width:100%;}
.games-app .mm-row,.games-app .mm-input-row{display:flex;align-items:center;gap:8px;}
.games-app .mm-num{width:1.5em;font-size:11px;color:var(--mute);text-align:right;}
.games-app .mm-pegs{display:flex;gap:6px;flex:1;}
.games-app .mm-peg{
  width:28px;height:28px;border-radius:50%;border:1px solid var(--line);
  background:var(--panel);cursor:pointer;padding:0;
}
.games-app .mm-peg.is-active{outline:2px solid var(--acc);outline-offset:2px;}
.games-app .mm-feedback{display:flex;flex-wrap:wrap;gap:3px;width:36px;}
.games-app .mm-pin{width:8px;height:8px;border-radius:50%;border:1px solid var(--line);background:transparent;}
.games-app .mm-pin.is-black{background:var(--acc);border-color:var(--acc);}
.games-app .mm-pin.is-white{background:var(--acc2);border-color:var(--acc);}
.games-app .mm-palette{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:8px 0;}
.games-app .mm-actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:8px 0;}
.games-app .mm-btn{
  border:1px solid var(--line);background:var(--panel);color:var(--acc);
  border-radius:4px;padding:8px 14px;cursor:pointer;font:inherit;
  font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
}
.games-app .mm-btn:hover{border-color:var(--acc);background:var(--sel);color:var(--acc2);}
.games-app .mm-check,.games-app .mm-new{
  background:var(--acc);color:var(--bg);border-color:var(--acc);
}
.games-app .mm-input-label{font-size:12px;color:var(--mute);letter-spacing:.06em;text-transform:uppercase;}
.games-app .mm-secret{opacity:.9;}

.games-app .snake-canvas{
  border:1px solid var(--line);border-radius:4px;
  box-shadow:0 0 12px rgba(155,188,15,.15);
  margin:0 auto;display:block;
}
`;
  document.head.append(s);
}

function mastermindGame(host) {
  host.replaceChildren();
  const COLORS = [
    { id: 'r', hex: '#e53e3e', label: 'Rood' },
    { id: 'g', hex: '#38a169', label: 'Groen' },
    { id: 'b', hex: '#3182ce', label: 'Blauw' },
    { id: 'y', hex: '#d69e2e', label: 'Geel' },
    { id: 'o', hex: '#dd6b20', label: 'Oranje' },
    { id: 'p', hex: '#805ad5', label: 'Paars' }
  ];
  const LEN = 4;
  const MAX = 10;

  function randomCode() {
    return Array.from({ length: LEN }, () => COLORS[Math.floor(Math.random() * COLORS.length)].id);
  }

  let secret = randomCode();
  let guesses = []; // { pegs: string[], feedback: { black, white } }
  let current = Array(LEN).fill(null);
  let activeSlot = 0;
  let over = false; // 'won' | 'lost' | false

  const status = el('div', 'game-status', 'Kies 4 kleuren en druk op Controleren');
  const board = el('div', 'mm-board');
  const inputRow = el('div', 'mm-input-row');
  const palette = el('div', 'mm-palette');
  const actions = el('div', 'mm-actions');
  const hint = el('p', 'game-hint', '● = juiste kleur op de juiste plaats · ○ = juiste kleur, verkeerde plaats');
  host.append(status, board, inputRow, palette, actions, hint);

  function feedback(guess, code) {
    const g = guess.slice();
    const c = code.slice();
    let black = 0;
    let white = 0;
    for (let i = 0; i < LEN; i++) {
      if (g[i] === c[i]) {
        black++;
        g[i] = c[i] = null;
      }
    }
    for (let i = 0; i < LEN; i++) {
      if (g[i] == null) continue;
      const j = c.indexOf(g[i]);
      if (j >= 0) {
        white++;
        c[j] = null;
      }
    }
    return { black, white };
  }

  function colorHex(id) {
    return COLORS.find(c => c.id === id)?.hex || '#ccc';
  }

  function pegEl(colorId, extraCls) {
    const d = el('button', 'mm-peg' + (extraCls ? ' ' + extraCls : ''));
    d.type = 'button';
    if (colorId) {
      d.style.background = colorHex(colorId);
      d.setAttribute('aria-label', COLORS.find(c => c.id === colorId)?.label || colorId);
    } else {
      d.classList.add('is-empty');
      d.setAttribute('aria-label', 'Leeg');
    }
    return d;
  }

  function renderBoard() {
    board.replaceChildren();
    for (let i = 0; i < MAX; i++) {
      const row = el('div', 'mm-row');
      const num = el('span', 'mm-num', String(i + 1));
      const pegs = el('div', 'mm-pegs');
      const fb = el('div', 'mm-feedback');
      if (guesses[i]) {
        guesses[i].pegs.forEach(p => pegs.append(pegEl(p)));
        for (let b = 0; b < guesses[i].feedback.black; b++) {
          const d = el('span', 'mm-pin is-black');
          d.title = 'Juiste kleur, juiste plaats';
          fb.append(d);
        }
        for (let w = 0; w < guesses[i].feedback.white; w++) {
          const d = el('span', 'mm-pin is-white');
          d.title = 'Juiste kleur, verkeerde plaats';
          fb.append(d);
        }
      } else {
        for (let k = 0; k < LEN; k++) pegs.append(pegEl(null));
      }
      row.append(num, pegs, fb);
      board.append(row);
    }
  }

  function renderInput() {
    inputRow.replaceChildren();
    if (over) return;
    const label = el('span', 'mm-input-label', 'Jouw code:');
    const pegs = el('div', 'mm-pegs');
    current.forEach((c, i) => {
      const p = pegEl(c, i === activeSlot ? 'is-active' : '');
      p.onclick = () => {
        activeSlot = i;
        renderInput();
      };
      pegs.append(p);
    });
    inputRow.append(label, pegs);
  }

  function renderPalette() {
    palette.replaceChildren();
    if (over) return;
    COLORS.forEach(c => {
      const b = pegEl(c.id);
      b.title = c.label;
      b.onclick = () => {
        if (over) return;
        current[activeSlot] = c.id;
        activeSlot = Math.min(LEN - 1, activeSlot + 1);
        renderInput();
      };
      palette.append(b);
    });
  }

  function renderActions() {
    actions.replaceChildren();
    if (!over) {
      const check = el('button', 'mm-btn mm-check', 'Controleren');
      check.type = 'button';
      check.onclick = () => {
        if (current.some(x => !x)) {
          status.textContent = 'Kies eerst 4 kleuren';
          return;
        }
        const fb = feedback(current, secret);
        guesses.push({ pegs: current.slice(), feedback: fb });
        if (fb.black === LEN) {
          over = 'won';
          status.textContent = 'Gevonden in ' + guesses.length + ' beurt' + (guesses.length === 1 ? '' : 'en') + '!';
        } else if (guesses.length >= MAX) {
          over = 'lost';
          status.textContent = 'Geen beurten meer. De code was:';
        } else {
          status.textContent = 'Beurt ' + guesses.length + '/' + MAX + ' · ● ' + fb.black + '  ○ ' + fb.white;
        }
        current = Array(LEN).fill(null);
        activeSlot = 0;
        renderAll();
        if (over === 'lost') showSecret();
      };
      const clear = el('button', 'mm-btn', 'Wissen');
      clear.type = 'button';
      clear.onclick = () => {
        current = Array(LEN).fill(null);
        activeSlot = 0;
        renderInput();
      };
      actions.append(check, clear);
    }
    const again = el('button', 'mm-btn mm-new', 'Nieuw spel');
    again.type = 'button';
    again.onclick = () => {
      secret = randomCode();
      guesses = [];
      current = Array(LEN).fill(null);
      activeSlot = 0;
      over = false;
      status.textContent = 'Kies 4 kleuren en druk op Controleren';
      renderAll();
    };
    actions.append(again);
  }

  function showSecret() {
    const row = el('div', 'mm-row mm-secret');
    row.append(el('span', 'mm-num', '✓'));
    const pegs = el('div', 'mm-pegs');
    secret.forEach(p => pegs.append(pegEl(p)));
    row.append(pegs, el('div', 'mm-feedback'));
    board.append(row);
  }

  function renderAll() {
    renderBoard();
    renderInput();
    renderPalette();
    renderActions();
  }

  renderAll();
}


export function createMastermindApp() {
  injectGameBaseStyles();
  const root = document.createElement('div');
  root.className = 'app-panel games-app';
  mastermindGame(root);
  return { root };
}
