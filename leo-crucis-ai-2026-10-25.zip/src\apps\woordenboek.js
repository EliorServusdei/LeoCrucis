// Woordenboek — offline Nederlands woordenboek (Wiktionary, CC BY-SA 3.0)
// Data: data/woordenboek/{a..z,#}.json + index.json
// ~126.500 woorden. Bladeren A–Z + zoeken.
// Extra woordenboeken: Nederlands → Latijn en Nederlands → Frans, te kiezen met de knoppen bovenaan.
// Bij openen: gesloten boek. Boek opent pas bij letterklik of Zoeken.
// Progressief: na ~50 woorden al bladeren; rest op de achtergrond.

import { createLatijnPanel, injectLatijnStyles } from './woordenboek-latijn.js';
import { createFransPanel, injectFransStyles } from './woordenboek-frans.js';
import { createOrigineelPanel, injectOrigineelStyles } from './woordenboek-origineel.js';
import { yieldForUi, withLoadSlot } from '../core/perf.js';

const BASE = 'data/woordenboek/';
/** Bestandsgeheugen (Tauri app_data/memory/*.json) — geen localStorage. */
const MEM_POS = 'woordenboek-pos';
const MEM_BOOKMARKS = 'woordenboek-bookmarks';
const MEM_HISTORY = 'woordenboek-history';
const HISTORY_MAX = 40;
const BOOKMARKS_MAX = 200;

/** Eerste batch: zoveel woorden moeten in spreads zitten vóór we het boek tonen (browse). */
const INITIAL_ENTRIES = 50;
/** Zoeken: vanaf dit aantal resultaten al tonen; daaronder wachten tot alles klaar is. */
const SEARCH_EARLY_MIN = 10;
/** Achtergrond-pakken: max spreads per tick (houdt UI soepel). */
const PACK_CHUNK_SPREADS = 8;

/** File-geheugen via Tauri. Schrijven / lezen / verwijderen / vervangen. Geen localStorage. */
const FileMem = (() => {
  function inTauri() {
    return !!(typeof window !== 'undefined' && window.__TAURI__?.core?.invoke);
  }
  async function invoke(cmd, args) {
    if (!inTauri()) return null;
    try {
      return await window.__TAURI__.core.invoke(cmd, args);
    } catch (e) {
      console.warn('[FileMem]', cmd, e);
      return null;
    }
  }
  function path(key) {
    // Alleen veilige segmenten; backend checkt ook.
    const safe = String(key || '').replace(/[^a-zA-Z0-9_\- .]/g, '').trim();
    if (!safe) throw new Error('ongeldige memory-sleutel');
    return 'memory/' + safe + (safe.endsWith('.json') ? '' : '.json');
  }
  /** Lees JSON of null. */
  async function read(key) {
    const s = await invoke('read_user_file', { path: path(key) });
    if (s == null || s === '') return null;
    try { return JSON.parse(s); } catch { return null; }
  }
  /** Schrijf / vervang volledige inhoud (JSON). */
  async function write(key, data) {
    await invoke('write_user_file', { path: path(key), contents: JSON.stringify(data) });
  }
  /** Verwijder bestand (geen fout als het niet bestaat). */
  async function remove(key) {
    await invoke('delete_user_file', { path: path(key) });
  }
  return { read, write, remove, inTauri };
})();

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function norm(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

function firstLetter(word) {
  let c = (word[0] || '#').toLowerCase();
  c = c.replace(/[äáàâ]/g, 'a').replace(/[ëéèê]/g, 'e')
       .replace(/[ïíìî]/g, 'i').replace(/[öóòô]/g, 'o')
       .replace(/[üúùû]/g, 'u').replace(/ç/g, 'c').replace(/ñ/g, 'n');
  if (c < 'a' || c > 'z') return '#';
  return c;
}

const POS_NL = {
  noun: 'zn.', verb: 'ww.', adj: 'bn.', adv: 'bw.', pron: 'vnw.',
  prep: 'vz.', conj: 'vw.', interj: 'tussenw.', num: 'telw.',
  article: 'lidw.', particle: 'part.', prefix: 'voorv.', suffix: 'achterv.',
  phrase: 'uitdr.', proverb: 'spreekwoord', abbreviation: 'afk.',
  name: 'naam', proper: 'eigenn.', character: 'teken'
};

function posLabel(p) {
  if (!p) return '';
  return POS_NL[p] || p;
}

function injectWbStyles() {
  let s = document.getElementById('wb-scroll-styles');
  if (!s) {
    s = document.createElement('style');
    s.id = 'wb-scroll-styles';
    document.head.append(s);
  }
  s.textContent = `
/* —— Woordenboek: bladbaar boek (geen scrollbar) —— */
body.browser-open #view-content:has(.wb-app),
body.browser-open #view .in:has(.wb-app){
  overflow:hidden !important;
  display:flex !important;
  flex-direction:column !important;
  min-height:0 !important;
  height:100% !important;
}
body.browser-open #view-content:has(.wb-app) > .view-head,
body.browser-open #view .in:has(.wb-app) > .view-head,
body.browser-open #view-content:has(.wb-app) > .browser-head,
body.browser-open #view .in:has(.wb-app) > .browser-head{
  flex:0 0 auto;
}
body.browser-open #view-content:has(.wb-app) > .wb-app,
body.browser-open #view .in:has(.wb-app) > .wb-app{
  flex:1 1 auto;
  min-height:0;
  max-width:none !important;
  width:100% !important;
  margin:0 !important;
  padding:6px 10px 10px !important;
  box-sizing:border-box;
  display:flex;
  flex-direction:column;
  gap:8px;
  overflow:hidden;
  background:transparent;
}
/* Eén compacte topbalk: zoekveld + knoppen + letters — allemaal even hoog */
.wb-app .wb-topbar{
  flex:0 0 auto;
  display:flex;
  flex-wrap:wrap;
  gap:6px;
  align-items:center;
  width:100%;
}
.wb-app .wb-topbar .wb-search-form{
  display:flex;
  flex:1 1 140px;
  min-width:110px;
  max-width:260px;
  gap:6px;
  align-items:center;
}
.wb-app .wb-topbar .wb-search{
  flex:1 1 auto;
  min-width:0;
  width:100%;
  height:34px;
  box-sizing:border-box;
  padding:6px 10px;
}
/* Gedeelde knopmaat: zoekicoon, A–Z en letters */
.wb-app .wb-topbar .wb-btn,
.wb-app .wb-topbar .wb-letter{
  flex:0 0 auto;
  box-sizing:border-box;
  height:34px;
  min-height:34px;
  padding:0 10px;
  margin:0;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  font-size:.88em;
  font-weight:600;
  line-height:1;
  border-radius:6px;
  border:1px solid var(--line);
  border-bottom:3px solid var(--wood-mid, #5a4010);
  background:var(--panel);
  color:var(--ink);
  cursor:pointer;
  white-space:nowrap;
}
.wb-app .wb-topbar .wb-btn:hover,
.wb-app .wb-topbar .wb-letter:hover{
  background:var(--sel);
}
.wb-app .wb-topbar .wb-btn-icon{
  width:34px;
  min-width:34px;
  padding:0;
}
.wb-app .wb-topbar .wb-btn-icon svg{
  width:1.15em;
  height:1.15em;
  display:block;
}
.wb-app .wb-topbar .wb-ghost{
  background:var(--panel);
}
.wb-app .wb-letters{
  display:flex;
  flex-wrap:wrap;
  gap:4px;
  flex:1 1 auto;
  min-width:0;
  align-items:center;
  padding:0;
}
.wb-app .wb-letters .wb-letter{
  min-width:34px;
  width:34px;
  padding:0;
  text-align:center;
}
.wb-app .wb-letters .wb-letter.on{
  background:var(--acc);
  color:#1a1410;
  border-color:var(--acc);
  border-bottom-color:var(--acc);
}
.wb-app .wb-status{
  flex:0 0 auto;
  margin:0;
  font-size:.85em;
  color:var(--mute, var(--muted));
  line-height:1.3;
}

.wb-stage{
  flex:1 1 auto;
  min-height:0;
  position:relative;
  display:flex;
  align-items:stretch;
  justify-content:center;
  gap:0;
}

.wb-book{
  position:relative;
  display:grid;
  grid-template-columns:1fr 1fr;
  width:min(100%, 1100px);
  height:100%;
  min-height:0;
  border-radius:10px;
  background:var(--wood, #6b4f12);
  box-shadow:
    0 14px 36px rgba(0,0,0,.32),
    0 0 0 5px var(--wood, #6b4f12),
    inset 0 0 0 1px rgba(255,255,255,.08);
  overflow:hidden;
  transition: width .45s ease, max-width .45s ease, box-shadow .35s ease,
              border-radius .35s ease, transform .4s ease;
}

/* —— Gesloten boek (cover vooraan) —— */
.wb-book.wb-closed{
  display:block;
  width:min(42%, 320px);
  max-width:320px;
  height:min(88%, 480px);
  align-self:center;
  margin:auto;
  border-radius:6px 14px 14px 6px;
  background:
    linear-gradient(90deg,
      #3d2a0e 0%,
      #5a3f14 4%,
      #6b4f12 8%,
      #7a5a1a 12%,
      #6b4f12 100%);
  box-shadow:
    8px 12px 28px rgba(0,0,0,.38),
    0 0 0 4px #4a3610,
    inset -2px 0 0 rgba(255,255,255,.06),
    inset 0 0 40px rgba(0,0,0,.15);
  cursor:default;
  transform: perspective(800px) rotateY(-6deg);
  transform-origin: left center;
}
.wb-book.wb-closed .wb-page,
.wb-book.wb-closed .wb-book-spine{
  display:none !important;
}
.wb-book.wb-closed .wb-cover{
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  height:100%;
  padding:24px 18px;
  box-sizing:border-box;
  text-align:center;
  color:#f5e6c8;
  background:
    radial-gradient(ellipse at 30% 20%, rgba(255,230,180,.12), transparent 55%),
    linear-gradient(165deg, #8b6914 0%, #6b4f12 40%, #5a4010 100%);
  border-radius:4px 12px 12px 4px;
  position:relative;
  overflow:hidden;
}
.wb-book.wb-closed .wb-cover::before{
  content:"";
  position:absolute; inset:10px;
  border:1.5px solid rgba(245,230,200,.28);
  border-radius:2px 8px 8px 2px;
  pointer-events:none;
}
.wb-book.wb-closed .wb-cover-title{
  font-family:Georgia,'Times New Roman',serif;
  font-size:1.55em;
  font-weight:700;
  letter-spacing:.04em;
  margin:0 0 8px;
  text-shadow:0 1px 2px rgba(0,0,0,.35);
  position:relative;
  z-index:1;
}
.wb-book.wb-closed .wb-cover-sub{
  font-size:.85em;
  opacity:.78;
  margin:0;
  font-style:italic;
  position:relative;
  z-index:1;
}
.wb-book.wb-closed .wb-cover-hint{
  margin-top:28px;
  font-size:.78em;
  opacity:.65;
  position:relative;
  z-index:1;
  max-width:18ch;
  line-height:1.35;
}
.wb-book:not(.wb-closed) .wb-cover{
  display:none !important;
}

.wb-book-spine{
  position:absolute;top:0;bottom:0;left:50%;width:3.2%;
  transform:translateX(-50%);pointer-events:none;z-index:4;
  background:linear-gradient(90deg,
    transparent,
    rgba(0,0,0,.18) 40%,
    rgba(0,0,0,.32) 50%,
    rgba(0,0,0,.18) 60%,
    transparent);
}
.wb-page{
  position:relative;
  min-width:0;min-height:0;
  height:100%;
  background:#f7f0e2;
  color:#3a2f24;
  overflow:hidden;
  display:flex;
  flex-direction:column;
  background-image:radial-gradient(rgba(120,90,50,.05) 1px, transparent 1px);
  background-size:6px 6px;
}
.wb-page-l{border-radius:8px 0 0 8px}
.wb-page-r{border-radius:0 8px 8px 0}
.wb-page-l::after,
.wb-page-r::after{
  content:"";position:absolute;top:0;bottom:0;width:12%;pointer-events:none;z-index:2;
}
.wb-page-l::after{
  right:0;
  background:linear-gradient(90deg, transparent, rgba(60,40,20,.14));
}
.wb-page-r::after{
  left:0;
  background:linear-gradient(270deg, transparent, rgba(60,40,20,.14));
}
.wb-page-inner{
  flex:1 1 auto;
  min-height:0;
  overflow:hidden;
  padding:16px 18px 12px;
  box-sizing:border-box;
  position:relative;
  z-index:1;
  display:flex;
  flex-direction:column;
}
.wb-page-r .wb-page-inner{padding-left:22px}
.wb-page-l .wb-page-inner{padding-right:22px}
.wb-page-num{
  flex:0 0 auto;
  text-align:center;
  font-size:11px;
  color:#8a7a68;
  letter-spacing:.06em;
  margin-top:6px;
  padding-bottom:2px;
}
.wb-list{
  flex:1 1 auto;
  min-height:0;
  display:flex;
  flex-direction:column;
  gap:6px;
  overflow:hidden;
}
.wb-card{
  background:transparent;
  border:0;
  border-bottom:1px solid rgba(90,70,40,.12);
  border-radius:0;
  padding:6px 2px 8px;
  box-shadow:none;
  flex:0 0 auto;
}
.wb-card-head{
  display:flex;flex-wrap:wrap;align-items:baseline;gap:6px 10px;
  margin-bottom:3px;
}
.wb-woord{
  margin:0;
  font-size:1.05em;
  font-weight:700;
  color:#2c241c;
  font-family:Georgia,'Times New Roman',serif;
}
.wb-meta{font-size:.78em;color:#6a5a48;font-style:italic}
.wb-bm-btn{
  margin-left:auto;
  border:none;background:transparent;cursor:pointer;
  padding:2px 4px;color:#8a7a68;line-height:0;
  border-radius:4px;
}
.wb-bm-btn:hover{color:#5a4a38;background:rgba(0,0,0,.06)}
.wb-bm-btn.wb-bm-on{color:#a67c3a}
.wb-defs{
  margin:0;
  padding-left:1.1em;
  line-height:1.4;
  color:#3a2f24;
  font-size:.9em;
}
.wb-defs li{margin-bottom:1px}
.wb-def-single{
  margin:0;
  line-height:1.4;
  color:#3a2f24;
  font-size:.9em;
}
.wb-card:only-child .wb-def-single,
.wb-card:only-child .wb-defs{
  display:-webkit-box;
  -webkit-box-orient:vertical;
  -webkit-line-clamp:14;
  overflow:hidden;
}
.wb-tip{margin:12px 0;font-size:.9em;color:#6a5a48}

.wb-nav{
  position:absolute;top:50%;transform:translateY(-50%);z-index:8;
  width:42px;height:64px;border:0;border-radius:10px;
  background:rgba(0,0,0,.32);color:#fff;
  font-size:1.8rem;line-height:1;cursor:pointer;opacity:.55;
  transition:opacity .15s;
}
.wb-nav:hover:not(:disabled){opacity:1}
.wb-nav:disabled{opacity:.15;cursor:default}
.wb-nav-prev{left:4px}
.wb-nav-next{right:4px}

.wb-app.wb-is-closed .wb-nav,
.wb-app.wb-is-closed .wb-foot{
  visibility:hidden;
  pointer-events:none;
}

.wb-foot{
  flex:0 0 auto;
  display:flex;
  align-items:center;
  justify-content:center;
  gap:12px;
  padding:4px 0 0;
  font-size:.88em;
  color:var(--mute, var(--muted));
}
.wb-foot-btn{
  font:inherit;
  padding:6px 14px;
  border-radius:6px;
  border:1px solid var(--line);
  background:var(--panel);
  color:var(--ink);
  cursor:pointer;
}
.wb-foot-btn:hover:not(:disabled){border-color:var(--acc);color:var(--acc)}
.wb-foot-btn:disabled{opacity:.35;cursor:default}
.wb-foot-info .wb-packing{
  opacity:.7;
  font-style:italic;
}

.wb-app{position:relative}
.wb-loading{
  position:absolute;inset:0;z-index:100;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  gap:16px;
  background:rgba(240,232,220,.97);
  pointer-events:all;
}
.wb-loading[hidden]{display:none !important}
.wb-spinner{
  width:42px;height:42px;
  border:3px solid rgba(90,70,40,.2);
  border-top-color:var(--acc,#8b2a32);
  border-radius:50%;
  animation:wb-spin .75s linear infinite;
}
@keyframes wb-spin{to{transform:rotate(360deg)}}
.wb-loading-msg{margin:0;font-size:1.1em;color:#3a2f24;font-weight:700;text-align:center;max-width:28ch}
.wb-loading-sub{margin:0;font-size:.9em;color:#6a5a48;text-align:center;max-width:32ch}

@media (max-width:720px){
  .wb-book:not(.wb-closed){grid-template-columns:1fr}
  .wb-book:not(.wb-closed) .wb-page-l{display:none}
  .wb-book:not(.wb-closed) .wb-book-spine{display:none}
  .wb-book:not(.wb-closed) .wb-page-r{border-radius:8px}
  .wb-book:not(.wb-closed) .wb-page-r::after{display:none}
  .wb-book.wb-closed{
    width:min(58%, 260px);
    height:min(70%, 380px);
    transform:none;
  }
}
`;
}

export function createWoordenboekApp() {
  injectWbStyles();
  injectLatijnStyles();
  injectFransStyles();
  injectOrigineelStyles();
  const root = el('div', 'app-panel wb-app wb-is-closed');

  let index = null;
  let currentLetter = null;
  let mode = 'closed'; // 'closed' | 'browse' | 'search' | 'bookmarks' | 'history'
  let searchQuery = '';
  let bookOpen = false;
  /** @type {string[]} genormaliseerde woorden (lowercase) */
  let bookmarks = [];
  /** @type {{ w: string, t: number }[]} recent (nieuwste eerst) */
  let history = [];

  // Eén topbalk: zoeken + A–Z + bladwijzers + geschiedenis + letters
  const topbar = el('div', 'wb-topbar');

  const form = el('form', 'wb-search-form');
  form.setAttribute('role', 'search');
  const searchIn = el('input', 'wb-search');
  searchIn.type = 'search';
  searchIn.placeholder = 'Zoek een woord…';
  searchIn.setAttribute('aria-label', 'Zoek in het woordenboek');
  searchIn.autocomplete = 'off';
  searchIn.spellcheck = false;
  const searchBtn = el('button', 'wb-btn wb-btn-icon');
  searchBtn.type = 'submit';
  searchBtn.title = 'Zoeken (alle treffers). Ctrl+Enter = alleen exact lemma';
  searchBtn.setAttribute('aria-label', 'Zoeken');
  searchBtn.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M15.5 15.5L21 21" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>';
  form.append(searchIn, searchBtn);

  const browseBtn = el('button', 'wb-btn wb-ghost', 'A–Z');
  browseBtn.type = 'button';
  browseBtn.title = 'Heel woordenboek bladeren (alle letters)';
  browseBtn.setAttribute('aria-label', 'Heel woordenboek bladeren van A tot Z');

  const bmBtn = el('button', 'wb-btn wb-ghost wb-btn-icon');
  bmBtn.type = 'button';
  bmBtn.title = 'Bladwijzers';
  bmBtn.setAttribute('aria-label', 'Bladwijzers');
  bmBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M6 4h12a1 1 0 0 1 1 1v16l-7-4-7 4V5a1 1 0 0 1 1-1z" fill="none" stroke="currentColor" stroke-width="2"/></svg>';

  const histBtn = el('button', 'wb-btn wb-ghost wb-btn-icon');
  histBtn.type = 'button';
  histBtn.title = 'Geschiedenis';
  histBtn.setAttribute('aria-label', 'Recent bekeken en gezochte woorden');
  histBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

  const letterBar = el('div', 'wb-letters');
  letterBar.setAttribute('role', 'navigation');
  letterBar.setAttribute('aria-label', 'Letters');

  topbar.append(form, browseBtn, bmBtn, histBtn, letterBar);

  const status = el('p', 'wb-status', 'Laden…');

  const stage = el('div', 'wb-stage');
  const book = el('div', 'wb-book wb-closed');
  book.setAttribute('aria-label', 'Woordenboekboek');

  const cover = el('div', 'wb-cover');
  const coverTitle = el('h2', 'wb-cover-title', 'Woordenboek');
  const coverSub = el('p', 'wb-cover-sub', 'Nederlands');
  const coverHint = el('p', 'wb-cover-hint', 'Kies een letter of zoek een woord om te openen');
  cover.append(coverTitle, coverSub, coverHint);
  book.append(cover);

  const pageL = el('div', 'wb-page wb-page-l');
  const pageLInner = el('div', 'wb-page-inner');
  const listL = el('div', 'wb-list');
  const numL = el('div', 'wb-page-num', '');
  pageLInner.append(listL, numL);
  pageL.append(pageLInner);

  const spine = el('div', 'wb-book-spine');

  const pageR = el('div', 'wb-page wb-page-r');
  const pageRInner = el('div', 'wb-page-inner');
  const listR = el('div', 'wb-list');
  const numR = el('div', 'wb-page-num', '');
  pageRInner.append(listR, numR);
  pageR.append(pageRInner);

  book.append(pageL, spine, pageR);

  const navPrev = el('button', 'wb-nav wb-nav-prev', '‹');
  navPrev.type = 'button';
  navPrev.setAttribute('aria-label', 'Vorige bladzijde');
  const navNext = el('button', 'wb-nav wb-nav-next', '›');
  navNext.type = 'button';
  navNext.setAttribute('aria-label', 'Volgende bladzijde');

  stage.append(navPrev, book, navNext);

  const foot = el('div', 'wb-foot');
  const footPrev = el('button', 'wb-foot-btn', '← Vorige');
  footPrev.type = 'button';
  const footInfo = el('span', 'wb-foot-info', '');
  const footNext = el('button', 'wb-foot-btn', 'Volgende →');
  footNext.type = 'button';
  foot.append(footPrev, footInfo, footNext);

  const loading = el('div', 'wb-loading');
  loading.hidden = true;
  loading.setAttribute('role', 'status');
  loading.setAttribute('aria-live', 'polite');
  const spinner = el('div', 'wb-spinner');
  spinner.setAttribute('aria-hidden', 'true');
  const loadMsg = el('p', 'wb-loading-msg', 'Woordenboek laden…');
  const loadSub = el('p', 'wb-loading-sub', 'Even geduld — Leo Crucis werkt nog');
  loading.append(spinner, loadMsg, loadSub);

  root.append(topbar, status, stage, foot, loading);

  // —— Woordenboeken: NL, NL→Latijn, NL→Frans, oorspronkelijke talen ——
  const modes = el('div', 'wb-modes');
  modes.setAttribute('role', 'group');
  modes.setAttribute('aria-label', 'Kies een woordenboek');
  const modeNl = el('button', 'wb-mode', 'Nederlands');
  modeNl.type = 'button';
  const modeLa = el('button', 'wb-mode', 'Nederlands → Latijn');
  modeLa.type = 'button';
  modeLa.title = 'Een Nederlands woord vertalen naar het Latijn';
  const modeFr = el('button', 'wb-mode', 'Nederlands → Frans');
  modeFr.type = 'button';
  modeFr.title = 'Een Nederlands woord vertalen naar het Frans';
  const modeOrig = el('button', 'wb-mode', 'Hebreeuws / Grieks');
  modeOrig.type = 'button';
  modeOrig.title = 'Oorspronkelijke talen → Nederlands (Strong’s)';
  modes.append(modeNl, modeLa, modeFr, modeOrig);
  root.prepend(modes);

  let latin = null;
  let frans = null;
  let origineel = null;
  function setDictMode(which) {
    const lat = which === 'la';
    const fr = which === 'fr';
    const orig = which === 'orig';
    modeNl.setAttribute('aria-pressed', String(!lat && !fr && !orig));
    modeLa.setAttribute('aria-pressed', String(lat));
    modeFr.setAttribute('aria-pressed', String(fr));
    modeOrig.setAttribute('aria-pressed', String(orig));
    root.classList.toggle('wb-lat-mode', lat);
    root.classList.toggle('wb-fr-mode', fr);
    root.classList.toggle('wb-orig-mode', orig);
    if (lat) {
      if (!latin) { latin = createLatijnPanel(); root.append(latin.root); }
      setTimeout(() => latin.focus(), 30);
    } else if (fr) {
      if (!frans) { frans = createFransPanel(); root.append(frans.root); }
      setTimeout(() => frans.focus(), 30);
    } else if (orig) {
      if (!origineel) { origineel = createOrigineelPanel(); root.append(origineel.root); }
      setTimeout(() => origineel.focus(), 30);
    } else {
      setTimeout(() => searchIn.focus(), 30);
    }
  }
  modeNl.onclick = () => setDictMode('nl');
  modeLa.onclick = () => setDictMode('la');
  modeFr.onclick = () => setDictMode('fr');
  modeOrig.onclick = () => setDictMode('orig');
  modeNl.setAttribute('aria-pressed', 'true');
  modeLa.setAttribute('aria-pressed', 'false');
  modeFr.setAttribute('aria-pressed', 'false');
  modeOrig.setAttribute('aria-pressed', 'false');

  // Open vanuit verdieping/woordstudie
  try {
    const pending = sessionStorage.getItem('lc-wb-origineel-q');
    if (pending) {
      sessionStorage.removeItem('lc-wb-origineel-q');
      setDictMode('orig');
      setTimeout(() => {
        if (origineel) origineel.setQuery(pending);
      }, 80);
    }
  } catch (_) {}


  // —— blad-state ——
  let allEntries = [];
  let highlightQ = '';
  let spreadIdx = 0;
  let spreads = [];
  let loadToken = 0;

  // Progressief pakken
  let packCursor = 0;       // volgende index in allEntries
  let packedCount = 0;     // hoeveel entries al in spreads zitten
  let packing = false;
  let packToken = 0;
  let packTimer = null;

  function setLoading(on, msg, sub) {
    loading.hidden = !on;
    if (msg) loadMsg.textContent = msg;
    if (sub != null) loadSub.textContent = sub;
    if (on) {
      navPrev.disabled = true;
      navNext.disabled = true;
      footPrev.disabled = true;
      footNext.disabled = true;
    }
  }

  function openBook() {
    if (bookOpen) return;
    bookOpen = true;
    book.classList.remove('wb-closed');
    root.classList.remove('wb-is-closed');
  }

  function stopPacking() {
    packing = false;
    packToken++;
    if (packTimer != null) {
      clearTimeout(packTimer);
      packTimer = null;
    }
  }

  function closeBook() {
    stopPacking();
    bookOpen = false;
    book.classList.add('wb-closed');
    root.classList.add('wb-is-closed');
    listL.replaceChildren();
    listR.replaceChildren();
    numL.textContent = '';
    numR.textContent = '';
    footInfo.textContent = '';
    navPrev.disabled = true;
    navNext.disabled = true;
    footPrev.disabled = true;
    footNext.disabled = true;
    allEntries = [];
    spreads = [];
    spreadIdx = 0;
    packCursor = 0;
    packedCount = 0;
    mode = 'closed';
    setActiveLetter(null);
  }

  async function loadIndex() {
    setLoading(true, 'Woordenboek laden…', 'Even geduld — Leo Crucis werkt nog');
    try {
      const res = await fetch(BASE + 'index.json');
      if (!res.ok) throw new Error('index');
      index = await res.json();
      buildLetterBar();
      try {
        const saved = await FileMem.read(MEM_POS);
        if (saved && saved.q) searchIn.value = saved.q;
      } catch {}
      await loadMemoryLists();
      setLoading(false);
      status.textContent = (index.words || 0).toLocaleString('nl-NL') +
        ' woorden · kies een letter of zoek een woord';
    } catch (e) {
      console.warn(e);
      status.textContent = 'Kon het woordenboek niet laden.';
      status.classList.add('wb-error');
      setLoading(false);
    }
  }

  async function loadMemoryLists() {
    try {
      const bm = await FileMem.read(MEM_BOOKMARKS);
      bookmarks = Array.isArray(bm) ? bm.map(norm).filter(Boolean) : [];
    } catch { bookmarks = []; }
    try {
      const h = await FileMem.read(MEM_HISTORY);
      history = Array.isArray(h) ? h.filter(x => x && x.w) : [];
    } catch { history = []; }
  }

  async function pushHistory(word) {
    const w = String(word || '').trim();
    if (!w) return;
    const nw = norm(w);
    history = history.filter(h => norm(h.w) !== nw);
    history.unshift({ w, t: Date.now() });
    if (history.length > HISTORY_MAX) history = history.slice(0, HISTORY_MAX);
    await FileMem.write(MEM_HISTORY, history);
  }

  async function toggleBookmark(word) {
    const nw = norm(word);
    if (!nw) return;
    const i = bookmarks.indexOf(nw);
    if (i >= 0) bookmarks.splice(i, 1);
    else {
      bookmarks.unshift(nw);
      if (bookmarks.length > BOOKMARKS_MAX) bookmarks = bookmarks.slice(0, BOOKMARKS_MAX);
    }
    await FileMem.write(MEM_BOOKMARKS, bookmarks);
  }

  /** Zoek één exact lemma (eerste letter eerst) en toon alleen dat. */
  async function openExactWord(q) {
    const nq = norm(q);
    if (!nq || !index) return false;
    const L = firstLetter(nq);
    try {
      const data = await loadLetter(L);
      const exact = data.find(e => norm(e.w) === nq);
      if (!exact) return false;
      mode = 'search';
      searchQuery = q;
      setActiveLetter(null);
      openBook();
      stopPacking();
      status.textContent = 'Lemma: ' + exact.w;
      startProgressiveList([exact], q, { waitAll: true });
      FileMem.write(MEM_POS, { q }).catch(() => {});
      pushHistory(exact.w).catch(() => {});
      return true;
    } catch {
      return false;
    }
  }

  async function showBookmarks() {
    mode = 'bookmarks';
    setActiveLetter(null);
    searchQuery = '';
    openBook();
    stopPacking();
    setLoading(true, 'Bladwijzers laden…', '');
    const entries = [];
    for (const nw of bookmarks) {
      try {
        const data = await loadLetter(firstLetter(nw));
        const e = data.find(x => norm(x.w) === nw);
        if (e) entries.push(e);
      } catch {}
    }
    setLoading(false);
    if (!entries.length) {
      status.textContent = 'Nog geen bladwijzers. Tik op het bladwijzer-icoon bij een woord.';
      startProgressiveList([], '', { waitAll: true });
    } else {
      status.textContent = entries.length + ' bladwijzer' + (entries.length === 1 ? '' : 's');
      startProgressiveList(entries, '', { waitAll: true });
    }
  }

  async function showHistory() {
    mode = 'history';
    setActiveLetter(null);
    searchQuery = '';
    openBook();
    stopPacking();
    setLoading(true, 'Geschiedenis laden…', '');
    const entries = [];
    const seen = new Set();
    for (const h of history) {
      const nw = norm(h.w);
      if (seen.has(nw)) continue;
      seen.add(nw);
      try {
        const data = await loadLetter(firstLetter(nw));
        const e = data.find(x => norm(x.w) === nw);
        if (e) entries.push(e);
      } catch {}
    }
    setLoading(false);
    if (!entries.length) {
      status.textContent = 'Nog geen geschiedenis. Zoek of open een woord.';
      startProgressiveList([], '', { waitAll: true });
    } else {
      status.textContent = entries.length + ' recent' + (entries.length === 1 ? '' : 'e') + ' woord' + (entries.length === 1 ? '' : 'en');
      startProgressiveList(entries, '', { waitAll: true });
    }
  }

  function buildLetterBar() {
    letterBar.replaceChildren();
    const letters = Object.keys(index.letters || {}).filter(l => l !== '#').sort();
    if (index.letters['#']) letters.push('#');
    letters.forEach(L => {
      const b = el('button', 'wb-letter', L === '#' ? '#' : L.toUpperCase());
      b.type = 'button';
      b.dataset.letter = L;
      b.title = (index.letters[L] || 0) + ' woorden';
      b.onclick = () => openLetter(L);
      letterBar.append(b);
    });
  }

  function setActiveLetter(L) {
    letterBar.querySelectorAll('.wb-letter').forEach(b => {
      b.classList.toggle('on', b.dataset.letter === L);
    });
  }

  /** Geen geheugencache: elke letter opnieuw ophalen (HTTP-cache van de browser mag wel). */
  async function loadLetter(L) {
    try {
      return await withLoadSlot(async () => {
        const res = await fetch(BASE + L + '.json', { cache: 'force-cache' });
        if (!res.ok) throw new Error('letter ' + L);
        const data = await res.json();
        try { await yieldForUi(); } catch (_) {}
        return data;
      });
    } catch (e) {
      const res = await fetch(BASE + L + '.json', { cache: 'force-cache' });
      if (!res.ok) throw new Error('letter ' + L);
      return await res.json();
    }
  }


  function pageContentHeight() {
    const h = listL.clientHeight || (pageLInner.clientHeight - 24) || 360;
    return Math.max(80, h);
  }

  function packPageEntries(startIdx, widthPx, heightPx) {
    const probe = document.createElement('div');
    probe.style.cssText = 'position:absolute;left:-9999px;top:0;visibility:hidden;overflow:hidden;'
      + 'display:flex;flex-direction:column;gap:6px;box-sizing:border-box;'
      + 'width:' + Math.max(120, widthPx) + 'px;';
    document.body.appendChild(probe);

    const out = [];
    let i = startIdx;
    while (i < allEntries.length) {
      const card = renderEntry(allEntries[i], highlightQ);
      probe.appendChild(card);
      if (probe.scrollHeight > heightPx + 1) {
        probe.removeChild(card);
        if (!out.length) {
          out.push(allEntries[i]);
          i++;
        }
        break;
      }
      out.push(allEntries[i]);
      i++;
    }
    probe.remove();
    return { entries: out, next: i };
  }

  function updateFootInfo() {
    const n = spreads.length;
    const total = allEntries.length;
    const done = packCursor >= total;
    let text = '';
    if (total) {
      text = 'Blad ' + (spreadIdx + 1) + ' van ' + Math.max(n, 1);
      if (!done) {
        text += ' · ' + packedCount.toLocaleString('nl-NL') + ' / ' +
          total.toLocaleString('nl-NL') + ' woorden (laden…)';
      } else {
        text += ' · ' + total.toLocaleString('nl-NL') + ' woorden';
      }
    }
    footInfo.textContent = text;
  }

  function showSpread() {
    if (!spreads.length) spreads = [{ left: [], right: [] }];
    if (spreadIdx >= spreads.length) spreadIdx = spreads.length - 1;
    if (spreadIdx < 0) spreadIdx = 0;

    const sp = spreads[spreadIdx];
    listL.replaceChildren();
    listR.replaceChildren();
    if (!allEntries.length) {
      listL.append(el('p', 'wb-tip', 'Geen woorden gevonden.'));
      numL.textContent = '';
      numR.textContent = '';
    } else {
      sp.left.forEach(e => listL.append(renderEntry(e, highlightQ)));
      sp.right.forEach(e => listR.append(renderEntry(e, highlightQ)));
      numL.textContent = String(spreadIdx * 2 + 1);
      numR.textContent = String(spreadIdx * 2 + 2);
    }

    const n = spreads.length;
    const atStart = spreadIdx <= 0;
    const packingLeft = packCursor < allEntries.length;
    // Volgende is disabled alleen als we echt aan het einde zitten én klaar met pakken
    const atEnd = spreadIdx >= n - 1 && !packingLeft;
    navPrev.disabled = atStart;
    navNext.disabled = atEnd && !packingLeft ? true : (spreadIdx >= n - 1 && packingLeft ? false : atEnd);
    // Als laatste beschikbare blad maar nog packing: next blijft actief; goSpread wacht/pakt bij
    if (spreadIdx >= n - 1 && packingLeft) {
      navNext.disabled = false;
      footNext.disabled = false;
    } else {
      navNext.disabled = atEnd;
      footNext.disabled = atEnd;
    }
    footPrev.disabled = atStart;
    updateFootInfo();
  }

  /** Pak maxSpreads spreads vanaf packCursor. Geeft true terug als er nog meer te pakken is. */
  function packChunk(maxSpreads) {
    if (packCursor >= allEntries.length) return false;
    const h = pageContentHeight();
    const wL = listL.clientWidth || Math.floor((book.clientWidth || 800) / 2) - 40;
    const wR = listR.clientWidth || wL;
    let added = 0;
    while (packCursor < allEntries.length && added < maxSpreads) {
      const left = packPageEntries(packCursor, wL, h);
      packCursor = left.next;
      const right = packPageEntries(packCursor, wR, h);
      packCursor = right.next;
      spreads.push({ left: left.entries, right: right.entries });
      packedCount += left.entries.length + right.entries.length;
      added++;
      if (!left.entries.length && !right.entries.length) break;
    }
    return packCursor < allEntries.length;
  }

  function schedulePackMore(token) {
    if (token !== packToken) return;
    packing = true;
    const still = packChunk(PACK_CHUNK_SPREADS);
    updateFootInfo();
    // Nav-state bijwerken als gebruiker op laatste blad zit
    if (spreadIdx >= spreads.length - 1) showSpread();
    if (still && token === packToken) {
      packTimer = setTimeout(async () => {
        try { await yieldForUi(); } catch (_) {}
        schedulePackMore(token);
      }, 0);
    } else {
      packing = false;
      packTimer = null;
      updateFootInfo();
      showSpread();
      // Status afronden bij browse
      if (mode === 'browse' && currentLetter) {
        const letterLabel = currentLetter === '#' ? '#' : currentLetter.toUpperCase();
        status.textContent = allEntries.length.toLocaleString('nl-NL') +
          ' woorden met \u2018' + letterLabel + '\u2019';
      }
    }
  }

  /**
   * Start progressief renderen.
   * opts.earlyMin — toon boek zodra minstens zoveel entries gepakt zijn (default INITIAL_ENTRIES).
   * opts.waitAll — wacht tot alles gepakt is vóór tonen (voor kleine zoekresultaten).
   */
  function startProgressiveList(entries, highlight, opts) {
    stopPacking();
    allEntries = entries.slice();
    highlightQ = highlight || '';
    spreadIdx = 0;
    spreads = [];
    packCursor = 0;
    packedCount = 0;

    const earlyMin = (opts && opts.earlyMin != null) ? opts.earlyMin : INITIAL_ENTRIES;
    const waitAll = !!(opts && opts.waitAll);

    if (!allEntries.length) {
      spreads = [{ left: [], right: [] }];
      showSpread();
      setLoading(false);
      return;
    }

    const token = ++packToken;

    // Layout nodig voor pageContentHeight — even in open boek met lege pagina's
    openBook();

    // Eerste chunk(s) synchroon tot earlyMin of alles
    const doFirst = () => {
      if (token !== packToken) return;
      if (waitAll) {
        while (packCursor < allEntries.length) packChunk(PACK_CHUNK_SPREADS);
        showSpread();
        setLoading(false);
        packing = false;
        updateFootInfo();
        return;
      }
      // Pak tot we genoeg entries hebben of klaar zijn
      while (packCursor < allEntries.length && packedCount < earlyMin) {
        packChunk(1);
      }
      // Minstens één spread
      if (!spreads.length && packCursor < allEntries.length) packChunk(1);

      showSpread();
      setLoading(false);

      if (packCursor < allEntries.length) {
        schedulePackMore(token);
      } else {
        packing = false;
        updateFootInfo();
      }
    };

    // Twee rAF zodat layout (breedte/hoogte pagina) klopt na openBook
    requestAnimationFrame(() => {
      requestAnimationFrame(doFirst);
    });
  }

  function goSpread(delta) {
    if (!bookOpen) return;
    const n = spreads.length || 1;
    const next = spreadIdx + delta;

    if (delta > 0 && next >= n) {
      // Gebruiker wil verder, maar spreads nog niet klaar → pak meteen meer
      if (packCursor < allEntries.length) {
        packChunk(PACK_CHUNK_SPREADS);
        updateFootInfo();
        if (spreads.length > spreadIdx + 1) {
          spreadIdx++;
          showSpread();
        } else {
          // Nog steeds niks: toon tijdelijk dat we laden in de voet
          updateFootInfo();
        }
        return;
      }
      return;
    }

    spreadIdx = Math.max(0, Math.min(Math.max(spreads.length, 1) - 1, next));
    showSpread();

    // Vooruit laden: als we dicht bij het einde zitten, pak extra
    if (spreadIdx >= spreads.length - 3 && packCursor < allEntries.length) {
      packChunk(PACK_CHUNK_SPREADS);
      updateFootInfo();
    }
  }

  function renderEntry(entry, highlight) {
    const card = el('article', 'wb-card');
    const head = el('header', 'wb-card-head');
    const title = el('h2', 'wb-woord', entry.w);
    head.append(title);
    if (entry.p && entry.p.length) {
      const meta = el('span', 'wb-meta', entry.p.map(posLabel).join(' · '));
      head.append(meta);
    }
    const bm = el('button', 'wb-bm-btn');
    bm.type = 'button';
    const isBm = bookmarks.includes(norm(entry.w));
    bm.classList.toggle('wb-bm-on', isBm);
    bm.title = isBm ? 'Bladwijzer verwijderen' : 'Bladwijzer toevoegen';
    bm.setAttribute('aria-label', bm.title);
    bm.innerHTML = isBm
      ? '<svg viewBox="0 0 24 24" width="14" height="14"><path d="M6 4h12a1 1 0 0 1 1 1v16l-7-4-7 4V5a1 1 0 0 1 1-1z" fill="currentColor"/></svg>'
      : '<svg viewBox="0 0 24 24" width="14" height="14"><path d="M6 4h12a1 1 0 0 1 1 1v16l-7-4-7 4V5a1 1 0 0 1 1-1z" fill="none" stroke="currentColor" stroke-width="2"/></svg>';
    bm.onclick = (ev) => {
      ev.stopPropagation();
      toggleBookmark(entry.w).then(() => {
        const on = bookmarks.includes(norm(entry.w));
        bm.classList.toggle('wb-bm-on', on);
        bm.title = on ? 'Bladwijzer verwijderen' : 'Bladwijzer toevoegen';
        bm.setAttribute('aria-label', bm.title);
        bm.innerHTML = on
          ? '<svg viewBox="0 0 24 24" width="14" height="14"><path d="M6 4h12a1 1 0 0 1 1 1v16l-7-4-7 4V5a1 1 0 0 1 1-1z" fill="currentColor"/></svg>'
          : '<svg viewBox="0 0 24 24" width="14" height="14"><path d="M6 4h12a1 1 0 0 1 1 1v16l-7-4-7 4V5a1 1 0 0 1 1-1z" fill="none" stroke="currentColor" stroke-width="2"/></svg>';
      });
    };
    head.append(bm);
    card.append(head);
    if (entry.d && entry.d.length) {
      if (entry.d.length === 1) {
        card.append(el('p', 'wb-def-single', entry.d[0]));
      } else {
        const ol = el('ol', 'wb-defs');
        entry.d.forEach(d => ol.append(el('li', '', d)));
        card.append(ol);
      }
    }
    card.addEventListener('click', () => {
      pushHistory(entry.w).catch(() => {});
    });
    return card;
  }

  async function openLetter(L) {
    mode = 'browse';
    currentLetter = L;
    searchQuery = '';
    searchIn.value = '';
    setActiveLetter(L);
    const letterLabel = L === '#' ? '#' : L.toUpperCase();
    status.textContent = 'Laden van \u2018' + letterLabel + '\u2019\u2026';
    const token = ++loadToken;
    stopPacking();
    openBook();
    setLoading(true, 'Woorden aan het plaatsen in het boek', 'Letter ' + letterLabel + ' — eerste bladzijden…');
    // Leeg boek tonen tijdens fetch
    allEntries = [];
    spreads = [{ left: [], right: [] }];
    packCursor = 0;
    packedCount = 0;
    showSpread();

    try {
      const data = await loadLetter(L);
      if (token !== loadToken) return;
      status.textContent = data.length.toLocaleString('nl-NL') +
        ' woorden met \u2018' + letterLabel + '\u2019 — eerste bladzijden…';
      setLoading(true, 'Woorden aan het plaatsen in het boek',
        'Eerste ' + INITIAL_ENTRIES + ' van ' + data.length.toLocaleString('nl-NL') + '…');
      startProgressiveList(data, '', { earlyMin: INITIAL_ENTRIES });
      FileMem.write(MEM_POS, { letter: L }).catch(() => {});
    } catch (e) {
      if (token !== loadToken) return;
      status.textContent = 'Kon letter niet laden.';
      status.classList.add('wb-error');
      setLoading(false);
    }
  }

  /** Voeg woorden toe terwijl het boek al open is; pak verder op de achtergrond. */
  function appendEntries(newEntries) {
    if (!newEntries || !newEntries.length) return;
    allEntries.push(...newEntries);
    updateFootInfo();
    if (!packing && packCursor < allEntries.length) {
      schedulePackMore(packToken);
    }
  }

  /** A–Z: heel woordenboek, letter voor letter, progressief bladerbaar. */
  async function openAllLetters() {
    if (!index) {
      status.textContent = 'Woordenboek is nog niet geladen.';
      return;
    }
    mode = 'browse';
    currentLetter = null;
    searchQuery = '';
    searchIn.value = '';
    setActiveLetter(null);
    const token = ++loadToken;
    stopPacking();
    openBook();

    const letters = Object.keys(index.letters || {}).filter(l => l !== '#').sort();
    if (index.letters['#']) letters.push('#');
    const totalWords = index.words || 0;

    setLoading(true, 'Woorden aan het plaatsen in het boek', 'Heel woordenboek — eerste bladzijden…');
    allEntries = [];
    spreads = [{ left: [], right: [] }];
    packCursor = 0;
    packedCount = 0;
    showSpread();

    status.textContent = 'Laden van A–Z… 0 / ' + totalWords.toLocaleString('nl-NL') + ' woorden';
    let shown = false;
    let loadedCount = 0;

    try {
      for (let li = 0; li < letters.length; li++) {
        if (token !== loadToken) return;
        const L = letters[li];
        const letterLabel = L === '#' ? '#' : L.toUpperCase();
        const data = await loadLetter(L);
        if (token !== loadToken) return;
        loadedCount += data.length;

        status.textContent = 'A–Z · ' + loadedCount.toLocaleString('nl-NL') +
          (totalWords ? ' / ' + totalWords.toLocaleString('nl-NL') : '') +
          ' woorden (letter ' + letterLabel + ')…';

        if (!shown) {
          if (allEntries.length + data.length >= INITIAL_ENTRIES || li === letters.length - 1) {
            const firstBatch = allEntries.concat(data);
            allEntries = [];
            setLoading(true, 'Woorden aan het plaatsen in het boek',
              'Eerste ' + INITIAL_ENTRIES + ' van ' + firstBatch.length.toLocaleString('nl-NL') + '…');
            startProgressiveList(firstBatch, '', { earlyMin: INITIAL_ENTRIES });
            shown = true;
          } else {
            allEntries.push(...data);
          }
        } else {
          appendEntries(data);
        }
      }
      if (token !== loadToken) return;

      if (!shown) {
        startProgressiveList(allEntries.slice(), '', { waitAll: true });
      }

      status.textContent = loadedCount.toLocaleString('nl-NL') + ' woorden · heel woordenboek (A–Z)';
      FileMem.write(MEM_POS, { all: true }).catch(() => {});
    } catch (e) {
      if (token !== loadToken) return;
      console.warn(e);
      status.textContent = 'Kon het volledige woordenboek niet laden.';
      status.classList.add('wb-error');
      setLoading(false);
    }
  }

  async function doSearch(q) {
    const nq = norm(q);
    if (!nq) {
      closeBook();
      status.textContent = (index && index.words)
        ? (index.words.toLocaleString('nl-NL') + ' woorden · kies een letter of zoek een woord')
        : 'Kies een letter of zoek een woord';
      FileMem.remove(MEM_POS).catch(() => {});
      return;
    }
    mode = 'search';
    searchQuery = q;
    setActiveLetter(null);
    status.textContent = 'Zoeken naar \u201c' + q + '\u201d\u2026';
    const token = ++loadToken;
    stopPacking();
    openBook();
    setLoading(true, 'Woorden aan het plaatsen in het boek', 'Zoeken naar “' + q + '”');
    allEntries = [];
    spreads = [{ left: [], right: [] }];
    showSpread();

    if (!index) {
      status.textContent = 'Woordenboek is nog niet geladen.';
      setLoading(false);
      return;
    }

    // Eerst de letter van de query, daarna de rest — geen maximum meer
    const startL = firstLetter(nq);
    const order = [startL, ...Object.keys(index.letters || {}).filter(l => l !== startL)];
    const found = [];
    let shownEarly = false;
    let lastAppended = 0;

    for (const L of order) {
      try {
        const data = await loadLetter(L);
        if (token !== loadToken) return;
        for (const e of data) {
          const nw = norm(e.w);
          if (nw === nq || nw.startsWith(nq) || (nq.length >= 3 && nw.includes(nq))) {
            found.push(e);
          }
        }
        // Vanaf SEARCH_EARLY_MIN: al tonen, daarna bij elke letter nieuwe treffers bijvoegen
        if (!shownEarly && found.length >= SEARCH_EARLY_MIN) {
          shownEarly = true;
          found.sort(searchSort(nq));
          lastAppended = found.length;
          status.textContent = found.length.toLocaleString('nl-NL') +
            '+ resultaten voor \u201c' + q + '\u201d (verder zoeken…)';
          startProgressiveList(found.slice(), q, { earlyMin: SEARCH_EARLY_MIN });
        } else if (shownEarly && found.length > lastAppended) {
          const extra = found.slice(lastAppended);
          lastAppended = found.length;
          appendEntries(extra);
          status.textContent = found.length.toLocaleString('nl-NL') +
            '+ resultaten voor \u201c' + q + '\u201d (verder zoeken…)';
        }
      } catch {}
    }
    if (token !== loadToken) return;

    if (!found.length) {
      status.textContent = 'Geen resultaten voor \u201c' + q + '\u201d. Tip: probeer een korter woord of A\u2013Z.';
      startProgressiveList([], '', { waitAll: true });
    } else if (!shownEarly) {
      // Minder dan SEARCH_EARLY_MIN: alles klaar, dan pas tonen
      found.sort(searchSort(nq));
      status.textContent = found.length.toLocaleString('nl-NL') +
        ' resultaat' + (found.length === 1 ? '' : 'en') + ' voor \u201c' + q + '\u201d';
      startProgressiveList(found, q, { waitAll: true });
    } else {
      // Al progressief getoond; eventueel rest bijvoegen + eindstatus
      if (found.length > lastAppended) {
        appendEntries(found.slice(lastAppended));
      }
      status.textContent = found.length.toLocaleString('nl-NL') +
        ' resultaten voor \u201c' + q + '\u201d';
    }
    FileMem.write(MEM_POS, { q }).catch(() => {});
    pushHistory(q).catch(() => {});
  }

  function searchSort(nq) {
    return (a, b) => {
      const na = norm(a.w), nb = norm(b.w);
      const score = (n) => n === nq ? 0 : n.startsWith(nq) ? 1 : 2;
      const sa = score(na), sb = score(nb);
      if (sa !== sb) return sa - sb;
      return na.localeCompare(nb, 'nl');
    };
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const q = searchIn.value.trim();
    // Enter = alle resultaten (exacte treffer staat vooraan via searchSort).
    // Ctrl/Cmd+Enter = alleen het exacte lemma openen.
    if (e.ctrlKey || e.metaKey) {
      const opened = await openExactWord(q);
      if (!opened) doSearch(q);
      return;
    }
    doSearch(q);
  });

  searchIn.addEventListener('input', () => {
    const v = searchIn.value.trim();
    if (!v && bookOpen && (mode === 'search' || mode === 'bookmarks' || mode === 'history')) {
      closeBook();
      status.textContent = (index && index.words)
        ? (index.words.toLocaleString('nl-NL') + ' woorden · kies een letter of zoek een woord')
        : 'Kies een letter of zoek een woord';
    }
  });

  browseBtn.onclick = () => {
    openAllLetters();
  };
  bmBtn.onclick = () => { showBookmarks(); };
  histBtn.onclick = () => { showHistory(); };

  navPrev.onclick = () => goSpread(-1);
  navNext.onclick = () => goSpread(1);
  footPrev.onclick = () => goSpread(-1);
  footNext.onclick = () => goSpread(1);

  root.tabIndex = 0;
  root.addEventListener('keydown', e => {
    if (root.classList.contains('wb-lat-mode') || root.classList.contains('wb-fr-mode') || root.classList.contains('wb-orig-mode') || !bookOpen) return;
    if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); goSpread(-1); }
    else if (e.key === 'ArrowRight' || e.key === 'PageDown') { e.preventDefault(); goSpread(1); }
  });

  setTimeout(() => searchIn.focus(), 40);
  loadIndex();

  return { root };
}
