// Export van een boek: PDF (direct downloaden), afdrukken / "Opslaan als PDF" (scherpe tekst) en Word (.doc).
// De documentinstellingen (papierformaat, marges, kop- en voettekst, …) staan als data-attributen op de .doc-wrapper (zie editor.js).

import { withLoading } from '../core/loading.js';

export const PAGES = { a3: [297, 420], a4: [210, 297], a5: [148, 210], letter: [215.9, 279.4], legal: [215.9, 355.6] };
export const MARGINS = { geen: 0, smal: 12, normaal: 20, breed: 28 };
export const DOC_KEYS = ['page', 'orient', 'margin', 'cols', 'watermark', 'header', 'footer', 'pagenum', 'theme', 'font', 'hyphen'];

const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
export const slugName = s => (s || 'boek').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'boek';

// Haalt een eventuele <div class="doc …"> wrapper van de inhoud en geeft stijl + instellingen terug.
export function parseDoc(html) {
  const t = document.createElement('template'); t.innerHTML = (html || '').trim();
  const nodes = [...t.content.childNodes].filter(n => !(n.nodeType === 3 && !n.textContent.trim()));
  const w = nodes.length === 1 && nodes[0].nodeType === 1 && nodes[0].classList.contains('doc') ? nodes[0] : null;
  if (!w) return { inner: html || '', style: '', attrs: {}, cls: 'doc' };
  const attrs = {}; DOC_KEYS.forEach(k => { const v = w.getAttribute('data-' + k); if (v != null) attrs[k] = v; });
  const m = /\bdoc-([a-z0-9]+)/.exec(w.className);
  return { inner: w.innerHTML, style: m ? m[1] : '', attrs, cls: w.className };
}

// Afmetingen in mm (rekening houdend met afdrukstand).
export function pageSize(attrs = {}) {
  const [pw, ph] = PAGES[attrs.page] || PAGES.a4;
  const land = attrs.orient === 'landscape';
  const margin = attrs.margin in MARGINS ? MARGINS[attrs.margin] : MARGINS.normaal;
  return { w: land ? ph : pw, h: land ? pw : ph, margin, landscape: land, portrait: [pw, ph] };
}

const libs = {};
export const loadLib = file => libs[file] || (libs[file] = new Promise((ok, no) => {
  const s = document.createElement('script');
  s.src = new URL('vendor/' + file, import.meta.url).href;
  s.onload = ok; s.onerror = () => { delete libs[file]; no(new Error('Kan ' + file + ' niet laden')); };
  document.head.append(s);
}));

export function downloadBlob(blob, name) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name; document.body.append(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
}

// Bouwt een onzichtbaar "blad" met exact de opmaak van de leesweergave (altijd op wit papier).
function buildStage(html) {
  const d = parseDoc(html), ps = pageSize(d.attrs);
  const stage = document.createElement('div');
  stage.className = 'pdf-stage';
  stage.style.cssText = `position:fixed;left:-30000px;top:0;width:${(ps.w - 2 * ps.margin).toFixed(2)}mm;`;
  const sheet = document.createElement('div');
  sheet.className = 'book pdf-sheet ' + d.cls.replace(/\bpaper\b/g, '');
  DOC_KEYS.forEach(k => { if (d.attrs[k] != null) sheet.setAttribute('data-' + k, d.attrs[k]); });
  sheet.innerHTML = d.inner;
  sheet.querySelectorAll('[contenteditable]').forEach(n => n.removeAttribute('contenteditable'));
  stage.append(sheet); document.body.append(stage);
  return { stage, sheet, d, ps };
}

const waitImages = root => Promise.all([...root.querySelectorAll('img')].map(i => i.complete ? 0 : new Promise(r => { i.onload = i.onerror = r; })));
const latin = s => String(s).replace(/[^\u0000-\u00ff]/g, '?');

// PDF direct downloaden (html2pdf: pagina's worden als beeld in het PDF-bestand gezet).
export function exportPdf(title, html) {
  return withLoading(() => exportPdfInner(title, html), 'PDF wordt gemaakt…');
}
async function exportPdfInner(title, html) {
  await loadLib('html2pdf.bundle.min.js');
  const st = buildStage(html), { ps, d } = st, a = d.attrs;
  const hasFoot = !!(a.footer || a.pagenum), hasHead = !!a.header;
  const mTop = Math.max(ps.margin, hasHead ? 14 : 0), mBot = Math.max(ps.margin, hasFoot ? 14 : 0);
  st.stage.style.width = (ps.w - 2 * ps.margin).toFixed(2) + 'mm';
  try {
    await waitImages(st.sheet);
    if (document.fonts && document.fonts.ready) await document.fonts.ready;
    const opt = {
      margin: [mTop, ps.margin, mBot, ps.margin],
      filename: slugName(title) + '.pdf',
      image: { type: 'jpeg', quality: 0.96 },
      html2canvas: { scale: 2, useCORS: true, backgroundColor: '#ffffff', logging: false, windowWidth: Math.round((ps.w - 2 * ps.margin) * 96 / 25.4) },
      jsPDF: { unit: 'mm', format: ps.portrait, orientation: ps.landscape ? 'landscape' : 'portrait', compress: true },
      pagebreak: { mode: ['css', 'legacy'], before: '.page-break', avoid: ['h1', 'h2', 'h3', 'h4', 'img', 'tr', 'blockquote', 'figure', '.s-kern', '.s-def', '.s-tip', '.s-let-op', '.s-belangrijk', '.s-opdracht', '.s-pull', '.box', 'li'] }
    };
    await window.html2pdf().set(opt).from(st.sheet).toPdf().get('pdf').then(pdf => {
      const n = pdf.internal.getNumberOfPages(), W = pdf.internal.pageSize.getWidth(), H = pdf.internal.pageSize.getHeight();
      for (let i = 1; i <= n; i++) {
        pdf.setPage(i);
        if (a.watermark) {
          pdf.saveGraphicsState && pdf.saveGraphicsState();
          if (pdf.GState && pdf.setGState) pdf.setGState(new pdf.GState({ opacity: 0.12 }));
          pdf.setTextColor(122, 31, 43); pdf.setFont('helvetica', 'bold'); pdf.setFontSize(Math.min(90, 900 / Math.max(6, a.watermark.length)));
          pdf.text(latin(a.watermark), W / 2, H / 2, { align: 'center', angle: 30 });
          pdf.restoreGraphicsState && pdf.restoreGraphicsState();
        }
        pdf.setFont('helvetica', 'normal'); pdf.setFontSize(9); pdf.setTextColor(110, 110, 110);
        if (a.header) pdf.text(latin(a.header), W / 2, Math.max(8, mTop / 2 + 2), { align: 'center' });
        if (a.footer) pdf.text(latin(a.footer), ps.margin, H - Math.max(7, mBot / 2 - 1));
        if (a.pagenum) pdf.text(`${i} / ${n}`, W - ps.margin, H - Math.max(7, mBot / 2 - 1), { align: 'right' });
      }
    }).save();
  } finally { st.stage.remove(); }
}

// Eigen afdrukvenster in de app (geen Windows/Chrome-printdialoog als hoofdflow).
export function printDoc(title, html) {
  openPrintPreview(title, html);
}

/** In-app print / PDF-venster: voorbeeld, instellingen, PDF opslaan, optioneel systeem-print. */
export function openPrintPreview(title, html) {
  const d = parseDoc(html);
  let attrs = { page: 'a4', orient: 'portrait', margin: 'normaal', ...d.attrs };

  const back = document.createElement('div');
  back.className = 'dlg-back print-preview-back';
  const box = document.createElement('div');
  box.className = 'dlg dlg-print';
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-label', 'Afdrukken of PDF opslaan');

  const head = document.createElement('div');
  head.className = 'print-preview-head';
  const h = document.createElement('h2');
  h.textContent = 'Afdrukken / PDF';
  const close = document.createElement('button');
  close.type = 'button'; close.className = 'back'; close.textContent = '✕';
  close.setAttribute('aria-label', 'Sluiten');
  close.onclick = () => back.remove();
  head.append(h, close);

  const layout = document.createElement('div');
  layout.className = 'print-preview-layout';

  // Sidebar settings
  const side = document.createElement('div');
  side.className = 'print-preview-side';
  const mkSelect = (label, key, options) => {
    const wrap = document.createElement('label');
    wrap.className = 'print-field';
    wrap.append(document.createTextNode(label));
    const sel = document.createElement('select');
    options.forEach(([v, t]) => {
      const o = document.createElement('option');
      o.value = v; o.textContent = t;
      if (attrs[key] === v) o.selected = true;
      sel.append(o);
    });
    sel.onchange = () => { attrs[key] = sel.value; refreshPreview(); };
    wrap.append(sel);
    side.append(wrap);
    return sel;
  };
  mkSelect('Papier', 'page', [['a4','A4'],['a5','A5'],['a3','A3'],['letter','Letter'],['legal','Legal']]);
  mkSelect('Stand', 'orient', [['portrait','Staand'],['landscape','Liggend']]);
  mkSelect('Marge', 'margin', [['geen','Geen'],['smal','Smal'],['normaal','Normaal'],['breed','Breed']]);

  const status = document.createElement('p');
  status.className = 'print-status';
  status.textContent = title || 'Document';
  side.append(status);

  const actions = document.createElement('div');
  actions.className = 'print-actions';

  const btnPdf = document.createElement('button');
  btnPdf.type = 'button';
  btnPdf.className = 'dlg-ok';
  btnPdf.textContent = '📄 Opslaan als PDF';
  btnPdf.onclick = async () => {
    status.textContent = 'PDF wordt gemaakt…';
    btnPdf.disabled = true;
    try {
      // Apply current attrs into html wrapper
      const wrapped = wrapWithAttrs(d.inner, d.cls, attrs);
      await exportPdf(title || 'document', wrapped);
      status.textContent = 'PDF gedownload';
    } catch (e) {
      status.textContent = 'Mislukt: ' + (e.message || e);
    }
    btnPdf.disabled = false;
  };

  const btnSystem = document.createElement('button');
  btnSystem.type = 'button';
  btnSystem.className = 'back';
  btnSystem.textContent = '🖨 Systeem-afdrukken…';
  btnSystem.title = 'Opent het Windows/printer-venster (optioneel)';
  btnSystem.onclick = () => {
    const wrapped = wrapWithAttrs(d.inner, d.cls, attrs);
    systemPrint(title, wrapped);
  };

  const btnCancel = document.createElement('button');
  btnCancel.type = 'button';
  btnCancel.className = 'back';
  btnCancel.textContent = 'Annuleren';
  btnCancel.onclick = () => back.remove();

  actions.append(btnPdf, btnSystem, btnCancel);
  side.append(actions);

  // Preview pane
  const previewWrap = document.createElement('div');
  previewWrap.className = 'print-preview-pane';
  const frame = document.createElement('iframe');
  frame.className = 'print-preview-frame';
  frame.title = 'Voorbeeld';
  previewWrap.append(frame);

  const refreshPreview = () => {
    const ps = pageSize(attrs);
    const css = new URL('styles.css', document.baseURI).href;
    const a = attrs;
    const q = s => String(s || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, ' ');
    const boxes = (a.header ? `@top-center{content:"${q(a.header)}";font:9pt sans-serif;color:#666}` : '') +
      (a.footer ? `@bottom-left{content:"${q(a.footer)}";font:9pt sans-serif;color:#666}` : '') +
      (a.pagenum ? `@bottom-right{content:counter(page) " / " counter(pages);font:9pt sans-serif;color:#666}` : '');
    const attrStr = DOC_KEYS.filter(k => a[k] != null && a[k] !== '').map(k => ` data-${k}="${esc(a[k])}"`).join('');
    const cls = (d.cls || 'doc').replace(/\bpaper\b/g, '');
    frame.srcdoc = `<!DOCTYPE html><html lang="nl"><head><meta charset="utf-8"><title>${esc(title)}</title>
<link rel="stylesheet" href="${css}">
<style>
html,body{margin:0;padding:16px;background:#e8e8e8}
.book{background:#fff;box-shadow:0 2px 12px rgba(0,0,0,.12);padding:${ps.margin}mm;max-width:${ps.w}mm;margin:0 auto;min-height:${ps.h - 2 * ps.margin}mm;box-sizing:border-box}
</style></head>
<body><div class="book pdf-sheet ${esc(cls)}"${attrStr}>${d.inner}</div></body></html>`;
  };

  layout.append(side, previewWrap);
  box.append(head, layout);
  back.append(box);
  document.body.append(back);
  refreshPreview();
  btnPdf.focus();
  back.addEventListener('keydown', e => { if (e.key === 'Escape') back.remove(); });
}

function wrapWithAttrs(inner, cls, attrs) {
  const el = document.createElement('div');
  el.className = (cls || 'doc').replace(/\bpaper\b/g, '');
  Object.entries(attrs || {}).forEach(([k, v]) => {
    if (v != null && v !== '') el.setAttribute('data-' + k, v);
  });
  el.innerHTML = inner || '';
  return el.outerHTML;
}

/** Optioneel: echte systeemprinter via browser/OS (secundair). */
function systemPrint(title, html) {
  const d = parseDoc(html), ps = pageSize(d.attrs), a = d.attrs;
  const css = new URL('styles.css', document.baseURI).href;
  const q = s => String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, ' ');
  const boxes = (a.header ? `@top-center{content:"${q(a.header)}";font:9pt sans-serif;color:#666}` : '') +
    (a.footer ? `@bottom-left{content:"${q(a.footer)}";font:9pt sans-serif;color:#666}` : '') +
    (a.pagenum ? `@bottom-right{content:counter(page) " / " counter(pages);font:9pt sans-serif;color:#666}` : '');
  const attrs = DOC_KEYS.filter(k => a[k] != null).map(k => ` data-${k}="${esc(a[k])}"`).join('');
  const f = document.createElement('iframe');
  f.setAttribute('aria-hidden', 'true');
  f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
  f.srcdoc = `<!DOCTYPE html><html lang="nl"><head><meta charset="utf-8"><title>${esc(title)}</title><link rel="stylesheet" href="${css}">
<style>@page{size:${ps.w}mm ${ps.h}mm;margin:${ps.margin}mm;${boxes}}
html,body{height:auto!important;min-height:0!important;display:block!important;overflow:visible!important;background:#fff!important;margin:0;padding:0}
.pdf-sheet{padding:0!important}</style></head>
<body><div class="book pdf-sheet ${esc(d.cls.replace(/\bpaper\b/g, ''))}"${attrs}>${d.inner}</div></body></html>`;
  f.onload = () => setTimeout(() => {
    try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) { window.print(); }
    setTimeout(() => f.remove(), 120000);
  }, 400);
  document.body.append(f);
}


// Word-bestand (.doc, HTML met Word-opmaak). De opmaak wordt per element vastgelegd zodat Word ze overneemt.
const WORD_PROPS = ['color', 'background-color', 'font-family', 'font-size', 'font-weight', 'font-style', 'text-decoration-line', 'text-align', 'line-height', 'text-transform', 'letter-spacing',
  'margin-top', 'margin-bottom', 'margin-left', 'margin-right', 'padding-top', 'padding-bottom', 'padding-left', 'padding-right',
  'border-top', 'border-bottom', 'border-left', 'border-right', 'list-style-type'];
export function exportWord(title, html) {
  const st = buildStage(html);
  try {
    [st.sheet, ...st.sheet.querySelectorAll('*')].forEach(el => {
      const cs = getComputedStyle(el); let css = '';
      WORD_PROPS.forEach(p => {
        const v = cs.getPropertyValue(p);
        if (!v || v === 'normal' && p !== 'font-weight' || v === 'none' || v === 'rgba(0, 0, 0, 0)' || /^0px( none.*)?$/.test(v) || /^0px none/.test(v)) return;
        if (/^border/.test(p) && (/^0px/.test(v) || /none/.test(v))) return;
        css += `${p}:${v};`;
      });
      if (el.tagName === 'IMG' && el.style.width) css += `width:${el.style.width};`;
      el.setAttribute('style', css + (el.tagName === 'IMG' ? 'max-width:100%;' : ''));
      el.removeAttribute('class');
    });
    const ps = st.ps, cm = n => (n / 10).toFixed(2) + 'cm';
    const doc = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>${esc(title)}</title>
<!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom></w:WordDocument></xml><![endif]-->
<style>@page Section1{size:${cm(ps.w)} ${cm(ps.h)};${ps.landscape ? 'mso-page-orientation:landscape;' : ''}margin:${cm(ps.margin)};}div.Section1{page:Section1}table{border-collapse:collapse}</style></head>
<body><div class="Section1">${st.sheet.outerHTML}</div></body></html>`;
    downloadBlob(new Blob(['\ufeff', doc], { type: 'application/msword' }), slugName(title) + '.doc');
  } finally { st.stage.remove(); }
}



/** Afdrukvoorbeeld voor PDF-boeken — met opties en echte afdruk. */
export async function openPdfPrintPreview(title, dataUrl, fileName) {
  const back = document.createElement('div');
  back.className = 'dlg-back print-preview-back';
  const box = document.createElement('div');
  box.className = 'dlg dlg-print';
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-label', 'PDF afdrukken');

  const headEl = document.createElement('div');
  headEl.className = 'print-preview-head';
  const h2 = document.createElement('h2');
  h2.textContent = 'PDF afdrukken';
  const close = document.createElement('button');
  close.type = 'button'; close.className = 'back'; close.textContent = '✕';
  close.setAttribute('aria-label', 'Sluiten');
  close.onclick = () => back.remove();
  headEl.append(h2, close);

  const layout = document.createElement('div');
  layout.className = 'print-preview-layout';
  const side = document.createElement('div');
  side.className = 'print-preview-side';

  const opts = {
    page: 'a4', orient: 'portrait', pages: 'all', range: '', scale: 'fit', margin: 'normaal', printer: ''
  };

  const mkSelect = (label, key, options) => {
    const wrap = document.createElement('label');
    wrap.className = 'print-field';
    wrap.append(document.createTextNode(label));
    const sel = document.createElement('select');
    options.forEach(([v, lab]) => {
      const o = document.createElement('option');
      o.value = v; o.textContent = lab;
      if (opts[key] === v) o.selected = true;
      sel.append(o);
    });
    sel.onchange = () => { opts[key] = sel.value; updateRangeVisibility(); };
    wrap.append(sel);
    side.append(wrap);
    return sel;
  };

  mkSelect('Papier', 'page', [['a4','A4'],['a5','A5'],['a3','A3'],['letter','Letter'],['legal','Legal']]);
  mkSelect('Stand', 'orient', [['portrait','Staand'],['landscape','Liggend']]);
  mkSelect('Marge', 'margin', [['geen','Geen'],['smal','Smal'],['normaal','Normaal'],['breed','Breed']]);
  mkSelect('Schaal', 'scale', [['fit','Passend op pagina'],['100','100% (origineel)']]);
  mkSelect('Pagina\'s', 'pages', [['all','Alle pagina\'s'],['range','Bereik…']]);

  const rangeWrap = document.createElement('label');
  rangeWrap.className = 'print-field';
  rangeWrap.hidden = true;
  rangeWrap.append(document.createTextNode('Bereik (bijv. 1-3,5)'));
  const rangeIn = document.createElement('input');
  rangeIn.type = 'text';
  rangeIn.placeholder = '1-2';
  rangeIn.oninput = () => { opts.range = rangeIn.value; };
  rangeWrap.append(rangeIn);
  side.append(rangeWrap);
  const updateRangeVisibility = () => { rangeWrap.hidden = opts.pages !== 'range'; };

  // Printerkeuze (desktop-app)
  const printerWrap = document.createElement('label');
  printerWrap.className = 'print-field';
  printerWrap.append(document.createTextNode('Printer'));
  const printerSel = document.createElement('select');
  const ph = document.createElement('option');
  ph.value = ''; ph.textContent = 'Printers laden…';
  printerSel.append(ph);
  printerWrap.append(printerSel);
  side.append(printerWrap);
  printerSel.onchange = () => { opts.printer = printerSel.value; };

  const status = document.createElement('p');
  status.className = 'print-status';
  status.textContent = 'PDF laden…';
  side.append(status);

  const actions = document.createElement('div');
  actions.className = 'print-actions';

  const btnPrint = document.createElement('button');
  btnPrint.type = 'button';
  btnPrint.className = 'dlg-ok';
  btnPrint.textContent = '🖨 Afdrukken';
  btnPrint.disabled = true;

  const btnDl = document.createElement('button');
  btnDl.type = 'button';
  btnDl.className = 'back';
  btnDl.textContent = '📄 PDF downloaden';
  btnDl.onclick = () => {
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = fileName || 'document.pdf';
    a.click();
    status.textContent = 'Download gestart';
  };

  const btnClose = document.createElement('button');
  btnClose.type = 'button';
  btnClose.className = 'back';
  btnClose.textContent = 'Sluiten';
  btnClose.onclick = () => back.remove();

  actions.append(btnPrint, btnDl, btnClose);
  side.append(actions);

  const pane = document.createElement('div');
  pane.className = 'print-preview-pane';
  const pagesHost = document.createElement('div');
  pagesHost.className = 'lc-pdf-print-pages';
  pane.append(pagesHost);
  layout.append(side, pane);
  box.append(headEl, layout);
  back.append(box);
  document.body.append(back);

  let pdfDoc = null;
  const inTauri = !!(window.__TAURI__ && window.__TAURI__.core && window.__TAURI__.core.invoke);

  const parseRange = (nPages) => {
    if (opts.pages === 'all' || !String(opts.range || '').trim()) {
      return Array.from({ length: nPages }, (_, i) => i + 1);
    }
    const set = new Set();
    opts.range.split(',').forEach(part => {
      part = part.trim();
      const m = /^(\d+)\s*-\s*(\d+)$/.exec(part);
      if (m) {
        let a = parseInt(m[1], 10), b = parseInt(m[2], 10);
        if (a > b) [a, b] = [b, a];
        for (let i = a; i <= b; i++) if (i >= 1 && i <= nPages) set.add(i);
      } else {
        const n = parseInt(part, 10);
        if (n >= 1 && n <= nPages) set.add(n);
      }
    });
    return [...set].sort((a, b) => a - b);
  };

  const renderPreview = async () => {
    if (!pdfDoc) return;
    const nums = parseRange(pdfDoc.numPages);
    pagesHost.replaceChildren();
    for (const num of nums) {
      const page = await pdfDoc.getPage(num);
      const viewport = page.getViewport({ scale: 1.15 });
      const canvas = document.createElement('canvas');
      canvas.className = 'lc-pdf-print-page';
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
      pagesHost.append(canvas);
    }
    status.textContent = `${pdfDoc.numPages} pagina's · ${nums.length} geselecteerd`;
  };

  side.querySelectorAll('select').forEach(sel => {
    if (sel === printerSel) return;
    sel.addEventListener('change', () => {
      if (pdfDoc) renderPreview().catch(e => { status.textContent = e.message; });
    });
  });
  rangeIn.addEventListener('change', () => {
    if (pdfDoc) renderPreview().catch(e => { status.textContent = e.message; });
  });

  /** Bouw PDF-bytes (base64) uit geselecteerde pagina's. */
  const buildPdfBase64 = async () => {
    const nums = parseRange(pdfDoc.numPages);
    if (!nums.length) throw new Error('Geen geldige pagina\'s');
    const ps = pageSize({ page: opts.page, orient: opts.orient, margin: opts.margin });
    const marginMm = ps.margin;
    const images = [];
    for (const num of nums) {
      const page = await pdfDoc.getPage(num);
      const base = page.getViewport({ scale: 1 });
      let scale;
      if (opts.scale === '100') scale = 2;
      else {
        const availW = (ps.w - 2 * marginMm) * 96 / 25.4;
        const availH = (ps.h - 2 * marginMm) * 96 / 25.4;
        scale = Math.min(availW / base.width, availH / base.height) * 1.5;
      }
      scale = Math.max(0.8, Math.min(3, scale));
      const viewport = page.getViewport({ scale });
      const canvas = document.createElement('canvas');
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
      images.push(canvas.toDataURL('image/jpeg', 0.93));
    }
    await loadLib('html2pdf.bundle.min.js');
    const JsPDF = (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
    if (!JsPDF) throw new Error('PDF-bibliotheek niet geladen');
    const orient = ps.landscape ? 'landscape' : 'portrait';
    const doc = new JsPDF({ unit: 'mm', format: ps.portrait, orientation: orient, compress: true });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const maxW = pageW - 2 * marginMm;
    const maxH = pageH - 2 * marginMm;
    images.forEach((src, i) => {
      if (i > 0) doc.addPage(ps.portrait, orient);
      const props = doc.getImageProperties(src);
      let w = props.width * 25.4 / 96, h = props.height * 25.4 / 96;
      const ratio = Math.min(maxW / w, maxH / h, 1);
      w *= ratio; h *= ratio;
      const x = marginMm + (maxW - w) / 2;
      const y = marginMm + (maxH - h) / 2;
      doc.addImage(src, 'JPEG', x, y, w, h);
    });
    const dataUri = doc.output('datauristring');
    const b64 = dataUri.split(',')[1] || '';
    return b64;
  };

  /** Base64 van de originele PDF (zonder data:-prefix). */
  const originalPdfBase64 = () => {
    const m = /^data:[^;]+;base64,(.+)$/i.exec(dataUrl || '');
    if (!m) throw new Error('Geen PDF-data om af te drukken');
    return m[1];
  };

  btnPrint.onclick = async () => {
    if (!pdfDoc) return;
    btnPrint.disabled = true;
    try {
      if (!inTauri) {
        status.textContent = 'Afdrukken met printerkeuze werkt alleen in de Leo Crucis-app (Tauri), niet in de browser.';
        btnPrint.disabled = false;
        return;
      }
      if (!opts.printer) {
        status.textContent = 'Kies eerst een printer in de lijst.';
        btnPrint.disabled = false;
        return;
      }
      status.textContent = 'Verzenden naar printer…';
      // Originele PDF naar de Windows-printer (geen jsPDF nodig, beste kwaliteit)
      const b64 = originalPdfBase64();
      const inv = window.__TAURI__.core.invoke;
      await inv('print_pdf', { pdfBase64: b64, printer: opts.printer });
      status.textContent = 'Afdruktaak verzonden naar "' + opts.printer + '".';
    } catch (e) {
      status.textContent = 'Afdrukken mislukt: ' + (e.message || e);
      console.error(e);
    }
    btnPrint.disabled = false;
  };

  back.addEventListener('keydown', e => { if (e.key === 'Escape') back.remove(); });

  // Printers laden
  (async () => {
    if (!inTauri) {
      printerSel.replaceChildren();
      const o = document.createElement('option');
      o.value = ''; o.textContent = '(Alleen in de desktop-app)';
      printerSel.append(o);
      status.textContent = 'Tip: start via "npm run tauri dev" voor echte printers.';
      return;
    }
    try {
      const inv = window.__TAURI__.core.invoke;
      const list = await inv('list_printers');
      printerSel.replaceChildren();
      if (!list || !list.length) {
        const o = document.createElement('option');
        o.value = ''; o.textContent = 'Geen printers gevonden';
        printerSel.append(o);
      } else {
        list.forEach((name, i) => {
          const o = document.createElement('option');
          o.value = name; o.textContent = name;
          if (i === 0) { o.selected = true; opts.printer = name; }
          printerSel.append(o);
        });
      }
    } catch (e) {
      printerSel.replaceChildren();
      const o = document.createElement('option');
      o.value = ''; o.textContent = 'Kon printers niet laden';
      printerSel.append(o);
      console.error(e);
    }
  })();

  try {
    const lib = await import(new URL('vendor/pdf.min.mjs', import.meta.url).href);
    lib.GlobalWorkerOptions.workerSrc = new URL('vendor/pdf.worker.min.mjs', import.meta.url).href;
    const m = /^data:([^;]+);base64,(.+)$/i.exec(dataUrl || '');
    if (!m) throw new Error('Geen PDF-data');
    const bin = atob(m[2]);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    pdfDoc = await lib.getDocument({ data: arr }).promise;
    btnPrint.disabled = false;
    await renderPreview();
    btnPrint.focus();
  } catch (e) {
    status.textContent = 'Fout: ' + (e.message || e);
    console.error(e);
  }
}
