/**
 * ui/focus-study.js — studieblok-timer, formatters en Focus-UI
 *
 * Kernlogica (studyBlock) + fmtDuration/fmtClock + showFocus-view.
 * Presence-tracking en session-persist blijven voorlopig in app.js
 * (zwaar gekoppeld aan edit.js / loadSessions).
 *
 * Gebruik:
 *   import { createFocusStudyApi, fmtDuration, fmtClock } from './ui/focus-study.js';
 *   const focus = createFocusStudyApi({ el, $, loadSettings, saveSettings, ask, ... });
 *   // focus.showFocus()  focus.startStudyBlock(25)  focus.studyBlock
 */

import { el } from '../core/dom.js';

export function fmtDuration(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  if (s < 60) return s + 's';
  const m = Math.floor(s / 60);
  const r = s % 60;
  if (m < 60) return r ? m + 'm ' + r + 's' : m + 'm';
  const h = Math.floor(m / 60);
  return (m % 60) ? h + 'u ' + (m % 60) + 'm' : h + 'u';
}

export function fmtClock(ms) {
  const s = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m + ':' + String(r).padStart(2, '0');
}

/**
 * @param {object} deps
 * @param {Function} deps.$                    — document query helper
 * @param {Function} deps.loadSettings
 * @param {Function} deps.saveSettings
 * @param {Function} deps.ask                  — confirm dialog
 * @param {Function} deps.canOpenNewRecent
 * @param {Function} deps.pushRecentApp
 * @param {Function} deps.removeRecentApp
 * @param {Function} deps.showHome
 * @param {HTMLElement} deps.viewContent
 * @param {HTMLElement} [deps.home]
 * @param {HTMLElement} [deps.view]
 * @param {Function} [deps.setHash]
 * @param {Function} [deps.periodStudySummary]
 * @param {Function} [deps.weekStudySummary]
 * @param {Function} [deps.recordStudyBlock]
 * @param {Function} [deps.evaluateAchievements]
 * @param {Function} [deps.persistCurrentSession]
 * @param {Function} [deps.setupPresenceTracking]
 * @param {Function} [deps.applyFocusBlockLock]
 * @param {Function} [deps.updatePresenceBadge]
 * @param {(v: string|null) => void} [deps.setCurrentSection]
 * @param {Function} [deps.isPageVisible]      — override visibility check
 */
export function createFocusStudyApi(deps) {
  const {
    $,
    loadSettings,
    saveSettings,
    ask,
    canOpenNewRecent,
    pushRecentApp,
    removeRecentApp,
    showHome,
    viewContent,
    home,
    view,
    setHash = (h) => { try { location.hash = h; } catch (_) {} },
    periodStudySummary,
    weekStudySummary,
    recordStudyBlock,
    evaluateAchievements,
    persistCurrentSession,
    setupPresenceTracking,
    applyFocusBlockLock,
    updatePresenceBadge,
    setCurrentSection = () => {},
    isPageVisible = () => document.visibilityState === 'visible' && document.hasFocus()
  } = deps;

  const studyBlock = {
    active: false,
    targetMs: 0,
    remainingMs: 0,
    focusedMs: 0,
    lastTick: 0,
    paused: false,
    timerId: null
  };

  function updateStudyUI() {
    const btn = typeof $ === 'function' ? $('#btn-study') : null;
    if (btn) {
      btn.classList.toggle('is-timing', !!studyBlock.active);
      btn.classList.toggle('is-paused', !!(studyBlock.active && studyBlock.paused));
    }
    document.body.classList.toggle('study-active', !!studyBlock.active);
    if (typeof applyFocusBlockLock === 'function') applyFocusBlockLock();
    if (typeof updatePresenceBadge === 'function') updatePresenceBadge();
  }

  function studyTick() {
    if (!studyBlock.active) return;
    const now = Date.now();
    const present = isPageVisible();
    if (present && !studyBlock.paused) {
      const delta = now - studyBlock.lastTick;
      studyBlock.remainingMs -= delta;
      studyBlock.focusedMs += delta;
      if (studyBlock.remainingMs <= 0) {
        studyBlock.remainingMs = 0;
        completeStudyBlock();
        return;
      }
    } else if (!present) {
      studyBlock.paused = true;
    }
    if (present) studyBlock.paused = false;
    studyBlock.lastTick = now;
    updateStudyUI();
  }

  async function startStudyBlock(minutes) {
    if (studyBlock.active) return;
    const st = loadSettings();
    const min = minutes || st.studyBlockMin || 25;
    studyBlock.active = true;
    studyBlock.targetMs = min * 60 * 1000;
    studyBlock.remainingMs = studyBlock.targetMs;
    studyBlock.focusedMs = 0;
    studyBlock.lastTick = Date.now();
    studyBlock.paused = false;
    if (studyBlock.timerId) clearInterval(studyBlock.timerId);
    studyBlock.timerId = setInterval(studyTick, 250);
    updateStudyUI();
    if (st.trackPresence === false) {
      st.trackPresence = true;
      saveSettings(st);
      if (typeof setupPresenceTracking === 'function') setupPresenceTracking(st);
    }
    if (typeof persistCurrentSession === 'function') persistCurrentSession(true);
  }

  async function stopStudyBlock() {
    if (!studyBlock.active) return;
    const done = studyBlock.focusedMs;
    const target = studyBlock.targetMs;
    if (done >= target * 0.85) {
      const choice = await ask(
        `Je had ${fmtDuration(done)} van de ${fmtDuration(target)}.\n\nAls voltooid tellen?`,
        { yes: 'Voltooien', no: 'Toch stoppen' }
      );
      if (choice) {
        completeStudyBlock();
        return;
      }
    } else {
      const ok = await ask(
        `Studieblok stoppen?\n\n${fmtDuration(done)} echte focustijd van ${fmtDuration(target)}.`,
        { yes: 'Stoppen', no: 'Doorgaan' }
      );
      if (!ok) return;
    }
    if (studyBlock.timerId) clearInterval(studyBlock.timerId);
    studyBlock.active = false;
    studyBlock.timerId = null;
    updateStudyUI();
    if (typeof persistCurrentSession === 'function') persistCurrentSession(true);
  }

  async function completeStudyBlock() {
    if (!studyBlock.active) return;
    const done = studyBlock.focusedMs;
    const target = studyBlock.targetMs;
    if (studyBlock.timerId) clearInterval(studyBlock.timerId);
    studyBlock.active = false;
    studyBlock.timerId = null;
    updateStudyUI();
    if (typeof recordStudyBlock === 'function') {
      try { await recordStudyBlock({ focusedMs: done, targetMs: target }); } catch (e) { console.warn(e); }
    }
    if (typeof evaluateAchievements === 'function') {
      try { evaluateAchievements(); } catch (_) {}
    }
    if (typeof persistCurrentSession === 'function') persistCurrentSession(true);
    try {
      await ask(
        `Blok voltooid!\n\n${fmtDuration(done)} focustijd.`,
        { yes: 'OK', no: null }
      );
    } catch (_) {}
  }

  /** Taartdiagram focus vs niet-focus (CSS conic-gradient). */
  function makePieChart(focusMs, awayMs, caption) {
    const wrap = el('div', 'focus-pie');
    const tot = Math.max(1, (focusMs || 0) + (awayMs || 0));
    const pct = Math.round(((focusMs || 0) / tot) * 100);
    const chart = el('div', 'focus-pie-chart');
    chart.style.background = `conic-gradient(var(--acc) 0% ${pct}%, var(--line) ${pct}% 100%)`;
    chart.setAttribute('aria-label', `${pct} procent focus`);
    const legend = el('div', 'focus-pie-legend');
    legend.append(
      el('div', 'focus-pie-cap', caption || ''),
      el('div', 'focus-pie-pct', pct + '%'),
      el('div', 'focus-pie-row', `● Focus ${fmtDuration(focusMs || 0)}`),
      el('div', 'focus-pie-row is-mute', `● Weg ${fmtDuration(awayMs || 0)}`)
    );
    wrap.append(chart, legend);
    return wrap;
  }

  /** Studie-menu: compact dashboard. */
  function showFocus() {
    if (typeof canOpenNewRecent === 'function' && !canOpenNewRecent('app-focus')) return;
    setCurrentSection(null);
    document.body.classList.remove('pdf-open');
    document.body.classList.add('browser-open');
    viewContent.replaceChildren();

    const head = el('div', 'view-head settings-head');
    const back = el('button', 'back', '← Terug');
    back.type = 'button';
    back.onclick = showHome;
    head.append(back, el('h1', '', 'Focusblok'));
    viewContent.append(head);

    let st = loadSettings();
    const panel = el('div', 'settings-page focus-page focus-simple');

    const card = el('div', 'settings-card');
    card.append(el('h2', 'focus-card-h', 'Focusblok'));
    const status = el('div', 'focus-block-status');

    const refresh = () => {
      status.replaceChildren();
      if (studyBlock.active) {
        status.append(
          el('p', 'focus-big-timer', fmtClock(studyBlock.remainingMs)),
          el('p', 'settings-hint', studyBlock.paused
            ? 'Gepauzeerd — kom terug in de app om verder te tellen.'
            : 'Bezig · ' + fmtDuration(studyBlock.focusedMs) + ' gefocust')
        );
        const stopBtn = el('button', 'focus-primary-btn focus-stop-btn', 'Blok stoppen');
        stopBtn.type = 'button';
        stopBtn.onclick = async () => {
          await stopStudyBlock();
          refresh();
        };
        status.append(stopBtn);
      } else {
        status.append(el('p', 'settings-hint',
          'Kies een duur. Tijd telt alleen terwijl je in de app bent. Tijdens een blok: geen games of video — muziek mag wel.'));
        const row = el('div', 'settings-choice focus-start-row');
        [[15, '15 min'], [25, '25 min'], [45, '45 min'], [60, '60 min']].forEach(([min, label]) => {
          const b = el('button', min === (st.studyBlockMin || 25) ? 'active' : '', label);
          b.type = 'button';
          b.onclick = async () => {
            st.studyBlockMin = min;
            saveSettings(st);
            await startStudyBlock(min);
            refresh();
          };
          row.append(b);
        });
        status.append(row);
      }
    };
    refresh();
    const timer = setInterval(() => {
      if (!document.body.contains(status)) { clearInterval(timer); return; }
      if (studyBlock.active) refresh();
    }, 500);
    card.append(status);

    // Korte stats
    try {
      if (typeof periodStudySummary === 'function') {
        const sum = periodStudySummary('week');
        const stats = el('div', 'focus-simple-stats');
        stats.append(
          el('div', 'focus-simple-stat', (sum.streak || 0) + ' dagen streak'),
          el('div', 'focus-simple-stat', (sum.blocks || 0) + ' blokken deze week'),
          el('div', 'focus-simple-stat', fmtDuration(sum.focusedMs || 0) + ' focustijd')
        );
        card.append(stats);
      }
    } catch (_) {}

    panel.append(card);
    viewContent.append(panel);

    if (home) home.style.display = 'none';
    if (view) view.style.display = 'block';
    setHash('#focus');

    pushRecentApp({
      id: 'app-focus',
      kind: 'focus',
      iconKind: 'focus',
      title: 'Focus / Studie',
      hint: 'App',
      activate: () => showFocus(),
      close: () => {
        try { removeRecentApp('app-focus'); } catch (_) {}
        try { showHome(); } catch (_) {}
      }
    });
  }

  return {
    studyBlock,
    fmtDuration,
    fmtClock,
    updateStudyUI,
    startStudyBlock,
    stopStudyBlock,
    completeStudyBlock,
    showFocus,
    makePieChart
  };
}
