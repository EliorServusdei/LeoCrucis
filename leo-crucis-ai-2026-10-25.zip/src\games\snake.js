// Slang — zelfstandige mini-app.
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}


function injectGameBaseStyles() {
  if (document.getElementById('lc-game-base-styles')) return;
  const s = document.createElement('style');
  s.id = 'lc-game-base-styles';
  s.textContent = `
.app-panel.games-app{
  display:flex;flex-direction:column;gap:0;min-height:0;height:100%;
  background:var(--bg);color:var(--ink);
  font-family:"Courier New",Courier,ui-monospace,monospace;
  position:relative;overflow:auto;
  padding:12px;box-sizing:border-box;
}
.games-app .game-status{
  font-weight:800;font-size:13px;letter-spacing:.1em;text-transform:uppercase;
  color:var(--acc);text-align:center;padding:10px 12px 4px;
  text-shadow:0 0 8px rgba(155,188,15,.3);
}
.games-app .game-hint{
  margin:0;font-size:11px;color:var(--mute);opacity:.65;text-align:center;
  letter-spacing:.06em;padding:0 12px 8px;
}
.games-app .game-reset{
  border:2px solid var(--line);background:var(--panel);color:var(--acc);
  border-radius:4px;padding:8px 16px;cursor:pointer;font:inherit;
  font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
  align-self:center;margin-top:8px;
}
.games-app .game-reset:hover{border-color:var(--acc);background:var(--sel);color:var(--acc2);}
.games-app .ttt-board{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:240px;margin:12px auto;width:100%;}
.games-app .ttt-cell{
  aspect-ratio:1;border:1px solid var(--line);border-radius:4px;
  background:var(--panel);color:var(--acc);font-weight:800;font-size:1.6rem;
  cursor:pointer;font-family:inherit;
}
.games-app .ttt-cell:hover:not(:disabled){
  border-color:var(--acc);background:var(--sel);
  box-shadow:0 0 10px rgba(155,188,15,.2);
}
.games-app .ttt-cell:disabled{cursor:default;opacity:.9;}
.games-app .snake-canvas{
  border:1px solid var(--line);border-radius:4px;
  box-shadow:0 0 12px rgba(155,188,15,.15);
  margin:0 auto;display:block;
}
`;
  document.head.append(s);
}

function snakeGame(host) {
  host.replaceChildren();
  const W = 16, H = 12, CELL = 22;
  const canvas = document.createElement('canvas');
  canvas.width = W * CELL;
  canvas.height = H * CELL;
  canvas.className = 'snake-canvas';
  const status = el('div', 'game-status', 'Pijltjes of WASD · spatie = pauze');
  const hint = el('p', 'game-hint', 'Klik op het speelveld om te starten');
  host.append(status, canvas, hint);

  let snake = [{ x: 4, y: 6 }, { x: 3, y: 6 }];
  let dir = { x: 1, y: 0 };
  let nextDir = { ...dir };
  let food = { x: 10, y: 6 };
  let score = 0;
  let alive = true;
  let paused = true;
  let timer = null;

  function placeFood() {
    const taken = new Set(snake.map(p => p.x + ',' + p.y));
    let x, y;
    do {
      x = Math.floor(Math.random() * W);
      y = Math.floor(Math.random() * H);
    } while (taken.has(x + ',' + y));
    food = { x, y };
  }

  function draw() {
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--panel').trim() || '#1a1814';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = 'rgba(128,128,128,.15)';
    for (let x = 0; x <= W; x++) { ctx.beginPath(); ctx.moveTo(x * CELL, 0); ctx.lineTo(x * CELL, H * CELL); ctx.stroke(); }
    for (let y = 0; y <= H; y++) { ctx.beginPath(); ctx.moveTo(0, y * CELL); ctx.lineTo(W * CELL, y * CELL); ctx.stroke(); }
    ctx.fillStyle = '#c45c4a';
    ctx.fillRect(food.x * CELL + 3, food.y * CELL + 3, CELL - 6, CELL - 6);
    snake.forEach((p, i) => {
      ctx.fillStyle = i === 0 ? '#7a1f2b' : '#a33';
      ctx.fillRect(p.x * CELL + 2, p.y * CELL + 2, CELL - 4, CELL - 4);
    });
  }

  function tick() {
    if (!alive || paused) return;
    dir = { ...nextDir };
    const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
    if (head.x < 0 || head.y < 0 || head.x >= W || head.y >= H || snake.some(p => p.x === head.x && p.y === head.y)) {
      alive = false;
      status.textContent = 'Game over · score ' + score + ' · klik om opnieuw';
      clearInterval(timer); timer = null;
      draw();
      return;
    }
    snake.unshift(head);
    if (head.x === food.x && head.y === food.y) {
      score++;
      status.textContent = 'Score: ' + score;
      placeFood();
    } else snake.pop();
    draw();
  }

  function start() {
    snake = [{ x: 4, y: 6 }, { x: 3, y: 6 }];
    dir = { x: 1, y: 0 }; nextDir = { ...dir };
    score = 0; alive = true; paused = false;
    placeFood();
    status.textContent = 'Score: 0';
    if (timer) clearInterval(timer);
    timer = setInterval(tick, 140);
    draw();
  }

  canvas.tabIndex = 0;
  canvas.onclick = () => {
    canvas.focus();
    if (!alive || paused) start();
  };
  const onKey = e => {
    if (!host.isConnected) { document.removeEventListener('keydown', onKey); return; }
    const k = e.key.toLowerCase();
    if (k === ' ' || k === 'spacebar') { e.preventDefault(); paused = !paused; status.textContent = paused ? 'Pauze' : 'Score: ' + score; return; }
    const map = { arrowup: [0, -1], arrowdown: [0, 1], arrowleft: [-1, 0], arrowright: [1, 0], w: [0, -1], s: [0, 1], a: [-1, 0], d: [1, 0] };
    if (map[k]) {
      e.preventDefault();
      const [x, y] = map[k];
      if (x === -dir.x && y === -dir.y) return;
      nextDir = { x, y };
      if (paused && alive) { paused = false; status.textContent = 'Score: ' + score; }
    }
  };
  document.addEventListener('keydown', onKey);
  draw();
}


export function createSnakeApp() {
  injectGameBaseStyles();
  const root = document.createElement('div');
  root.className = 'app-panel games-app';
  snakeGame(root);
  return { root };
}
