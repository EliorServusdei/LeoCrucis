// 4 op een rij — zelfstandige mini-app.
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}


function injectGameBaseStyles() {
  if (document.getElementById('lc-game-base-styles')) return;
  const s = document.createElement('style');
  s.id = 'lc-game-base-styles';
  s.textContent = `
.app-panel.games-app{
  display:flex;flex-direction:column;gap:0;min-height:0;height:100%;
  background:var(--bg);color:var(--ink);
  font-family:"Courier New",Courier,ui-monospace,monospace;
  position:relative;overflow:auto;
  padding:12px;box-sizing:border-box;
}
.games-app .game-status{
  font-weight:800;font-size:13px;letter-spacing:.1em;text-transform:uppercase;
  color:var(--acc);text-align:center;padding:10px 12px 4px;
  text-shadow:0 0 8px rgba(155,188,15,.3);
}
.games-app .game-hint{
  margin:0;font-size:11px;color:var(--mute);opacity:.65;text-align:center;
  letter-spacing:.06em;padding:0 12px 8px;
}
.games-app .game-reset{
  border:2px solid var(--line);background:var(--panel);color:var(--acc);
  border-radius:4px;padding:8px 16px;cursor:pointer;font:inherit;
  font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
  align-self:center;margin-top:8px;
}
.games-app .game-reset:hover{border-color:var(--acc);background:var(--sel);color:var(--acc2);}
.games-app .ttt-board{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:240px;margin:12px auto;width:100%;}
.games-app .ttt-cell{
  aspect-ratio:1;border:1px solid var(--line);border-radius:4px;
  background:var(--panel);color:var(--acc);font-weight:800;font-size:1.6rem;
  cursor:pointer;font-family:inherit;
}
.games-app .ttt-cell:hover:not(:disabled){
  border-color:var(--acc);background:var(--sel);
  box-shadow:0 0 10px rgba(155,188,15,.2);
}
.games-app .ttt-cell:disabled{cursor:default;opacity:.9;}
.games-app .snake-canvas{
  border:1px solid var(--line);border-radius:4px;
  box-shadow:0 0 12px rgba(155,188,15,.15);
  margin:0 auto;display:block;
}
`;
  document.head.append(s);
}

// ---------- 4 op een rij ----------
function c4InjectStyles() {
  if (document.getElementById('c4-styles')) return;
  const s = document.createElement('style');
  s.id = 'c4-styles';
  s.textContent = `
.c4-app{
  display:flex;flex-direction:column;align-items:center;gap:10px;
  width:100%;height:100%;min-height:0;box-sizing:border-box;
  padding:8px 12px 16px;overflow:auto;
}
.c4-toolbar{
  display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:center;
  width:100%;max-width:420px;
}
.c4-mode{
  display:flex;gap:4px;border:1px solid var(--line);border-radius:4px;padding:2px;background:var(--panel);
}
.c4-mode button{
  border:none;background:transparent;color:var(--mute);font:inherit;font-size:11px;
  font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:6px 10px;
  border-radius:3px;cursor:pointer;
}
.c4-mode button.active{
  background:var(--acc);color:var(--bg);
}
.c4-board-wrap{
  position:relative;padding:10px;border-radius:8px;
  background:linear-gradient(180deg,#1a3a6e 0%,#0d2244 100%);
  border:2px solid #2a5a9e;
  box-shadow:0 0 18px rgba(42,90,158,.35), inset 0 0 20px rgba(0,0,0,.35);
}
.c4-cols{
  display:grid;grid-template-columns:repeat(7,1fr);gap:6px;
}
.c4-col{
  display:flex;flex-direction:column;gap:6px;cursor:pointer;
  border:none;background:transparent;padding:0;min-width:0;
}
.c4-col:hover:not(:disabled) .c4-cell.empty{
  box-shadow:inset 0 0 0 2px rgba(255,255,255,.25);
}
.c4-col:disabled{cursor:default;}
.c4-cell{
  width:clamp(28px,8vw,42px);aspect-ratio:1;border-radius:50%;
  background:#0a1628;border:1px solid rgba(0,0,0,.45);
  box-shadow:inset 0 2px 6px rgba(0,0,0,.55);
  transition:background .15s ease, box-shadow .15s ease, transform .12s ease;
}
.c4-cell.red{
  background:radial-gradient(circle at 35% 30%,#ff8a7a,#c62828 55%,#7a1212);
  box-shadow:0 0 10px rgba(198,40,40,.45), inset 0 2px 4px rgba(255,255,255,.25);
}
.c4-cell.yellow{
  background:radial-gradient(circle at 35% 30%,#ffe082,#f9a825 55%,#a66b00);
  box-shadow:0 0 10px rgba(249,168,37,.45), inset 0 2px 4px rgba(255,255,255,.3);
}
.c4-cell.win{
  animation:c4-pulse .7s ease-in-out infinite alternate;
}
@keyframes c4-pulse{
  from{transform:scale(1);filter:brightness(1);}
  to{transform:scale(1.08);filter:brightness(1.25);}
}
.c4-cell.drop{
  animation:c4-drop .28s cubic-bezier(.2,.8,.3,1);
}
@keyframes c4-drop{
  from{transform:translateY(-120%);opacity:.4;}
  to{transform:translateY(0);opacity:1;}
}
.c4-legend{
  display:flex;gap:16px;align-items:center;justify-content:center;
  font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
  color:var(--mute);
}
.c4-dot{
  display:inline-block;width:12px;height:12px;border-radius:50%;margin-right:6px;
  vertical-align:middle;
}
.c4-dot.red{background:#c62828;box-shadow:0 0 6px rgba(198,40,40,.5);}
.c4-dot.yellow{background:#f9a825;box-shadow:0 0 6px rgba(249,168,37,.5);}
.c4-legend .active-turn{color:var(--acc);text-shadow:0 0 8px rgba(155,188,15,.35);}
`;
  document.head.append(s);
}

function connectFourGame(host) {
  host.replaceChildren();
  c4InjectStyles();

  const ROWS = 6, COLS = 7;
  /** @type {(0|1|2)[][]} 0 leeg, 1 rood, 2 geel */
  let board = Array.from({ length: ROWS }, () => Array(COLS).fill(0));
  let turn = 1; // 1 = rood, 2 = geel
  let over = false;
  /** @type {number[][]|null} */
  let winCells = null;
  let mode = 'pvp'; // 'pvp' | 'ai'
  let thinking = false;

  const root = el('div', 'c4-app');
  const status = el('div', 'game-status', 'Rood mag beginnen');
  const toolbar = el('div', 'c4-toolbar');
  const modeBox = el('div', 'c4-mode');
  const btnPvp = el('button', 'active', '2 spelers');
  btnPvp.type = 'button';
  const btnAi = el('button', '', 'vs computer');
  btnAi.type = 'button';
  modeBox.append(btnPvp, btnAi);
  const reset = el('button', 'game-reset', 'Opnieuw');
  reset.type = 'button';
  toolbar.append(modeBox, reset);

  const legend = el('div', 'c4-legend');
  const wrap = el('div', 'c4-board-wrap');
  const colsEl = el('div', 'c4-cols');
  wrap.append(colsEl);

  root.append(status, toolbar, legend, wrap);
  host.append(root);

  function setMode(m) {
    mode = m;
    btnPvp.classList.toggle('active', m === 'pvp');
    btnAi.classList.toggle('active', m === 'ai');
    newGame();
  }
  btnPvp.onclick = () => setMode('pvp');
  btnAi.onclick = () => setMode('ai');
  reset.onclick = () => newGame();

  function newGame() {
    board = Array.from({ length: ROWS }, () => Array(COLS).fill(0));
    turn = 1;
    over = false;
    winCells = null;
    thinking = false;
    status.textContent = mode === 'ai' ? 'Jij bent rood — jouw beurt' : 'Rood mag beginnen';
    render();
  }

  function cellKey(r, c) { return r + ',' + c; }

  function checkWin(b, player) {
    const dirs = [[0,1],[1,0],[1,1],[1,-1]];
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        if (b[r][c] !== player) continue;
        for (const [dr, dc] of dirs) {
          const cells = [[r, c]];
          let ok = true;
          for (let k = 1; k < 4; k++) {
            const nr = r + dr * k, nc = c + dc * k;
            if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS || b[nr][nc] !== player) {
              ok = false; break;
            }
            cells.push([nr, nc]);
          }
          if (ok) return cells;
        }
      }
    }
    return null;
  }

  function isFull(b) {
    return b[0].every(v => v !== 0);
  }

  function dropRow(b, col) {
    for (let r = ROWS - 1; r >= 0; r--) {
      if (b[r][col] === 0) return r;
    }
    return -1;
  }

  function validCols(b) {
    const out = [];
    for (let c = 0; c < COLS; c++) if (dropRow(b, c) >= 0) out.push(c);
    return out;
  }

  /** Eenvoudige AI: winst pakken, blokkeren, anders centrum prefereren. */
  function aiPick() {
    const me = 2, opp = 1;
    const cols = validCols(board);
    if (!cols.length) return -1;

    // Directe winst
    for (const c of cols) {
      const r = dropRow(board, c);
      board[r][c] = me;
      const w = checkWin(board, me);
      board[r][c] = 0;
      if (w) return c;
    }
    // Blokkeer tegenstander
    for (const c of cols) {
      const r = dropRow(board, c);
      board[r][c] = opp;
      const w = checkWin(board, opp);
      board[r][c] = 0;
      if (w) return c;
    }
    // Centreer + licht random
    const order = [3, 2, 4, 1, 5, 0, 6].filter(c => cols.includes(c));
    // Voorkeur voor zetten die 3-op-rij dreigen
    let best = order[0], bestScore = -1;
    for (const c of order) {
      const r = dropRow(board, c);
      board[r][c] = me;
      let score = (3 - Math.abs(c - 3)) * 2;
      // Tel open lijnen van lengte 2+
      const dirs = [[0,1],[1,0],[1,1],[1,-1]];
      for (const [dr, dc] of dirs) {
        let count = 1, open = 0;
        for (const sign of [1, -1]) {
          for (let k = 1; k < 4; k++) {
            const nr = r + dr * k * sign, nc = c + dc * k * sign;
            if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) break;
            if (board[nr][nc] === me) count++;
            else if (board[nr][nc] === 0) { open++; break; }
            else break;
          }
        }
        if (count >= 3 && open) score += 8;
        else if (count >= 2 && open) score += 3;
      }
      board[r][c] = 0;
      if (score > bestScore) { bestScore = score; best = c; }
    }
    return best;
  }

  function playCol(col) {
    if (over || thinking) return;
    const row = dropRow(board, col);
    if (row < 0) return;
    board[row][col] = turn;
    const lastDrop = [row, col];

    const w = checkWin(board, turn);
    if (w) {
      over = true;
      winCells = w;
      const name = turn === 1 ? 'Rood' : 'Geel';
      status.textContent = name + ' wint!';
      render(lastDrop);
      return;
    }
    if (isFull(board)) {
      over = true;
      status.textContent = 'Gelijkspel';
      render(lastDrop);
      return;
    }
    turn = turn === 1 ? 2 : 1;
    if (mode === 'ai') {
      status.textContent = turn === 1 ? 'Jouw beurt (rood)' : 'Computer denkt…';
    } else {
      status.textContent = (turn === 1 ? 'Rood' : 'Geel') + ' is aan de beurt';
    }
    render(lastDrop);

    if (mode === 'ai' && turn === 2 && !over) {
      thinking = true;
      setTimeout(() => {
        thinking = false;
        if (over) return;
        const c = aiPick();
        if (c >= 0) playCol(c);
      }, 380);
    }
  }

  function render(lastDrop) {
    const winSet = new Set((winCells || []).map(([r, c]) => cellKey(r, c)));
    legend.replaceChildren();
    const l1 = el('span', turn === 1 && !over ? 'active-turn' : '');
    l1.append(Object.assign(el('span', 'c4-dot red'), {}), document.createTextNode('Rood'));
    const l2 = el('span', turn === 2 && !over ? 'active-turn' : '');
    l2.append(Object.assign(el('span', 'c4-dot yellow'), {}), document.createTextNode(mode === 'ai' ? 'Computer' : 'Geel'));
    legend.append(l1, l2);

    colsEl.replaceChildren();
    for (let c = 0; c < COLS; c++) {
      const colBtn = el('button', 'c4-col');
      colBtn.type = 'button';
      colBtn.disabled = over || thinking || dropRow(board, c) < 0;
      colBtn.setAttribute('aria-label', 'Kolom ' + (c + 1));
      colBtn.onclick = () => playCol(c);
      for (let r = 0; r < ROWS; r++) {
        const v = board[r][c];
        let cls = 'c4-cell';
        if (v === 0) cls += ' empty';
        else if (v === 1) cls += ' red';
        else cls += ' yellow';
        if (winSet.has(cellKey(r, c))) cls += ' win';
        if (lastDrop && lastDrop[0] === r && lastDrop[1] === c) cls += ' drop';
        colBtn.append(el('div', cls));
      }
      colsEl.append(colBtn);
    }
  }

  newGame();
}

/** Speeltoestel (console) inbedden in de manager-stage. */

export function createConnect4App() {
  injectGameBaseStyles();
  const root = document.createElement('div');
  root.className = 'app-panel games-app';
  connectFourGame(root);
  return { root };
}
