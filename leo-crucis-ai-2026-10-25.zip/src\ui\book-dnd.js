/**
 * ui/book-dnd.js — slepen van boekruggen + kleurkiezer (fase 1)
 *
 * Pointer-gebaseerd slepen (betrouwbaarder dan HTML5 DnD op gedraaide ruggen).
 * Werkt alleen in editor-modus (dev).
 */

import { el } from '../core/dom.js';

/**
 * @param {object} deps
 * @param {() => boolean} [deps.getDev] — standaard true
 * @param {(item: object, idx?: number) => number} deps.colorOf
 * @param {(itemId: string) => { items: object[], index: number }|null} deps.findItemLoc
 * @param {(room: object) => object[]} deps.ensureShelves
 * @param {() => void|Promise<void>} deps.persist
 * @param {() => void} deps.renderWorld
 */
export function createBookDndApi(deps) {
  const {
    getDev = () => true,
    colorOf,
    findItemLoc,
    ensureShelves,
    persist,
    renderWorld,
  } = deps;

  const dropHandlers = new WeakMap();
  const DND = {
    id: null,
    sourceEl: null,
    ghost: null,
    active: false,
    didDrag: false,
    pending: null, // { el, item, x, y, pointerId }
    over: null,
    clear() {
      if (DND.ghost) { DND.ghost.remove(); DND.ghost = null; }
      if (DND.sourceEl) DND.sourceEl.classList.remove('dragging');
      document.body.classList.remove('dragging-book');
      document.querySelectorAll('.drag-over').forEach(e => e.classList.remove('drag-over'));
      DND.id = null;
      DND.sourceEl = null;
      DND.active = false;
      DND.pending = null;
      DND.over = null;
    }
  };

  /** Kleurenkiezer bij een boekrug (editor-modus). */
  function openSpineColorPicker(item, anchor, fallbackIdx) {
    document.querySelectorAll('.spine-color-pop').forEach(n => n.remove());
    const pop = el('div', 'spine-color-pop');
    const cur = colorOf(item, fallbackIdx);
    for (let i = 0; i < 10; i++) {
      const sw = el('button', 'spine-swatch c' + i + (i === cur ? ' active' : ''));
      sw.type = 'button';
      sw.title = 'Kleur ' + (i + 1);
      sw.setAttribute('aria-label', 'Kleur ' + (i + 1));
      sw.onclick = e => {
        e.preventDefault();
        e.stopPropagation();
        item.color = i;
        persist();
        pop.remove();
        renderWorld();
      };
      pop.append(sw);
    }
    document.body.appendChild(pop);
    const ar = anchor.getBoundingClientRect();
    const pr = pop.getBoundingClientRect();
    let left = ar.left + ar.width / 2 - pr.width / 2;
    let top = ar.top - pr.height - 8;
    if (top < 8) top = ar.bottom + 8;
    if (left < 8) left = 8;
    if (left + pr.width > window.innerWidth - 8) left = window.innerWidth - pr.width - 8;
    pop.style.left = left + 'px';
    pop.style.top = top + 'px';
    const close = ev => {
      if (pop.contains(ev.target) || anchor.contains(ev.target)) return;
      pop.remove();
      document.removeEventListener('pointerdown', close, true);
    };
    setTimeout(() => document.addEventListener('pointerdown', close, true), 0);
  }

  /** Verplaats een boek naar een andere kamer/plank/index. */
  function moveBook(itemId, targetRoom, targetShelf, targetIndex) {
    const loc = findItemLoc(itemId);
    if (!loc) return false;
    const [item] = loc.items.splice(loc.index, 1);
    let destItems;
    if (targetShelf) {
      if (!targetShelf.items) targetShelf.items = [];
      destItems = targetShelf.items;
    } else {
      ensureShelves(targetRoom);
      if (!targetRoom.shelves.length) targetRoom.shelves.push({ label: null, items: [] });
      destItems = targetRoom.shelves[0].items || (targetRoom.shelves[0].items = []);
    }
    let idx = targetIndex == null ? destItems.length : targetIndex;
    if (destItems === loc.items && loc.index < idx) idx -= 1;
    idx = Math.max(0, Math.min(idx, destItems.length));
    destItems.splice(idx, 0, item);
    return true;
  }

  function wireBookDrag(el, item) {
    if (!getDev()) return;
    el.classList.add('spine-draggable');
    el.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      if (e.target.closest('.dev-x, .spine-color-btn')) return;
      DND.pending = { el, item, x: e.clientX, y: e.clientY, pointerId: e.pointerId };
      DND.didDrag = false;
    });
  }

  function wireDropTarget(el, { onDrop, hint }) {
    if (!getDev()) return;
    el.dataset.dropTarget = '1';
    dropHandlers.set(el, onDrop);
    if (hint) el.title = (el.title ? el.title + ' — ' : '') + hint;
  }

  function dndFindTarget(clientX, clientY) {
    const stack = document.elementsFromPoint(clientX, clientY);
    for (const node of stack) {
      if (node === DND.ghost || node === DND.sourceEl) continue;
      const t = node.closest && node.closest('[data-drop-target]');
      if (t && dropHandlers.has(t) && t !== DND.sourceEl) return t;
    }
    return null;
  }

  function dndStart(pending, e) {
    DND.active = true;
    DND.didDrag = true;
    DND.id = pending.item.id;
    DND.sourceEl = pending.el;
    pending.el.classList.add('dragging');
    document.body.classList.add('dragging-book');

    const rect = pending.el.getBoundingClientRect();
    const ghost = pending.el.cloneNode(true);
    ghost.classList.remove('dragging');
    ghost.classList.add('spine-ghost');
    ghost.style.width = rect.width + 'px';
    ghost.style.height = rect.height + 'px';
    ghost.style.left = (e.clientX - rect.width / 2) + 'px';
    ghost.style.top = (e.clientY - rect.height / 2) + 'px';
    ghost.querySelectorAll('.dev-x').forEach(n => n.remove());
    document.body.appendChild(ghost);
    DND.ghost = ghost;

    try { pending.el.setPointerCapture(pending.pointerId); } catch (err) {}
  }

  function dndMove(e) {
    if (DND.ghost) {
      const g = DND.ghost;
      const w = parseFloat(g.style.width) || 40;
      const h = parseFloat(g.style.height) || 40;
      g.style.left = (e.clientX - w / 2) + 'px';
      g.style.top = (e.clientY - h / 2) + 'px';
    }
    const target = dndFindTarget(e.clientX, e.clientY);
    if (DND.over && DND.over !== target) DND.over.classList.remove('drag-over');
    if (target) target.classList.add('drag-over');
    DND.over = target;
  }

  function dndFinish(e) {
    const id = DND.id;
    const target = dndFindTarget(e.clientX, e.clientY);
    const handler = target && dropHandlers.get(target);
    DND.clear();
    if (id && handler) handler(id);
  }

  /** Installeer globale pointer-listeners (één keer aanroepen). */
  function installGlobalListeners() {
    document.addEventListener('pointermove', e => {
      if (DND.active) {
        e.preventDefault();
        dndMove(e);
        return;
      }
      const p = DND.pending;
      if (!p) return;
      const dx = e.clientX - p.x;
      const dy = e.clientY - p.y;
      if (Math.hypot(dx, dy) < 8) return;
      dndStart(p, e);
      dndMove(e);
    }, { passive: false });

    document.addEventListener('pointerup', e => {
      if (DND.active) {
        e.preventDefault();
        dndFinish(e);
      }
      DND.pending = null;
    });
    document.addEventListener('pointercancel', () => DND.clear());
  }

  return {
    openSpineColorPicker,
    moveBook,
    wireBookDrag,
    wireDropTarget,
    installGlobalListeners,
    /** Of de laatste pointer-actie een sleep was (klik vs sleep). */
    get didDrag() { return DND.didDrag; },
    clear: () => DND.clear(),
  };
}
