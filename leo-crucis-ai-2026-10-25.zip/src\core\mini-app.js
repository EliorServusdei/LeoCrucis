/**
 * core/mini-app.js — formeel MiniApp-contract (fase 2)
 *
 * Alle mini-apps worden via normalizeMiniApp() in dit contract gebracht,
 * zodat host (mini-apps-view) en registry één API kennen.
 *
 * @typedef {Object} MiniApp
 * @property {HTMLElement} el          - zichtbare root in de DOM
 * @property {HTMLElement} root        - alias van el (legacy)
 * @property {string} [kind]           - app-id (bible, notes, …)
 * @property {() => void} [close]      - opruimen bij sluiten (timers, listeners)
 * @property {() => void} [unmount]    - alias van close
 * @property {() => void} [focus]      - focus naar de app verplaatsen
 * @property {(pos: *) => void} [navigate] - ga naar positie (bijbelvers, woord, …)
 * @property {() => object|null} [getState] - serialiseerbare staat voor restore
 * @property {(state: object) => void} [setState] - herstel eerder getState()
 * @property {() => boolean|void} [handleBack] - true = intern afgehandeld
 * @property {() => void} [destroy]    - legacy (tetris); wordt op close gezet
 */

/**
 * Breng een willekeurige factory-returnwaarde naar het MiniApp-contract.
 * @param {object|HTMLElement|null} app
 * @param {string} [kind]
 * @returns {MiniApp|null}
 */
export function normalizeMiniApp(app, kind = '') {
  if (!app) return null;

  // Factory gaf per ongeluk een los DOM-knooppunt terug
  if (app.nodeType === 1) {
    return {
      el: app,
      root: app,
      kind,
      close: null,
      unmount: null,
      focus: () => { try { app.focus?.(); } catch (_) {} },
      navigate: null,
      getState: null,
      setState: null,
      handleBack: null,
    };
  }

  const el = app.el || app.root;
  if (!el || el.nodeType !== 1) return null;

  const closeFn =
    typeof app.close === 'function' ? app.close.bind(app)
      : typeof app.unmount === 'function' ? app.unmount.bind(app)
        : typeof app.destroy === 'function' ? app.destroy.bind(app)
          : null;

  const handleBack =
    typeof app.handleBack === 'function' ? app.handleBack.bind(app) : null;

  const navigate =
    typeof app.navigate === 'function' ? app.navigate.bind(app)
      : typeof app.goTo === 'function' ? app.goTo.bind(app)
        : null;

  const getState =
    typeof app.getState === 'function' ? app.getState.bind(app) : null;

  const setState =
    typeof app.setState === 'function' ? app.setState.bind(app)
      : typeof app.restore === 'function' ? app.restore.bind(app)
        : null;

  const focus =
    typeof app.focus === 'function' ? app.focus.bind(app)
      : () => {
        try {
          const t = el.querySelector('input, textarea, [tabindex], button, a, select');
          if (t) t.focus();
          else if (typeof el.focus === 'function') el.focus();
        } catch (_) {}
      };

  /** @type {MiniApp} */
  const normalized = {
    el,
    root: app.root || el,
    kind: kind || app.kind || '',
    close: closeFn,
    unmount: closeFn,
    focus,
    navigate,
    getState,
    setState,
    handleBack,
  };

  // Behoud extra properties (goHub, …) voor specifieke hosts
  for (const k of Object.keys(app)) {
    if (k in normalized) continue;
    try { normalized[k] = app[k]; } catch (_) {}
  }

  return normalized;
}

/**
 * Roep close/unmount veilig aan (geen throw naar de host).
 * @param {MiniApp|null|undefined} app
 */
export function safeCloseMiniApp(app) {
  if (!app) return;
  const fn = app.close || app.unmount || app.destroy;
  if (typeof fn !== 'function') return;
  try { fn.call(app); } catch (e) { console.warn('mini-app close', app.kind, e); }
}

/**
 * Snapshot voor recente apps / split restore.
 * @param {MiniApp|null} app
 * @param {*} startPos
 * @returns {{ kind: string, startPos: *, saved: object|null }}
 */
export function snapshotMiniApp(app, startPos = null) {
  let saved = null;
  if (app && typeof app.getState === 'function') {
    try { saved = app.getState(); } catch (_) { saved = null; }
  }
  return {
    kind: (app && app.kind) || '',
    startPos: startPos ?? null,
    saved: saved && typeof saved === 'object' ? saved : null,
  };
}

/**
 * Herstel state na mount (setState of navigate als fallback).
 * @param {MiniApp|null} app
 * @param {{ startPos?: *, saved?: object|null }} [slot]
 */
export function restoreMiniApp(app, slot) {
  if (!app || !slot) return;
  if (slot.saved && typeof app.setState === 'function') {
    try { app.setState(slot.saved); return; } catch (e) { console.warn('setState', e); }
  }
  if (slot.startPos != null && typeof app.navigate === 'function') {
    try { app.navigate(slot.startPos); } catch (e) { console.warn('navigate', e); }
  }
}
