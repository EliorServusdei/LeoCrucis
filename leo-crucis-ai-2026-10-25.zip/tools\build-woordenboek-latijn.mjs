#!/usr/bin/env node
// Bouwt het Nederlands → Latijn woordenboek (src/data/woordenboek-latijn/nl-la.json).
//
// Er bestaat geen vrij beschikbaar Nederlands–Latijn woordenboek in machineleesbare vorm. Daarom wordt
// het opgebouwd met een tussenstap (pivot) via Engels en Duits, uit de FreeDict-woordenboeken
// (https://github.com/freedict/fd-dictionaries, GNU GPL v2+):
//
//   Route A: nld-eng (+ omgekeerd eng-nld)  →  eng-lat
//   Route B: nld-eng (+ omgekeerd eng-nld)  →  lat-eng (omgekeerd)
//   Route C: nld-deu (+ omgekeerd deu-nld)  →  lat-deu (omgekeerd)
//
// Een Latijns woord dat via meer routes bevestigd wordt, krijgt een hogere score (1–3).
// Grammatica (genitief, geslacht, stamtijden) komt uit lat-deu.
//
// Gebruik:
//   git clone --depth 1 https://github.com/freedict/fd-dictionaries.git tools/freedict
//   node tools/build-woordenboek-latijn.mjs [map-met-freedict]   (standaard: tools/freedict)

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.resolve(process.argv[2] || path.join(here, 'freedict'));
const OUT = path.resolve(here, '../src/data/woordenboek-latijn/nl-la.json');

const unesc = s => s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/&apos;/g, "'").replace(/&quot;/g, '"').replace(/ĳ/g, 'ij').replace(/Ĳ/g, 'IJ').replace(/\s+/g, ' ').trim();
const key = s => unesc(s).toLowerCase();
/** Klassieke schoolspelling: æ → ae, œ → oe */
const latin = s => unesc(s).replace(/Æ/g, 'Ae').replace(/æ/g, 'ae').replace(/Œ/g, 'Oe').replace(/œ/g, 'oe');

function readEntries(pair) {
  const f = path.join(SRC, pair, pair + '.tei');
  if (!fs.existsSync(f)) throw new Error('Ontbreekt: ' + f);
  const s = fs.readFileSync(f, 'utf8');
  const out = [];
  for (const m of s.matchAll(/<entry\b[^>]*>([\s\S]*?)<\/entry>/g)) {
    const b = m[1];
    const o = b.match(/<orth>([\s\S]*?)<\/orth>/);
    if (!o) continue;
    const quotes = [...b.matchAll(/<quote>([\s\S]*?)<\/quote>/g)].map(q => unesc(q[1])).filter(Boolean);
    out.push({ orth: unesc(o[1]), quotes, body: b });
  }
  return out;
}

const add = (map, a, b) => { if (!a || !b) return; (map.get(a) || map.set(a, new Set()).get(a)).add(b); };

/** a → b uit "a-b" (vooruit) en optioneel uit "b-a" (omgekeerd). */
function pairs(fwdPair, backPair) {
  const m = new Map();
  for (const e of readEntries(fwdPair)) for (const q of e.quotes) add(m, key(e.orth), key(q));
  if (backPair) for (const e of readEntries(backPair)) for (const q of e.quotes) add(m, key(q), key(e.orth));
  return m;
}

const nlEn = pairs('nld-eng', null);
for (const e of readEntries('eng-nld')) for (const q of e.quotes) add(nlEn, key(q), key(e.orth));
const nlDe = pairs('nld-deu', null);
for (const e of readEntries('deu-nld')) for (const q of e.quotes) add(nlDe, key(q), key(e.orth));

// Engels → Latijn (routes A en B), Duits → Latijn (route C). Waarde = Map<latijn, route>
const enLa = new Map(), deLa = new Map();
const addRoute = (map, from, la, r) => {
  const m = map.get(from) || map.set(from, new Map()).get(from);
  (m.get(la) || m.set(la, new Set()).get(la)).add(r);
};
for (const e of readEntries('eng-lat')) for (const q of e.quotes) addRoute(enLa, key(e.orth), latin(q), 'A');
for (const e of readEntries('lat-eng')) for (const q of e.quotes) addRoute(enLa, key(q), latin(e.orth), 'B');

// Grammatica uit lat-deu + route C
const gram = new Map();
const infMap = new Map(); // infinitief → lemma (amare → amo)
const MASC_A = new Set(['nauta','agricola','poeta','incola','scriba','pirata','auriga','advena','collega','convena','verna','lanista','athleta','propheta','papa','Iuda','Barnabas']);
const POS = { n: 'zn.', v: 'ww.', adj: 'bn.', adv: 'bw.', prep: 'vz.', conj: 'vw.', int: 'tussenw.', num: 'telw.', pron: 'vnw.' };
for (const e of readEntries('lat-deu')) {
  const lemma = latin(e.orth);
  for (const q of e.quotes) addRoute(deLa, key(q), lemma, 'C');
  if (gram.has(lemma)) continue;
  const pos = (e.body.match(/<pos>(\w+)<\/pos>/) || [])[1];
  if (!pos) continue;
  const infl = [...e.body.matchAll(/<form type="infl">([\s\S]*?)<\/form>/g)].map(m => {
    const o = m[1].match(/<orth(?: type="(\w+)")?>([\s\S]*?)<\/orth>/);
    const g = m[1].match(/<gen>(\w+)<\/gen>/);
    const c = m[1].match(/<case>(\w+)<\/case>/);
    return o ? { type: o[1] || '', o: latin(o[2]), gen: g && g[1], kase: c && c[1] } : null;
  }).filter(Boolean);
  const gen = (e.body.match(/<\/pos>\s*(?:<number>\w+<\/number>\s*)?<gen>(\w+)<\/gen>/) || [])[1];
  let line = lemma;
  const inf0 = infl.find(x => x.type === 'inf');
  if (pos === 'v' && inf0) infMap.set(inf0.o, lemma);
  if (pos === 'n') {
    const g = infl.find(x => x.kase === 'gen');
    if (g) line += ', ' + g.o;
    // De bron heeft enkele foute geslachten (villa = m.). Eerste verbuiging op -a/-ae is vrouwelijk, op enkele uitzonderingen na.
    const suspicious = gen === 'm' && /a$/.test(lemma) && g && /ae$/.test(g.o) && !MASC_A.has(lemma);
    if (gen && !suspicious) line += ' (' + gen + '.)';
  } else if (pos === 'v') {
    for (const t of ['inf', 'perf', 'sup']) { const x = infl.find(i => i.type === t); if (x) line += ', ' + x.o; }
  } else if (pos === 'adj') {
    for (const x of infl) if (x.gen) line += ', ' + x.o;
  }
  gram.set(lemma, { pos: POS[pos] || pos, line });
}

// Samenvoegen
const perNl = new Map();
const allNl = new Set([...nlEn.keys(), ...nlDe.keys()]);
for (const nl of [...allNl].sort((a, b) => a.localeCompare(b, 'nl'))) {
  const found = new Map(); // latijn → Set<route>
  const take = (via, table) => {
    for (const mid of via || []) {
      const m = table.get(mid);
      if (!m) continue;
      for (const [la, rs] of m) for (const r of rs) (found.get(la) || found.set(la, new Set()).get(la)).add(r);
    }
  };
  take(nlEn.get(nl), enLa);
  take(nlDe.get(nl), deLa);
  if (!found.size) continue;
  // Infinitieven (amare) horen bij hun lemma (amo)
  for (const [la, rs] of [...found]) {
    const lem = infMap.get(la);
    if (lem && !gram.has(la) && lem !== la) {
      found.delete(la);
      const t = found.get(lem) || found.set(lem, new Set()).get(lem);
      for (const r of rs) t.add(r);
    }
  }
  perNl.set(nl, found);
}

// Handmatige aanvullingen (score 4) — zie woordenboek-latijn-extra.txt
const extra = new Map(); // nl-key → Map<lemma, {gram,pos}>
const extraFile = path.join(here, 'woordenboek-latijn-extra.txt');
for (const raw of fs.readFileSync(extraFile, 'utf8').split(/\r?\n/)) {
  const line = raw.trim();
  if (!line || line.startsWith('#')) continue;
  const [nl, la, g, pos] = line.split('|').map(x => x.trim());
  if (!nl || !la) continue;
  const k = key(nl);
  (extra.get(k) || extra.set(k, new Map()).get(k)).set(la, { gram: g || '', pos: pos || '' });
  if (!perNl.has(k)) perNl.set(k, new Map());
}

const out = [];
for (const nl of [...perNl.keys()].sort((a, b) => a.localeCompare(b, 'nl'))) {
  const found = perNl.get(nl);
  const ex = extra.get(nl) || new Map();
  const rows = new Map();
  for (const [la, rs] of found) {
    const g = gram.get(la);
    rows.set(la, [la, rs.size, g ? (g.line === la ? '' : g.line) : '', g ? g.pos : '']);
  }
  for (const [la, x] of ex) {
    const old = rows.get(la);
    rows.set(la, [la, 4, x.gram === la ? '' : x.gram, x.pos || (old ? old[3] : '')]);
  }
  const list = [...rows.values()].map(r => { while (r.length > 2 && !r[r.length - 1]) r.pop(); return r; })
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'la'));
  if (list.length) out.push([nl, list]);
}

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify({
  v: 1,
  built: new Date().toISOString().slice(0, 10),
  words: out.length,
  pairs: out.reduce((n, e) => n + e[1].length, 0),
  // entry = [nederlands, [[latijn, score, grammatica?, woordsoort?], …]]
  entries: out
}));
console.log('Klaar:', out.length, 'Nederlandse woorden →', OUT, (fs.statSync(OUT).size / 1024).toFixed(0) + ' KB');
