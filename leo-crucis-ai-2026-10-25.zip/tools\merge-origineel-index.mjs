#!/usr/bin/env node
/**
 * Voegt de vertaling "origineel" (Hebreeuws OT + Grieks NT) toe aan data/bijbel/index.json.
 * Gebruik: node tools/merge-origineel-index.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'src', 'data', 'bijbel');
const indexPath = path.join(root, 'index.json');
const partialPath = path.join(root, 'index-origineel.json');

const index = JSON.parse(fs.readFileSync(indexPath, 'utf8'));
const partial = JSON.parse(fs.readFileSync(partialPath, 'utf8'));
const tr = partial.translations[0];

index.translations = (index.translations || []).filter(t => t.id !== 'origineel');
index.translations.push(tr);

// books list: keep existing; add any missing osis from origineel
const byOsis = new Map((index.books || []).map(b => [b.osis, b]));
for (const b of partial.books) {
  if (!byOsis.has(b.osis)) byOsis.set(b.osis, b);
}
index.books = [...byOsis.values()].sort((a, b) => (a.n || 0) - (b.n || 0));

if (!index.booksByTranslation) index.booksByTranslation = {};
index.booksByTranslation.origineel = partial.booksByTranslation.origineel;

fs.writeFileSync(indexPath, JSON.stringify(index, null, 2));
console.log('Toegevoegd: origineel (' + partial.books.length + ' boeken). Vertalingen:', index.translations.map(t => t.id).join(', '));
