/**
 * ui/search-history.js — zoekgeschiedenis (persist + formatters)
 *
 * Pure-ish module: geen DOM, alleen localStorage + optionele Tauri writeFile/readFile.
 * app.js houdt dunne wrappers of importeert deze API rechtstreeks.
 */

const SEARCH_RECENT_KEY = 'lc-search-recent-v1';
/** Geschiedenis als bestand in de gebruikersmap (Tauri) — onbeperkt lang. */
const SEARCH_HISTORY_FILE = 'search-history.json';

/** @type {{ q: string, at: string }[]|null} */
let _searchHistoryCache = null;
let _searchHistoryFlushTimer = null;

/** Optionele injectie voor Tauri (inTauri, readFile, writeFile). */
let _deps = {
  inTauri: false,
  readFile: null,
  writeFile: null
};

/**
 * Roep één keer aan na imports (optioneel; zonder deps blijft localStorage werken).
 * @param {{ inTauri?: boolean, readFile?: Function, writeFile?: Function }} deps
 */
export function configureSearchHistory(deps = {}) {
  if (deps.inTauri != null) _deps.inTauri = !!deps.inTauri;
  if (typeof deps.readFile === 'function') _deps.readFile = deps.readFile;
  if (typeof deps.writeFile === 'function') _deps.writeFile = deps.writeFile;
}

export function normalizeHistoryEntries(raw) {
  if (!Array.isArray(raw)) return [];
  const out = [];
  for (const x of raw) {
    if (typeof x === 'string' && x.trim()) {
      out.push({ q: x.trim(), at: new Date().toISOString() });
    } else if (x && typeof x === 'object' && typeof x.q === 'string' && x.q.trim()) {
      out.push({ q: x.q.trim(), at: typeof x.at === 'string' ? x.at : new Date().toISOString() });
    }
  }
  return out;
}

/** Unieke zoektermen (nieuwste eerst) voor chips / suggesties. */
export function loadSearchRecent() {
  const list = getSearchHistory();
  const seen = new Set();
  const out = [];
  for (const e of list) {
    const k = e.q.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(e.q);
  }
  return out;
}

export function getSearchHistory() {
  if (Array.isArray(_searchHistoryCache)) return _searchHistoryCache.slice();
  try {
    const a = JSON.parse(localStorage.getItem(SEARCH_RECENT_KEY) || '[]');
    _searchHistoryCache = normalizeHistoryEntries(a);
  } catch {
    _searchHistoryCache = [];
  }
  return _searchHistoryCache.slice();
}

function persistSearchHistoryNow() {
  const list = Array.isArray(_searchHistoryCache) ? _searchHistoryCache : [];
  try { localStorage.setItem(SEARCH_RECENT_KEY, JSON.stringify(list)); } catch {}
  if (_deps.inTauri && typeof _deps.writeFile === 'function') {
    _deps.writeFile(SEARCH_HISTORY_FILE, JSON.stringify(list, null, 1))
      .catch(e => console.warn('search-history.json:', e));
  }
}

function scheduleSearchHistoryFlush() {
  if (_searchHistoryFlushTimer) return;
  _searchHistoryFlushTimer = setTimeout(() => {
    _searchHistoryFlushTimer = null;
    persistSearchHistoryNow();
  }, 300);
}

/** Elke zoekactie = nieuwe geschiedenisregel (ook bij dezelfde term). */
export function saveSearchRecent(q) {
  const v = String(q || '').trim();
  if (!v || v.length < 2) return;
  const list = getSearchHistory();
  list.unshift({ q: v, at: new Date().toISOString() });
  _searchHistoryCache = list;
  scheduleSearchHistoryFlush();
}

/** Laad geschiedenis uit gebruikersmap (Tauri) en merge met localStorage. */
export async function initSearchHistoryFromFile() {
  if (!(_deps.inTauri && typeof _deps.readFile === 'function')) return;
  try {
    const raw = await _deps.readFile(SEARCH_HISTORY_FILE);
    if (!raw) return;
    const fromFile = normalizeHistoryEntries(JSON.parse(raw));
    if (!fromFile.length) return;
    const local = getSearchHistory();
    // Bestand wint als het langer/nieuwer is; anders merge op (q,at)
    const key = e => e.q.toLowerCase() + '|' + e.at;
    const map = new Map();
    for (const e of fromFile) map.set(key(e), e);
    for (const e of local) {
      const k = key(e);
      if (!map.has(k)) map.set(k, e);
    }
    const merged = [...map.values()].sort((a, b) => String(b.at).localeCompare(String(a.at)));
    _searchHistoryCache = merged;
    try { localStorage.setItem(SEARCH_RECENT_KEY, JSON.stringify(merged)); } catch {}
  } catch (_) {
    // bestand bestaat nog niet — ok
  }
}

export function clearSearchHistory() {
  _searchHistoryCache = [];
  try { localStorage.removeItem(SEARCH_RECENT_KEY); } catch {}
  if (_deps.inTauri && typeof _deps.writeFile === 'function') {
    _deps.writeFile(SEARCH_HISTORY_FILE, '[]').catch(() => {});
  }
}

/** Verwijder één entry (op q + optioneel exact at). */
export function removeSearchHistoryEntry(entry) {
  const q = entry && typeof entry === 'object' ? String(entry.q || '') : String(entry || '');
  const at = entry && typeof entry === 'object' ? String(entry.at || '') : '';
  const v = q.trim().toLowerCase();
  if (!v) return;
  let removed = false;
  _searchHistoryCache = getSearchHistory().filter(e => {
    if (removed) return true;
    if (e.q.toLowerCase() !== v) return true;
    if (at && e.at !== at) return true;
    removed = true;
    return false;
  });
  scheduleSearchHistoryFlush();
}

export function formatSearchHistoryTime(iso) {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '';
    return d.toLocaleString('nl-BE', { dateStyle: 'short', timeStyle: 'short' });
  } catch (_) { return ''; }
}

export function formatSearchHistoryRelative(iso) {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '';
    const now = new Date();
    const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startThat = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const dayDiff = Math.round((startToday - startThat) / 86400000);
    const time = d.toLocaleTimeString('nl-BE', { hour: '2-digit', minute: '2-digit' });
    if (dayDiff === 0) return 'Vandaag · ' + time;
    if (dayDiff === 1) return 'Gisteren · ' + time;
    if (dayDiff > 1 && dayDiff < 7) {
      const day = d.toLocaleDateString('nl-BE', { weekday: 'long' });
      return day.charAt(0).toUpperCase() + day.slice(1) + ' · ' + time;
    }
    return d.toLocaleDateString('nl-BE', {
      day: 'numeric',
      month: 'short',
      year: d.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
    }) + ' · ' + time;
  } catch (_) { return formatSearchHistoryTime(iso); }
}

export function historyDayKey(iso) {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return 'overig';
    const now = new Date();
    const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startThat = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const dayDiff = Math.round((startToday - startThat) / 86400000);
    if (dayDiff === 0) return 'vandaag';
    if (dayDiff === 1) return 'gisteren';
    if (dayDiff > 1 && dayDiff < 7) return 'week';
    if (d.getFullYear() === now.getFullYear()) return 'jaar';
    return 'ouder';
  } catch (_) { return 'overig'; }
}

export const HISTORY_DAY_LABELS = {
  vandaag: 'Vandaag',
  gisteren: 'Gisteren',
  week: 'Deze week',
  jaar: 'Eerder dit jaar',
  ouder: 'Ouder',
  overig: 'Overig'
};

export { SEARCH_RECENT_KEY, SEARCH_HISTORY_FILE };
