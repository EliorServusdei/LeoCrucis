/**
 * core/world-model.js — pure helpers rond de stad/wereld-structuur.
 */
export function roomItems(room) {
  if (!room) return [];
  if (room.shelves) return room.shelves.flatMap(s => s.items || []);
  return room.items || [];
}
export function allItems(world) {
  if (!world || !world.buildings) return [];
  return world.buildings.flatMap(b => (b.rooms || []).flatMap(roomItems));
}
export function itemOf(world, id) {
  return allItems(world).find(i => i.id === id) || null;
}
export function findItemLoc(world, id) {
  if (!world || !world.buildings) return null;
  for (const b of world.buildings) {
    for (const r of b.rooms || []) {
      if (r.shelves) {
        for (const sh of r.shelves) {
          const items = sh.items || (sh.items = []);
          const idx = items.findIndex(it => it.id === id);
          if (idx >= 0) return { building: b, room: r, shelf: sh, items, index: idx };
        }
      } else {
        const items = r.items || (r.items = []);
        const idx = items.findIndex(it => it.id === id);
        if (idx >= 0) return { building: b, room: r, shelf: null, items, index: idx };
      }
    }
  }
  return null;
}
export function whereOf(world, id) {
  if (!world || !world.buildings) return '';
  for (const b of world.buildings) {
    for (const r of b.rooms || []) {
      if (roomItems(r).some(i => i.id === id)) return `${b.label} › ${r.label}`;
    }
  }
  return '';
}
export function ensureShelves(room) {
  if (!room.shelves) {
    room.shelves = [{ label: null, items: room.items ? [...room.items] : [] }];
    delete room.items;
  }
  return room.shelves;
}
export function colorOf(item, fallbackIdx = 0) {
  const c = item && item.color;
  if (typeof c === 'number' && c >= 0 && c <= 9) return c;
  return ((fallbackIdx % 10) + 10) % 10;
}
export function defaultColorForId(id) {
  let h = 0;
  const s = String(id || '');
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h % 10;
}
export function textOf(html) {
  const d = new DOMParser().parseFromString(html || '', 'text/html');
  d.querySelectorAll('script,style').forEach(n => n.remove());
  return (d.body.textContent || '').replace(/\s+/g, ' ').trim();
}
export function detectType(html) {
  if (!html) return 'doc';
  if (html.includes('class="pdf-book"') || html.includes("class='pdf-book'")) return 'pdf';
  if (html.includes('data-slides')) return 'pptx';
  if (html.includes('data-sheet')) return 'xlsx';
  return 'doc';
}
