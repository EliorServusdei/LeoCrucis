/**
 * Worldbuilding Studio — main mini-app
 * createWorldbuildingApp() → MiniApp-contract
 */
import { el } from '../../core/dom.js';
import { createEditor } from '../../editor/editor.js';
import { ask } from '../../core/edit.js';
import {
  NAV_SECTIONS, PROJECT_STATUSES, WORLD_TYPES, ACCENT_COLORS, WORLD_SYMBOLS,
  RELATION_TYPES, collectionForModule, schemaFor,
} from './constants.js';
import {
  loadIndex, loadProject, saveProject, deleteProject, duplicateProject,
  createFullProject, createItem, logActivity, searchProject,
  exportProjectJson, parseImport, emptyCollections, downloadDataBundle,
} from './store.js';
import {
  icon, btn, iconBtn, input, textarea, select, field, modal,
  confirmDialog, toast, emptyState, formatRelative, debounce,
  statusBadge, typeBadge,
} from './ui.js';

let stylesInjected = false;
function ensureStyles() {
  if (stylesInjected) return;
  stylesInjected = true;
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = new URL('./styles.css', import.meta.url).href;
  document.head.appendChild(link);
}

export function createWorldbuildingApp(startPos) {
  ensureStyles();
  const root = el('div', 'wb-root mini-app-root');
  root.setAttribute('tabindex', '0');

  let project = null, index = { projects: [] }, view = 'projects';
  let module = 'dashboard', itemId = null, editing = false;
  let dirty = false, saveState = 'idle', sidebarCollapsed = false;
  let openSections = new Set(['world', 'stories']);
  let searchQuery = '', listFilter = '';
  let navFilter = '';
  let bookMode = 'edit'; // 'edit' | 'read'
  // Studio (Auteurs Codex-stijl) state
  let sideTab = 'manuscript'; // 'manuscript' | 'world'
  let studioTabs = []; // { key, type, collection, id, title }
  let activeStudioKey = null;
  let zenMode = false;
  let openBookFolders = new Set(); // book ids die opengeklapt zijn in de boom

  function setDirty(v = true) {
    dirty = v;
    saveState = v ? 'dirty' : saveState === 'saving' ? 'saving' : 'saved';
    updateSaveStatus();
  }
  function updateSaveStatus() {
    const s = root.querySelector('.wb-save-status');
    if (!s) return;
    s.className = 'wb-save-status ' + (saveState === 'idle' ? '' : saveState);
    s.textContent = ({ idle: '', dirty: 'Niet opgeslagen', saving: 'Opslaan…', saved: 'Opgeslagen' })[saveState] || '';
  }
  async function persist() {
    if (!project) return;
    saveState = 'saving'; updateSaveStatus();
    try {
      project = await saveProject(project);
      dirty = false; saveState = 'saved'; updateSaveStatus();
      setTimeout(() => { if (saveState === 'saved') { saveState = 'idle'; updateSaveStatus(); } }, 2000);
    } catch (e) {
      saveState = 'dirty'; updateSaveStatus();
      toast('Opslaan mislukt: ' + (e.message || e), 'error');
    }
  }
  const autoSave = debounce(() => { if (dirty && project) persist(); }, 1200);

  async function boot() {
    root.innerHTML = '';
    const loading = el('div', 'wb-loading');
    loading.appendChild(el('div', 'wb-spinner'));
    loading.appendChild(document.createTextNode('Worldbuilding Studio laden…'));
    root.appendChild(loading);
    try { index = await loadIndex(); } catch { index = { projects: [] }; }
    if (startPos?.projectId) {
      const p = await loadProject(startPos.projectId);
      if (p) { project = p; view = 'workspace'; module = startPos.module || 'dashboard'; itemId = startPos.itemId || null; }
    }
    render();
  }

  function render() {
    if (root._wbGraphCleanup) { root._wbGraphCleanup(); root._wbGraphCleanup = null; }
    root.innerHTML = '';
    if (view === 'projects') renderProjectSelect();
    else renderWorkspace();
  }

  function renderProjectSelect() {
    const page = el('div', 'wb-projects');
    const head = el('div', 'wb-projects-head');
    const titles = el('div');
    titles.appendChild(el('h1', 'wb-projects-title', 'Worldbuilding Studio'));
    titles.appendChild(el('p', 'wb-projects-sub', 'Ontwerp, organiseer en documenteer complete fictieve werelden.'));
    head.appendChild(titles);
    const actions = el('div'); actions.style.cssText = 'display:flex;gap:.5rem';
    actions.appendChild(btn('Importeren', { icon: 'import', onClick: () => doImport() }));
    actions.appendChild(btn('Data-bestanden', {
      icon: 'export',
      title: 'Download index + project-JSON voor src/apps/worldbuilding/projecten/',
      onClick: async () => {
        try {
          const n = await downloadDataBundle();
          toast(n + ' bestand(en) gedownload — plaats in src/apps/worldbuilding/projecten/', 'success');
        } catch (e) { toast(e.message || 'Download mislukt', 'error'); }
      },
    }));
    actions.appendChild(btn('Nieuw project', { icon: 'plus', cls: 'wb-btn-primary', onClick: () => openProjectForm() }));
    head.appendChild(actions); page.appendChild(head);
    const grid = el('div', 'wb-project-grid');
    const newCard = el('div', 'wb-project-card wb-new-card');
    newCard.tabIndex = 0; newCard.appendChild(icon('plus', 28));
    newCard.appendChild(el('span', '', 'Nieuw worldbuildingproject'));
    newCard.onclick = () => openProjectForm(); grid.appendChild(newCard);
    const projects = [...(index.projects || [])].sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));
    if (!projects.length) {
      page.appendChild(grid);
      page.appendChild(emptyState({ icon: 'world', title: 'Nog geen werelden',
        text: 'Maak je eerste worldbuildingproject aan.',
        action: btn('Eerste wereld maken', { cls: 'wb-btn-primary', icon: 'plus', onClick: () => openProjectForm() }) }));
    } else {
      for (const meta of projects) grid.appendChild(projectCard(meta));
      page.appendChild(grid);
    }
    root.appendChild(page);
  }

  function projectCard(meta) {
    const card = el('div', 'wb-project-card');
    card.style.setProperty('--wb-card-accent', meta.accent || '#c9a227');
    card.tabIndex = 0;
    const cover = el('div', 'wb-project-cover');
    cover.appendChild(el('div', 'wb-symbol', meta.symbol || '✦'));
    card.appendChild(cover);
    const body = el('div', 'wb-project-body');
    body.appendChild(el('h3', 'wb-project-name', meta.name || 'Naamloos'));
    if (meta.subtitle) body.appendChild(el('p', 'wb-project-sub', meta.subtitle));
    if (meta.description) body.appendChild(el('p', 'wb-project-desc', meta.description));
    const badges = el('div', 'wb-project-meta');
    badges.appendChild(statusBadge(meta.status || 'concept'));
    badges.appendChild(typeBadge(meta.worldType || 'high-fantasy'));
    body.appendChild(badges);
    const foot = el('div', 'wb-project-foot');
    foot.appendChild(el('span', '', ((meta.counts || {}).total || 0) + ' items · ' + formatRelative(meta.updatedAt)));
    const acts = el('div', 'wb-project-actions');
    acts.appendChild(iconBtn('edit', { title: 'Bewerken', onClick: e => { e.stopPropagation(); openProjectForm(meta); } }));
    acts.appendChild(iconBtn('copy', { title: 'Dupliceren', onClick: async e => {
      e.stopPropagation();
      try { await duplicateProject(meta.id); index = await loadIndex(); toast('Gedupliceerd', 'success'); render(); }
      catch (err) { toast(err.message || 'Mislukt', 'error'); }
    }}));
    acts.appendChild(iconBtn('export', { title: 'Exporteren', onClick: async e => { e.stopPropagation(); await doExport(meta.id); } }));
    acts.appendChild(iconBtn('trash', { title: 'Verwijderen', cls: 'wb-btn-danger', onClick: async e => {
      e.stopPropagation();
      if (!(await confirmDialog('Project "' + meta.name + '" verwijderen?', { yes: 'Verwijderen', danger: true }))) return;
      await deleteProject(meta.id); index = await loadIndex(); toast('Verwijderd'); render();
    }}));
    foot.appendChild(acts); body.appendChild(foot); card.appendChild(body);
    const open = async () => {
      const p = await loadProject(meta.id);
      if (!p) { toast('Laden mislukt', 'error'); return; }
      project = p; view = 'workspace'; module = 'dashboard'; itemId = null; editing = false; dirty = false; render();
    };
    card.onclick = open;
    card.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } };
    return card;
  }

  function openProjectForm(existing = null) {
    const isEdit = !!existing;
    const form = el('div', 'wb-form-grid wb-project-form');

    const nameIn = input({ value: existing?.name || '', placeholder: 'Bijv. Eldoria', aria: 'Naam' });
    const subIn = input({ value: existing?.subtitle || '', placeholder: 'Korte ondertitel (optioneel)', aria: 'Ondertitel' });
    const descIn = textarea({ value: existing?.description || '', rows: 3, placeholder: 'Waar gaat deze wereld over?', aria: 'Beschrijving' });
    const typeSel = select(WORLD_TYPES, { value: existing?.worldType || 'high-fantasy', aria: 'Type' });
    const statusSel = select(PROJECT_STATUSES, { value: existing?.status || 'concept', aria: 'Status' });

    let chosenSymbol = existing?.symbol || '✦';
    if (!WORLD_SYMBOLS.includes(chosenSymbol)) chosenSymbol = '✦';
    const symbolGrid = el('div', 'wb-symbol-grid');
    for (const sym of WORLD_SYMBOLS) {
      const b = el('button', 'wb-symbol-opt' + (sym === chosenSymbol ? ' active' : ''));
      b.type = 'button';
      b.textContent = sym;
      b.title = sym;
      b.setAttribute('aria-label', 'Symbool ' + sym);
      b.onclick = () => {
        chosenSymbol = sym;
        symbolGrid.querySelectorAll('.wb-symbol-opt').forEach(x => x.classList.toggle('active', x.textContent === sym));
      };
      symbolGrid.appendChild(b);
    }

    let chosenAccent = existing?.accent || ACCENT_COLORS[0];
    const colorRow = el('div', 'wb-accent-grid');
    for (const c of ACCENT_COLORS) {
      const sw = el('button', 'wb-accent-swatch' + (c === chosenAccent ? ' active' : ''));
      sw.type = 'button';
      sw.style.background = c;
      sw.title = c;
      sw.setAttribute('aria-label', 'Kleur ' + c);
      sw.onclick = () => {
        chosenAccent = c;
        colorRow.querySelectorAll('.wb-accent-swatch').forEach(x => {
          x.classList.toggle('active', x.title === c);
        });
      };
      colorRow.appendChild(sw);
    }

    const row2 = el('div', 'wb-form-row');
    row2.append(field('Wereldtype', typeSel), field('Status', statusSel));

    form.append(
      field('Naam *', nameIn),
      field('Ondertitel', subIn),
      field('Beschrijving', descIn),
      row2,
      field('Symbool', symbolGrid),
      field('Accentkleur', colorRow)
    );

    document.body.appendChild(modal({
      title: isEdit ? 'Project bewerken' : 'Nieuw project', body: form,
      actions: [
        { label: 'Annuleren' },
        { label: isEdit ? 'Opslaan' : 'Aanmaken', primary: true, onClick: async () => {
          const name = nameIn.value.trim();
          if (!name) { toast('Naam is verplicht', 'error'); return false; }
          try {
            if (isEdit) {
              let p = await loadProject(existing.id);
              if (!p) throw new Error('Niet gevonden');
              Object.assign(p, {
                name,
                subtitle: subIn.value.trim(),
                description: descIn.value.trim(),
                worldType: typeSel.value,
                status: statusSel.value,
                symbol: chosenSymbol || '✦',
                accent: chosenAccent,
              });
              await saveProject(p); toast('Bijgewerkt', 'success');
            } else {
              const p = createFullProject({
                name,
                subtitle: subIn.value.trim(),
                description: descIn.value.trim(),
                worldType: typeSel.value,
                status: statusSel.value,
                symbol: chosenSymbol || '✦',
                accent: chosenAccent,
              });
              await saveProject(p); toast('Aangemaakt', 'success');
            }
            index = await loadIndex(); render();
          } catch (e) { toast(e.message || 'Mislukt', 'error'); return false; }
        }},
      ],
    }));
    nameIn.focus();
  }

  async function doExport(id) {
    const p = await loadProject(id || project?.id);
    if (!p) { toast('Geen project', 'error'); return; }
    const blob = new Blob([exportProjectJson(p)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = ((p.name || 'world').replace(/[^\w\-]+/g, '_')) + '.wb.json';
    a.click(); URL.revokeObjectURL(a.href); toast('Export gedownload', 'success');
  }

  function doImport() {
    const fileIn = document.createElement('input'); fileIn.type = 'file'; fileIn.accept = '.json,application/json';
    fileIn.onchange = async () => {
      const file = fileIn.files?.[0]; if (!file) return;
      try {
        const parsed = parseImport(await file.text());
        parsed.id = 'wb_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
        parsed.name = parsed.name + ' (import)';
        await saveProject(parsed); index = await loadIndex(); toast('Geïmporteerd', 'success'); render();
      } catch (e) { toast('Import mislukt: ' + (e.message || e), 'error'); }
    };
    fileIn.click();
  }

  function renderWorkspace() {
    if (!project) { view = 'projects'; render(); return; }
    root.classList.add('wb-studio-mode');
    const studio = el('div', 'wb-studio' + (zenMode ? ' zen' : ''));

    // 1) Header eerst (bovenaan)
    studio.appendChild(buildStudioHeader());

    // 2) Body eronder: links + editor
    const body = el('div', 'wb-studio-body');
    if (!zenMode) body.appendChild(buildStudioLeft());
    body.appendChild(buildStudioCenter());
    studio.appendChild(body);

    root.appendChild(studio);
  }

  function studioKey(type, collection, id) {
    return type + ':' + (collection || '') + ':' + id;
  }

  function openStudioTab(type, collection, id, title) {
    const key = studioKey(type, collection, id);
    if (!studioTabs.find(t => t.key === key)) {
      studioTabs.push({ key, type, collection, id, title: title || 'Naamloos' });
    } else {
      const t = studioTabs.find(t => t.key === key);
      if (title) t.title = title;
    }
    activeStudioKey = key;
    // Sync legacy module/itemId for compatibility
    if (collection) {
      for (const sec of NAV_SECTIONS) for (const it of sec.items) {
        if (it.collection === collection) { module = it.id; break; }
      }
      itemId = id;
    }
    render();
  }

  function closeStudioTab(key, e) {
    if (e) e.stopPropagation();
    studioTabs = studioTabs.filter(t => t.key !== key);
    if (activeStudioKey === key) {
      activeStudioKey = studioTabs.length ? studioTabs[studioTabs.length - 1].key : null;
      if (!activeStudioKey) { itemId = null; }
    }
    render();
  }

  function countProjectWords() {
    let total = 0;
    const wordy = (html) => {
      if (!html) return 0;
      const text = String(html).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      return text ? text.split(/\s+/).length : 0;
    };
    for (const b of project.books || []) total += wordy(b.html || b.content || '');
    for (const c of project.chapters || []) total += wordy(c.html || c.content || c.description || '');
    return total;
  }

  function buildStudioHeader() {
    const head = el('header', 'wb-studio-header');
    const left = el('div', 'wb-studio-header-left');
    const mark = el('div', 'wb-studio-mark');
    mark.appendChild(icon('book', 16));
    left.appendChild(mark);
    const titles = el('div', 'wb-studio-titles');
    titles.appendChild(el('div', 'wb-studio-brand', 'Worldbuilding Studio'));
    const nameIn = input({
      value: project.name || '',
      aria: 'Projectnaam',
      cls: 'wb-studio-title-input',
    });
    nameIn.addEventListener('change', () => {
      project.name = nameIn.value.trim() || project.name;
      setDirty(); autoSave();
    });
    titles.appendChild(nameIn);
    left.appendChild(titles);
    head.appendChild(left);

    const right = el('div', 'wb-studio-header-right');
    const words = el('span', 'wb-studio-words');
    words.innerHTML = '<strong>' + countProjectWords().toLocaleString('nl-NL') + '</strong> woorden';
    right.appendChild(words);
    right.appendChild(btn(zenMode ? 'Zen uit' : 'Zen modus', {
      icon: 'expand',
      cls: 'wb-btn-ghost',
      onClick: () => { zenMode = !zenMode; render(); },
    }));
    right.appendChild(btn('Opslaan', { icon: 'save', onClick: () => persist() }));
    right.appendChild(btn('Exporteren', { icon: 'export', cls: 'wb-btn-primary', onClick: () => doExport() }));
    right.appendChild(iconBtn('back', {
      title: 'Alle projecten',
      cls: 'wb-btn-ghost',
      onClick: async () => {
        if (dirty) await persist();
        project = null;
        view = 'projects';
        studioTabs = [];
        activeStudioKey = null;
        zenMode = false;
        root.classList.remove('wb-studio-mode');
        index = await loadIndex();
        render();
      },
    }));
    head.appendChild(right);
    return head;
  }

  function buildStudioLeft() {
    const side = el('aside', 'wb-studio-left');
    const tabs = el('div', 'wb-studio-side-tabs');
    const mBtn = el('button', 'wb-studio-side-tab' + (sideTab === 'manuscript' ? ' active' : ''));
    mBtn.type = 'button';
    mBtn.appendChild(icon('book', 14));
    mBtn.appendChild(el('span', '', 'Manuscript'));
    mBtn.onclick = () => { sideTab = 'manuscript'; render(); };
    const wBtn = el('button', 'wb-studio-side-tab' + (sideTab === 'world' ? ' active' : ''));
    wBtn.type = 'button';
    wBtn.appendChild(icon('globe', 14));
    wBtn.appendChild(el('span', '', 'Worldbuilding'));
    wBtn.onclick = () => { sideTab = 'world'; render(); };
    tabs.append(mBtn, wBtn);
    side.appendChild(tabs);

    const body = el('div', 'wb-studio-side-body');
    if (sideTab === 'manuscript') body.appendChild(buildManuscriptTree());
    else body.appendChild(buildWorldTree());
    side.appendChild(body);

    const foot = el('div', 'wb-studio-side-foot');
    foot.appendChild(el('span', '', 'Offline · auto-save'));
    side.appendChild(foot);
    return side;
  }

  function chaptersForBook(bookId) {
    return (project.chapters || [])
      .filter(c => c.bookId === bookId)
      .sort((a, b) => {
        const ao = parseInt(a.order, 10);
        const bo = parseInt(b.order, 10);
        if (!isNaN(ao) && !isNaN(bo) && ao !== bo) return ao - bo;
        return (a.createdAt || '').localeCompare(b.createdAt || '');
      });
  }

  function chaptersForBook(bookId) {
    return (project.chapters || [])
      .filter(c => c.bookId === bookId)
      .sort((a, b) => {
        const ao = parseInt(a.order, 10);
        const bo = parseInt(b.order, 10);
        if (!isNaN(ao) && !isNaN(bo) && ao !== bo) return ao - bo;
        return (a.createdAt || '').localeCompare(b.createdAt || '');
      });
  }

  function addChapterToBook(bookId) {
    const existing = chaptersForBook(bookId);
    const item = createItem('chapters', {
      name: 'Hoofdstuk ' + (existing.length + 1),
      html: '<p><br></p>',
      bookId,
      order: String(existing.length + 1),
    });
    if (!project.chapters) project.chapters = [];
    project.chapters.push(item);
    openBookFolders.add(bookId);
    logActivity(project, 'create', 'Hoofdstuk aangemaakt', { collection: 'chapters', id: item.id });
    setDirty();
    autoSave();
    openStudioTab('chapter', 'chapters', item.id, item.name);
  }

  function deleteChapter(chapterId) {
    return (async () => {
      const ch = (project.chapters || []).find(c => c.id === chapterId);
      const name = ch?.name || 'dit hoofdstuk';
      if (!(await confirmDialog('Hoofdstuk "' + name + '" verwijderen?', { yes: 'Verwijderen', danger: true }))) return;
      project.chapters = (project.chapters || []).filter(c => c.id !== chapterId);
      const key = studioKey('chapter', 'chapters', chapterId);
      studioTabs = studioTabs.filter(t => t.key !== key);
      if (activeStudioKey === key) activeStudioKey = studioTabs.length ? studioTabs[studioTabs.length - 1].key : null;
      logActivity(project, 'delete', 'Hoofdstuk verwijderd', { collection: 'chapters', id: chapterId });
      setDirty();
      autoSave();
      toast('Hoofdstuk verwijderd');
      render();
    })();
  }

  function deleteBook(bookId) {
    return (async () => {
      const b = (project.books || []).find(x => x.id === bookId);
      const name = b?.name || 'dit boek';
      const n = chaptersForBook(bookId).length;
      const msg = n
        ? 'Boek "' + name + '" en ' + n + ' hoofdstuk(ken) verwijderen?'
        : 'Boek "' + name + '" verwijderen?';
      if (!(await confirmDialog(msg, { yes: 'Verwijderen', danger: true }))) return;
      project.books = (project.books || []).filter(x => x.id !== bookId);
      project.chapters = (project.chapters || []).filter(c => c.bookId !== bookId);
      openBookFolders.delete(bookId);
      // sluit open tabs voor dit boek + hoofdstukken
      studioTabs = studioTabs.filter(t => {
        if (t.collection === 'books' && t.id === bookId) return false;
        if (t.collection === 'chapters') {
          // chapter already removed from project; drop if id no longer exists
          return (project.chapters || []).some(c => c.id === t.id);
        }
        return true;
      });
      if (activeStudioKey && !studioTabs.some(t => t.key === activeStudioKey)) {
        activeStudioKey = studioTabs.length ? studioTabs[studioTabs.length - 1].key : null;
      }
      logActivity(project, 'delete', 'Boek verwijderd', { collection: 'books', id: bookId });
      setDirty();
      autoSave();
      toast('Boek verwijderd');
      render();
    })();
  }

  function buildManuscriptTree() {
    const wrap = el('div', 'wb-ms-tree');
    const head = el('div', 'wb-ms-head');
    head.appendChild(el('span', 'wb-ms-label', 'Boeken'));
    head.appendChild(btn('Boek', {
      icon: 'plus',
      cls: 'wb-btn-ghost wb-btn-xs',
      onClick: () => {
        const item = createItem('books', { name: 'Nieuw boek', html: '<p><br></p>' });
        if (!project.books) project.books = [];
        project.books.unshift(item);
        openBookFolders.add(item.id);
        logActivity(project, 'create', 'Boek aangemaakt', { collection: 'books', id: item.id });
        setDirty();
        autoSave();
        addChapterToBook(item.id);
      },
    }));
    wrap.appendChild(head);

    const books = project.books || [];
    const orphanChapters = (project.chapters || []).filter(c => !c.bookId || !books.some(b => b.id === c.bookId));

    if (!books.length && !orphanChapters.length) {
      wrap.appendChild(el('p', 'wb-ms-empty', 'Nog geen boeken. Maak een boek aan — hoofdstukken horen eronder.'));
      return wrap;
    }

    for (const b of books) {
      const chaps = chaptersForBook(b.id);
      if (chaps.length && !openBookFolders.has(b.id) && openBookFolders.size === 0) {
        openBookFolders.add(b.id);
      }
      const isOpen = openBookFolders.has(b.id);
      const bookActive = activeStudioKey === studioKey('book', 'books', b.id)
        || chaps.some(c => activeStudioKey === studioKey('chapter', 'chapters', c.id));

      const folder = el('div', 'wb-ms-folder' + (isOpen ? ' open' : '') + (bookActive ? ' has-active' : ''));

      const row = el('div', 'wb-ms-book-row');
      const toggle = el('button', 'wb-ms-toggle');
      toggle.type = 'button';
      toggle.title = isOpen ? 'Inklappen' : 'Uitklappen';
      toggle.textContent = isOpen ? '▾' : '▸';
      toggle.onclick = (e) => {
        e.stopPropagation();
        if (openBookFolders.has(b.id)) openBookFolders.delete(b.id);
        else openBookFolders.add(b.id);
        render();
      };
      row.appendChild(toggle);

      const bookBtn = el('button', 'wb-ms-item wb-ms-book' + (activeStudioKey === studioKey('book', 'books', b.id) ? ' active' : ''));
      bookBtn.type = 'button';
      bookBtn.appendChild(icon('book', 14));
      bookBtn.appendChild(el('span', '', b.name || 'Naamloos boek'));
      bookBtn.appendChild(el('span', 'wb-ms-count', String(chaps.length)));
      bookBtn.onclick = () => {
        openBookFolders.add(b.id);
        openStudioTab('book', 'books', b.id, b.name);
      };
      row.appendChild(bookBtn);

      const addChap = el('button', 'wb-ms-add-chap');
      addChap.type = 'button';
      addChap.title = 'Hoofdstuk toevoegen';
      addChap.textContent = '+';
      addChap.onclick = (e) => {
        e.stopPropagation();
        addChapterToBook(b.id);
      };
      row.appendChild(addChap);

      const delBook = el('button', 'wb-ms-del');
      delBook.type = 'button';
      delBook.title = 'Boek verwijderen';
      delBook.textContent = '×';
      delBook.onclick = (e) => {
        e.stopPropagation();
        deleteBook(b.id);
      };
      row.appendChild(delBook);
      folder.appendChild(row);

      if (isOpen) {
        const kids = el('div', 'wb-ms-children');
        if (!chaps.length) {
          kids.appendChild(el('p', 'wb-ms-empty', 'Nog geen hoofdstukken. Klik + om er een toe te voegen.'));
        }
        for (const c of chaps) {
          const crow = el('div', 'wb-ms-chapter-row');
          const cbtn = el('button', 'wb-ms-item wb-ms-chapter' + (activeStudioKey === studioKey('chapter', 'chapters', c.id) ? ' active' : ''));
          cbtn.type = 'button';
          cbtn.appendChild(icon('file-text', 13));
          cbtn.appendChild(el('span', '', c.name || 'Naamloos'));
          cbtn.onclick = () => {
            openBookFolders.add(b.id);
            openStudioTab('chapter', 'chapters', c.id, c.name);
          };
          crow.appendChild(cbtn);
          const delChap = el('button', 'wb-ms-del');
          delChap.type = 'button';
          delChap.title = 'Hoofdstuk verwijderen';
          delChap.textContent = '×';
          delChap.onclick = (e) => {
            e.stopPropagation();
            deleteChapter(c.id);
          };
          crow.appendChild(delChap);
          kids.appendChild(crow);
        }
        folder.appendChild(kids);
      }
      wrap.appendChild(folder);
    }

    if (orphanChapters.length) {
      wrap.appendChild(el('div', 'wb-ms-group-title', 'Zonder boek'));
      for (const c of orphanChapters) {
        const crow = el('div', 'wb-ms-chapter-row');
        const row = el('button', 'wb-ms-item' + (activeStudioKey === studioKey('chapter', 'chapters', c.id) ? ' active' : ''));
        row.type = 'button';
        row.appendChild(icon('file-text', 14));
        row.appendChild(el('span', '', c.name || 'Naamloos'));
        row.onclick = () => openStudioTab('chapter', 'chapters', c.id, c.name);
        crow.appendChild(row);
        const delChap = el('button', 'wb-ms-del');
        delChap.type = 'button';
        delChap.title = 'Hoofdstuk verwijderen';
        delChap.textContent = '×';
        delChap.onclick = (e) => {
          e.stopPropagation();
          deleteChapter(c.id);
        };
        crow.appendChild(delChap);
        wrap.appendChild(crow);
      }
    }

    return wrap;
  }

  function buildWorldTree() {
    const wrap = el('div', 'wb-ms-tree');
    const head = el('div', 'wb-ms-head');
    head.appendChild(el('span', 'wb-ms-label', 'Personages & lore'));
    head.appendChild(btn('Nieuw', {
      icon: 'plus',
      cls: 'wb-btn-ghost wb-btn-xs',
      onClick: () => openQuickCreate(),
    }));
    wrap.appendChild(head);

    const groups = [
      { label: 'Personages', icon: 'user', cols: [['characters', 'Personage']] },
      { label: 'Locaties', icon: 'map-pin', cols: [['locations', 'Locatie'], ['cities', 'Stad'], ['continents', 'Continent']] },
      { label: 'Items & magie', icon: 'gem', cols: [['artifacts', 'Artefact'], ['magic', 'Magie'], ['creatures', 'Wezen']] },
      { label: 'Lore & historie', icon: 'scroll', cols: [['events', 'Gebeurtenis'], ['factions', 'Factie'], ['religions', 'Religie'], ['notes', 'Notitie']] },
    ];

    for (const g of groups) {
      wrap.appendChild(el('div', 'wb-ms-group-title', g.label));
      let any = false;
      for (const [col, label] of g.cols) {
        for (const it of project[col] || []) {
          any = true;
          const row = el('button', 'wb-ms-item' + (activeStudioKey === studioKey('entity', col, it.id) ? ' active' : ''));
          row.type = 'button';
          row.appendChild(icon(g.icon, 14));
          row.appendChild(el('span', '', it.name || 'Naamloos'));
          row.onclick = () => openStudioTab('entity', col, it.id, it.name);
          wrap.appendChild(row);
        }
      }
      if (!any) wrap.appendChild(el('p', 'wb-ms-empty', 'Geen items'));
    }
    return wrap;
  }

  function tabIconName(t) {
    if (t.type === 'book') return 'book';
    if (t.type === 'chapter') return 'file-text';
    const col = t.collection || '';
    const map = {
      characters: 'user',
      locations: 'map-pin',
      cities: 'building',
      continents: 'globe',
      factions: 'shield',
      events: 'flag',
      artifacts: 'gem',
      magic: 'wand',
      creatures: 'dragon',
      religions: 'sun',
      notes: 'pen',
      ideas: 'lightbulb',
      cultures: 'sparkles',
      races: 'users',
      organizations: 'briefcase',
      languages: 'book',
      plots: 'scroll',
      eras: 'hourglass',
      wars: 'swords',
      dynasties: 'crown',
      biomes: 'leaf',
      maps: 'map',
      technology: 'cog',
      laws: 'scale',
      floraFauna: 'flower',
      themes: 'palette',
      concepts: 'box',
    };
    return map[col] || 'box';
  }

  function buildStudioCenter() {
    const main = el('main', 'wb-studio-center');
    const tabBar = el('div', 'wb-studio-tabbar');
    if (!studioTabs.length) {
      tabBar.appendChild(el('span', 'wb-studio-tabbar-empty', 'Open een boek, hoofdstuk of personage links'));
    } else {
      for (const t of studioTabs) {
        const tab = el('button', 'wb-studio-tab' + (t.key === activeStudioKey ? ' active' : ''));
        tab.type = 'button';
        tab.title = (t.type === 'book' ? 'Boek' : t.type === 'chapter' ? 'Hoofdstuk' : (schemaFor(t.collection)?.label || 'Item'))
          + ': ' + (t.title || '');
        const ic = icon(tabIconName(t), 13);
        ic.classList?.add?.('wb-studio-tab-icon');
        if (ic.setAttribute) ic.setAttribute('aria-hidden', 'true');
        tab.appendChild(ic);
        tab.appendChild(el('span', 'wb-studio-tab-label', t.title || 'Tab'));
        const x = el('span', 'wb-studio-tab-x', '×');
        x.onclick = (e) => closeStudioTab(t.key, e);
        tab.appendChild(x);
        tab.onclick = () => { activeStudioKey = t.key; itemId = t.id; render(); };
        tabBar.appendChild(tab);
      }
    }
    main.appendChild(tabBar);

    const editor = el('div', 'wb-studio-editor');
    const active = studioTabs.find(t => t.key === activeStudioKey);
    if (!active) {
      editor.appendChild(emptyState({
        icon: 'book',
        title: project.name || 'Jouw wereld',
        text: 'Kies links een manuscript of worldbuilding-item, of maak iets nieuws.',
        action: btn('Schrijf een boek', {
          cls: 'wb-btn-primary',
          icon: 'book',
          onClick: () => {
            const item = createItem('books', { name: 'Nieuw manuscript', html: '<p><br></p>' });
            if (!project.books) project.books = [];
            project.books.unshift(item);
            setDirty(); autoSave();
            openStudioTab('book', 'books', item.id, item.name);
          },
        }),
      }));
    } else if (active.type === 'book' || active.type === 'chapter') {
      editor.appendChild(buildStudioWriter(active));
    } else {
      editor.appendChild(buildStudioEntity(active));
    }
    main.appendChild(editor);
    return main;
  }

  function buildStudioWriter(tab) {
    const items = project[tab.collection] || [];
    const item = items.find(i => i.id === tab.id);
    if (!item) return el('p', '', 'Item niet gevonden.');

    const wrap = el('div', 'wb-studio-writer');
    const top = el('div', 'wb-studio-writer-top');
    const titleIn = input({ value: item.name || '', aria: 'Titel', cls: 'wb-studio-writer-title' });
    titleIn.placeholder = tab.type === 'book' ? 'Boektitel' : 'Hoofdstuktitel';
    top.appendChild(titleIn);
    const status = el('span', 'wb-save-status');
    top.appendChild(status);
    wrap.appendChild(top);

    // Eenvoudige opmaakbalk: alleen vet, cursief, onderstrepen
    const toolbar = el('div', 'wb-mini-toolbar');
    const cmds = [
      { cmd: 'bold', label: 'B', title: 'Vet (Ctrl+B)', cls: 'wb-fmt-b' },
      { cmd: 'italic', label: 'I', title: 'Cursief (Ctrl+I)', cls: 'wb-fmt-i' },
      { cmd: 'underline', label: 'U', title: 'Onderstrepen (Ctrl+U)', cls: 'wb-fmt-u' },
    ];
    for (const c of cmds) {
      const b = el('button', 'wb-mini-fmt ' + c.cls);
      b.type = 'button';
      b.title = c.title;
      b.setAttribute('aria-label', c.title);
      b.textContent = c.label;
      b.onmousedown = (e) => {
        e.preventDefault(); // focus blijft in de editor
        document.execCommand(c.cmd, false, null);
        area.focus();
        auto();
      };
      toolbar.appendChild(b);
    }
    wrap.appendChild(toolbar);

    const editorPane = el('div', 'wb-studio-writer-pane');
    const area = el('div', 'wb-mini-editor manuscript-editor');
    area.setAttribute('contenteditable', 'true');
    area.setAttribute('role', 'textbox');
    area.setAttribute('aria-multiline', 'true');
    area.setAttribute('aria-label', 'Manuscript');
    area.spellcheck = true;
    area.innerHTML = item.html || item.content || '<p><br></p>';
    editorPane.appendChild(area);
    wrap.appendChild(editorPane);

    const getHtml = () => area.innerHTML;
    const edApi = { getHtml, setHtml: (h) => { area.innerHTML = h; }, focus: () => area.focus() };

    const saveNow = () => {
      item.name = titleIn.value.trim() || item.name || 'Naamloos';
      item.html = getHtml();
      item.updatedAt = new Date().toISOString();
      tab.title = item.name;
      setDirty();
      persist().then(() => {
        status.textContent = 'Opgeslagen';
        status.className = 'wb-save-status saved';
      });
    };

    const auto = debounce(() => {
      try {
        item.html = getHtml();
        item.name = titleIn.value.trim() || item.name;
        item.updatedAt = new Date().toISOString();
        tab.title = item.name;
        setDirty();
        autoSave();
        status.textContent = 'Niet opgeslagen';
        status.className = 'wb-save-status dirty';
      } catch (_) {}
    }, 1200);

    titleIn.addEventListener('input', auto);
    area.addEventListener('input', auto);
    area.addEventListener('keydown', (e) => {
      if (!(e.ctrlKey || e.metaKey)) return;
      const k = e.key.toLowerCase();
      if (k === 'b') { e.preventDefault(); document.execCommand('bold'); auto(); }
      else if (k === 'i') { e.preventDefault(); document.execCommand('italic'); auto(); }
      else if (k === 'u') { e.preventDefault(); document.execCommand('underline'); auto(); }
      else if (k === 's') { e.preventDefault(); saveNow(); }
    });
    titleIn.addEventListener('change', () => {
      const tabEl = root.querySelector('.wb-studio-tab.active .wb-studio-tab-label');
      if (tabEl) tabEl.textContent = titleIn.value.trim() || 'Naamloos';
    });

    wrap._save = saveNow;
    queueMicrotask(() => area.focus());
    return wrap;
  }

  function buildStudioEntity(tab) {
    const items = project[tab.collection] || [];
    const item = items.find(i => i.id === tab.id);
    if (!item) return el('p', '', 'Item niet gevonden.');
    const schema = schemaFor(tab.collection);
    const wrap = el('div', 'wb-studio-entity');

    const head = el('div', 'wb-studio-entity-head');
    head.appendChild(el('span', 'wb-studio-entity-type', schema.label));
    const nameIn = input({ value: item.name || '', aria: 'Naam', cls: 'wb-studio-writer-title' });
    head.appendChild(nameIn);
    wrap.appendChild(head);

    const form = el('div', 'wb-form-grid');
    const descIn = textarea({ value: item.description || '', rows: 3, placeholder: 'Samenvatting…', aria: 'Beschrijving' });
    form.appendChild(field('Samenvatting', descIn));

    const fieldInputs = {};
    for (const f of schema.fields || []) {
      let ctrl;
      if (f.type === 'textarea') {
        ctrl = textarea({ value: item[f.key] || '', rows: 4, aria: f.label });
      } else {
        ctrl = input({ value: item[f.key] || '', aria: f.label });
      }
      fieldInputs[f.key] = ctrl;
      form.appendChild(field(f.label, ctrl));
    }
    wrap.appendChild(form);

    const actions = el('div', 'wb-form-actions');
    actions.appendChild(btn('Opslaan', {
      icon: 'save',
      cls: 'wb-btn-primary',
      onClick: () => {
        item.name = nameIn.value.trim() || item.name;
        item.description = descIn.value.trim();
        for (const [k, ctrl] of Object.entries(fieldInputs)) {
          item[k] = ctrl.value;
        }
        item.updatedAt = new Date().toISOString();
        tab.title = item.name;
        setDirty();
        persist();
        toast('Opgeslagen', 'success');
        render();
      },
    }));
    actions.appendChild(btn('Verwijderen', {
      cls: 'wb-btn-danger',
      onClick: async () => {
        if (!(await confirmDialog('Dit item verwijderen?', { yes: 'Verwijderen', danger: true }))) return;
        project[tab.collection] = (project[tab.collection] || []).filter(i => i.id !== item.id);
        setDirty();
        closeStudioTab(tab.key);
        autoSave();
      },
    }));
    wrap.appendChild(actions);

    nameIn.addEventListener('input', debounce(() => {
      item.name = nameIn.value.trim() || item.name;
      tab.title = item.name;
      setDirty();
      autoSave();
    }, 800));

    return wrap;
  }

  function collectionCount(col) {
    if (!col || !project) return 0;
    return Array.isArray(project[col]) ? project[col].length : 0;
  }

  const SECTION_ICONS = {
    world: 'globe',
    history: 'timeline',
    people: 'users',
    systems: 'wand',
    stories: 'book',
    analysis: 'network',
  };

  function goModule(id) {
    module = id;
    itemId = null;
    editing = false;
    bookMode = 'edit';
    listFilter = '';
    render();
  }

  function buildSidebar() {
    // Compact icon-rail — geen lange lijsten meer
    const side = el('aside', 'wb-sidebar wb-icon-rail');

    const head = el('div', 'wb-rail-head');
    const accent = el('div', 'wb-sidebar-accent');
    accent.style.background = project.accent || '#c9a227';
    head.appendChild(accent);
    head.title = project.name || 'Wereld';
    side.appendChild(head);

    const nav = el('nav', 'wb-rail-nav');

    // Dashboard
    const homeBtn = el('button', 'wb-rail-btn' + (module === 'dashboard' && !itemId ? ' active' : ''));
    homeBtn.type = 'button';
    homeBtn.title = 'Dashboard';
    homeBtn.setAttribute('aria-label', 'Dashboard');
    homeBtn.appendChild(icon('home', 20));
    homeBtn.onclick = () => goModule('dashboard');
    nav.appendChild(homeBtn);

    // Sectie-knoppen → springen naar dashboard-sectie of eerste module
    for (const sec of NAV_SECTIONS) {
      const first = sec.items[0];
      const secActive = sec.items.some(it => it.id === module);
      const b = el('button', 'wb-rail-btn' + (secActive ? ' active' : ''));
      b.type = 'button';
      b.title = sec.label;
      b.setAttribute('aria-label', sec.label);
      b.appendChild(icon(SECTION_ICONS[sec.id] || first?.icon || 'box', 20));
      const total = sec.items.reduce((n, it) => n + collectionCount(it.collection), 0);
      if (total > 0) {
        const badge = el('span', 'wb-rail-badge', total > 99 ? '99+' : String(total));
        b.appendChild(badge);
      }
      b.onclick = () => {
        // Ga naar dashboard en scroll naar deze sectie
        module = 'dashboard';
        itemId = null;
        editing = false;
        listFilter = '';
        render();
        queueMicrotask(() => {
          const elSec = root.querySelector('[data-dash-section="' + sec.id + '"]');
          if (elSec) elSec.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
      };
      nav.appendChild(b);
    }

    side.appendChild(nav);

    const foot = el('div', 'wb-rail-foot');
    const backBtn = el('button', 'wb-rail-btn');
    backBtn.type = 'button';
    backBtn.title = 'Alle projecten';
    backBtn.setAttribute('aria-label', 'Alle projecten');
    backBtn.appendChild(icon('back', 20));
    backBtn.onclick = async () => {
      if (dirty) await persist();
      project = null;
      view = 'projects';
      index = await loadIndex();
      render();
    };
    foot.appendChild(backBtn);
    side.appendChild(foot);
    return side;
  }

  function buildTopbar() {
    const bar = el('div', 'wb-topbar');
    if (module !== 'dashboard' || itemId) {
      bar.appendChild(iconBtn('home', {
        title: 'Dashboard',
        cls: 'wb-btn-ghost',
        onClick: () => goModule('dashboard'),
      }));
    }
    bar.appendChild(el('h2', 'wb-topbar-title', moduleTitle()));
    bar.appendChild(el('span', 'wb-save-status'));
    const actions = el('div', 'wb-topbar-actions');
    actions.appendChild(iconBtn('search', { title: 'Zoeken (Ctrl+K)', onClick: () => openCommandPalette() }));
    actions.appendChild(iconBtn('save', { title: 'Opslaan', onClick: () => persist() }));
    actions.appendChild(iconBtn('export', { title: 'Exporteren', onClick: () => doExport() }));
    bar.appendChild(actions);
    queueMicrotask(updateSaveStatus);
    return bar;
  }

  function moduleTitle() {
    if (itemId) {
      const col = collectionForModule(module);
      const item = col && (project[col] || []).find(i => i.id === itemId);
      return item?.name || 'Item';
    }
    for (const sec of NAV_SECTIONS) for (const it of sec.items) if (it.id === module) return it.label;
    return 'Worldbuilding';
  }

  function buildModuleView() {
    if (itemId) {
      const col = collectionForModule(module);
      if (col === 'books') return buildBookWriter();
      return buildDetailView();
    }
    if (module === 'dashboard') return buildDashboard();
    if (module === 'timeline') return buildTimeline();
    if (module === 'graph' || module === 'relations') return buildGraph();
    if (module === 'search') return buildSearch();
    if (module === 'tags') return buildTags();
    if (module === 'maps') return buildMapsModule();
    return buildCollectionList();
  }

  function openItem(collection, id) {
    for (const sec of NAV_SECTIONS) for (const it of sec.items)
      if (it.collection === collection) { module = it.id; itemId = id; editing = false; render(); return; }
    itemId = id; render();
  }

  function miniCard(collection, item) {
    const card = el('div', 'wb-mini-card');
    card.appendChild(el('h4', '', item.name || 'Naamloos'));
    if (item.description) card.appendChild(el('p', '', item.description));
    card.onclick = () => openItem(collection, item.id); return card;
  }

  function buildDashboard() {
    const wrap = el('div', 'wb-dashboard');

    // Hero
    const hero = el('div', 'wb-dash-hero');
    hero.style.setProperty('--wb-hero-accent', (project.accent || '#c9a227') + '33');
    const left = el('div');
    left.appendChild(el('h1', '', project.name || 'Wereld'));
    if (project.subtitle) left.appendChild(el('p', 'wb-dash-sub', project.subtitle));
    if (project.description) left.appendChild(el('p', 'wb-dash-desc', project.description));
    const meta = el('div', 'wb-project-meta');
    meta.style.marginTop = '.75rem';
    meta.appendChild(statusBadge(project.status || 'concept'));
    meta.appendChild(typeBadge(project.worldType || 'high-fantasy'));
    left.appendChild(meta);
    hero.appendChild(left);
    const heroActs = el('div', 'wb-dash-hero-acts');
    heroActs.appendChild(btn('Schrijf een boek', {
      icon: 'book', cls: 'wb-btn-primary',
      onClick: () => { module = 'books'; createNewItem('books'); },
    }));
    heroActs.appendChild(btn('Nieuwe inhoud', { icon: 'plus', onClick: () => openQuickCreate() }));
    hero.appendChild(heroActs);
    wrap.appendChild(hero);

    // Navigatie-hub: alle categorieën als icoonknoppen
    for (const sec of NAV_SECTIONS) {
      const secBlock = el('section', 'wb-dash-section');
      secBlock.setAttribute('data-dash-section', sec.id);
      const head = el('div', 'wb-dash-section-head');
      head.appendChild(icon(SECTION_ICONS[sec.id] || 'box', 18));
      head.appendChild(el('h3', 'wb-section-title', sec.label));
      secBlock.appendChild(head);

      const grid = el('div', 'wb-dash-nav-grid');
      for (const item of sec.items) {
        const n = collectionCount(item.collection);
        const tile = el('button', 'wb-dash-tile');
        tile.type = 'button';
        tile.appendChild(icon(item.icon, 22));
        tile.appendChild(el('span', 'wb-dash-tile-label', item.label));
        if (item.collection) {
          tile.appendChild(el('span', 'wb-dash-tile-count', String(n)));
        }
        tile.onclick = () => goModule(item.id);
        grid.appendChild(tile);
      }
      secBlock.appendChild(grid);
      wrap.appendChild(secBlock);
    }

    // Favorieten
    const favs = [];
    for (const col of Object.keys(emptyCollections())) {
      if (['activity', 'favorites', 'relations'].includes(col)) continue;
      for (const it of project[col] || []) if (it.favorite) favs.push({ collection: col, item: it });
    }
    if (favs.length) {
      wrap.appendChild(el('h3', 'wb-section-title', 'Favorieten'));
      const list = el('div', 'wb-card-list');
      for (const { collection, item } of favs.slice(0, 8)) list.appendChild(miniCard(collection, item));
      wrap.appendChild(list);
    }

    // Activiteit
    wrap.appendChild(el('h3', 'wb-section-title', 'Recente activiteit'));
    const acts = project.activity || [];
    if (!acts.length) {
      wrap.appendChild(emptyState({
        icon: 'scroll',
        title: 'Nog geen activiteit',
        text: 'Kies hierboven een categorie of start snel.',
        action: btn('Snel starten', { cls: 'wb-btn-primary', icon: 'plus', onClick: () => openQuickCreate() }),
      }));
    } else {
      const ul = el('ul', 'wb-activity-list');
      for (const a of acts.slice(0, 12)) {
        const li = el('li');
        li.appendChild(el('span', '', a.label || a.action));
        li.appendChild(el('time', '', formatRelative(a.at)));
        ul.appendChild(li);
      }
      wrap.appendChild(ul);
    }
    return wrap;
  }

  function buildCollectionList() {
    const col = collectionForModule(module);
    if (!col) return emptyState({ icon: 'box', title: 'Module', text: 'Geen collectie.' });
    const schema = schemaFor(col);
    const items = project[col] || [];
    const q = listFilter.trim().toLowerCase();
    const filtered = q ? items.filter(it => [it.name, it.description, ...(it.tags || [])].join(' ').toLowerCase().includes(q)) : items;
    const wrap = el('div');
    const toolbar = el('div', 'wb-toolbar');
    const filterIn = input({ placeholder: 'Zoek…', value: listFilter, aria: 'Filter' });
    filterIn.addEventListener('input', debounce(e => { listFilter = e.target.value; render(); const inp = root.querySelector('.wb-toolbar .wb-input'); if (inp) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); } }, 250));
    toolbar.appendChild(filterIn);
    toolbar.appendChild(btn('Nieuw ' + schema.label.toLowerCase(), { icon: 'plus', cls: 'wb-btn-primary', onClick: () => createNewItem(col) }));
    wrap.appendChild(toolbar);
    if (!filtered.length) {
      wrap.appendChild(emptyState({ icon: 'box',
        title: items.length ? 'Geen resultaten' : 'Nog geen ' + schema.labelPlural.toLowerCase(),
        text: items.length ? 'Pas je zoekopdracht aan.' : 'Maak je eerste item aan.',
        action: !items.length ? btn('Nieuw', { cls: 'wb-btn-primary', icon: 'plus', onClick: () => createNewItem(col) }) : null }));
      return wrap;
    }
    const grid = el('div', 'wb-item-grid');
    for (const item of filtered) grid.appendChild(itemCard(col, item));
    wrap.appendChild(grid); return wrap;
  }

  function itemCard(collection, item) {
    const card = el('div', 'wb-item-card');
    const head = el('div', 'wb-item-card-head');
    head.appendChild(el('h3', '', item.name || 'Naamloos'));
    if (item.favorite) { const star = icon('star-filled', 16); star.classList.add('wb-fav'); head.appendChild(star); }
    card.appendChild(head);
    if (item.description) card.appendChild(el('p', 'wb-item-desc', item.description));
    if (item.tags?.length) {
      const tags = el('div', 'wb-item-tags');
      for (const t of item.tags.slice(0, 5)) tags.appendChild(el('span', 'wb-tag', t));
      card.appendChild(tags);
    }
    card.onclick = () => { itemId = item.id; editing = false; render(); };
    return card;
  }

  function createNewItem(collection) {
    const schema = schemaFor(collection);
    const item = createItem(collection, { name: 'Nieuw ' + schema.label.toLowerCase() });
    if (!project[collection]) project[collection] = [];
    project[collection].unshift(item);
    logActivity(project, 'create', schema.label + ' "' + item.name + '" aangemaakt', { collection, id: item.id });
    setDirty(); autoSave(); itemId = item.id; editing = true; render();
  }

  function findItemById(id) {
    for (const col of Object.keys(emptyCollections())) {
      if (['activity','favorites','relations'].includes(col)) continue;
      const found = (project[col] || []).find(i => i.id === id);
      if (found) return { ...found, _collection: col };
    }
    return null;
  }
  function relationLabel(type) { return RELATION_TYPES.find(r => r.id === type)?.label || type; }

  function buildDetailView() {
    const col = collectionForModule(module);
    if (!col) return el('div', '', 'Onbekend');
    const item = (project[col] || []).find(i => i.id === itemId);
    if (!item) { itemId = null; return buildCollectionList(); }
    const schema = schemaFor(col);
    const wrap = el('div', 'wb-detail');
    const head = el('div', 'wb-detail-head');
    const backRow = el('div'); backRow.style.marginBottom = '.75rem';
    backRow.appendChild(btn('Terug naar lijst', { icon: 'back', cls: 'wb-btn-ghost', onClick: () => { itemId = null; editing = false; render(); } }));
    head.appendChild(backRow);

    if (!editing) {
      const titleRow = el('div'); titleRow.style.cssText = 'display:flex;align-items:center;gap:.75rem';
      titleRow.appendChild(el('h1', '', item.name || 'Naamloos'));
      if (item.favorite) { const s = icon('star-filled', 20); s.classList.add('wb-fav'); titleRow.appendChild(s); }
      head.appendChild(titleRow);
      if (item.description) { const d = el('p', ''); d.style.cssText = 'color:var(--wb-mute);margin-top:.5rem'; d.textContent = item.description; head.appendChild(d); }
      wrap.appendChild(head);
      const grid = el('div', 'wb-form-grid');
      for (const f of schema.fields) {
        const val = item[f.key]; if (val == null || val === '') continue;
        const block = el('div', 'wb-field');
        block.appendChild(el('div', 'wb-label', f.label));
        const v = el('div', ''); v.style.whiteSpace = 'pre-wrap'; v.textContent = String(val);
        block.appendChild(v); grid.appendChild(block);
      }
      if (item.customFields) for (const [k, v] of Object.entries(item.customFields)) {
        if (v == null || v === '') continue;
        const block = el('div', 'wb-field');
        block.appendChild(el('div', 'wb-label', k));
        const val = el('div', ''); val.style.whiteSpace = 'pre-wrap'; val.textContent = String(v);
        block.appendChild(val); grid.appendChild(block);
      }
      wrap.appendChild(grid);
      if (item.tags?.length) {
        const tags = el('div', 'wb-item-tags'); tags.style.marginTop = '1rem';
        for (const t of item.tags) tags.appendChild(el('span', 'wb-tag', t));
        wrap.appendChild(tags);
      }
      const rels = (project.relations || []).filter(r => r.fromId === item.id || r.toId === item.id);
      if (rels.length) {
        wrap.appendChild(el('h3', 'wb-section-title', 'Relaties'));
        const rl = el('div', 'wb-rel-list');
        for (const r of rels) {
          const otherId = r.fromId === item.id ? r.toId : r.fromId;
          const other = findItemById(otherId);
          const row = el('div', 'wb-rel-row');
          row.appendChild(el('span', 'wb-rel-type', relationLabel(r.type)));
          row.appendChild(el('span', '', other?.name || otherId));
          if (other) { row.style.cursor = 'pointer'; row.onclick = () => openItem(other._collection, other.id); }
          rl.appendChild(row);
        }
        wrap.appendChild(rl);
      }
      const acts = el('div', 'wb-form-actions');
      acts.appendChild(btn('Bewerken', { icon: 'edit', cls: 'wb-btn-primary', onClick: () => { editing = true; render(); } }));
      acts.appendChild(btn(item.favorite ? 'Uit favorieten' : 'Favoriet', { icon: 'star', onClick: () => {
        item.favorite = !item.favorite; item.updatedAt = new Date().toISOString(); setDirty(); autoSave(); render();
      }}));
      acts.appendChild(btn('Relatie toevoegen', { icon: 'git-branch', onClick: () => openRelationForm(item) }));
      acts.appendChild(btn('Verwijderen', { icon: 'trash', cls: 'wb-btn-danger', onClick: async () => {
        if (!(await confirmDialog('"' + item.name + '" verwijderen?', { yes: 'Verwijderen', danger: true }))) return;
        project[col] = (project[col] || []).filter(i => i.id !== item.id);
        project.relations = (project.relations || []).filter(r => r.fromId !== item.id && r.toId !== item.id);
        logActivity(project, 'delete', schema.label + ' verwijderd');
        setDirty(); autoSave(); itemId = null; render();
      }}));
      wrap.appendChild(acts);
    } else {
      wrap.appendChild(head);
      const form = el('div', 'wb-form-grid');
      const nameIn = input({ value: item.name || '', aria: 'Naam' });
      const descIn = textarea({ value: item.description || '', rows: 4, aria: 'Beschrijving' });
      const tagsIn = input({ value: (item.tags || []).join(', '), placeholder: 'tag1, tag2', aria: 'Tags' });
      form.append(field('Naam *', nameIn), field('Beschrijving', descIn), field('Tags', tagsIn));
      const fieldInputs = {};
      for (const f of schema.fields) {
        const ctrl = f.type === 'textarea' ? textarea({ value: item[f.key] || '', rows: 3, aria: f.label }) : input({ value: item[f.key] || '', aria: f.label });
        fieldInputs[f.key] = ctrl; form.appendChild(field(f.label, ctrl));
      }
      const customWrap = el('div', 'wb-field');
      customWrap.appendChild(el('div', 'wb-label', 'Aangepaste velden (sleutel: waarde)'));
      const customIn = textarea({
        value: Object.entries(item.customFields || {}).map(([k, v]) => k + ': ' + v).join('\n'),
        rows: 3, placeholder: 'mapX: 45\nmapY: 60', aria: 'Custom',
      });
      customWrap.appendChild(customIn); form.appendChild(customWrap); wrap.appendChild(form);
      const acts = el('div', 'wb-form-actions');
      acts.appendChild(btn('Opslaan', { icon: 'save', cls: 'wb-btn-primary', onClick: () => {
        const name = nameIn.value.trim();
        if (!name) { toast('Naam verplicht', 'error'); return; }
        item.name = name; item.description = descIn.value.trim();
        item.tags = tagsIn.value.split(',').map(t => t.trim()).filter(Boolean);
        for (const f of schema.fields) item[f.key] = fieldInputs[f.key].value;
        const cf = {};
        for (const line of customIn.value.split('\n')) {
          const m = line.match(/^([^:]+):\s*(.*)$/);
          if (m) cf[m[1].trim()] = m[2].trim();
        }
        item.customFields = cf;
        if (cf.mapX != null) item.mapX = parseFloat(cf.mapX) || item.mapX;
        if (cf.mapY != null) item.mapY = parseFloat(cf.mapY) || item.mapY;
        item.updatedAt = new Date().toISOString();
        logActivity(project, 'update', schema.label + ' bijgewerkt', { collection: col, id: item.id });
        editing = false; setDirty(); autoSave(); render(); toast('Opgeslagen', 'success');
      }}));
      acts.appendChild(btn('Annuleren', { onClick: () => { editing = false; render(); } }));
      wrap.appendChild(acts);
    }
    return wrap;
  }

  function openRelationForm(fromItem) {
    const form = el('div', 'wb-form-grid');
    const typeSel = select(RELATION_TYPES, { value: 'related', aria: 'Type' });
    const options = [{ id: '', label: '— kies item —' }];
    for (const col of Object.keys(emptyCollections())) {
      if (['activity','favorites','relations'].includes(col)) continue;
      for (const it of project[col] || []) {
        if (it.id === fromItem.id) continue;
        options.push({ id: it.id, label: it.name + ' (' + schemaFor(col).label + ')' });
      }
    }
    const toSel = select(options, { value: '', aria: 'Doel' });
    form.append(field('Type', typeSel), field('Naar', toSel));
    document.body.appendChild(modal({
      title: 'Relatie vanuit "' + fromItem.name + '"', body: form,
      actions: [
        { label: 'Annuleren' },
        { label: 'Toevoegen', primary: true, onClick: () => {
          if (!toSel.value) { toast('Kies een item', 'error'); return false; }
          if (!project.relations) project.relations = [];
          project.relations.push({ id: 'rel_' + Date.now().toString(36), fromId: fromItem.id, toId: toSel.value, type: typeSel.value });
          setDirty(); autoSave(); render(); toast('Relatie toegevoegd', 'success');
        }},
      ],
    }));
  }

  function buildTimeline() {
    const wrap = el('div');
    const toolbar = el('div', 'wb-toolbar');
    toolbar.appendChild(btn('Nieuw tijdperk', { icon: 'hourglass', onClick: () => createNewItem('eras') }));
    toolbar.appendChild(btn('Nieuwe gebeurtenis', { icon: 'flag', cls: 'wb-btn-primary', onClick: () => createNewItem('events') }));
    wrap.appendChild(toolbar);
    const eras = [...(project.eras || [])].sort((a, b) => String(a.dateStart || '').localeCompare(String(b.dateStart || '')));
    const events = [...(project.events || [])].sort((a, b) => String(a.dateStart || '').localeCompare(String(b.dateStart || '')));
    if (!eras.length && !events.length) {
      wrap.appendChild(emptyState({ icon: 'timeline', title: 'Lege tijdlijn', text: 'Voeg tijdperken en gebeurtenissen toe.',
        action: btn('Eerste gebeurtenis', { cls: 'wb-btn-primary', icon: 'plus', onClick: () => createNewItem('events') }) }));
      return wrap;
    }
    if (project.calendar?.name) {
      const info = el('p', ''); info.style.cssText = 'color:var(--wb-mute);font-size:.9em';
      info.textContent = 'Kalender: ' + project.calendar.name; wrap.appendChild(info);
    }
    const tl = el('div', 'wb-timeline');
    function tlEventCard(ev) {
      const card = el('div', 'wb-tl-event');
      if (ev.dateStart || ev.dateEnd) card.appendChild(el('div', 'wb-tl-date', [ev.dateStart, ev.dateEnd].filter(Boolean).join(' — ')));
      card.appendChild(el('h4', '', ev.name || 'Gebeurtenis'));
      if (ev.description) card.appendChild(el('p', '', ev.description));
      card.onclick = () => { module = 'events'; itemId = ev.id; render(); };
      return card;
    }
    if (eras.length) {
      const assigned = new Set();
      for (const era of eras) {
        const block = el('div', 'wb-tl-era');
        const title = el('h3', 'wb-tl-era-title', era.name || 'Tijdperk');
        title.style.cursor = 'pointer';
        title.onclick = () => { module = 'eras'; itemId = era.id; render(); };
        block.appendChild(title);
        for (const ev of events) if (ev.era && ev.era === era.name) { assigned.add(ev.id); block.appendChild(tlEventCard(ev)); }
        tl.appendChild(block);
      }
      const rest = events.filter(e => !assigned.has(e.id));
      if (rest.length) {
        const block = el('div', 'wb-tl-era');
        block.appendChild(el('h3', 'wb-tl-era-title', 'Overige gebeurtenissen'));
        for (const ev of rest) block.appendChild(tlEventCard(ev));
        tl.appendChild(block);
      }
    } else for (const ev of events) tl.appendChild(tlEventCard(ev));
    wrap.appendChild(tl); return wrap;
  }

  function buildGraph() {
    const wrap = el('div');
    wrap.appendChild(el('p', '', 'Kennisgrafiek: sleep knooppunten, klik om te openen.'));
    const toolbar = el('div', 'wb-toolbar');
    toolbar.appendChild(btn('Relatie toevoegen', { icon: 'plus', cls: 'wb-btn-primary', onClick: () => {
      const any = (project.characters || [])[0] || (project.locations || [])[0] || (project.factions || [])[0];
      if (!any) { toast('Maak eerst items', 'error'); return; }
      openRelationForm(any);
    }}));
    wrap.appendChild(toolbar);
    const nodes = [], nodeMap = new Map();
    const cols = [['characters','#b8922a'],['locations','#7a1f2b'],['cities','#6b4a35'],['factions','#c45c6a'],['events','#a89888'],['artifacts','#e0b84a']];
    for (const [col, color] of cols) for (const it of project[col] || []) {
      const n = { id: it.id, label: it.name || '?', collection: col, color, x: 0, y: 0, vx: 0, vy: 0 };
      nodes.push(n); nodeMap.set(it.id, n);
    }
    if (!nodes.length) {
      wrap.appendChild(emptyState({ icon: 'network', title: 'Geen knooppunten', text: 'Voeg personages of locaties toe.' }));
      return wrap;
    }
    const W = 800, H = 500;
    nodes.forEach((n, i) => {
      const angle = (i / nodes.length) * Math.PI * 2, r = 120 + (i % 5) * 30;
      n.x = W / 2 + Math.cos(angle) * r; n.y = H / 2 + Math.sin(angle) * r;
    });
    const edges = [];
    for (const r of project.relations || [])
      if (nodeMap.has(r.fromId) && nodeMap.has(r.toId)) edges.push({ from: r.fromId, to: r.toId });
    const graphWrap = el('div', 'wb-graph-wrap');
    const canvas = document.createElement('canvas'); canvas.width = W; canvas.height = H;
    graphWrap.appendChild(canvas);
    const legend = el('div', 'wb-graph-legend');
    legend.textContent = nodes.length + ' knooppunten · ' + edges.length + ' relaties';
    graphWrap.appendChild(legend); wrap.appendChild(graphWrap);
    const ctx = canvas.getContext('2d');
    let anim = null, drag = null, offset = { x: 0, y: 0 };
    function simStep() {
      for (const n of nodes) { n.vx *= 0.85; n.vy *= 0.85; }
      for (let i = 0; i < nodes.length; i++) for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i], b = nodes[j];
        let dx = a.x - b.x, dy = a.y - b.y, dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = 800 / (dist * dist); dx = (dx / dist) * force; dy = (dy / dist) * force;
        a.vx += dx; a.vy += dy; b.vx -= dx; b.vy -= dy;
      }
      for (const e of edges) {
        const a = nodeMap.get(e.from), b = nodeMap.get(e.to); if (!a || !b) continue;
        let dx = b.x - a.x, dy = b.y - a.y, dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = (dist - 100) * 0.02; dx = (dx / dist) * force; dy = (dy / dist) * force;
        a.vx += dx; a.vy += dy; b.vx -= dx; b.vy -= dy;
      }
      for (const n of nodes) {
        n.vx += (W / 2 - n.x) * 0.005; n.vy += (H / 2 - n.y) * 0.005;
        if (drag !== n) { n.x += n.vx; n.y += n.vy; }
      }
    }
    function draw() {
      ctx.clearRect(0, 0, W, H); ctx.save(); ctx.translate(offset.x, offset.y);
      ctx.strokeStyle = getComputedStyle(root).getPropertyValue('--line').trim() || 'rgba(0,0,0,0.2)'; ctx.lineWidth = 1.5;
      for (const e of edges) {
        const a = nodeMap.get(e.from), b = nodeMap.get(e.to); if (!a || !b) continue;
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      }
      for (const n of nodes) {
        ctx.beginPath(); ctx.arc(n.x, n.y, 10, 0, Math.PI * 2);
        ctx.fillStyle = n.color; ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,0.4)'; ctx.stroke();
        ctx.fillStyle = getComputedStyle(root).getPropertyValue('--ink').trim() || '#1a1410'; ctx.font = '12px system-ui'; ctx.textAlign = 'center';
        ctx.fillText(n.label.slice(0, 22), n.x, n.y + 22);
      }
      ctx.restore();
    }
    function loop() { simStep(); draw(); anim = requestAnimationFrame(loop); }
    anim = requestAnimationFrame(loop);
    function toWorld(mx, my) { return { x: mx - offset.x, y: my - offset.y }; }
    canvas.addEventListener('mousedown', e => {
      const rect = canvas.getBoundingClientRect();
      const mx = ((e.clientX - rect.left) / rect.width) * W, my = ((e.clientY - rect.top) / rect.height) * H;
      const w = toWorld(mx, my);
      for (const n of nodes) { const dx = n.x - w.x, dy = n.y - w.y; if (dx * dx + dy * dy < 256) { drag = n; return; } }
      drag = { pan: true, lx: mx, ly: my };
    });
    canvas.addEventListener('mousemove', e => {
      if (!drag) return;
      const rect = canvas.getBoundingClientRect();
      const mx = ((e.clientX - rect.left) / rect.width) * W, my = ((e.clientY - rect.top) / rect.height) * H;
      if (drag.pan) { offset.x += mx - drag.lx; offset.y += my - drag.ly; drag.lx = mx; drag.ly = my; }
      else { const w = toWorld(mx, my); drag.x = w.x; drag.y = w.y; drag.vx = 0; drag.vy = 0; }
    });
    canvas.addEventListener('mouseup', () => {
      if (drag && !drag.pan && drag.id) { const n = drag; drag = null; cancelAnimationFrame(anim); openItem(n.collection, n.id); }
      else drag = null;
    });
    canvas.addEventListener('mouseleave', () => { drag = null; });
    root._wbGraphCleanup = () => { if (anim) cancelAnimationFrame(anim); };
    return wrap;
  }

  function buildMapsModule() {
    const wrap = el('div');
    const toolbar = el('div', 'wb-toolbar');
    toolbar.appendChild(btn('Nieuwe kaart', { icon: 'plus', cls: 'wb-btn-primary', onClick: () => createNewItem('maps') }));
    wrap.appendChild(toolbar);
    const maps = project.maps || [];
    if (maps.length) {
      wrap.appendChild(el('h3', 'wb-section-title', 'Kaarten'));
      const grid = el('div', 'wb-item-grid');
      for (const m of maps) grid.appendChild(itemCard('maps', m));
      wrap.appendChild(grid);
    }
    wrap.appendChild(el('h3', 'wb-section-title', 'Wereldkaart'));
    const mapWrap = el('div', 'wb-map-wrap');
    const canvas = el('div', 'wb-map-canvas');
    const markers = [];
    for (const col of ['locations', 'cities', 'continents']) {
      for (const it of project[col] || []) {
        if (it.mapX != null && it.mapY != null) markers.push({ item: it, collection: col });
        else if (it.customFields?.mapX != null)
          markers.push({ item: { ...it, mapX: parseFloat(it.customFields.mapX), mapY: parseFloat(it.customFields.mapY || 50) }, collection: col });
      }
    }
    if (!markers.length) {
      const all = [...(project.locations || []).map(i => ({ item: i, collection: 'locations' })),
        ...(project.cities || []).map(i => ({ item: i, collection: 'cities' }))].slice(0, 12);
      all.forEach((m, i) => {
        const angle = (i / Math.max(all.length, 1)) * Math.PI * 2;
        markers.push({ item: { ...m.item, mapX: 50 + Math.cos(angle) * 28, mapY: 50 + Math.sin(angle) * 22 }, collection: m.collection });
      });
    }
    for (const m of markers) {
      const mk = el('div', 'wb-map-marker');
      mk.style.left = (m.item.mapX || 50) + '%'; mk.style.top = (m.item.mapY || 50) + '%';
      mk.appendChild(el('div', 'wb-map-marker-dot'));
      mk.appendChild(el('div', 'wb-map-marker-label', m.item.name || '?'));
      mk.onclick = () => openItem(m.collection, m.item.id);
      canvas.appendChild(mk);
    }
    mapWrap.appendChild(canvas); wrap.appendChild(mapWrap);
    const tip = el('p', ''); tip.style.cssText = 'color:var(--wb-mute);font-size:.85em;margin-top:.75rem';
    tip.textContent = 'Tip: voeg in aangepaste velden mapX: 45 en mapY: 60 toe (percentages).';
    wrap.appendChild(tip); return wrap;
  }

  function buildSearch() {
    const wrap = el('div');
    const toolbar = el('div', 'wb-toolbar');
    const qIn = input({ placeholder: 'Zoek…', value: searchQuery, aria: 'Zoeken' });
    toolbar.appendChild(qIn); wrap.appendChild(toolbar);
    const resultsEl = el('div', 'wb-search-results'); wrap.appendChild(resultsEl);
    function run() {
      searchQuery = qIn.value; resultsEl.innerHTML = '';
      if (!searchQuery.trim()) {
        resultsEl.appendChild(emptyState({ icon: 'search', title: 'Zoeken', text: 'Typ een naam, trefwoord of tag.' }));
        return;
      }
      const hits = searchProject(project, searchQuery);
      if (!hits.length) {
        resultsEl.appendChild(emptyState({ icon: 'search', title: 'Geen resultaten', text: 'Niets voor "' + searchQuery + '".' }));
        return;
      }
      for (const { collection, item } of hits.slice(0, 50)) {
        const hit = el('button', 'wb-search-hit');
        hit.appendChild(icon('file-text', 16));
        hit.appendChild(el('strong', '', item.name || 'Naamloos'));
        hit.appendChild(el('span', 'wb-hit-col', schemaFor(collection).label));
        hit.onclick = () => openItem(collection, item.id);
        resultsEl.appendChild(hit);
      }
    }
    qIn.addEventListener('input', debounce(run, 200));
    queueMicrotask(run); queueMicrotask(() => qIn.focus());
    return wrap;
  }

  function buildTags() {
    const wrap = el('div');
    const tagMap = new Map();
    for (const col of Object.keys(emptyCollections())) {
      if (['activity','favorites','relations'].includes(col)) continue;
      for (const it of project[col] || []) for (const t of it.tags || []) {
        if (!tagMap.has(t)) tagMap.set(t, []);
        tagMap.get(t).push({ collection: col, item: it });
      }
    }
    if (!tagMap.size) return emptyState({ icon: 'tag', title: 'Geen tags', text: 'Voeg tags toe bij items.' });
    for (const [tag, items] of [...tagMap.entries()].sort((a, b) => b[1].length - a[1].length)) {
      wrap.appendChild(el('h3', 'wb-section-title', tag + ' (' + items.length + ')'));
      const list = el('div', 'wb-card-list');
      for (const { collection, item } of items.slice(0, 12)) list.appendChild(miniCard(collection, item));
      wrap.appendChild(list);
    }
    return wrap;
  }


  function buildBookWriter() {
    const col = 'books';
    const items = project[col] || [];
    const item = items.find(i => i.id === itemId);
    if (!item) { itemId = null; return buildCollectionList(); }

    const isRead = bookMode === 'read';
    const wrap = el('div', 'wb-book-writer' + (isRead ? ' wb-book-reading' : ''));

    // Top bar always present
    const top = el('div', 'wb-book-top');
    const leftMeta = el('div', 'wb-book-meta');
    leftMeta.appendChild(btn('Terug', {
      icon: 'back', cls: 'wb-btn-ghost',
      onClick: () => { itemId = null; editing = false; bookMode = 'edit'; render(); },
    }));
    if (isRead) {
      leftMeta.appendChild(el('h2', 'wb-book-read-title', item.name || 'Naamloos manuscript'));
    } else {
      const titleIn = input({ value: item.name || '', aria: 'Boektitel', cls: 'wb-book-title-input' });
      titleIn.placeholder = 'Boektitel';
      leftMeta.appendChild(titleIn);
      wrap._titleIn = titleIn;
    }
    top.appendChild(leftMeta);

    const actions = el('div', 'wb-book-actions');
    const statusEl = el('span', 'wb-save-status');
    actions.appendChild(statusEl);

    // Mode toggle
    const modeToggle = el('div', 'wb-book-mode-toggle');
    const editBtn = btn('Bewerken', {
      icon: 'pen',
      cls: 'wb-btn-ghost' + (!isRead ? ' active' : ''),
      onClick: () => { bookMode = 'edit'; render(); },
    });
    const readBtn = btn('Lezen', {
      icon: 'book',
      cls: 'wb-btn-ghost' + (isRead ? ' active' : ''),
      onClick: () => { bookMode = 'read'; render(); },
    });
    modeToggle.append(editBtn, readBtn);
    actions.appendChild(modeToggle);

    if (!isRead) {
      actions.appendChild(btn('Opslaan', {
        icon: 'save', cls: 'wb-btn-primary',
        onClick: () => saveBookNow(),
      }));
    }
    top.appendChild(actions);
    wrap.appendChild(top);

    if (isRead) {
      // —— LEESMODUS ——
      const reader = el('div', 'wb-book-reader');
      const metaBits = [];
      if (item.genre) metaBits.push(item.genre);
      if (item.status) metaBits.push(item.status);
      if (metaBits.length) {
        reader.appendChild(el('p', 'wb-book-reader-meta', metaBits.join(' · ')));
      }
      if (item.synopsis || item.description) {
        reader.appendChild(el('p', 'wb-book-reader-synopsis', item.synopsis || item.description));
      }
      const content = el('article', 'wb-book-reader-content');
      content.innerHTML = item.html || '<p><em>Nog geen tekst. Schakel naar Bewerken om te schrijven.</em></p>';
      // Klikbare world-refs
      content.querySelectorAll('[data-wb-ref]').forEach(node => {
        node.style.cursor = 'pointer';
        node.addEventListener('click', (e) => {
          e.preventDefault();
          const id = node.getAttribute('data-wb-ref');
          const c = node.getAttribute('data-wb-col');
          if (id && c) openItem(c, id);
        });
      });
      reader.appendChild(content);
      wrap.appendChild(reader);
      return wrap;
    }

    // —— BEWERKMODUS ——
    const titleIn = wrap._titleIn;
    const metaRow = el('div', 'wb-book-fields');
    const genreIn = input({ value: item.genre || '', placeholder: 'Genre', aria: 'Genre' });
    const statusIn = input({ value: item.status || 'klad', placeholder: 'Status', aria: 'Status' });
    const synIn = textarea({ value: item.synopsis || item.description || '', rows: 2, placeholder: 'Synopsis…', aria: 'Synopsis' });
    metaRow.append(
      field('Genre', genreIn),
      field('Status', statusIn),
      field('Synopsis', synIn)
    );
    wrap.appendChild(metaRow);

    const body = el('div', 'wb-book-body');
    const editorPane = el('div', 'wb-book-editor-pane');
    const side = el('div', 'wb-book-side');

    side.appendChild(el('h3', 'wb-section-title', 'Wereld integreren'));
    side.appendChild(el('p', 'wb-book-side-hint', 'Klik om een verwijzing in je manuscript te zetten. De tekst blijft gekoppeld aan dit worldbuildingproject.'));

    const searchIn = input({ placeholder: 'Zoek personage, locatie…', aria: 'Zoek in wereld' });
    side.appendChild(searchIn);
    const hits = el('div', 'wb-book-entity-list');
    side.appendChild(hits);

    function entityList(q = '') {
      hits.innerHTML = '';
      const qq = q.trim().toLowerCase();
      const cols = [
        ['characters', 'Personage'],
        ['locations', 'Locatie'],
        ['cities', 'Stad'],
        ['factions', 'Factie'],
        ['events', 'Gebeurtenis'],
        ['artifacts', 'Artefact'],
        ['creatures', 'Wezen'],
      ];
      let n = 0;
      for (const [c, label] of cols) {
        for (const it of project[c] || []) {
          if (qq && !(it.name || '').toLowerCase().includes(qq)) continue;
          const b = el('button', 'wb-book-entity');
          b.type = 'button';
          b.appendChild(el('span', 'wb-hit-col', label));
          b.appendChild(el('strong', '', it.name || 'Naamloos'));
          b.onclick = () => insertEntity(c, it);
          hits.appendChild(b);
          n++;
          if (n >= 40) break;
        }
        if (n >= 40) break;
      }
      if (!n) hits.appendChild(el('p', '', 'Geen items. Maak eerst personages of locaties in dit project.'));
    }
    searchIn.addEventListener('input', debounce(() => entityList(searchIn.value), 200));
    entityList();

    side.appendChild(el('h3', 'wb-section-title', 'Snel'));
    const quick = el('div', 'wb-book-quick');
    quick.appendChild(btn('Nieuw personage', { icon: 'user', onClick: () => {
      createNewItem('characters');
    }}));
    quick.appendChild(btn('Nieuwe locatie', { icon: 'map-pin', onClick: () => {
      module = 'regions';
      createNewItem('locations');
    }}));
    side.appendChild(quick);

    let edApi = null;
    try {
      edApi = createEditor(item.html || '<p><br></p>', { ask });
      if (edApi.setTitle) edApi.setTitle(item.name || 'manuscript');
      editorPane.appendChild(edApi.bar);
      if (edApi.spacer) editorPane.appendChild(edApi.spacer);
      editorPane.appendChild(edApi.area);
    } catch (err) {
      console.error(err);
      const fallback = textarea({ value: item.html || '', rows: 20, aria: 'Manuscript' });
      fallback.className = (fallback.className || '') + ' wb-book-fallback';
      editorPane.appendChild(fallback);
      edApi = {
        getHtml: () => fallback.value,
        setHtml: (h) => { fallback.value = h; },
        focus: () => fallback.focus(),
      };
    }

    function insertEntity(collection, it) {
      const label = schemaFor(collection).label;
      const snippet = `<span data-wb-ref="${it.id}" data-wb-col="${collection}" class="wb-inline-ref" title="${label}">${it.name || 'Item'}</span>`;
      try {
        edApi.focus?.();
        const ok = document.execCommand('insertHTML', false, snippet + '\u00a0');
        if (!ok && edApi.getHtml && edApi.setHtml) {
          edApi.setHtml((edApi.getHtml() || '') + snippet);
        }
      } catch {
        if (edApi.getHtml && edApi.setHtml) edApi.setHtml((edApi.getHtml() || '') + ' ' + (it.name || ''));
      }
      if (!project.relations) project.relations = [];
      const exists = project.relations.some(r => r.fromId === item.id && r.toId === it.id);
      if (!exists) {
        project.relations.push({
          id: 'rel_' + Date.now().toString(36),
          fromId: item.id,
          toId: it.id,
          type: 'related',
          note: 'Vermeld in boek',
        });
      }
      setDirty();
      toast(it.name + ' ingevoegd', 'success');
    }

    function saveBookNow() {
      item.name = titleIn.value.trim() || item.name || 'Naamloos manuscript';
      item.genre = genreIn.value.trim();
      item.status = statusIn.value.trim();
      item.synopsis = synIn.value.trim();
      item.description = item.synopsis;
      try { item.html = edApi.getHtml ? edApi.getHtml() : (item.html || ''); } catch (_) {}
      item.updatedAt = new Date().toISOString();
      logActivity(project, 'update', 'Boek "' + item.name + '" opgeslagen', { collection: 'books', id: item.id });
      setDirty();
      persist().then(() => {
        statusEl.textContent = 'Opgeslagen';
        statusEl.className = 'wb-save-status saved';
      });
    }

    const autoBook = debounce(() => {
      try {
        if (edApi?.getHtml) item.html = edApi.getHtml();
        item.name = titleIn.value.trim() || item.name;
        item.genre = genreIn.value.trim();
        item.status = statusIn.value.trim();
        item.synopsis = synIn.value.trim();
        item.description = item.synopsis;
        item.updatedAt = new Date().toISOString();
        setDirty();
        autoSave();
        statusEl.textContent = 'Niet opgeslagen';
        statusEl.className = 'wb-save-status dirty';
      } catch (_) {}
    }, 1500);

    titleIn.addEventListener('input', autoBook);
    genreIn.addEventListener('input', autoBook);
    statusIn.addEventListener('input', autoBook);
    synIn.addEventListener('input', autoBook);
    editorPane.addEventListener('input', autoBook);

    body.appendChild(editorPane);
    body.appendChild(side);
    wrap.appendChild(body);

    const linked = (project.relations || []).filter(r => r.fromId === item.id || r.toId === item.id);
    if (linked.length) {
      const box = el('div', 'wb-book-linked');
      box.appendChild(el('h3', 'wb-section-title', 'Gekoppeld in dit manuscript'));
      const list = el('div', 'wb-rel-list');
      for (const r of linked) {
        const oid = r.fromId === item.id ? r.toId : r.fromId;
        const other = findItemById(oid);
        if (!other) continue;
        const row = el('div', 'wb-rel-row');
        row.style.cursor = 'pointer';
        row.appendChild(el('span', 'wb-rel-type', relationLabel(r.type)));
        row.appendChild(el('span', '', other.name || oid));
        row.onclick = () => openItem(other._collection, other.id);
        list.appendChild(row);
      }
      box.appendChild(list);
      wrap.appendChild(box);
    }

    return wrap;
  }

  function openQuickCreate() {
    const options = [
      { id: 'characters', label: 'Personage' }, { id: 'locations', label: 'Locatie' },
      { id: 'cities', label: 'Stad' }, { id: 'factions', label: 'Factie' },
      { id: 'events', label: 'Gebeurtenis' }, { id: 'ideas', label: 'Idee' },
      { id: 'notes', label: 'Notitie' }, { id: 'creatures', label: 'Wezen' },
      { id: 'artifacts', label: 'Artefact' },
      { id: 'books', label: 'Boek / manuscript' },
    ];
    const form = el('div', 'wb-form-grid');
    const typeSel = select(options, { value: 'characters', aria: 'Type' });
    const nameIn = input({ placeholder: 'Naam', aria: 'Naam' });
    form.append(field('Type', typeSel), field('Naam', nameIn));
    document.body.appendChild(modal({
      title: 'Snel nieuwe inhoud', body: form,
      actions: [
        { label: 'Annuleren' },
        { label: 'Aanmaken', primary: true, onClick: () => {
          const col = typeSel.value;
          const name = nameIn.value.trim() || ('Nieuw ' + schemaFor(col).label.toLowerCase());
          const item = createItem(col, { name });
          if (!project[col]) project[col] = [];
          project[col].unshift(item);
          logActivity(project, 'create', schemaFor(col).label + ' aangemaakt', { collection: col, id: item.id });
          setDirty(); autoSave();
          const typ = col === 'books' ? 'book' : col === 'chapters' ? 'chapter' : 'entity';
          openStudioTab(typ, col, item.id, item.name);
        }},
      ],
    }));
    nameIn.focus();
  }

  function openCommandPalette() {
    const overlay = el('div', 'wb-cmd-overlay');
    const box = el('div', 'wb-cmd');
    const qIn = input({ placeholder: 'Ga naar… of zoek', aria: 'Commandopalet' });
    const list = el('div', 'wb-cmd-list');
    box.append(qIn, list); overlay.appendChild(box);
    const commands = [];
    for (const sec of NAV_SECTIONS) for (const it of sec.items)
      commands.push({ label: it.label, icon: it.icon, run: () => { module = it.id; itemId = null; close(); render(); } });
    commands.push({ label: 'Nieuw personage', icon: 'user', run: () => { close(); module = 'characters'; createNewItem('characters'); } });
    commands.push({ label: 'Nieuwe locatie', icon: 'map-pin', run: () => { close(); module = 'regions'; createNewItem('locations'); } });
    commands.push({ label: 'Terug naar projecten', icon: 'back', run: async () => {
      close(); if (dirty) await persist(); project = null; view = 'projects'; index = await loadIndex(); render();
    }});
    let active = 0, filtered = commands;
    function renderList() {
      list.innerHTML = '';
      const q = qIn.value.trim().toLowerCase();
      filtered = commands.filter(c => c.label.toLowerCase().includes(q));
      if (q && project) for (const { collection, item } of searchProject(project, q).slice(0, 8))
        filtered.push({ label: item.name, icon: 'file-text', hint: schemaFor(collection).label, run: () => { close(); openItem(collection, item.id); } });
      if (active >= filtered.length) active = Math.max(0, filtered.length - 1);
      filtered.forEach((c, i) => {
        const b = el('button', 'wb-cmd-item' + (i === active ? ' active' : ''));
        b.appendChild(icon(c.icon || 'box', 16)); b.appendChild(el('span', '', c.label));
        if (c.hint) b.appendChild(el('kbd', '', c.hint));
        b.onclick = () => c.run(); list.appendChild(b);
      });
    }
    function close() { overlay.remove(); }
    qIn.addEventListener('input', () => { active = 0; renderList(); });
    qIn.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') { e.preventDefault(); active = Math.min(active + 1, filtered.length - 1); renderList(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); active = Math.max(active - 1, 0); renderList(); }
      else if (e.key === 'Enter') { e.preventDefault(); filtered[active]?.run(); }
      else if (e.key === 'Escape') close();
    });
    overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
    document.body.appendChild(overlay); renderList(); qIn.focus();
  }

  function onKey(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); if (view === 'workspace') openCommandPalette(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); if (project) persist(); }
  }
  document.addEventListener('keydown', onKey);
  boot();

  return {
    el: root, root, kind: 'worldbuilding',
    close() {
      document.removeEventListener('keydown', onKey);
      if (root._wbGraphCleanup) root._wbGraphCleanup();
      if (dirty && project) saveProject(project).catch(() => {});
    },
    focus() { try { root.focus(); } catch (_) {} },
    getState() { return { view, projectId: project?.id || null, module, itemId, sidebarCollapsed }; },
    setState(s) {
      if (!s?.projectId) return;
      loadProject(s.projectId).then(p => {
        if (p) { project = p; view = 'workspace'; module = s.module || 'dashboard'; itemId = s.itemId || null; sidebarCollapsed = !!s.sidebarCollapsed; render(); }
      });
    },
    handleBack() {
      if (itemId) { itemId = null; editing = false; render(); return true; }
      if (view === 'workspace') {
        if (dirty) persist();
        project = null; view = 'projects';
        loadIndex().then(idx => { index = idx; render(); });
        return true;
      }
      return false;
    },
  };
}
