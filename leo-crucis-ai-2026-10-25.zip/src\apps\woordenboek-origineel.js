// Woordenboek oorspronkelijke talen: Hebreeuws & Grieks → Nederlands (Strong’s)
// Data: data/woordenboek-origineel/lexicon.json

const DATA_URL = 'data/woordenboek-origineel/lexicon.json';
const EXAMPLES = ['ἀγάπη', 'θεός', 'λόγος', 'אָב', 'אֱלֹהִים', 'G25', 'H1', 'πιστεύω'];

let dataPromise = null;

function loadData() {
  if (!dataPromise) {
    dataPromise = fetch(DATA_URL)
      .then(r => { if (!r.ok) throw new Error('lexicon'); return r.json(); })
      .then(d => {
        const byStrong = new Map();
        const entries = d.entries.map(row => {
          const e = {
            s: row[0], l: row[1], t: row[2] || '', n: row[3] || '',
            lang: row[4], e: row[5] || '', k: row[6] || '', d: row[7] || ''
          };
          byStrong.set(e.s, e);
          return e;
        });
        const byLemma = new Map();
        for (const [k, arr] of Object.entries(d.byLemma || {})) {
          byLemma.set(k, arr.map(s => byStrong.get(s)).filter(Boolean));
        }
        return { meta: d.meta, entries, byStrong, byLemma };
      })
      .catch(err => { dataPromise = null; throw err; });
  }
  return dataPromise;
}

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function normLemma(s) {
  return String(s || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[\u0591-\u05C7]/g, '')
    .toLowerCase()
    .trim();
}

function normQuery(s) {
  return String(s || '').trim();
}

/** Publieke lookup: strong ("G25"/"H1") of lemma. */
export async function lookupOrigineel(query) {
  const data = await loadData();
  const q = normQuery(query);
  if (!q) return [];
  const strong = q.toUpperCase().replace(/^([GH])0+/, '$1');
  if (/^[GH]\d+$/i.test(strong) && data.byStrong.has(strong)) {
    return [data.byStrong.get(strong)];
  }
  // bare number → try G then H
  if (/^\d+$/.test(q)) {
    const hits = [];
    if (data.byStrong.has('G' + q)) hits.push(data.byStrong.get('G' + q));
    if (data.byStrong.has('H' + q)) hits.push(data.byStrong.get('H' + q));
    if (hits.length) return hits;
  }
  const key = normLemma(q);
  if (data.byLemma.has(key)) return data.byLemma.get(key).slice(0, 20);
  // partial lemma search
  const out = [];
  for (const [k, list] of data.byLemma) {
    if (k.includes(key) || key.includes(k)) {
      for (const e of list) out.push(e);
      if (out.length >= 30) break;
    }
  }
  return out.slice(0, 30);
}

export function injectOrigineelStyles() {
  if (document.getElementById('wbo-styles')) return;
  const s = document.createElement('style');
  s.id = 'wbo-styles';
  s.textContent = `
.wb-app.wb-orig-mode > :not(.wb-modes):not(.wb-orig){display:none !important}
.wb-orig{flex:1 1 auto;min-height:0;display:none;flex-direction:column}
.wb-app.wb-orig-mode .wb-orig{display:flex}
.wbo-root{display:flex;flex-direction:column;height:100%;min-height:0;gap:8px;padding:4px 2px}
.wbo-head{flex:0 0 auto}
.wbo-title{font-size:1.05rem;font-weight:700;margin:0 0 2px}
.wbo-sub{font-size:.8rem;color:var(--muted,#666);margin:0 0 8px}
.wbo-form{display:flex;gap:6px;margin-bottom:6px}
.wbo-input{flex:1;font:inherit;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:var(--panel,#fff);color:var(--ink)}
.wbo-btn{font:inherit;padding:8px 12px;border-radius:8px;border:1px solid var(--line);background:var(--acc);color:#fff;cursor:pointer}
.wbo-examples{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px}
.wbo-chip{font-size:.75rem;padding:3px 8px;border-radius:999px;border:1px solid var(--line);background:var(--panel);cursor:pointer}
.wbo-chip:hover{border-color:var(--acc)}
.wbo-body{flex:1;min-height:0;overflow:auto;display:flex;flex-direction:column;gap:10px}
.wbo-card{border:1px solid var(--line);border-radius:10px;padding:12px 14px;background:var(--panel)}
.wbo-lemma{font-size:1.45rem;font-weight:700;line-height:1.3}
.wbo-lemma.he{direction:rtl;font-family:"SBL Hebrew","Ezra SIL","Noto Serif Hebrew","Times New Roman",serif}
.wbo-lemma.gr{font-family:"SBL Greek","Gentium Plus","Noto Serif","Times New Roman",serif}
.wbo-meta{font-size:.85rem;color:var(--muted,#666);margin:4px 0 8px}
.wbo-strong{display:inline-block;font-weight:600;color:var(--acc);margin-right:6px}
.wbo-gloss{font-size:1.05rem;margin:0 0 6px}
.wbo-en{font-size:.85rem;color:var(--muted,#666);font-style:italic;margin:0 0 4px}
.wbo-der{font-size:.8rem;color:var(--muted,#888);margin:0}
.wbo-empty{padding:16px;color:var(--muted,#666);font-size:.9rem}
.wbo-lang-tag{font-size:.7rem;text-transform:uppercase;letter-spacing:.04em;padding:2px 6px;border-radius:4px;background:color-mix(in srgb,var(--acc) 12%,transparent);margin-left:6px}
`;
  document.head.append(s);
}

export function createOrigineelPanel(opts = {}) {
  injectOrigineelStyles();
  const root = el('div', 'wb-orig wbo-root');
  const head = el('div', 'wbo-head');
  head.append(el('h3', 'wbo-title', 'Oorspronkelijke talen'));
  head.append(el('p', 'wbo-sub', 'Hebreeuws & Grieks → Nederlands (Strong’s)'));

  const form = el('form', 'wbo-form');
  const input = el('input', 'wbo-input');
  input.type = 'search';
  input.placeholder = 'Lemma, Strong’s-nummer (G25 / H1)…';
  input.setAttribute('aria-label', 'Zoek in Hebreeuws/Grieks woordenboek');
  const btn = el('button', 'wbo-btn', 'Zoek');
  btn.type = 'submit';
  form.append(input, btn);
  head.append(form);

  const examples = el('div', 'wbo-examples');
  for (const ex of EXAMPLES) {
    const c = el('button', 'wbo-chip', ex);
    c.type = 'button';
    c.onclick = () => { input.value = ex; run(ex); };
    examples.append(c);
  }
  head.append(examples);
  root.append(head);

  const body = el('div', 'wbo-body');
  body.append(el('p', 'wbo-empty', 'Zoek op een Hebreeuws of Grieks woord, of op een Strong’s-nummer (bijv. G25, H430).'));
  root.append(body);

  let data = null;

  function renderEntry(e) {
    const card = el('div', 'wbo-card');
    const lemma = el('div', 'wbo-lemma ' + (e.lang === 'he' ? 'he' : 'gr'), e.l);
    const tag = el('span', 'wbo-lang-tag', e.lang === 'he' ? 'Hebreeuws' : 'Grieks');
    lemma.append(tag);
    card.append(lemma);
    const meta = el('div', 'wbo-meta');
    const st = el('span', 'wbo-strong', e.s);
    meta.append(st);
    if (e.t) meta.append(document.createTextNode(e.t));
    card.append(meta);
    if (e.n) card.append(el('p', 'wbo-gloss', e.n));
    if (e.e && e.e !== e.n) card.append(el('p', 'wbo-en', e.e));
    if (e.k) card.append(el('p', 'wbo-en', 'KJV: ' + e.k));
    if (e.d) card.append(el('p', 'wbo-der', e.d));
    return card;
  }

  async function run(q) {
    body.replaceChildren(el('p', 'wbo-empty', 'Zoeken…'));
    try {
      if (!data) data = await loadData();
      const hits = await lookupOrigineel(q);
      body.replaceChildren();
      if (!hits.length) {
        body.append(el('p', 'wbo-empty', 'Geen treffer voor “' + q + '”. Probeer een lemma of Strong’s-nummer.'));
        return;
      }
      for (const e of hits) body.append(renderEntry(e));
    } catch {
      body.replaceChildren(el('p', 'wbo-empty', 'Kon het woordenboek niet laden.'));
    }
  }

  form.onsubmit = (ev) => {
    ev.preventDefault();
    run(input.value);
  };

  // preload
  loadData().then(d => { data = d; }).catch(() => {});

  if (opts.initialQuery) {
    input.value = opts.initialQuery;
    setTimeout(() => run(opts.initialQuery), 50);
  }

  return {
    root,
    focus() { input.focus(); },
    setQuery(q) { input.value = q || ''; run(q); },
    lookup: lookupOrigineel
  };
}
