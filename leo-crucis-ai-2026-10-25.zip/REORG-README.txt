Leo Crucis — src-reorganisatie (losse files opgeruimd)
=====================================================
Datum: 2026-10-23

Probleem
--------
In src/ stonden nog ~15 losse .js-bestanden naast de al bestaande
mappen (apps/, core/, ui/, styles/). Dat hoort niet bij de
fase-architectuur (fase 1 core, fase 2 ui, fase 3 styles).

Oplossing
---------
Alles is ondergebracht in domeinmappen. Alleen entrypoints blijven
op de root van src/:

  src/
    app.js          ← entry (orchestratie)
    index.html
    styles.css      ← CSS-entry (@import styles/*)
    version.js      ← auto-generated
    default.json

    core/           ← foundation + infra
      ...bestaand...
      + edit.js         (storage, settings, Tauri-bridge)
      + search.js
      + loading.js
      + perf.js
      + transfers.js
      + refs.js

    editor/         ← document-editors (NIEUW)
      editor.js
      choose.js
      docstyles.js
      pdf.js
      pdfbook.js
      sheet.js
      slides.js

    media/          ← audio/video (NIEUW)
      player.js
      media-library.js

    apps/   ui/   styles/   data/   stad/   ← ongewijzigd

Imports
-------
Alle static + dynamic imports zijn bijgewerkt in:
  - src/app.js
  - src/apps/album.js, bijbel.js, woordenboek.js, registry.js
  - src/editor/pdf.js
  - src/media/media-library.js

Toepassen op je echte project
-----------------------------
1. Backup van je src/ maken.
2. Bestanden verplaatsen zoals hierboven (of deze zip over src/ mergen).
3. De gewijzigde import-paden in de genoemde bestanden overnemen
   (of de versies uit deze zip gebruiken).
4. testen: npm run web  of  npm run dev

Geen functionele wijzigingen — alleen structuur + importpaden.
