/**
 * Worldbuilding Studio — constanten & schema's
 */
export const PROJECT_STATUSES = [
  { id: 'concept', label: 'Concept' },
  { id: 'development', label: 'In ontwikkeling' },
  { id: 'complete', label: 'Voltooid' },
  { id: 'archived', label: 'Gearchiveerd' },
];
export const WORLD_TYPES = [
  { id: 'high-fantasy', label: 'High fantasy' },
  { id: 'dark-fantasy', label: 'Dark fantasy' },
  { id: 'low-fantasy', label: 'Low fantasy' },
  { id: 'sci-fi', label: 'Sciencefiction' },
  { id: 'alt-history', label: 'Alternatieve geschiedenis' },
  { id: 'mythic', label: 'Mythologisch' },
  { id: 'steampunk', label: 'Steampunk' },
  { id: 'other', label: 'Anders' },
];
export const ACCENT_COLORS = ['#c9a227','#7c5cbf','#3d7ea6','#c45c6a','#2d8a6e','#b85c38','#5b6eae','#8a6d3b'];

export const WORLD_SYMBOLS = [
  '✦', '✧', '★', '☆', '◆', '◇', '●', '○',
  '▲', '△', '⬡', '⬢', '⚜', '⚔', '🕊', '🌿',
  '🔥', '❄', '🌙', '☀', '⚡', '🌊', '🐉', '🏛',
];

export const NAV_SECTIONS = [
  { id: 'world', label: 'Wereld', items: [
    { id: 'dashboard', label: 'Overzicht', icon: 'home', collection: null },
    { id: 'continents', label: 'Continenten', icon: 'globe', collection: 'continents' },
    { id: 'regions', label: "Regio's", icon: 'map-pin', collection: 'locations' },
    { id: 'cities', label: 'Steden', icon: 'building', collection: 'cities' },
    { id: 'maps', label: 'Kaarten', icon: 'map', collection: 'maps' },
    { id: 'biomes', label: 'Biomen', icon: 'leaf', collection: 'biomes' },
  ]},
  { id: 'history', label: 'Geschiedenis', items: [
    { id: 'timeline', label: 'Tijdlijn', icon: 'timeline', collection: null },
    { id: 'events', label: 'Gebeurtenissen', icon: 'flag', collection: 'events' },
    { id: 'eras', label: 'Tijdperken', icon: 'hourglass', collection: 'eras' },
    { id: 'wars', label: 'Oorlogen', icon: 'swords', collection: 'wars' },
    { id: 'dynasties', label: 'Dynastieën', icon: 'crown', collection: 'dynasties' },
  ]},
  { id: 'people', label: 'Bewoners', items: [
    { id: 'characters', label: 'Personages', icon: 'user', collection: 'characters' },
    { id: 'races', label: 'Rassen', icon: 'users', collection: 'races' },
    { id: 'cultures', label: 'Culturen', icon: 'sparkles', collection: 'cultures' },
    { id: 'factions', label: 'Facties', icon: 'shield', collection: 'factions' },
    { id: 'organizations', label: 'Organisaties', icon: 'briefcase', collection: 'organizations' },
    { id: 'religions', label: 'Religies', icon: 'sun', collection: 'religions' },
    { id: 'languages', label: 'Talen', icon: 'book', collection: 'languages' },
  ]},
  { id: 'systems', label: 'Systemen', items: [
    { id: 'magic', label: 'Magie', icon: 'wand', collection: 'magic' },
    { id: 'creatures', label: 'Wezens', icon: 'dragon', collection: 'creatures' },
    { id: 'flora-fauna', label: 'Flora & fauna', icon: 'flower', collection: 'floraFauna' },
    { id: 'artifacts', label: 'Artefacten', icon: 'gem', collection: 'artifacts' },
    { id: 'technology', label: 'Technologie', icon: 'cog', collection: 'technology' },
    { id: 'laws', label: 'Natuurwetten', icon: 'scale', collection: 'laws' },
  ]},
  { id: 'stories', label: 'Verhalen', items: [
    { id: 'books', label: 'Boeken', icon: 'book', collection: 'books' },
    { id: 'chapters', label: 'Hoofdstukken', icon: 'file-text', collection: 'chapters' },
    { id: 'plots', label: 'Verhaallijnen', icon: 'scroll', collection: 'plots' },
    { id: 'themes', label: "Thema's", icon: 'palette', collection: 'themes' },
    { id: 'ideas', label: 'Ideeën', icon: 'lightbulb', collection: 'ideas' },
    { id: 'notes', label: 'Notities', icon: 'pen', collection: 'notes' },
    { id: 'concepts', label: 'Concepten', icon: 'box', collection: 'concepts' },
  ]},
  { id: 'analysis', label: 'Analyse', items: [
    { id: 'relations', label: 'Relaties', icon: 'git-branch', collection: null },
    { id: 'graph', label: 'Grafiek', icon: 'network', collection: null },
    { id: 'search', label: 'Zoeken', icon: 'search', collection: null },
    { id: 'tags', label: 'Tags', icon: 'tag', collection: null },
  ]},
];

const baseFields = {
  characters: [
    { key: 'title', label: 'Titel / rang', type: 'text' },
    { key: 'age', label: 'Leeftijd', type: 'text' },
    { key: 'gender', label: 'Geslacht', type: 'text' },
    { key: 'species', label: 'Soort / ras', type: 'text' },
    { key: 'personality', label: 'Persoonlijkheid', type: 'textarea' },
    { key: 'appearance', label: 'Uiterlijk', type: 'textarea' },
    { key: 'background', label: 'Achtergrond', type: 'textarea' },
    { key: 'goals', label: 'Doelen & motivaties', type: 'textarea' },
    { key: 'fears', label: 'Angsten', type: 'textarea' },
    { key: 'skills', label: 'Vaardigheden', type: 'textarea' },
  ],
  locations: [
    { key: 'category', label: 'Categorie', type: 'text' },
    { key: 'atmosphere', label: 'Sfeer', type: 'textarea' },
    { key: 'geography', label: 'Geografie', type: 'textarea' },
    { key: 'climate', label: 'Klimaat', type: 'text' },
    { key: 'population', label: 'Bevolking', type: 'text' },
    { key: 'culture', label: 'Cultuur', type: 'textarea' },
    { key: 'government', label: 'Bestuur', type: 'textarea' },
    { key: 'history', label: 'Geschiedenis', type: 'textarea' },
  ],
  cities: [
    { key: 'type', label: 'Type', type: 'text' },
    { key: 'population', label: 'Inwoners', type: 'text' },
    { key: 'ruler', label: 'Heerser', type: 'text' },
    { key: 'atmosphere', label: 'Sfeer', type: 'textarea' },
    { key: 'history', label: 'Geschiedenis', type: 'textarea' },
  ],
  continents: [
    { key: 'type', label: 'Type', type: 'text' },
    { key: 'capital', label: 'Hoofdstad', type: 'text' },
    { key: 'climate', label: 'Klimaat', type: 'text' },
    { key: 'geography', label: 'Geografie', type: 'textarea' },
    { key: 'history', label: 'Geschiedenis', type: 'textarea' },
  ],
  factions: [
    { key: 'type', label: 'Type', type: 'text' },
    { key: 'leader', label: 'Leider', type: 'text' },
    { key: 'motto', label: 'Motto', type: 'text' },
    { key: 'goals', label: 'Doelen', type: 'textarea' },
    { key: 'history', label: 'Geschiedenis', type: 'textarea' },
  ],
  events: [
    { key: 'dateStart', label: 'Startdatum', type: 'text' },
    { key: 'dateEnd', label: 'Einddatum', type: 'text' },
    { key: 'era', label: 'Tijdperk', type: 'text' },
    { key: 'significance', label: 'Belang', type: 'textarea' },
    { key: 'outcome', label: 'Uitkomst', type: 'textarea' },
  ],
  eras: [
    { key: 'dateStart', label: 'Begin', type: 'text' },
    { key: 'dateEnd', label: 'Einde', type: 'text' },
    { key: 'summary', label: 'Samenvatting', type: 'textarea' },
  ],
  wars: [
    { key: 'dateStart', label: 'Begin', type: 'text' },
    { key: 'dateEnd', label: 'Einde', type: 'text' },
    { key: 'sides', label: 'Partijen', type: 'textarea' },
    { key: 'outcome', label: 'Uitkomst', type: 'textarea' },
  ],
  dynasties: [
    { key: 'founder', label: 'Stichter', type: 'text' },
    { key: 'reign', label: 'Regeerperiode', type: 'text' },
    { key: 'realm', label: 'Rijk', type: 'text' },
    { key: 'history', label: 'Geschiedenis', type: 'textarea' },
  ],
  races: [
    { key: 'lifespan', label: 'Levensduur', type: 'text' },
    { key: 'appearance', label: 'Uiterlijk', type: 'textarea' },
    { key: 'culture', label: 'Cultuur', type: 'textarea' },
    { key: 'abilities', label: 'Bijzondere eigenschappen', type: 'textarea' },
  ],
  cultures: [
    { key: 'values', label: 'Waarden', type: 'textarea' },
    { key: 'customs', label: 'Gebruiken', type: 'textarea' },
  ],
  organizations: [
    { key: 'type', label: 'Type', type: 'text' },
    { key: 'leader', label: 'Leider', type: 'text' },
    { key: 'purpose', label: 'Doel', type: 'textarea' },
  ],
  religions: [
    { key: 'type', label: 'Type', type: 'text' },
    { key: 'deities', label: 'Godheden', type: 'textarea' },
    { key: 'tenets', label: 'Leerstellingen', type: 'textarea' },
  ],
  languages: [
    { key: 'speakers', label: 'Sprekers', type: 'text' },
    { key: 'script', label: 'Schrijfsysteem', type: 'text' },
  ],
  magic: [
    { key: 'source', label: 'Bron', type: 'text' },
    { key: 'rules', label: 'Regels', type: 'textarea' },
    { key: 'limitations', label: 'Beperkingen', type: 'textarea' },
  ],
  creatures: [
    { key: 'habitat', label: 'Habitat', type: 'text' },
    { key: 'behavior', label: 'Gedrag', type: 'textarea' },
    { key: 'abilities', label: 'Vermogens', type: 'textarea' },
  ],
  floraFauna: [
    { key: 'type', label: 'Type', type: 'text' },
    { key: 'habitat', label: 'Habitat', type: 'text' },
  ],
  artifacts: [
    { key: 'type', label: 'Type', type: 'text' },
    { key: 'powers', label: 'Krachten', type: 'textarea' },
    { key: 'origin', label: 'Oorsprong', type: 'textarea' },
  ],
  technology: [{ key: 'level', label: 'Niveau', type: 'text' }, { key: 'application', label: 'Toepassing', type: 'textarea' }],
  laws: [{ key: 'domain', label: 'Domein', type: 'text' }, { key: 'rules', label: 'Regels', type: 'textarea' }],
  plots: [{ key: 'status', label: 'Status', type: 'text' }, { key: 'summary', label: 'Samenvatting', type: 'textarea' }],
  chapters: [{ key: 'order', label: 'Volgorde', type: 'text' }, { key: 'summary', label: 'Samenvatting', type: 'textarea' }],
  books: [
    { key: 'genre', label: 'Genre', type: 'text' },
    { key: 'status', label: 'Status (concept/klad/definitief)', type: 'text' },
    { key: 'synopsis', label: 'Synopsis', type: 'textarea' },
    { key: 'pov', label: 'Perspectief / verteller', type: 'text' },
    { key: 'targetAudience', label: 'Doelgroep', type: 'text' },
  ],
  themes: [{ key: 'expression', label: 'Uitwerking', type: 'textarea' }],
  ideas: [{ key: 'status', label: 'Status', type: 'text' }],
  notes: [],
  concepts: [{ key: 'status', label: 'Status', type: 'text' }],
  biomes: [{ key: 'climate', label: 'Klimaat', type: 'text' }, { key: 'features', label: 'Kenmerken', type: 'textarea' }],
  maps: [{ key: 'scale', label: 'Schaal', type: 'text' }, { key: 'region', label: 'Regio', type: 'text' }],
};

export const COLLECTION_SCHEMAS = {};
for (const [k, fields] of Object.entries(baseFields)) {
  const labels = {
    characters: ['Personage','Personages'], locations: ['Locatie','Locaties'], cities: ['Stad / dorp','Steden'],
    continents: ['Continent / land','Continenten'], factions: ['Factie','Facties'], events: ['Gebeurtenis','Gebeurtenissen'],
    eras: ['Tijdperk','Tijdperken'], wars: ['Oorlog','Oorlogen'], dynasties: ['Dynastie','Dynastieën'],
    races: ['Ras / volk','Rassen'], cultures: ['Cultuur','Culturen'], organizations: ['Organisatie','Organisaties'],
    religions: ['Religie','Religies'], languages: ['Taal','Talen'], magic: ['Magiesysteem','Magiesystemen'],
    creatures: ['Wezen','Wezens'], floraFauna: ['Flora / fauna','Flora & fauna'], artifacts: ['Artefact','Artefacten'],
    technology: ['Technologie','Technologie'], laws: ['Natuurwet','Natuurwetten'], plots: ['Verhaallijn','Verhaallijnen'],
    chapters: ['Hoofdstuk','Hoofdstukken'], books: ['Boek','Boeken'], themes: ['Thema',"Thema's"], ideas: ['Idee','Ideeën'],
    notes: ['Notitie','Notities'], concepts: ['Concept','Concepten'], biomes: ['Bioom','Biomen'], maps: ['Kaart','Kaarten'],
  };
  const [label, labelPlural] = labels[k] || ['Item','Items'];
  COLLECTION_SCHEMAS[k] = { label, labelPlural, fields };
}

export const RELATION_TYPES = [
  { id: 'family', label: 'Familie' }, { id: 'ally', label: 'Bondgenoot' }, { id: 'enemy', label: 'Vijand' },
  { id: 'member', label: 'Lid van' }, { id: 'rules', label: 'Regeert' }, { id: 'owns', label: 'Bezit' },
  { id: 'located', label: 'Gelegen in' }, { id: 'participated', label: 'Deelgenomen aan' },
  { id: 'created', label: 'Geschapen' }, { id: 'related', label: 'Gerelateerd' },
  { id: 'rival', label: 'Rivaal' }, { id: 'mentor', label: 'Mentor van' },
];

export const ICONS = {
  home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
  'map-pin': '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
  building: '<rect width="16" height="20" x="4" y="2" rx="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M12 6h.01"/>',
  map: '<polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/><line x1="9" x2="9" y1="3" y2="18"/><line x1="15" x2="15" y1="6" y2="21"/>',
  leaf: '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>',
  timeline: '<path d="M12 2v20"/><path d="M8 6h8"/><path d="M6 12h12"/><path d="M8 18h8"/>',
  flag: '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" x2="4" y1="22" y2="15"/>',
  hourglass: '<path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/>',
  swords: '<polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5"/><line x1="13" x2="19" y1="19" y2="13"/>',
  crown: '<path d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14"/>',
  user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  sparkles: '<path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/>',
  briefcase: '<rect width="20" height="14" x="2" y="7" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/>',
  book: '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"/>',
  expand: '<polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" x2="14" y1="3" y2="10"/><line x1="3" x2="10" y1="21" y2="14"/>',
  wand: '<path d="m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72Z"/><path d="m14 7 3 3"/>',
  dragon: '<path d="M12 2c2 3 2 6 0 9"/><path d="M12 2c-2 3-2 6 0 9"/><circle cx="12" cy="12" r="2"/>',
  flower: '<circle cx="12" cy="12" r="3"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/>',
  gem: '<path d="M6 3h12l4 6-10 13L2 9Z"/><path d="M2 9h20"/>',
  cog: '<circle cx="12" cy="12" r="3"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2"/>',
  scale: '<path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="M7 21h10"/><path d="M12 3v18"/>',
  scroll: '<path d="M8 21h12a2 2 0 0 0 2-2v-2H10v2a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v3h4"/><path d="M19 17V5a2 2 0 0 0-2-2H4"/>',
  'file-text': '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
  palette: '<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/>',
  lightbulb: '<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/>',
  pen: '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/>',
  box: '<path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/>',
  'git-branch': '<line x1="6" x2="6" y1="3" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/>',
  network: '<rect x="16" y="16" width="6" height="6" rx="1"/><rect x="2" y="16" width="6" height="6" rx="1"/><rect x="9" y="2" width="6" height="6" rx="1"/><path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3"/><path d="M12 12V8"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  tag: '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  edit: '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  'star-filled': '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="currentColor"/>',
  copy: '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  export: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
  import: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
  chevronLeft: '<path d="m15 18-6-6 6-6"/>', chevronRight: '<path d="m9 18 6-6-6-6"/>', chevronDown: '<path d="m6 9 6 6 6-6"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>', check: '<path d="M20 6 9 17l-5-5"/>',
  menu: '<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>',
  save: '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>',
  back: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  world: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
};

export function collectionForModule(moduleId) {
  for (const sec of NAV_SECTIONS)
    for (const item of sec.items)
      if (item.id === moduleId) return item.collection;
  return null;
}
export function schemaFor(collection) {
  return COLLECTION_SCHEMAS[collection] || { label: 'Item', labelPlural: 'Items', fields: [] };
}
