// BKE — zelfstandige mini-app.
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}


function injectGameBaseStyles() {
  if (document.getElementById('lc-game-base-styles')) return;
  const s = document.createElement('style');
  s.id = 'lc-game-base-styles';
  s.textContent = `
.app-panel.games-app{
  display:flex;flex-direction:column;gap:0;min-height:0;height:100%;
  background:var(--bg);color:var(--ink);
  font-family:"Courier New",Courier,ui-monospace,monospace;
  position:relative;overflow:auto;
  padding:12px;box-sizing:border-box;
}
.games-app .game-status{
  font-weight:800;font-size:13px;letter-spacing:.1em;text-transform:uppercase;
  color:var(--acc);text-align:center;padding:10px 12px 4px;
  text-shadow:0 0 8px rgba(155,188,15,.3);
}
.games-app .game-hint{
  margin:0;font-size:11px;color:var(--mute);opacity:.65;text-align:center;
  letter-spacing:.06em;padding:0 12px 8px;
}
.games-app .game-reset{
  border:2px solid var(--line);background:var(--panel);color:var(--acc);
  border-radius:4px;padding:8px 16px;cursor:pointer;font:inherit;
  font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
  align-self:center;margin-top:8px;
}
.games-app .game-reset:hover{border-color:var(--acc);background:var(--sel);color:var(--acc2);}
.games-app .ttt-board{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:240px;margin:12px auto;width:100%;}
.games-app .ttt-cell{
  aspect-ratio:1;border:1px solid var(--line);border-radius:4px;
  background:var(--panel);color:var(--acc);font-weight:800;font-size:1.6rem;
  cursor:pointer;font-family:inherit;
}
.games-app .ttt-cell:hover:not(:disabled){
  border-color:var(--acc);background:var(--sel);
  box-shadow:0 0 10px rgba(155,188,15,.2);
}
.games-app .ttt-cell:disabled{cursor:default;opacity:.9;}
.games-app .snake-canvas{
  border:1px solid var(--line);border-radius:4px;
  box-shadow:0 0 12px rgba(155,188,15,.15);
  margin:0 auto;display:block;
}
`;
  document.head.append(s);
}

function tictactoe(host) {
  host.replaceChildren();
  let board = Array(9).fill(null);
  let turn = 'X';
  let over = false;
  const status = el('div', 'game-status', 'Jij bent X');
  const grid = el('div', 'ttt-board');
  host.append(status, grid);

  const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  function winner() {
    for (const [a,b,c] of wins) if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
    if (board.every(Boolean)) return 'draw';
    return null;
  }
  function render() {
    grid.replaceChildren();
    board.forEach((v, i) => {
      const b = el('button', 'ttt-cell', v || '');
      b.type = 'button';
      b.disabled = !!v || over;
      b.onclick = () => {
        if (over || board[i]) return;
        board[i] = turn;
        const w = winner();
        if (w === 'draw') { over = true; status.textContent = 'Gelijkspel'; }
        else if (w) { over = true; status.textContent = w + ' wint!'; }
        else { turn = turn === 'X' ? 'O' : 'X'; status.textContent = 'Beurt: ' + turn; }
        render();
      };
      grid.append(b);
    });
  }
  const reset = el('button', 'game-reset', 'Opnieuw');
  reset.type = 'button';
  reset.onclick = () => { board = Array(9).fill(null); turn = 'X'; over = false; status.textContent = 'Jij bent X'; render(); };
  host.append(reset);
  render();
}


export function createBkeApp() {
  injectGameBaseStyles();
  const root = document.createElement('div');
  root.className = 'app-panel games-app';
  tictactoe(root);
  return { root };
}
