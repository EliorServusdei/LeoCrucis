/**
 * ui/mini-apps-view.js — mini-apps, split-view, showMiniApp
 */
import { el } from '../core/dom.js';
import {
  createMiniAppInstance as createMiniAppFromRegistry,
  miniAppIconSvg as registryMiniAppIconSvg,
  MINI_APP_ICONS
} from '../apps/registry.js';
import { safeCloseMiniApp, snapshotMiniApp } from '../core/mini-app.js';

export const MINI_APP_TITLES = {
  audio: 'Audiospeler',
  video: 'Videospeler',
  calendar: 'Kalender',
  notes: 'Notities',
  budgetter: 'Slim Budgetter',
  todo: 'Taken',
  calculator: 'Rekenmachine',
  timer: 'Timer',
  browser: 'Browser',
  bible: 'Bijbel',
  'verse-study': 'Verdieping',
  woordenboek: 'Woordenboek',
  codex: 'Canoniek Recht',
  focus: 'Focusblok',
  memory: 'Memory',
  snake: 'Slang',
  bke: 'BKE',
  tetris: 'Tetris',
  mastermind: 'Mastermind',
  connect4: '4 op een rij',
  speeltoestel: 'Speeltoestel',
  gallery: 'Kunstgalerij',
  album: 'Fotoalbum',
  maps: 'Atlas',
  worldbuilding: 'Worldbuilding Studio',
  'xref-map': 'Bijbelgrafieken',
  doc: 'Editor',
  pptx: 'Presentatiemaker',
  xlsx: 'Spreadsheetmaker',
};

export function createMiniAppsViewApi(deps) {
  const {
    canOpenNewRecent,
    pushRecentApp,
    removeRecentApp,
    showHome,
    guardFocusBlock = (_k, fn) => fn,
    viewContent,
    home,
    view,
    setHash = (h) => { try { location.hash = h; } catch (_) {} },
    setCurrentSection = () => {},
    createMiniAppInstance = createMiniAppFromRegistry,
    showMediaPlayer = () => {},
    loadSettings = () => ({}),
  } = deps;

  let splitLeft = null;
  let splitRight = null;
  let splitRatio = 0.5;
  /** Laatste getState() per kind — voor restore bij heropenen via recent/home */
  const lastSavedByKind = new Map();

  const miniAppIconSvg = registryMiniAppIconSvg;
  const MINI_APP_TITLES_LOCAL = MINI_APP_TITLES;

  /** Sluit alle actieve mini-app instanties in de view (timers, media, …). */
  function closeMountedApps() {
    if (!viewContent) return;
    viewContent.querySelectorAll('.split-pane, .split-pane-single').forEach(pane => {
      if (pane._miniAppInst) {
        try {
          const inst = pane._miniAppInst;
          const snap = snapshotMiniApp(inst, null);
          if (snap.saved && inst.kind) {
            lastSavedByKind.set(inst.kind, snap.saved);
            if (splitLeft && splitLeft.kind === inst.kind) splitLeft = { ...splitLeft, saved: snap.saved };
            if (splitRight && splitRight.kind === inst.kind) splitRight = { ...splitRight, saved: snap.saved };
          }
        } catch (_) {}
        safeCloseMiniApp(pane._miniAppInst);
        pane._miniAppInst = null;
      }
    });
  }

  function clearSplitState() {
    closeMountedApps();
    splitLeft = null;
    splitRight = null;
    document.body.classList.remove('split-open');
    document.body.classList.remove('app-fullscreen');
    document.querySelectorAll('.is-fs').forEach(n => n.classList.remove('is-fs'));
    try { syncHeaderNavState(); } catch (_) {}
  }

  function closeSplitSide(side) {
    if (side === 'left') splitLeft = null;
    else splitRight = null;
    if (!splitLeft && !splitRight) {
      showHome();
      return;
    }
    // Eén app/picker over: full-screen opnieuw tekenen
    renderMiniAppView();
  }

  /** Mini-app-keuze in een leeg split-paneel. */
  function createSplitPicker(excludeKind, targetSide) {
    const root = el('div', 'split-picker mini-app-root');
    root.append(el('p', 'split-picker-title', 'Kies een app'));
    root.append(el('p', 'split-picker-hint', 'Deze opent in dit venster naast de andere app.'));
    const grid = el('div', 'split-picker-grid');
    // Zelfde set als de header-tools die een app openen (niet: nieuw document/presentatie/rekenblad)
    const order = [
      'audio', 'video',
      'calendar', 'notes', 'bible', 'codex', 'xref-map', 'woordenboek',
      'memory', 'snake', 'bke', 'tetris', 'mastermind', 'connect4', 'speeltoestel', 'gallery', 'album', 'maps'
    ];
    for (const kind of order) {
      const card = el('button', 'split-picker-card');
      card.type = 'button';
      card.title = MINI_APP_TITLES[kind] || kind;
      const icWrap = el('span', 'split-picker-icon');
      const svg = miniAppIconSvg(kind);
      if (svg) icWrap.append(svg);
      else icWrap.textContent = '•';
      const lab = el('span', 'split-picker-label', MINI_APP_TITLES[kind] || kind);
      card.append(icWrap, lab);
      if (kind === excludeKind) {
        card.classList.add('is-current');
        card.title = (MINI_APP_TITLES[kind] || kind) + ' (nu open)';
      }
      card.onclick = () => {
        const open = () => {
          const slot = { kind, startPos: null };
          if (targetSide === 'left') splitLeft = slot;
          else splitRight = slot;
          renderMiniAppView();
        };
        if (kind === 'speeltoestel' || kind === 'video') {
          guardFocusBlock(kind === 'video' ? 'video' : kind, open)();
        } else {
          open();
        }
      };
      grid.append(card);
    }
    root.append(grid);
    return { root };
  }

  /**
   * Pane zonder titelbalk (Windows-stijl): content direct onder de globale header.
   * Alleen in splitscreen: minimale strip met × (en ⇄ op links).
   */
  function mountMiniPane(paneEl, side, slot) {
    const isPicker = slot.kind === '__picker__';
    const other = side === 'left' ? splitRight : splitLeft;
    const alone = !other;
    const both = !!(splitLeft && splitRight);
    const otherIsApp = other && other.kind !== '__picker__';
    const thisIsApp = !isPicker;

    // Geen lokale chrome bij één app — navigatie zit in de globale header.
    // Bij split: alleen × / wissel, geen titel, geen fullscreen.
    if (both) {
      const head = el('div', 'view-head browser-head split-pane-head split-pane-head--minimal');
      const close = el('button', 'split-icon-btn', '×');
      close.type = 'button';
      close.title = 'Dit venster sluiten';
      close.setAttribute('aria-label', close.title);
      close.onclick = () => closeSplitSide(side);
      head.append(close);

      if (side === 'left' && thisIsApp && otherIsApp) {
        const actions = el('div', 'split-head-actions');
        const swap = el('button', 'split-icon-btn split-swap-btn', '⇄');
        swap.type = 'button';
        swap.title = 'Vensters wisselen';
        swap.setAttribute('aria-label', 'Vensters wisselen');
        swap.onclick = () => {
          const tmp = splitLeft;
          splitLeft = splitRight;
          splitRight = tmp;
          renderMiniAppView();
        };
        actions.append(swap);
        head.append(actions);
      }
      paneEl.append(head);
    }

    if (isPicker) {
      const otherKind = other && other.kind !== '__picker__' ? other.kind : null;
      const picker = createSplitPicker(otherKind, side);
      paneEl.append(picker.root);
    } else {
      let app = null;
      try {
        app = createMiniAppInstance(slot.kind, slot.startPos, { saved: slot.saved || null });
      } catch (err) {
        console.error('Mini-app starten mislukt:', slot.kind, err);
        const errBox = el('div', 'mini-app-root');
        errBox.style.padding = '24px';
        errBox.append(el('p', '', 'Deze app kon niet worden geopend.'));
        errBox.append(el('p', 'settings-hint', String(err && err.message || err)));
        paneEl.append(errBox);
      }
      paneEl._miniAppInst = app || null;
      const appRoot = app && (app.el || app.root);
      if (appRoot) {
        appRoot.classList.add('mini-app-root');
        paneEl.append(appRoot);
      } else if (!paneEl.querySelector('.mini-app-root')) {
        const empty = el('div', 'mini-app-root');
        empty.style.padding = '24px';
        empty.append(el('p', '', 'Onbekende of lege app — gebruik Terug in de header'));
        paneEl.append(empty);
      }
    }
  }

  /** Open tweede pane (picker) of sluit split terug naar één app. */
  function toggleSplitFromHeader() {
    let allowSplit = true;
    try { allowSplit = loadSettings().splitScreen !== false; } catch (_) {}
    if (!allowSplit) return;

    const both = !!(splitLeft && splitRight);
    if (both) {
      // Secundair (rechts) sluiten; links blijft
      if (splitRight) {
        closeSplitSide('right');
      } else {
        closeSplitSide('left');
      }
      return;
    }

    const only = splitLeft || splitRight;
    if (!only || only.kind === '__picker__') return;

    if (!splitLeft && splitRight) {
      splitLeft = splitRight;
      splitRight = null;
    }
    splitRight = { kind: '__picker__' };
    renderMiniAppView();
  }

  /** Actieve mini-app instantie (links bij voorkeur, anders rechts). */
  function getPrimaryAppInst() {
    if (!viewContent) return null;
    const panes = viewContent.querySelectorAll('.split-pane, .split-pane-single');
    for (const pane of panes) {
      if (pane._miniAppInst) return pane._miniAppInst;
    }
    return null;
  }

  /**
   * Slimme terug: 1) handleBack van de app, 2) secundair split-pane sluiten, 3) home.
   * @returns {boolean} true als iets is afgehandeld
   */
  function goBackSmart() {
    const both = !!(splitLeft && splitRight);
    const inst = getPrimaryAppInst();
    if (inst && typeof inst.handleBack === 'function') {
      try {
        if (inst.handleBack()) {
          syncHeaderNavState();
          return true;
        }
      } catch (e) { console.warn('handleBack', e); }
    }
    if (both) {
      // Sluit rechter pane eerst (secundair)
      if (splitRight) closeSplitSide('right');
      else closeSplitSide('left');
      return true;
    }
    if (splitLeft || splitRight) {
      showHome();
      return true;
    }
    // Geen mini-app: browser-history als fallback
    try { history.back(); } catch (_) {}
    return true;
  }

  function goForwardSmart() {
    try { history.forward(); } catch (_) {}
    return true;
  }

  /** Open-apps taakbalk wordt in app.js gerenderd (renderHeaderOpenApps). */
  function syncHeaderAppChip() {
    try {
      if (typeof window !== 'undefined' && typeof window.renderHeaderOpenApps === 'function') {
        window.renderHeaderOpenApps();
      }
    } catch (_) {}
  }

  function syncHeaderNavState() {
    const back = document.getElementById('btn-nav-back');
    const fwd = document.getElementById('btn-nav-forward');
    const splitBtn = document.getElementById('btn-nav-split');
    const inApp = !!(splitLeft || splitRight) && document.body.classList.contains('browser-open');
    const both = !!(splitLeft && splitRight);
    let allowSplit = true;
    try { allowSplit = loadSettings().splitScreen !== false; } catch (_) {}

    if (back) {
      back.disabled = false;
      back.removeAttribute('aria-disabled');
      back.classList.toggle('is-disabled', false);
      back.title = inApp ? 'Terug' : 'Terug';
    }
    if (fwd) {
      // Browser bepaalt of vooruit kan; we disablen niet hard
      fwd.disabled = false;
    }
    if (splitBtn) {
      const canSplit = inApp && allowSplit && !both && splitLeft && splitLeft.kind !== '__picker__';
      const canUnsplit = both;
      splitBtn.disabled = !(canSplit || canUnsplit);
      splitBtn.setAttribute('aria-disabled', splitBtn.disabled ? 'true' : 'false');
      splitBtn.classList.toggle('is-disabled', splitBtn.disabled);
      splitBtn.classList.toggle('is-split-active', both);
      if (both) {
        splitBtn.title = 'Splitscreen sluiten';
        splitBtn.setAttribute('aria-label', 'Splitscreen sluiten');
      } else {
        splitBtn.title = 'Splitscreen — tweede app ernaast';
        splitBtn.setAttribute('aria-label', 'Splitscreen openen');
      }
    }
    try { syncHeaderAppChip(); } catch (_) {}
  }

  function wireSplitDivider(divider, wrap) {
    let dragging = false;
    const onMove = (clientX) => {
      const rect = wrap.getBoundingClientRect();
      if (rect.width < 40) return;
      let r = (clientX - rect.left) / rect.width;
      r = Math.max(0.25, Math.min(0.75, r));
      splitRatio = r;
      wrap.style.setProperty('--split-ratio', (r * 100).toFixed(2) + '%');
    };
    const end = () => {
      if (!dragging) return;
      dragging = false;
      document.body.classList.remove('split-dragging');
      window.removeEventListener('pointermove', onPtr);
      window.removeEventListener('pointerup', end);
      window.removeEventListener('pointercancel', end);
    };
    const onPtr = (e) => { if (dragging) onMove(e.clientX); };
    divider.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      dragging = true;
      document.body.classList.add('split-dragging');
      window.addEventListener('pointermove', onPtr);
      window.addEventListener('pointerup', end);
      window.addEventListener('pointercancel', end);
    });
    // Toetsenbord: pijltjes
    divider.tabIndex = 0;
    divider.setAttribute('role', 'separator');
    divider.setAttribute('aria-orientation', 'vertical');
    divider.setAttribute('aria-valuenow', Math.round(splitRatio * 100));
    divider.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') {
        splitRatio = Math.max(0.25, splitRatio - 0.05);
        wrap.style.setProperty('--split-ratio', (splitRatio * 100).toFixed(2) + '%');
        e.preventDefault();
      } else if (e.key === 'ArrowRight') {
        splitRatio = Math.min(0.75, splitRatio + 0.05);
        wrap.style.setProperty('--split-ratio', (splitRatio * 100).toFixed(2) + '%');
        e.preventDefault();
      }
    });
  }

  /** Tekent 1 of 2 mini-apps in #view-content. */
  function renderMiniAppView() {
    // Opruimen vóór DOM wissen (media, timers, getState-snapshot)
    closeMountedApps();
    viewContent.replaceChildren();
    const both = !!(splitLeft && splitRight);
    // Split-layout ook bij picker (tweede paneel zichtbaar)
    document.body.classList.toggle('split-open', both);

    if (!both) {
      const only = splitLeft || splitRight;
      if (!only) {
        showHome();
        return;
      }
      if (!splitLeft && splitRight) {
        splitLeft = splitRight;
        splitRight = null;
      }
      // Picker alleen is geen zinvol scherm → home
      if (splitLeft.kind === '__picker__') {
        showHome();
        return;
      }
      const pane = el('div', 'split-pane split-pane-single');
      mountMiniPane(pane, 'left', splitLeft);
      viewContent.append(pane);
    } else {
      const wrap = el('div', 'split-wrap');
      wrap.style.setProperty('--split-ratio', (splitRatio * 100).toFixed(2) + '%');
      const paneL = el('div', 'split-pane split-pane-left');
      const paneR = el('div', 'split-pane split-pane-right');
      const divider = el('div', 'split-divider');
      divider.title = 'Sleep om te verdelen';
      mountMiniPane(paneL, 'left', splitLeft);
      mountMiniPane(paneR, 'right', splitRight);
      wrap.append(paneL, divider, paneR);
      viewContent.append(wrap);
      wireSplitDivider(divider, wrap);
    }

    home.style.display = 'none';
    view.style.display = 'block';


    const kinds = [];
    if (splitLeft && splitLeft.kind !== '__picker__') kinds.push(splitLeft.kind);
    if (splitRight && splitRight.kind !== '__picker__') kinds.push(splitRight.kind);
    const want = kinds.length === 2 ? '#' + kinds[0] + '+' + kinds[1]
      : kinds.length === 1 ? '#' + kinds[0]
      : '#';
    if (want && (location.hash || '') !== want) {
      try { history.replaceState(null, '', want); } catch (_) { location.hash = want; }
    }
    window.scrollTo(0, 0);
    try { syncHeaderNavState(); } catch (_) {}
  }

  /**
   * Open een mini-app (vult het view-gebied; chrome zit in de globale header).
   * Splitscreen via de header-knop ◫.
   */
  function showMiniApp(kind, startPos) {
    const recentId = 'app-' + kind;
    if (!canOpenNewRecent(recentId)) return;

    setCurrentSection(null);
    document.body.classList.remove('pdf-open');
    document.body.classList.remove('search-open');
    document.body.classList.add('browser-open');

    const prevSaved =
      (splitLeft && splitLeft.kind === kind && splitLeft.saved) ||
      (splitRight && splitRight.kind === kind && splitRight.saved) ||
      lastSavedByKind.get(kind) ||
      null;

    // Altijd één app full-screen — geen automatische split
    splitLeft = { kind, startPos: startPos || null, saved: prevSaved };
    splitRight = null;
    renderMiniAppView();

    // Houd bij in recente apps (blijft open in het overzicht)
    const title = (typeof MINI_APP_TITLES !== 'undefined' && MINI_APP_TITLES[kind]) || kind;
    pushRecentApp({
      id: recentId,
      kind: 'app',
      iconKind: kind,
      title,
      hint: 'App',
      activate: () => showMiniApp(kind, startPos || null),
      close: () => {
        try {
          if (splitLeft && splitLeft.kind === kind) {
            splitLeft = null;
            if (splitRight) renderMiniAppView();
            else showHome();
          } else if (splitRight && splitRight.kind === kind) {
            splitRight = null;
            if (splitLeft) renderMiniAppView();
            else showHome();
          }
        } catch (_) { try { showHome(); } catch (__) {} }
      }
    });
    try { syncHeaderNavState(); } catch (_) {}
    try { syncHeaderAppChip(); } catch (_) {}
  }


  /** Woordstudie → woordenboek oorspronkelijke talen */
  window.addEventListener('lc-open-woordenboek-origineel', (e) => {
    const q = (e.detail && e.detail.query) || '';
    try { sessionStorage.setItem('lc-wb-origineel-q', q); } catch (_) {}
    showMiniApp('woordenboek');
  });

  /** Klik op een vers in de Bijbel → splitscreen met Verdieping-app. */
  window.addEventListener('lc-open-verse-study', (e) => {
    const d = e.detail || {};
    const biblePos = Object.assign({}, d.biblePos || {
      osis: d.osis,
      chapter: d.chapter,
      from: d.verse,
      to: d.verse,
    }, { q: null }); // nooit zoekmarkering bij verdieping openen
    splitLeft = { kind: 'bible', startPos: biblePos };
    splitRight = {
      kind: 'verse-study',
      startPos: {
        osis: d.osis,
        chapter: d.chapter,
        verse: d.verse,
        bookNl: d.bookNl,
      },
    };
    renderMiniAppView();
  });

  /** Kruisverwijzing in Verdieping → navigeer de Bijbel (herlaad links). */
  window.addEventListener('lc-bible-navigate', (e) => {
    const osis = e.detail && e.detail.osis;
    if (!osis) return;
    const parts = String(osis).split('.');
    if (parts.length < 2) return;
    const bookOsis = parts[0];
    const chapter = parseInt(parts[1], 10) || 1;
    const verse = parts[2] ? parseInt(parts[2], 10) : null;
    const biblePos = {
      osis: bookOsis,
      chapter,
      from: verse || undefined,
      to: verse || undefined,
      q: null,
    };
    // Links blijft Bijbel, rechts blijft Verdieping (desnoods bijwerken)
    if (!splitLeft || splitLeft.kind !== 'bible') {
      splitLeft = { kind: 'bible', startPos: biblePos };
    } else {
      splitLeft = { kind: 'bible', startPos: biblePos };
    }
    if (splitRight && splitRight.kind === 'verse-study' && verse) {
      splitRight = {
        kind: 'verse-study',
        startPos: {
          osis: bookOsis,
          chapter,
          verse,
          bookNl: bookOsis,
        },
      };
    }
    renderMiniAppView();
  });

  // Audio- en videospeler (src/media/player.js). Vult het scherm zoals de browser.
  // Audio: bij wegnavigeren blijft de muziek op de achtergrond spelen (mini-controls in de header).
  // Video: stopt en ruimt zichzelf op.

  function wireMiniAppEvents() {
    try {
      window.addEventListener('lc-open-verse-study', (e) => {
        const d = e && e.detail;
        if (d) showMiniApp('verse-study', d);
      });
      window.addEventListener('lc-open-woordenboek', (e) => {
        const d = e && e.detail;
        showMiniApp('woordenboek', d || undefined);
      });
    } catch (_) {}
  }

  return {
    showMiniApp,
    renderMiniAppView,
    clearSplitState,
    closeSplitSide,
    createSplitPicker,
    mountMiniPane,
    wireSplitDivider,
    miniAppIconSvg,
    wireMiniAppEvents,
    toggleSplitFromHeader,
    goBackSmart,
    goForwardSmart,
    syncHeaderNavState,
    syncHeaderAppChip,
    getPrimaryAppInst,
    get splitLeft() { return splitLeft; },
    set splitLeft(v) { splitLeft = v; },
    get splitRight() { return splitRight; },
    set splitRight(v) { splitRight = v; },
    get splitRatio() { return splitRatio; },
    set splitRatio(v) { splitRatio = v; },
  };
}
