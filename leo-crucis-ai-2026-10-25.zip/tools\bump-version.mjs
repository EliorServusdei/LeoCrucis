/**
 * Verhoogt automatisch het versienummer bij een build.
 *
 * Gebruik:
 *   node tools/bump-version.mjs          → 0.1.0 → 0.1.1 (patch)
 *   node tools/bump-version.mjs minor    → 0.1.1 → 0.2.0
 *   node tools/bump-version.mjs major    → 0.2.0 → 1.0.0
 *   node tools/bump-version.mjs set 1.2.3
 *   node tools/bump-version.mjs --dry    → toon alleen, schrijf niet
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');

const args = process.argv.slice(2);
const dry = args.includes('--dry');
const mode = args.find(a => a !== '--dry') || 'patch';

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}
function writeJson(p, obj) {
  fs.writeFileSync(p, JSON.stringify(obj, null, 2) + '\n');
}

function bump(ver, kind) {
  if (kind === 'set') {
    const v = args[args.indexOf('set') + 1];
    if (!v || !/^\d+\.\d+\.\d+/.test(v)) throw new Error('Gebruik: set 1.2.3');
    return v.split('-')[0];
  }
  const [maj, min, pat] = ver.split('.').map(n => parseInt(n, 10) || 0);
  if (kind === 'major') return `${maj + 1}.0.0`;
  if (kind === 'minor') return `${maj}.${min + 1}.0`;
  return `${maj}.${min}.${(pat || 0) + 1}`; // patch
}

const pkgPath = path.join(root, 'package.json');
const tauriPath = path.join(root, 'src-tauri', 'tauri.conf.json');
const cargoPath = path.join(root, 'src-tauri', 'Cargo.toml');
const versionJs = path.join(root, 'src', 'version.js');

const pkg = readJson(pkgPath);
const oldV = pkg.version || '0.1.0';
const kind = mode === 'set' ? 'set' : mode;
const newV = bump(oldV, kind);

console.log(`Versie: ${oldV} → ${newV}${dry ? ' (dry-run)' : ''}`);

if (dry) process.exit(0);

pkg.version = newV;
writeJson(pkgPath, pkg);

const tauri = readJson(tauriPath);
tauri.version = newV;
writeJson(tauriPath, tauri);

let cargo = fs.readFileSync(cargoPath, 'utf8');
cargo = cargo.replace(/^version\s*=\s*"[^"]+"/m, `version = "${newV}"`);
fs.writeFileSync(cargoPath, cargo);

fs.writeFileSync(
  versionJs,
  `// Automatisch gegenereerd door tools/bump-version.mjs — niet handmatig wijzigen.\nexport const APP_VERSION = '${newV}';\nexport const APP_NAME = 'Bibliotheek Leo Crucis';\n`
);

console.log('Bijgewerkt: package.json, tauri.conf.json, Cargo.toml, src/version.js');
