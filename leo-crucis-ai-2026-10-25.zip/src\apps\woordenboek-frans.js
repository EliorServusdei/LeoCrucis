// Woordenboek Nederlands → Frans — als opengeslagen boek
// Data: data/woordenboek-frans/nl-fr.json (gebouwd met tools/build-woordenboek-frans.mjs)
//
// Bron: FreeDict nld-fra + fra-nld (GNU GPL v2+). Entry = [nederlands, [[frans, score], …]]
// Score: 3 = uit FreeDict (directe bron).
//
// Opbouw: linkerpagina = register (zoeken, A–Z, woordenlijst met eerste vertaling);
//         rechterpagina = het gekozen woord met de Franse vertalingen.

const DATA_URL = 'data/woordenboek-frans/nl-fr.json';
const RESULTS_MAX = 80;
const EXAMPLES = ['vriend', 'schrijven', 'kerk', 'liefde', 'goed', 'huis'];

let dataPromise = null;
function loadData() {
  if (!dataPromise) {
    dataPromise = fetch(DATA_URL)
      .then(r => { if (!r.ok) throw new Error('nl-fr'); return r.json(); })
      .then(d => {
        const entries = d.entries.map(e => ({ w: e[0], n: norm(e[0]), l: e[1] }));
        const byNorm = new Map();
        const byLetter = new Map();
        for (const e of entries) {
          (byNorm.get(e.n) || byNorm.set(e.n, []).get(e.n)).push(e);
          const L = letterOf(e.n);
          (byLetter.get(L) || byLetter.set(L, []).get(L)).push(e);
        }
        return { meta: d, entries, byNorm, byLetter };
      })
      .catch(err => { dataPromise = null; throw err; });
  }
  return dataPromise;
}

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function norm(s) {
  return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
}

function letterOf(n) {
  const c = (n[0] || '#');
  return c >= 'a' && c <= 'z' ? c : '#';
}

const SCORE_LABEL = {
  3: 'Directe FreeDict-bron',
  2: 'Via Engels bevestigd',
  1: 'Wikidata (vaak eigennamen)'
};
// [css-klasse, uitleg, korte letter]
const GENDER = {
  'm.': ['m', 'mannelijk (le / un)', 'm'],
  'f.': ['f', 'vrouwelijk (la / une)', 'v'],
  'm./f.': ['mf', 'mannelijk of vrouwelijk', 'm/v']
};
const POS_LABEL = { 'zn.': 'zelfstandig naamwoord', 'ww.': 'werkwoord', 'bn.': 'bijvoeglijk naamwoord', 'bw.': 'bijwoord' };

export function injectFransStyles() {
  if (document.getElementById('wbf-styles')) return;
  const s = document.createElement('style');
  s.id = 'wbf-styles';
  s.textContent = `
/* —— Woordenboek: keuze tussen de twee woordenboeken —— */
.wb-modes{flex:0 0 auto;display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.wb-mode{height:30px;padding:0 14px;border-radius:999px;border:1px solid var(--line);background:transparent;
  color:var(--ink);font:inherit;font-size:.86em;font-weight:600;cursor:pointer}
.wb-mode:hover{border-color:var(--acc)}
.wb-mode[aria-pressed="true"]{background:var(--acc);border-color:var(--acc);color:#fff8ea;text-shadow:0 1px 1px rgba(0,0,0,.25)}
.wb-app.wb-fr-mode > :not(.wb-modes):not(.wb-fr){display:none !important}
.wb-fr{flex:1 1 auto;min-height:0;display:none;flex-direction:column;container-type:inline-size}
.wb-app.wb-fr-mode .wb-fr{display:flex}

/* —— Nederlands → Frans: opengeslagen boek —— */
.wbf-stage{flex:1 1 auto;min-height:0;display:flex;justify-content:center;padding:2px 0 4px}
.wbf-book{--wbf-red:#7a1f2b;--wbf-gold:#a67c3a;--wbf-gutter:38px;grid-template-columns:1fr 1fr}
/* Twee even brede pagina's; de rug ligt exact op de scheiding en niets loopt eronder door */
.wbf-book .wb-book-spine{width:var(--wbf-gutter)}
.wbf-book .wb-page-inner{padding:14px 18px 10px;overflow:hidden}
.wbf-book .wb-page-l .wb-page-inner{padding-right:calc(var(--wbf-gutter) / 2 + 14px)}
.wbf-book .wb-page-r .wb-page-inner{padding-left:calc(var(--wbf-gutter) / 2 + 14px)}

/* linkerpagina: register */
.wbf-search{display:flex;gap:6px;margin:0 0 8px;flex:0 0 auto}
.wbf-input{flex:1 1 auto;min-width:0;height:32px;box-sizing:border-box;padding:4px 10px;border-radius:6px;
  border:1px solid rgba(90,70,40,.35);background:#fffaf0;color:#2c241c;font:inherit;font-size:.92em}
.wbf-input:focus{outline:2px solid var(--wbf-gold);outline-offset:0}
.wbf-letters{flex:0 0 auto;display:flex;flex-wrap:wrap;gap:3px;margin:0 0 8px}
.wbf-letter{min-width:24px;height:24px;padding:0 5px;border-radius:5px;border:1px solid rgba(90,70,40,.22);
  background:transparent;color:#4a3b2a;font:inherit;font-size:.8em;font-weight:700;text-transform:uppercase;cursor:pointer}
.wbf-letter:hover{border-color:var(--wbf-gold);color:var(--wbf-red)}
.wbf-letter.on{background:var(--wbf-red);border-color:var(--wbf-red);color:#fff8ea}
.wbf-head{flex:0 0 auto;font-size:.74em;letter-spacing:.12em;text-transform:uppercase;color:#8a7a68;margin:0 0 4px;
  display:flex;justify-content:space-between;gap:8px}
.wbf-words{flex:1 1 auto;min-height:0;overflow-y:auto;margin:0 -6px 0 -2px;padding:0 6px 0 2px}
.wbf-word{display:flex;align-items:baseline;gap:8px;width:100%;box-sizing:border-box;text-align:left;padding:5px 6px;
  border:0;border-bottom:1px solid rgba(90,70,40,.1);background:transparent;color:#2c241c;font:inherit;cursor:pointer;border-radius:4px}
.wbf-word:hover{background:rgba(166,124,58,.12)}
.wbf-word.on{background:rgba(122,31,43,.1);box-shadow:inset 3px 0 0 var(--wbf-red)}
.wbf-w{font-family:Georgia,'Times New Roman',serif;font-weight:700;flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.wbf-fw{margin-left:auto;font-family:Georgia,'Times New Roman',serif;font-style:italic;font-size:.88em;color:var(--wbf-red);
  flex:0 1 45%;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:right}
.wbf-fw.low{opacity:.5}
.wbf-none{margin:14px 2px;font-size:.9em;color:#6a5a48;line-height:1.45}

/* rechterpagina: het woord */
.wbf-entry{flex:1 1 auto;min-height:0;overflow-y:auto;margin:0 -8px 0 0;padding:0 8px 8px 0}
.wbf-top{display:flex;align-items:center;gap:6px;margin:0 0 2px}
.wbf-kicker{font-size:.72em;letter-spacing:.16em;text-transform:uppercase;color:#8a7a68;margin-right:auto}
.wbf-step{width:28px;height:28px;border-radius:6px;border:1px solid rgba(90,70,40,.25);background:transparent;color:#4a3b2a;
  font-size:1.1em;line-height:1;cursor:pointer}
.wbf-step:hover:not(:disabled){border-color:var(--wbf-gold);color:var(--wbf-red)}
.wbf-step:disabled{opacity:.3;cursor:default}
.wbf-back{display:none;height:28px;padding:0 10px;border-radius:6px;border:1px solid rgba(90,70,40,.25);background:transparent;
  color:#4a3b2a;font:inherit;font-size:.82em;cursor:pointer}
.wbf-nl{margin:0;font-family:Georgia,'Times New Roman',serif;font-size:2.1em;line-height:1.1;font-weight:700;font-style:italic;color:#2c241c;word-break:break-word}
.wbf-rule{display:flex;align-items:center;gap:10px;margin:10px 0 14px;color:var(--wbf-gold)}
.wbf-rule::before,.wbf-rule::after{content:"";flex:1;height:1px;background:linear-gradient(90deg,transparent,var(--wbf-gold),transparent)}
.wbf-rule span{font-size:.8em}
.wbf-tr{padding:2px 0 14px;margin:0 0 14px;border-bottom:1px solid rgba(90,70,40,.14)}
.wbf-tr:last-child{border-bottom:0}
.wbf-trhead{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.wbf-la{margin:0;font-family:Georgia,'Times New Roman',serif;font-size:1.75em;line-height:1.15;font-weight:700;color:var(--wbf-red)}
.wbf-pos{font-size:.74em;font-style:italic;color:#6a5a48;border:1px solid rgba(90,70,40,.25);border-radius:999px;padding:1px 8px}
.wbf-g{display:inline-flex;align-items:center;justify-content:center;min-width:22px;height:22px;padding:0 6px;border-radius:999px;
  font-size:.74em;font-weight:700;color:#fff;cursor:help}
.wbf-g.m{background:#2f5d8a}.wbf-g.f{background:#a23b4a}.wbf-g.n{background:#4d7a4a}.wbf-g.mf{background:linear-gradient(90deg,#2f5d8a 50%,#a23b4a 50%)}
.wbf-conf{margin-left:auto;font-size:.74em;letter-spacing:1px;color:var(--wbf-gold);cursor:help;white-space:nowrap}
.wbf-conf.ok{color:#fff;background:var(--wbf-gold);border-radius:999px;padding:1px 9px;letter-spacing:0}
.wbf-conf.s1{opacity:.6}
.wbf-boxes{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 0}
.wbf-box{min-width:88px;border:1px solid rgba(90,70,40,.22);border-radius:8px;background:rgba(255,250,240,.7);padding:4px 10px 6px}
.wbf-box small{display:block;font-size:.66em;letter-spacing:.1em;text-transform:uppercase;color:#8a7a68}
.wbf-box b{font-family:Georgia,'Times New Roman',serif;font-size:1.05em;color:#2c241c}
.wbf-raw{margin:6px 0 0;font-style:italic;color:#6a5a48;font-size:.92em}
.wbf-more{margin-top:2px}
.wbf-more > summary{cursor:pointer;font-size:.84em;color:#6a5a48;padding:4px 0 10px}
.wbf-more .wbf-la{font-size:1.4em}
.wbf-legend{margin:6px 0 0;font-size:.74em;line-height:1.45;color:#8a7a68}

/* welkomstpagina */
.wbf-welcome{flex:1 1 auto;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:8px;padding:8px}
.wbf-orn{font-size:3.2em;line-height:1;color:var(--wbf-gold);font-family:Georgia,serif}
.wbf-wt{margin:0;font-family:Georgia,'Times New Roman',serif;font-size:1.7em;font-weight:700;color:#2c241c;letter-spacing:.03em}
.wbf-ws{margin:0;font-style:italic;color:#6a5a48}
.wbf-wp{margin:4px 0 6px;max-width:34ch;font-size:.9em;line-height:1.5;color:#4a3b2a}
.wbf-chips{display:flex;flex-wrap:wrap;gap:6px;justify-content:center}
.wbf-chip{height:30px;padding:0 14px;border-radius:999px;border:1px solid var(--wbf-gold);background:transparent;color:var(--wbf-red);
  font-family:Georgia,'Times New Roman',serif;font-size:.95em;font-weight:700;cursor:pointer}
.wbf-chip:hover{background:var(--wbf-red);border-color:var(--wbf-red);color:#fff8ea}

/* smalle ruimte (of splitscreen): één pagina tegelijk */
@container (max-width:720px){
  .wbf-book{grid-template-columns:1fr}
  .wbf-book .wb-book-spine{display:none}
  .wbf-book .wb-page-l,.wbf-book .wb-page-r{border-radius:8px}
  .wbf-book.wb-book:not(.wb-closed)[data-view="list"] .wb-page-l{display:flex}
  .wbf-book.wb-book:not(.wb-closed)[data-view="list"] .wb-page-r{display:none}
  .wbf-book.wb-book:not(.wb-closed)[data-view="entry"] .wb-page-l{display:none}
  .wbf-book.wb-book:not(.wb-closed)[data-view="entry"] .wb-page-r{display:flex}
  .wbf-book.wb-book:not(.wb-closed) .wb-page-l::after,
  .wbf-book.wb-book:not(.wb-closed) .wb-page-r::after{display:none}
  .wbf-book[data-view="entry"] .wbf-back{display:inline-block}
  .wbf-book .wb-page-l .wb-page-inner,
  .wbf-book .wb-page-r .wb-page-inner{padding:12px 14px 8px}
}
`;
  document.head.append(s);
}

function displayWord(e) {
  const w = e.w;
  return e.l.length && e.l.every(r => /^[A-Z]/.test(r[0])) ? w.charAt(0).toUpperCase() + w.slice(1) : w;
}

function searchEntries(data, q) {
  const nq = norm(q);
  if (!nq) return null;
  const exact = data.byNorm.get(nq) || [];
  const prefix = [], contains = [];
  for (const e of data.entries) {
    if (e.n === nq) continue;
    if (e.n.startsWith(nq)) prefix.push(e);
    else if (nq.length >= 3 && e.n.includes(nq)) contains.push(e);
  }
  return [...exact, ...prefix, ...contains].slice(0, RESULTS_MAX);
}

/** Het paneel zelf. Geeft { root, focus, setQuery } terug. */
export function createFransPanel() {
  injectFransStyles();
  const root = el('div', 'wb-fr');

  const stage = el('div', 'wbf-stage');
  const book = el('div', 'wb-book wbf-book');
  book.dataset.view = 'list';
  book.setAttribute('aria-label', 'Woordenboek Nederlands naar Frans');

  // —— Linkerpagina: register ——
  const pageL = el('div', 'wb-page wb-page-l');
  const innerL = el('div', 'wb-page-inner');
  const form = el('form', 'wbf-search');
  form.setAttribute('role', 'search');
  const input = el('input', 'wbf-input');
  input.type = 'search';
  input.placeholder = 'Zoek een Nederlands woord…';
  input.setAttribute('aria-label', 'Zoek een Nederlands woord om het Fransse woord te vinden');
  input.autocomplete = 'off';
  input.spellcheck = false;
  form.append(input);
  const letters = el('div', 'wbf-letters');
  letters.setAttribute('role', 'navigation');
  letters.setAttribute('aria-label', 'Letters');
  const headL = el('div', 'wbf-head');
  const headTitle = el('span', '', 'Nederlands');
  const headCount = el('span', '', '');
  headL.append(headTitle, headCount);
  const words = el('div', 'wbf-words');
  words.setAttribute('role', 'listbox');
  innerL.append(form, letters, headL, words);
  pageL.append(innerL);

  const spine = el('div', 'wb-book-spine');

  // —— Rechterpagina: woord ——
  const pageR = el('div', 'wb-page wb-page-r');
  const innerR = el('div', 'wb-page-inner');
  pageR.append(innerR);

  book.append(pageL, spine, pageR);
  stage.append(book);
  root.append(stage);

  // —— State ——
  let data = null;
  let list = [];          // huidige lijst (letter of zoekresultaten)
  let listIdx = -1;       // geselecteerd woord in list
  let curLetter = null;
  let searching = false;
  const wordBtns = [];

  function setView(v) { book.dataset.view = v; }

  function buildLetters() {
    letters.replaceChildren();
    const all = 'abcdefghijklmnopqrstuvwxyz#'.split('');
    for (const L of all) {
      if (!data.byLetter.has(L)) continue;
      const b = el('button', 'wbf-letter', L);
      b.type = 'button';
      b.dataset.l = L;
      b.title = data.byLetter.get(L).length.toLocaleString('nl-NL') + ' woorden';
      b.onclick = () => { input.value = ''; showLetter(L); };
      letters.append(b);
    }
  }

  function markLetter(L) {
    for (const b of letters.children) b.classList.toggle('on', b.dataset.l === L);
  }

  function renderList(entries, title) {
    list = entries;
    listIdx = -1;
    headTitle.textContent = title;
    headCount.textContent = entries.length.toLocaleString('nl-NL');
    words.replaceChildren();
    wordBtns.length = 0;
    if (!entries.length) {
      words.append(el('p', 'wbf-none', 'Geen woorden gevonden. Probeer de stam van het woord (\u201cschrijf\u201d), de onbepaalde wijs (\u201cschrijven\u201d) of een synoniem.'));
      return;
    }
    const frag = document.createDocumentFragment();
    entries.forEach((e, i) => {
      const b = el('button', 'wbf-word');
      b.type = 'button';
      b.setAttribute('role', 'option');
      const first = e.l[0];
      let fwText = first ? first[0] : '';
      if (first && first[2] && GENDER[first[2]]) fwText += ' · ' + GENDER[first[2]][2];
      const fw = el('span', 'wbf-fw' + (first && first[1] < 2 ? ' low' : ''), fwText);
      if (fw.classList.contains('low')) fw.title = 'Minder zeker';
      else if (first && first[2] && GENDER[first[2]]) fw.title = GENDER[first[2]][1];
      b.append(el('span', 'wbf-w', displayWord(e)), fw);
      b.onclick = () => select(i, true);
      frag.append(b);
      wordBtns.push(b);
    });
    words.append(frag);
    words.scrollTop = 0;
  }

  function showLetter(L) {
    searching = false;
    curLetter = L;
    markLetter(L);
    renderList(data.byLetter.get(L) || [], L === '#' ? '#' : L.toUpperCase());
    setView('list');
    showWelcome();
  }

  function runSearch(q) {
    const res = searchEntries(data, q);
    if (!res) { // leeg veld: terug naar de letterlijst
      searching = false;
      showLetter(curLetter || 'a');
      return;
    }
    searching = true;
    markLetter(null);
    renderList(res, 'Zoekresultaten');
    if (res.length) select(0, false);
    else showWelcome(true);
  }

  function select(i, openEntryView) {
    if (i < 0 || i >= list.length) return;
    listIdx = i;
    wordBtns.forEach((b, j) => {
      b.classList.toggle('on', j === i);
      b.setAttribute('aria-selected', String(j === i));
    });
    const b = wordBtns[i];
    if (b) b.scrollIntoView({ block: 'nearest' });
    renderEntry(list[i]);
    if (openEntryView) setView('entry');
  }

  function openWord(w) {
    input.value = w;
    runSearch(w);
    setView('entry');
  }

  // —— Rechterpagina inhoud ——
  function showWelcome(noResult) {
    innerR.replaceChildren();
    const box = el('div', 'wbf-welcome');
    box.append(
      el('div', 'wbf-orn', '\u2720'),
      el('h2', 'wbf-wt', 'Français'),
      el('p', 'wbf-ws', 'Nederlands \u2192 Frans')
    );
    if (noResult) {
      box.append(el('p', 'wbf-wp', 'Dat woord staat er (nog) niet in. Probeer een ander woord of kies er een uit de lijst.'));
    } else {
      box.append(el('p', 'wbf-wp', 'Kies links een woord, een letter, of zoek er een. Hier verschijnt dan het Frans, met de Franse vertaling(en).'));
    }
    const chips = el('div', 'wbf-chips');
    for (const w of EXAMPLES) {
      if (!data || !data.byNorm.has(norm(w))) continue;
      const c = el('button', 'wbf-chip', w);
      c.type = 'button';
      c.onclick = () => openWord(w);
      chips.append(c);
    }
    box.append(chips);
    innerR.append(box);
  }

  function renderTranslation(row, isMore) {
    const [fr, score, gender, pos, note] = row;
    const tr = el('article', 'wbf-tr');
    const head = el('div', 'wbf-trhead');
    head.append(el('h3', 'wbf-la', fr));
    if (pos) {
      const p = el('span', 'wbf-pos', pos);
      p.title = POS_LABEL[pos] || pos;
      head.append(p);
    }
    if (gender && GENDER[gender]) {
      const g = el('span', 'wbf-g ' + GENDER[gender][0], GENDER[gender][2]);
      g.title = GENDER[gender][1];
      head.append(g);
    }
    const conf = el('span', 'wbf-conf' + (score >= 3 ? ' ok' : ' s' + Math.min(score, 3)),
      score >= 3 ? '\u2713' : '\u25CF'.repeat(Math.min(score, 3)));
    conf.title = SCORE_LABEL[score] || SCORE_LABEL[3] || '';
    head.append(conf);
    tr.append(head);
    if (note) {
      const boxes = el('div', 'wbf-boxes');
      const bx = el('div', 'wbf-box');
      bx.append(el('small', '', 'artikel'), el('b', '', note));
      boxes.append(bx);
      if (pos) {
        const bx2 = el('div', 'wbf-box');
        bx2.append(el('small', '', 'woordsoort'), el('b', '', POS_LABEL[pos] || pos));
        boxes.append(bx2);
      }
      tr.append(boxes);
    } else if (pos) {
      const boxes = el('div', 'wbf-boxes');
      const bx2 = el('div', 'wbf-box');
      bx2.append(el('small', '', 'woordsoort'), el('b', '', POS_LABEL[pos] || pos));
      boxes.append(bx2);
      tr.append(boxes);
    }
    return tr;
  }

  function renderEntry(entry) {
    innerR.replaceChildren();
    const top = el('div', 'wbf-top');
    const back = el('button', 'wbf-back', '\u2190 Lijst');
    back.type = 'button';
    back.onclick = () => setView('list');
    const prev = el('button', 'wbf-step', '\u2039');
    prev.type = 'button';
    prev.title = 'Vorig woord';
    prev.setAttribute('aria-label', 'Vorig woord');
    prev.disabled = listIdx <= 0;
    prev.onclick = () => select(listIdx - 1, false);
    const next = el('button', 'wbf-step', '\u203A');
    next.type = 'button';
    next.title = 'Volgend woord';
    next.setAttribute('aria-label', 'Volgend woord');
    next.disabled = listIdx >= list.length - 1;
    next.onclick = () => select(listIdx + 1, false);
    top.append(back, el('span', 'wbf-kicker', 'Nederlands'), prev, next);

    const wrap = el('div', 'wbf-entry');
    wrap.append(el('h2', 'wbf-nl', displayWord(entry)));
    const rule = el('div', 'wbf-rule');
    rule.append(el('span', '', '\u25C6'));
    wrap.append(rule);

        // Alle vertalingen tonen (FreeDict is direct).
    for (const r of entry.l) wrap.append(renderTranslation(r));
    wrap.append(el('p', 'wbf-legend',
      'Geslacht: m = mannelijk (le/un), v = vrouwelijk (la/une). \u2713 = directe bron, \u25CF\u25CF = via Engels. ' +
      'Bron: FreeDict (GNU GPL) + geslachtslijst. Controleer altijd even in een goed Frans woordenboek.'));
    innerR.append(top, wrap);
    wrap.scrollTop = 0;
  }

  // —— Events ——
  let t = null;
  input.addEventListener('input', () => {
    if (!data) return;
    clearTimeout(t);
    t = setTimeout(() => runSearch(input.value), 120);
  });
  form.addEventListener('submit', e => {
    e.preventDefault();
    if (!data) return;
    clearTimeout(t);
    runSearch(input.value);
    if (list.length) setView('entry');
  });
  root.addEventListener('keydown', e => {
    if (!data || !list.length) return;
    if (e.key === 'ArrowDown' && document.activeElement === input) {
      e.preventDefault();
      select(Math.min(listIdx + 1, list.length - 1), false);
    } else if (e.key === 'ArrowUp' && document.activeElement === input) {
      e.preventDefault();
      select(Math.max(listIdx - 1, 0), false);
    }
  });

  // —— Laden ——
  headCount.textContent = '';
  words.append(el('p', 'wbf-none', 'Laden\u2026'));
  innerR.append(el('div', 'wbf-welcome', ''));

  loadData().then(d => {
    data = d;
    buildLetters();
    if (input.value.trim()) runSearch(input.value);
    else showLetter(data.byLetter.has('a') ? 'a' : [...data.byLetter.keys()][0]);
  }).catch(() => {
    words.replaceChildren(el('p', 'wbf-none', 'Kon het Nederlands\u2013Frans woordenboek niet laden.'));
  });

  return {
    root,
    focus() { input.focus(); },
    setQuery(q) { input.value = q || ''; if (data) runSearch(q); }
  };
}
