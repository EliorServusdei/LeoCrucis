// Editor-modus en opslag: wijzigingen en kleine dialogen (geen prompt()/confirm(), die werken niet overal in de app).
const KEY = { dev: 'lc-dev', world: 'lc-world', details: 'lc-details', extra: 'lc-extra-index', refs: 'lc-refs', settings: 'lc-settings' };
/** Focus/studie: aparte documenten (geen localStorage). */
const FOCUS_STUDY_FILE = 'focus-study.json';
const FOCUS_SESSIONS_FILE = 'focus-sessions.json';
const get = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
const put = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { alert('Opslaan mislukt: ' + e.message); } };

/** Editor is altijd actief in de app; bewaard voor compatibiliteit met oudere code. */
export const isDev = () => true;
export const setDev = (_on) => { /* no-op: editor blijft altijd aan */ };
export const loadSaved = () => ({ world: get(KEY.world, null), details: get(KEY.details, null) });
// In de echte app (Tauri) worden boeken en wereld als bestanden bewaard in de gebruikersmap; in de browser in localStorage.
const inv = window.__TAURI__ && window.__TAURI__.core && window.__TAURI__.core.invoke;
export const inTauri = !!inv;
export const readFile = path => inv('read_user_file', { path });          // tekst of null
export const writeFile = (path, contents) => inv('write_user_file', { path, contents });
export const deleteFile = path => inv('delete_user_file', { path });
export const openFolder = () => inv('open_user_folder');
/** Open media/music of media/video in de bestandsverkenner (Tauri). kind: 'audio' | 'video' */
export const openMediaFolder = (kind) => inv('open_media_folder', { kind: kind === 'video' ? 'video' : 'music' });
export const listStad = () => inv('list_user_stad');                     // [[gebouwmap, [boek-id's], gebouw.json-tekst of null], ...]
export const exportUserImage = (dir, name, dataB64) => inv('export_user_image', { dir, name, dataB64 });
export const listUserCovers = () => inv('list_user_covers');           // [[gebouwmap, pad], ...]
export const readUserImageB64 = rel => inv('read_user_image_b64', { rel });
export const readUserPdfB64 = (dir, name) => inv('read_user_pdf_b64', { dir, name });
export const resetFiles = bundled => inv('reset_user_data', { bundled });   // wist alleen world.json en de meegeleverde boeken, nooit je eigen boeken
export const saveWorld = w => inTauri ? writeFile('world.json', JSON.stringify(w, null, 1)) : put(KEY.world, w);
export const saveDetails = d => put(KEY.details, d);
export const loadExtra = () => get(KEY.extra, {});                 // zoekfragmenten van eigen/gewijzigde boeken
export const saveExtra = x => put(KEY.extra, x);
export const loadRefs = () => get(KEY.refs, {});                  // eigen referentiegegevens per boek (browser)
export const saveRefs = r => put(KEY.refs, r);
export const resetAll = () => Object.values(KEY).filter(k => k !== KEY.dev).forEach(k => localStorage.removeItem(k));

export const slug = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'nieuw';
export function uniqueId(base, taken) { let id = base, n = 2; while (taken.has(id)) id = base + '-' + n++; return id; }

// Dialoog: ask('Titel van het boek', { input: true }) -> tekst of null; ask('Zeker?', { yes: 'Verwijder' }) -> true/false
export function ask(message, { input = false, value = '', yes = 'OK', no: noLabel = 'Annuleren' } = {}) {
  return new Promise(resolve => {
    const back = document.createElement('div'); back.className = 'dlg-back';
    const box = document.createElement('div'); box.className = 'dlg'; box.setAttribute('role', 'dialog');
    const p = document.createElement('p'); p.textContent = message; box.append(p);
    let field = null;
    if (input) { field = document.createElement('input'); field.value = value; box.append(field); }
    const row = document.createElement('div'); row.className = 'dlg-row';
    const no = document.createElement('button'); no.textContent = noLabel; no.className = 'back';
    const ok = document.createElement('button'); ok.textContent = yes; ok.className = 'dlg-ok';
    row.append(no, ok); box.append(row); back.append(box); document.body.append(back);
    const done = v => { back.remove(); resolve(v); };
    no.onclick = () => done(input ? null : false);
    ok.onclick = () => done(input ? (field.value.trim() || null) : true);
    back.addEventListener('keydown', e => { if (e.key === 'Escape') no.onclick(); if (e.key === 'Enter' && input) ok.onclick(); });
    (field || ok).focus();
  });
}


/** Printers van het systeem (alleen Tauri-desktopapp). */
export async function listPrinters() {
  if (!inv) throw new Error('Printers alleen in de Leo Crucis-app (niet in de browser)');
  return inv('list_printers');
}

/** PDF (base64) afdrukken op gekozen printer. */
export async function printPdfBase64(pdfBase64, printer) {
  if (!inv) throw new Error('Afdrukken alleen in de Leo Crucis-app (niet in de browser)');
  return inv('print_pdf', { pdfBase64, printer });
}


/** App-instellingen (thema, lettergrootte, weergave, …). */
const DEFAULT_SETTINGS = {
  theme: 'system',      // light | dark | system
  fontSize: 'normal',   // small | normal | large | xlarge
  reduceMotion: false,
  fullscreen: true,
  pdfMaxMb: 500,        // maximale grootte van een ingelezen PDF (MB)
  viewMode: 'interactive', // interactive | compact | list
  splitScreen: true,    // twee mini-apps naast elkaar (Bijbel + Notities, …)
  recentAppsMax: 3,     // max. open apps in recente-apps overzicht (1–8)
  focusMode: false,     // fullscreen + altijd vooraan + bevestiging bij afsluiten
  trackPresence: true,  // detecteer of je op het scherm blijft
  warnOnReturn: true,   // melding als je terugkomt na wegklikken
  warnAfterSec: 20,     // minimale afwezigheid (seconden) voor een melding
  presenceGraceSec: 8,  // seconden wachten vooraleer "weg" te markeren
  studyBlockMin: 25,    // standaard studieblok in minuten
  saveSessionHistory: true,  // sessies altijd bewaren (standaard aan)
  sessionHistoryMax: 60,     // max. aantal bewaarde sessies (1–500)
  // Prestaties bij laden/downloads
  loadThrottle: true,        // vertraag zwaar werk als FPS te laag is
  loadMinFps: 30,            // drempel (frames per seconde)
  loadThrottleMs: 120,       // max. extra pauze per yield (ms) bij lage FPS
  maxFps: 0,                 // 0 = onbeperkt; anders plafond (CPU sparen)
  loadPower: 'normal',       // low | normal | high | max — hoe hard laden
  loadConcurrency: 2,        // max. parallelle downloads (1–4)
  hwAccel: true,             // GPU / hardwareversnelling voor CSS & canvas
  mediaQuality: 'normal',    // high | normal | low — afbeeldingen/media
  searchIndexMode: 'ondemand', // startup | ondemand
  pdfQuality: 'normal',      // fast | normal | sharp
  backgroundTasks: true,     // periodieke scans / achtergrondwerk
  restoreSession: true,      // laatste scherm herstellen bij start
  animDuration: 'normal',    // short | normal | off
  bibleMarkDepth: true,      // verzen met/zonder verdieping zwart/grijs in Bijbeltekst
  biblePlanMinReadMin: 5     // minimale leestijd per leesplan-dag (minuten)
};

/** localStorage-sleutels als betrouwbare backup (browser + fallback als bestanden falen). */
const LS_STUDY = 'lc-focus-study-v2';
const LS_SESSIONS = 'lc-focus-sessions-v2';

/** Studie-statistieken: voltooide blokken, streak, history per dag, mijlpalen. */
const DEFAULT_STUDY = {
  streak: 0,
  lastCompleteDay: null, // YYYY-MM-DD (lokaal)
  totalBlocks: 0,
  totalFocusMs: 0,
  // day -> { blocks, focusMs }
  days: {},
  // id -> ISO timestamp wanneer behaald
  achievements: {}
};
/** In-memory cache — sync lezen voor de UI; schrijven geserialiseerd + localStorage-backup. */
let _studyCache = null;
let _sessionsCache = null;
let _focusStorageReady = false;
let _writeChain = Promise.resolve(); // serialiseert alle file-writes
let _studyDirty = false;
let _sessionsDirty = false;
let _flushTimer = null;

function normalizeStudy(raw) {
  const r = raw && typeof raw === 'object' ? raw : {};
  return {
    ...DEFAULT_STUDY,
    ...r,
    days: { ...(r.days || {}) },
    achievements: { ...(r.achievements || {}) }
  };
}

function normalizeSession(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const id = String(raw.id || '').trim();
  if (!id) return null;
  return {
    id,
    start: raw.start || id,
    end: raw.end || new Date().toISOString(),
    day: raw.day || todayKey(new Date(raw.start || id)),
    focusMs: Math.max(0, Number(raw.focusMs) || 0),
    awayMs: Math.max(0, Number(raw.awayMs) || 0),
    leaves: Math.max(0, Number(raw.leaves) || 0)
  };
}

function normalizeSessions(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  const seen = new Set();
  for (const raw of list) {
    const s = normalizeSession(raw);
    if (!s || seen.has(s.id)) continue;
    seen.add(s.id);
    out.push(s);
  }
  return out;
}

function readLs(key) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : null;
  } catch (e) { return null; }
}
function writeLs(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; }
  catch (e) { console.warn('localStorage schrijven mislukt:', key, e); return false; }
}

export function loadStudy() {
  if (_studyCache) return {
    ..._studyCache,
    days: { ...(_studyCache.days || {}) },
    achievements: { ...(_studyCache.achievements || {}) }
  };
  // Fallback: localStorage als init nog niet klaar is
  const ls = readLs(LS_STUDY);
  if (ls) return normalizeStudy(ls);
  return { ...DEFAULT_STUDY, days: {}, achievements: {} };
}

export function saveStudy(s) {
  _studyCache = normalizeStudy(s);
  _studyDirty = true;
  writeLs(LS_STUDY, _studyCache); // synchrone backup — nooit verliezen bij crash
  scheduleFocusFlush();
}

export function loadSessions() {
  if (Array.isArray(_sessionsCache)) return _sessionsCache.map(s => ({ ...s }));
  const ls = readLs(LS_SESSIONS);
  if (Array.isArray(ls)) return normalizeSessions(ls);
  return [];
}

export function saveSessions(list) {
  _sessionsCache = normalizeSessions(list);
  _sessionsDirty = true;
  writeLs(LS_SESSIONS, _sessionsCache);
  scheduleFocusFlush();
}

function scheduleFocusFlush() {
  if (_flushTimer) return;
  _flushTimer = setTimeout(() => {
    _flushTimer = null;
    flushFocusStorage().catch(e => console.warn('Focus flush:', e));
  }, 400);
}

/** Forceer direct wegschrijven (bestands-IO + localStorage). Wacht tot klaar. */
export async function flushFocusStorage() {
  if (_flushTimer) { clearTimeout(_flushTimer); _flushTimer = null; }
  const doStudy = _studyDirty && _studyCache;
  const doSes = _sessionsDirty && Array.isArray(_sessionsCache);
  if (!doStudy && !doSes) return;
  // Snapshot onder lock van de write-chain
  const studySnap = doStudy ? JSON.parse(JSON.stringify(_studyCache)) : null;
  const sesSnap = doSes ? JSON.parse(JSON.stringify(_sessionsCache)) : null;
  if (doStudy) _studyDirty = false;
  if (doSes) _sessionsDirty = false;

  _writeChain = _writeChain.then(async () => {
    if (studySnap) {
      writeLs(LS_STUDY, studySnap);
      if (inTauri) {
        try { await writeFile(FOCUS_STUDY_FILE, JSON.stringify(studySnap, null, 1)); }
        catch (e) {
          console.warn('focus-study.json schrijven:', e);
          _studyDirty = true; // opnieuw proberen
        }
      }
      try { if (window.__lcFocusWriteHook) window.__lcFocusWriteHook(FOCUS_STUDY_FILE, JSON.stringify(studySnap, null, 1)); }
      catch (e) { /* ignore */ }
    }
    if (sesSnap) {
      writeLs(LS_SESSIONS, sesSnap);
      if (inTauri) {
        try { await writeFile(FOCUS_SESSIONS_FILE, JSON.stringify(sesSnap, null, 1)); }
        catch (e) {
          console.warn('focus-sessions.json schrijven:', e);
          _sessionsDirty = true;
        }
      }
      try { if (window.__lcFocusWriteHook) window.__lcFocusWriteHook(FOCUS_SESSIONS_FILE, JSON.stringify(sesSnap, null, 1)); }
      catch (e) { /* ignore */ }
    }
  }).catch(e => console.warn('Focus write chain:', e));
  await _writeChain;
}

/** Standaarddocumenten uit de app-bundel: src/data/focus-*.json */
async function loadBundledFocusJson(name) {
  try {
    const res = await fetch(`data/${name}`);
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    return null;
  }
}

/**
 * Laad focusdata (volgorde = meest betrouwbaar eerst):
 * 1) gebruikersmap (Tauri bestanden)
 * 2) localStorage backup (browser + crash-recovery)
 * 3) gebundelde standaarddocumenten
 * 4) oude localStorage-sleutels (migratie)
 */
export async function initFocusStorage() {
  if (_focusStorageReady) return;
  let studyRaw = null;
  let sessionsRaw = null;

  if (inTauri) {
    try {
      const t = await readFile(FOCUS_STUDY_FILE);
      if (t != null && String(t).trim() !== '') studyRaw = JSON.parse(t);
    } catch (e) { console.warn('Lezen focus-study.json:', e); }
    try {
      const t = await readFile(FOCUS_SESSIONS_FILE);
      if (t != null && String(t).trim() !== '') sessionsRaw = JSON.parse(t);
    } catch (e) { console.warn('Lezen focus-sessions.json:', e); }
  }

  // localStorage-backup (ook in Tauri als bestanden leeg/corrupt zijn)
  if (!studyRaw) studyRaw = readLs(LS_STUDY);
  if (!sessionsRaw) sessionsRaw = readLs(LS_SESSIONS);

  // Bundel
  if (!studyRaw) studyRaw = await loadBundledFocusJson(FOCUS_STUDY_FILE);
  if (!sessionsRaw) sessionsRaw = await loadBundledFocusJson(FOCUS_SESSIONS_FILE);

  // Migratie oude sleutels
  try {
    if (!studyRaw) {
      const old = localStorage.getItem('lc-study');
      if (old) {
        studyRaw = JSON.parse(old);
        localStorage.removeItem('lc-study');
      }
    }
    if (!sessionsRaw) {
      const old = localStorage.getItem('lc-sessions');
      if (old) {
        sessionsRaw = JSON.parse(old);
        localStorage.removeItem('lc-sessions');
      }
    }
  } catch (e) { /* ignore */ }

  _studyCache = normalizeStudy(studyRaw);
  _sessionsCache = normalizeSessions(sessionsRaw);
  _focusStorageReady = true;

  // Direct durably opslaan (localStorage + bestanden)
  writeLs(LS_STUDY, _studyCache);
  writeLs(LS_SESSIONS, _sessionsCache);
  _studyDirty = true;
  _sessionsDirty = true;
  await flushFocusStorage();
}

/** Bestandsnamen (voor UI/hints). */
export const FOCUS_FILES = { study: FOCUS_STUDY_FILE, sessions: FOCUS_SESSIONS_FILE };
export function todayKey(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** Definitie van mijlpalen / achievements. */
export const ACHIEVEMENTS = [
  { id: 'first_block', icon: '▶', title: 'Eerste blok', desc: '1 studieblok afgerond', check: s => (s.totalBlocks || 0) >= 1 },
  { id: 'blocks_5', icon: '5', title: 'Op dreef', desc: '5 blokken totaal', check: s => (s.totalBlocks || 0) >= 5 },
  { id: 'blocks_25', icon: '25', title: 'Vasthoudend', desc: '25 blokken totaal', check: s => (s.totalBlocks || 0) >= 25 },
  { id: 'blocks_100', icon: '100', title: 'Centurion', desc: '100 blokken totaal', check: s => (s.totalBlocks || 0) >= 100 },
  { id: 'time_1h', icon: '1u', title: 'Eerste uur', desc: '1 uur focustijd totaal', check: s => (s.totalFocusMs || 0) >= 3600000 },
  { id: 'time_10h', icon: '10u', title: 'Diepe focus', desc: '10 uur focustijd totaal', check: s => (s.totalFocusMs || 0) >= 36000000 },
  { id: 'time_50h', icon: '50u', title: 'Marathon', desc: '50 uur focustijd totaal', check: s => (s.totalFocusMs || 0) >= 180000000 },
  { id: 'streak_3', icon: '3', title: 'Drie dagen', desc: 'Streak van 3 dagen', check: s => (s.streak || 0) >= 3 },
  { id: 'streak_7', icon: '7', title: 'Weekvast', desc: 'Streak van 7 dagen', check: s => (s.streak || 0) >= 7 },
  { id: 'streak_30', icon: '30', title: 'Maandvast', desc: 'Streak van 30 dagen', check: s => (s.streak || 0) >= 30 },
  { id: 'day_3blocks', icon: '★★★', title: 'Drukke dag', desc: '3 blokken op één dag', check: s => Object.values(s.days || {}).some(d => (d.blocks || 0) >= 3) },
  { id: 'long_45', icon: '45', title: 'Lang blok', desc: 'Een blok van 45+ min', check: s => !!(s.achievements && s.achievements.long_45) || (s._lastBlockMs || 0) >= 45 * 60 * 1000 }
];

/** Controleer en ontgrendel nieuwe mijlpalen. Geeft nieuw behaalde terug. */
export function evaluateAchievements(s, extra = {}) {
  const state = { ...s, ...extra };
  if (!state.achievements) state.achievements = {};
  const newly = [];
  for (const a of ACHIEVEMENTS) {
    if (state.achievements[a.id]) continue;
    let ok = false;
    try { ok = !!a.check(state); } catch (e) { ok = false; }
    if (ok) {
      state.achievements[a.id] = new Date().toISOString();
      newly.push(a);
    }
  }
  return { state, newly };
}

/** Registreer een voltooid studieblok; werkt streak en mijlpalen bij. */
export function recordStudyBlock(durationMs) {
  let s = loadStudy();
  const day = todayKey();
  if (!s.days[day]) s.days[day] = { blocks: 0, focusMs: 0 };
  s.days[day].blocks += 1;
  s.days[day].focusMs += durationMs;
  s.totalBlocks = (s.totalBlocks || 0) + 1;
  s.totalFocusMs = (s.totalFocusMs || 0) + durationMs;

  // Streak: opeenvolgende kalenderdagen met ≥1 blok
  if (s.lastCompleteDay === day) {
    // zelfde dag: streak blijft
  } else {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yKey = todayKey(yesterday);
    if (s.lastCompleteDay === yKey) s.streak = (s.streak || 0) + 1;
    else s.streak = 1;
    s.lastCompleteDay = day;
  }
  // Oude dagen opschonen (houd ~90 dagen)
  const keys = Object.keys(s.days).sort();
  while (keys.length > 90) {
    delete s.days[keys.shift()];
  }

  const { state, newly } = evaluateAchievements(s, { _lastBlockMs: durationMs });
  // long_45 handmatig als blok lang genoeg was
  if (durationMs >= 45 * 60 * 1000 && !state.achievements.long_45) {
    state.achievements.long_45 = new Date().toISOString();
    const def = ACHIEVEMENTS.find(a => a.id === 'long_45');
    if (def) newly.push(def);
  }
  saveStudy(state);
  state._newlyUnlocked = newly;
  return state;
}
/** Samenvatting van de laatste 7 dagen. */
export function weekStudySummary() {
  return periodStudySummary('week');
}

/** Sessies: max. bepaalt de gebruiker (sessionHistoryMax). Altijd lokaal + bestand. */
export function clampSessionMax(n) {
  let x = parseInt(n, 10);
  if (!Number.isFinite(x) || x < 1) x = 1;
  if (x > 500) x = 500;
  return x;
}
/** Schrijf of werk huidige sessie bij. maxCount = max. bewaarde sessies. */
export function upsertSession(session, maxCount) {
  const norm = normalizeSession(session);
  if (!norm) return loadSessions();
  let list = loadSessions();
  const i = list.findIndex(x => x.id === norm.id);
  if (i >= 0) list[i] = norm;
  else list.unshift(norm);
  // Nieuwste eerst (op end-tijd)
  list.sort((a, b) => String(b.end || b.start || '').localeCompare(String(a.end || a.start || '')));
  const max = clampSessionMax(maxCount != null ? maxCount : (loadSettings().sessionHistoryMax || 60));
  if (list.length > max) list = list.slice(0, max);
  saveSessions(list);
  return list;
}
/** Trim bestaande lijst tot max. */
export function trimSessions(maxCount) {
  const max = clampSessionMax(maxCount);
  let list = loadSessions();
  if (list.length > max) {
    list = list.slice(0, max);
    saveSessions(list);
  }
  return list;
}
export function clearSessions() {
  saveSessions([]);
  flushFocusStorage().catch(() => {});
}

/** Voortgang voor periode: day | week | month | year | total */
export function periodStudySummary(period = 'week') {
  const s = loadStudy();
  const now = new Date();
  const start = new Date(now);
  if (period === 'day') {
    start.setHours(0, 0, 0, 0);
  } else if (period === 'week') {
    start.setDate(start.getDate() - 6);
    start.setHours(0, 0, 0, 0);
  } else if (period === 'month') {
    start.setDate(1);
    start.setHours(0, 0, 0, 0);
  } else if (period === 'year') {
    start.setMonth(0, 1);
    start.setHours(0, 0, 0, 0);
  } else {
    start.setTime(0);
  }

  let blocks = 0, focusMs = 0;
  const dayBars = [];
  const startKey = period === 'total' ? '1970-01-01' : todayKey(start);

  Object.keys(s.days || {}).forEach(key => {
    if (period !== 'total' && key < startKey) return;
    const day = s.days[key];
    blocks += day.blocks || 0;
    focusMs += day.focusMs || 0;
  });

  // Weekbalken altijd 7 dagen (voor grafiek)
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = todayKey(d);
    const day = s.days[key];
    dayBars.push({
      key,
      label: d.toLocaleDateString('nl-BE', { weekday: 'short' }).replace('.', ''),
      blocks: day ? (day.blocks || 0) : 0,
      focusMs: day ? (day.focusMs || 0) : 0
    });
  }

  // Sessies in periode (focus/away)
  const sessions = loadSessions().filter(ses => {
    if (period === 'total') return true;
    const t = ses.start || ses.id;
    return t >= start.toISOString();
  });
  let sessFocus = 0, sessAway = 0;
  sessions.forEach(ses => {
    sessFocus += ses.focusMs || 0;
    sessAway += ses.awayMs || 0;
  });

  return {
    period,
    blocks,
    focusMs,
    streak: s.streak || 0,
    totalBlocks: s.totalBlocks || 0,
    totalFocusMs: s.totalFocusMs || 0,
    dayBars,
    achievements: s.achievements || {},
    sessionFocusMs: sessFocus,
    sessionAwayMs: sessAway,
    sessionCount: sessions.length
  };
}
export function loadSettings() {
  return { ...DEFAULT_SETTINGS, ...get(KEY.settings, {}) };
}
export function saveSettings(s) {
  put(KEY.settings, { ...DEFAULT_SETTINGS, ...s });
}
export function applySettings(s) {
  const st = { ...DEFAULT_SETTINGS, ...s };
  const root = document.documentElement;
  if (st.theme === 'system') root.removeAttribute('data-theme');
  else root.setAttribute('data-theme', st.theme);
  root.setAttribute('data-font', st.fontSize || 'normal');
  root.setAttribute('data-view', 'interactive');
  root.classList.toggle('reduce-motion', !!st.reduceMotion);
  root.classList.toggle('focus-mode', !!st.focusMode);
  root.classList.toggle('no-hw-accel', st.hwAccel === false);
  root.setAttribute('data-media-quality', st.mediaQuality || 'normal');
  root.setAttribute('data-pdf-quality', st.pdfQuality || 'normal');
  root.setAttribute('data-anim', st.animDuration || 'normal');
  root.classList.toggle('anim-off', (st.animDuration || 'normal') === 'off' || !!st.reduceMotion);
  root.classList.toggle('anim-short', (st.animDuration || 'normal') === 'short');
  return st;
}

/** Wis tijdelijke cache (niet: instellingen, wereld, studie). */
export function clearAppCache() {
  const keep = new Set([
    'lc-dev', 'lc-world', 'lc-details', 'lc-extra-index', 'lc-refs', 'lc-settings',
    'lc-focus-study-v2', 'lc-focus-sessions-v2',
  ]);
  const removed = [];
  try {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k) keys.push(k);
    }
    for (const k of keys) {
      if (keep.has(k)) continue;
      // alleen lc- / leo-achtige caches
      if (/^(lc-|leo-|woordenboek|search)/i.test(k) || k.includes('recent') || k.includes('pos-v') || k.includes('cache')) {
        localStorage.removeItem(k);
        removed.push(k);
      }
    }
  } catch (e) {
    console.warn('clearAppCache', e);
  }
  try {
    window.dispatchEvent(new CustomEvent('lc-cache-cleared', { detail: { removed } }));
  } catch (_) {}
  return removed;
}

/** Huidig Tauri-venster (of null in de browser). */
export function getTauriWindow() {
  try {
    const wapi = window.__TAURI__?.window || window.__TAURI__?.webviewWindow;
    if (!wapi) return null;
    return (wapi.getCurrentWindow || wapi.getCurrentWebviewWindow)?.() || null;
  } catch (e) { return null; }
}
