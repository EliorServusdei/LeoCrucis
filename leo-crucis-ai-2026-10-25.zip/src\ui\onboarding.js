/**
 * ui/onboarding.js — korte eerste-keer-rondleiding (fase 4)
 */

const STORAGE_KEY = 'lc-onboarding-v1';

const STEPS = [
  {
    title: 'Welkom bij Leo Crucis',
    body: 'Dit is je bibliotheek: een stad met gebouwen, planken en boeken. Klik op een gebouw om naar binnen te gaan.',
  },
  {
    title: 'Zoeken',
    body: 'Open zoeken met de knop “Zoeken” of de sneltoets Ctrl+K (op Mac: ⌘K). Typ een woord, bijbelvers of appnaam.',
  },
  {
    title: 'Apps',
    body: 'Bijbel, woordenboek, kalender, notities en meer open je via het startscherm of zoeken — niet via de header.',
  },
  {
    title: 'Navigatie',
    body: 'Gebruik ← → in de header of Alt+pijltjes om terug en vooruit te gaan. Home brengt je naar het startscherm.',
  },
  {
    title: 'Klaar',
    body: 'Tip: druk op ? voor een overzicht van sneltoetsen. Je kunt deze rondleiding later opnieuw starten via Instellingen.',
  },
];

export function hasCompletedOnboarding() {
  try {
    return localStorage.getItem(STORAGE_KEY) === 'done';
  } catch (_) {
    return true;
  }
}

export function markOnboardingDone() {
  try { localStorage.setItem(STORAGE_KEY, 'done'); } catch (_) {}
}

export function resetOnboarding() {
  try { localStorage.removeItem(STORAGE_KEY); } catch (_) {}
}

/**
 * Toon de rondleiding (modaal).
 * @param {{ onDone?: () => void }} [opts]
 */
export function startOnboarding(opts = {}) {
  const existing = document.getElementById('lc-onboarding');
  if (existing) existing.remove();

  let step = 0;

  const back = document.createElement('div');
  back.id = 'lc-onboarding';
  back.className = 'lc-onboard-back';
  back.setAttribute('role', 'dialog');
  back.setAttribute('aria-modal', 'true');
  back.setAttribute('aria-label', 'Rondleiding');

  const box = document.createElement('div');
  box.className = 'lc-onboard-box';

  const progress = document.createElement('div');
  progress.className = 'lc-onboard-progress';
  progress.setAttribute('aria-hidden', 'true');

  const title = document.createElement('h2');
  title.className = 'lc-onboard-title';

  const body = document.createElement('p');
  body.className = 'lc-onboard-body';

  const actions = document.createElement('div');
  actions.className = 'lc-onboard-actions';

  const skip = document.createElement('button');
  skip.type = 'button';
  skip.className = 'back';
  skip.textContent = 'Overslaan';

  const next = document.createElement('button');
  next.type = 'button';
  next.className = 'dlg-ok';
  next.textContent = 'Volgende';

  actions.append(skip, next);
  box.append(progress, title, body, actions);
  back.appendChild(box);
  document.body.appendChild(back);

  function finish() {
    markOnboardingDone();
    back.remove();
    try { opts.onDone && opts.onDone(); } catch (_) {}
  }

  function render() {
    const s = STEPS[step];
    title.textContent = s.title;
    body.textContent = s.body;
    progress.textContent = `${step + 1} / ${STEPS.length}`;
    next.textContent = step >= STEPS.length - 1 ? 'Aan de slag' : 'Volgende';
    next.focus();
  }

  skip.onclick = finish;
  next.onclick = () => {
    if (step >= STEPS.length - 1) finish();
    else {
      step += 1;
      render();
    }
  };

  back.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      e.preventDefault();
      finish();
    }
  });

  render();
}

/**
 * Start alleen als de gebruiker de rondleiding nog niet heeft gezien.
 * @param {{ delayMs?: number, onDone?: () => void }} [opts]
 */
export function maybeStartOnboarding(opts = {}) {
  if (hasCompletedOnboarding()) return;
  const delay = opts.delayMs != null ? opts.delayMs : 600;
  setTimeout(() => {
    if (hasCompletedOnboarding()) return;
    startOnboarding(opts);
  }, delay);
}
