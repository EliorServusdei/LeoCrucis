/**
 * core/json.js — eenvoudige fetch-JSON helper.
 */

export async function loadJSON(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Kan ${path} niet laden (${res.status})`);
  return res.json();
}
