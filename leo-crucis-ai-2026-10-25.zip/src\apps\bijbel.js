// Bijbellezer — leest de losse tekstbestanden uit data/bijbel/ (zie tools/build-bijbel-vulgata.mjs).
// De tekst is een los databestand per vertaling: een extra vertaling toevoegen = een nieuwe map
// data/bijbel/<id>/ en een regel in data/bijbel/index.json ("translations").

import { loadSettings } from '../core/edit.js';

const BASE = 'data/bijbel/';
const META_BASE = 'data/bijbel-meta/';
const PLAN_URL = 'data/bijbel-leesplan.json';
const POS_KEY = 'lc-bijbel-pos-v1';
const PLAN_KEY = 'lc-bijbel-leesplan-v1';
const metaCache = new Map();

/** Laadt verdiepingsmeta voor een hoofdstuk; geeft Set van versnummers (string) met data. */
async function loadMetaVerseSet(bookOsis, chapter) {
  const key = `${bookOsis}.${chapter}`;
  if (metaCache.has(key)) return metaCache.get(key);
  try {
    const res = await fetch(`${META_BASE}${bookOsis}.${chapter}.json`);
    if (!res.ok) {
      const empty = new Set();
      metaCache.set(key, empty);
      return empty;
    }
    const data = await res.json();
    const set = new Set(Object.keys((data && data.verses) || {}));
    metaCache.set(key, set);
    return set;
  } catch {
    const empty = new Set();
    metaCache.set(key, empty);
    return empty;
  }
}

const norm = s => String(s)
  .toLowerCase()
  .replace(/æ/g, 'ae').replace(/œ/g, 'oe')
  .normalize('NFD').replace(/[̀-ͯ]/g, '');
// Zoeken: de Vulgaat mengt i/j en u/v, dus die vallen samen.
const squash = s => norm(s).replace(/j/g, 'i').replace(/v/g, 'u');
// Boeknamen: spaties en punten weg, zodat "1 Kor." en "1kor" gelijk zijn.
const bookKey = s => norm(s).replace(/[^a-z0-9]/g, '');

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

/** Arabisch getal → kleine Romeinse cijfers (i, ii, iii, iv, …). */
function toRoman(n) {
  n = Math.floor(Number(n)) || 0;
  if (n <= 0) return '';
  const vals = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1];
  const syms = ['m', 'cm', 'd', 'cd', 'c', 'xc', 'l', 'xl', 'x', 'ix', 'v', 'iv', 'i'];
  let out = '';
  for (let i = 0; i < vals.length; i++) {
    while (n >= vals[i]) { out += syms[i]; n -= vals[i]; }
  }
  return out;
}

function loadPos() {
  try { return JSON.parse(localStorage.getItem(POS_KEY) || 'null') || {}; } catch { return {}; }
}
function savePos(p) {
  try { localStorage.setItem(POS_KEY, JSON.stringify(p)); } catch (_) {}
}

const PLAN_MIN_READ_MS_DEFAULT = 5 * 60 * 1000;

function loadPlanProgress() {
  try {
    const raw = JSON.parse(localStorage.getItem(PLAN_KEY) || 'null') || {};
    const startedAt = (raw.startedAt && typeof raw.startedAt === 'object') ? raw.startedAt : {};
    // normaliseer keys naar string
    const started = {};
    for (const [k, v] of Object.entries(startedAt)) {
      const t = Number(v);
      if (t > 0) started[String(k)] = t;
    }
    return {
      startDate: raw.startDate || null,
      completed: Array.isArray(raw.completed) ? raw.completed.map(Number) : [],
      currentDay: Number(raw.currentDay) || 1,
      startedAt: started, // day -> timestamp ms wanneer lezen begon
    };
  } catch {
    return { startDate: null, completed: [], currentDay: 1, startedAt: {} };
  }
}
function savePlanProgress(p) {
  try { localStorage.setItem(PLAN_KEY, JSON.stringify(p)); } catch (_) {}
}

function planMinReadMs() {
  try {
    const st = loadSettings();
    const min = Number(st && st.biblePlanMinReadMin);
    if (min > 0 && min <= 120) return Math.round(min * 60 * 1000);
  } catch (_) {}
  return PLAN_MIN_READ_MS_DEFAULT;
}
function planMinReadLabel() {
  const m = Math.round(planMinReadMs() / 60000) || 5;
  return m === 1 ? '1 minuut' : (m + ' minuten');
}

// Veelgebruikte afkortingen die niet met het begin van de naam samenvallen.
const EXTRA_ALIASES = {
  Gen: ['gn'], Exod: ['ex'], Num: ['nm'], Deut: ['dt'], Josh: ['joz'], Judg: ['re', 'rechtersboek'],
  '1Sam': ['1sm'], '2Sam': ['2sm'], '1Kgs': ['1kon', '1reg'], '2Kgs': ['2kon', '2reg'],
  '1Chr': ['1kron', '1par'], '2Chr': ['2kron', '2par'], Ps: ['ps', 'psalm'], Prov: ['spr', 'spreuk'],
  Eccl: ['pred', 'qoh'], Song: ['hoogl', 'hl', 'cant'], Isa: ['js', 'jes'], Jer: ['jr'], Lam: ['kl'],
  Ezek: ['ez', 'ezech'], Dan: ['dn'], Tob: ['tb', 'tobias'], Jdt: ['judit', 'judith'],
  Wis: ['wijs', 'sap'], Sir: ['sirach', 'ecc'], Bar: ['baruch'],
  '1Macc': ['1mak', '1mach'], '2Macc': ['2mak', '2mach'],
  Matt: ['mt', 'mat'], Mark: ['mc', 'mr', 'mar'], Luke: ['lc', 'luc'],
  John: ['joh', 'jo', 'jn'], Acts: ['hand', 'hnd'], Rom: ['rm'], '1Cor': ['1kor'], '2Cor': ['2kor'],
  Gal: ['gl'], Eph: ['ef'], Phil: ['fil', 'flp'], Col: ['kol'], '1Thess': ['1tes', '1thes'],
  '2Thess': ['2tes', '2thes'], '1Tim': ['1tm'], '2Tim': ['2tm'], Phlm: ['flm', 'filem'],
  Heb: ['hebr'], Jas: ['jak', 'jc'], '1Pet': ['1pt'], '2Pet': ['2pt'], '1John': ['1joh', '1jo'],
  '2John': ['2joh', '2jo'], '3John': ['3joh', '3jo'], Rev: ['openb', 'apoc', 'ap']
};

export function createBijbelApp(startPos) {
  const root = el('div', 'app-panel bijbel-app');
  const state = { idx: null, tr: null, tr2: null, compare: false, book: null, chapter: 1, hi: null, cache: new Map(), all: null };
  // startPos (uit zoekresultaat) heeft voorrang op opgeslagen positie
  const pos = Object.assign({}, loadPos(), startPos && typeof startPos === 'object' ? startPos : {});
  let flow = pos.flow === true; // doorlopende tekst i.p.v. één vers per regel
  if (pos.compare === true) state.compare = true;
  let sideOpen = pos.sideOpen !== false; // boekenlijst standaard open
  let planMode = false; // zijbalk toont leesplan i.p.v. boekenlijst
  let planData = null;  // geladen uit bijbel-leesplan.json
  let planProg = loadPlanProgress();

  // ── bovenbalk (groepen + iconen, rustiger) ─────────────
  const bar = el('div', 'bb-bar');

  const svgIcon = (paths, size = 20) => {
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    s.setAttribute('width', String(size));
    s.setAttribute('height', String(size));
    s.setAttribute('fill', 'none');
    s.setAttribute('stroke', 'currentColor');
    s.setAttribute('stroke-width', '2');
    s.setAttribute('stroke-linecap', 'round');
    s.setAttribute('stroke-linejoin', 'round');
    s.setAttribute('aria-hidden', 'true');
    s.style.width = size + 'px';
    s.style.height = size + 'px';
    s.style.flexShrink = '0';
    s.innerHTML = paths;
    return s;
  };
  const icBook = () => svgIcon('<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>');
  const icGo = () => svgIcon('<path d="M5 12h14"/><path d="M13 6l6 6-6 6"/>');
  const icSearch = () => svgIcon('<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>');
  const icFlow = () => svgIcon('<path d="M4 6h16M4 12h10M4 18h14"/>'); // regels = verzen onder elkaar
  const icFlowOn = () => svgIcon('<path d="M4 7h16M4 12h16M4 17h16"/>'); // doorlopend
  const icCompare = () => svgIcon('<rect x="3" y="4" width="8" height="16" rx="1.5"/><rect x="13" y="4" width="8" height="16" rx="1.5"/>');
  const icList = () => svgIcon('<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>');
  const icPlan = () => svgIcon('<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/><path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/>');

  // Groep: vertaling
  const grpTr = el('div', 'bb-grp');
  const trSel = el('select', 'bb-select bb-tr');
  trSel.setAttribute('aria-label', 'Vertaling');
  trSel.title = 'Vertaling';
  const trSel2 = el('select', 'bb-select bb-tr2');
  trSel2.setAttribute('aria-label', 'Tweede vertaling');
  trSel2.title = 'Tweede vertaling (vergelijken)';
  trSel2.hidden = !state.compare;
  const trLead = el('span', 'bb-grp-ic');
  trLead.append(icBook());
  trLead.title = 'Vertaling';
  grpTr.append(trLead, trSel, trSel2);

  // Groep: ga naar
  const grpGo = el('div', 'bb-grp bb-grp-grow');
  const refForm = el('form', 'bb-form');
  const refIn = el('input', 'bb-input');
  refIn.type = 'text';
  refIn.placeholder = 'Joh 3,16';
  refIn.setAttribute('aria-label', 'Ga naar bijbelplaats');
  refIn.title = 'Ga naar (bv. Joh 3,16 of Gen 1)';
  const refBtn = el('button', 'bb-btn bb-btn-icon');
  refBtn.type = 'submit';
  refBtn.title = 'Ga naar plaats';
  refBtn.setAttribute('aria-label', 'Ga naar plaats');
  refBtn.append(icGo());
  refForm.append(refIn, refBtn);
  grpGo.append(refForm);

  // Groep: zoeken
  const grpSearch = el('div', 'bb-grp bb-grp-grow');
  const searchForm = el('form', 'bb-form');
  const qIn = el('input', 'bb-input');
  qIn.type = 'search';
  qIn.placeholder = 'Zoeken…';
  qIn.setAttribute('aria-label', 'Zoeken in de bijbel');
  const scopeSel = el('select', 'bb-select bb-scope');
  scopeSel.setAttribute('aria-label', 'Zoekbereik');
  scopeSel.title = 'Zoekbereik';
  for (const [v, lab] of [['all', 'Alles'], ['OT', 'OT'], ['NT', 'NT'], ['book', 'Boek']]) {
    const o = el('option', '', lab); o.value = v;
    if (v === 'all') o.textContent = 'Alles';
    if (v === 'OT') { o.textContent = 'OT'; o.title = 'Oude Testament'; }
    if (v === 'NT') { o.textContent = 'NT'; o.title = 'Nieuwe Testament'; }
    if (v === 'book') { o.textContent = 'Boek'; o.title = 'Huidig boek'; }
    scopeSel.append(o);
  }
  const qBtn = el('button', 'bb-btn bb-btn-icon');
  qBtn.type = 'submit';
  qBtn.title = 'Zoeken';
  qBtn.setAttribute('aria-label', 'Zoeken');
  qBtn.append(icSearch());
  searchForm.append(qIn, scopeSel, qBtn);
  grpSearch.append(searchForm);

  // Groep: weergave-opties (icon-toggles)
  const grpOpts = el('div', 'bb-grp bb-grp-opts');

  const listBtn = el('button', 'bb-btn bb-btn-icon bb-ghost');
  listBtn.type = 'button';
  listBtn.append(icList());
  const syncListBtn = () => {
    listBtn.classList.toggle('on', sideOpen);
    listBtn.title = sideOpen ? 'Boekenlijst verbergen' : 'Boekenlijst tonen';
    listBtn.setAttribute('aria-label', listBtn.title);
    listBtn.setAttribute('aria-pressed', sideOpen ? 'true' : 'false');
  };
  syncListBtn();
  // onclick wired after layout bestaat

  const flowBtn = el('button', 'bb-btn bb-btn-icon bb-ghost');
  flowBtn.type = 'button';
  const syncFlowBtn = () => {
    flowBtn.replaceChildren(flow ? icFlowOn() : icFlow());
    flowBtn.title = flow
      ? 'Doorlopend lezen (aan) — klik voor verzen onder elkaar'
      : 'Verzen onder elkaar — klik voor doorlopend lezen';
    flowBtn.setAttribute('aria-label', flowBtn.title);
    flowBtn.classList.toggle('on', flow);
  };
  syncFlowBtn();
  flowBtn.onclick = () => { flow = !flow; savePos({ ...loadPos(), flow }); syncFlowBtn(); renderChapter(); };

  const cmpBtn = el('button', 'bb-btn bb-btn-icon bb-ghost');
  cmpBtn.type = 'button';
  cmpBtn.append(icCompare());
  const syncCmpBtn = () => {
    cmpBtn.classList.toggle('on', state.compare);
    cmpBtn.title = state.compare ? 'Vergelijken uitzetten' : 'Twee vertalingen vergelijken';
    cmpBtn.setAttribute('aria-label', cmpBtn.title);
    cmpBtn.setAttribute('aria-pressed', state.compare ? 'true' : 'false');
    trSel2.hidden = !state.compare;
    grpTr.classList.toggle('bb-grp-compare', state.compare);
  };
  syncCmpBtn();
  cmpBtn.onclick = async () => {
    state.compare = !state.compare;
    savePos({ ...loadPos(), compare: state.compare, tr2: state.tr2 && state.tr2.id });
    syncCmpBtn();
    refreshSide();
    await renderChapter();
  };
  const planBtn = el('button', 'bb-btn bb-btn-icon bb-ghost');
  planBtn.type = 'button';
  planBtn.append(icPlan());
  const syncPlanBtn = () => {
    planBtn.classList.toggle('on', planMode);
    planBtn.title = planMode ? 'Leesplan verbergen — toon boekenlijst' : 'Bijbelleesplan (364 dagen)';
    planBtn.setAttribute('aria-label', planBtn.title);
    planBtn.setAttribute('aria-pressed', planMode ? 'true' : 'false');
  };
  syncPlanBtn();

  grpOpts.append(listBtn, planBtn, flowBtn, cmpBtn);

  bar.append(grpTr, grpGo, grpSearch, grpOpts);

  function syncSearchPlaceholder() {
    if (!state.tr) return;
    const lang = state.tr.language || '';
    if (lang === 'la') qIn.placeholder = 'Zoeken (Latijn)…';
    else if (lang === 'he-gr' || lang === 'he' || lang === 'hbo') qIn.placeholder = 'Zoeken (Hebreeuws/Grieks)…';
    else if (lang === 'gr' || lang === 'el' || lang === 'grc') qIn.placeholder = 'Zoeken (Grieks)…';
    else qIn.placeholder = 'Zoeken…';
  }

  function isRtlTranslation(tr) {
    if (!tr) return false;
    if (tr.rtl === true) return true;
    const lang = tr.language || '';
    return lang === 'he' || lang === 'hbo' || lang === 'he-gr' || lang === 'ar';
  }

  /** Alleen Hebreeuwse (proto-canonieke) OT-boeken RTL; deuterocanoniek + NT zijn Grieks. */
  function isRtlBook(tr, book) {
    if (!isRtlTranslation(tr)) return false;
    if ((tr.language || '') === 'he-gr') {
      if (!book || book.t !== 'OT') return false;
      // deuterocanonieke boeken in deze vertaling zijn Grieks (LXX)
      if (book.deutero || book.osis in { Tob:1, Jdt:1, Wis:1, Sir:1, Bar:1, '1Macc':1, '2Macc':1 }) return false;
      return true;
    }
    return true;
  }

  // ── zijbalk + lezer (inklappen via knop in de balk) ──
  const layout = el('div', 'bb-layout');
  if (!sideOpen) layout.classList.add('bb-side-collapsed');

  const side = el('nav', 'bb-side');
  side.setAttribute('aria-label', 'Bijbelboeken');
  side.id = 'bb-side-nav';
  listBtn.setAttribute('aria-controls', 'bb-side-nav');

  const main = el('div', 'bb-main');
  layout.append(side, main);
  root.append(bar, layout);

  listBtn.onclick = () => {
    sideOpen = !sideOpen;
    layout.classList.toggle('bb-side-collapsed', !sideOpen);
    syncListBtn();
    savePos({ ...loadPos(), sideOpen });
  };

  planBtn.onclick = async () => {
    planMode = !planMode;
    syncPlanBtn();
    if (planMode) {
      if (!sideOpen) {
        sideOpen = true;
        layout.classList.remove('bb-side-collapsed');
        syncListBtn();
        savePos({ ...loadPos(), sideOpen });
      }
      await ensurePlan();
      buildPlanSide();
      // Open de huidige vrijgegeven dag, of herteken zodat alleen toegestane chips zichtbaar zijn
      const u = unlockedDay();
      const day = (planData.plan || []).find(d => d.day === u);
      if (!state.book || !isChapterAllowedInPlan(state.book.osis, state.chapter)) {
        if (day && day.refs && day.refs[0]) {
          await openPlanRef(day.refs[0], u);
        }
      } else {
        // al op een toegestaan hoofdstuk: herteken (chips filteren)
        await renderChapter();
      }
    } else {
      clearPlanTimer();
      buildSide();
      // volledige hoofdstukkeuze terug
      if (state.book) await renderChapter();
    }
  };

  const status = el('p', 'bb-status', 'Bijbel laden…');
  main.append(status);

  // ── boeken ─────────────────────────────────────────────
  const bookByOsis = o => state.idx.books.find(b => b.osis === o);
  const bookBtns = new Map();

  function booksForTrId(trId) {
    if (!state.idx || !trId) return [];
    const allowed = state.idx.booksByTranslation && state.idx.booksByTranslation[trId];
    if (allowed) {
      const set = new Set(allowed);
      return state.idx.books.filter(b => set.has(b.osis));
    }
    return state.idx.books;
  }

  function booksForTr() {
    if (!state.tr) return [];
    // Bij vergelijken: alleen boeken die in beide vertalingen voorkomen
    if (state.compare && state.tr2) {
      const a = new Set(booksForTrId(state.tr.id).map(b => b.osis));
      return booksForTrId(state.tr2.id).filter(b => a.has(b.osis));
    }
    return booksForTrId(state.tr.id);
  }

  function buildSide() {
    side.replaceChildren();
    bookBtns.clear();
    for (const [t, label] of [['OT', 'Oude Testament'], ['NT', 'Nieuwe Testament']]) {
      side.append(el('h3', 'bb-side-h', label));
      const ul = el('ul', 'bb-books');
      for (const b of booksForTr().filter(x => x.t === t)) {
        const li = el('li');
        const btn = el('button', 'bb-book', b.nl);
        btn.type = 'button';
        btn.title = b.la;
        btn.onclick = () => openBook(b.osis, 1);
        bookBtns.set(b.osis, btn);
        li.append(btn); ul.append(li);
      }
      side.append(ul);
    }
    const info = el('p', 'bb-note');
    if (state.compare && state.tr2) {
      info.textContent = `Vergelijken: ${state.tr.name} ↔ ${state.tr2.name}. Alleen gemeenschappelijke boeken.`;
    } else {
      info.textContent = state.tr.note || '';
    }
    side.append(info);
  }

  /** Zijbalk: leesplan behouden als planMode aan staat. */
  function refreshSide() {
    if (planMode) buildPlanSide();
    else buildSide();
  }

  async function ensurePlan() {
    if (planData) return planData;
    try {
      const res = await fetch(PLAN_URL);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      planData = await res.json();
    } catch (e) {
      planData = { title: 'Bijbelleesplan', days: 0, plan: [], description: 'Kon leesplan niet laden.' };
      console.warn('Leesplan laden mislukt', e);
    }
    return planData;
  }

  /** Hoogste dag die al gelezen mag worden (volgende na laatste afgevinkte). */
  function unlockedDay() {
    const done = planProg.completed;
    if (!done.length) return 1;
    const maxDone = Math.max(...done);
    const max = (planData && planData.days) || 364;
    return Math.min(max, maxDone + 1);
  }

  function isDayDone(day) {
    return planProg.completed.includes(Number(day));
  }

  /** Dag is zichtbaar als afgerond of als de actieve leesdag. */
  function isDayUnlocked(day) {
    day = Number(day);
    return day <= unlockedDay();
  }

  /** Alleen de actieve leesdag mag geopend worden (niet eerdere/afgeronde dagen). */
  function isDayReadable(day) {
    day = Number(day);
    return day === unlockedDay() && !isDayDone(day);
  }

  function activeDayEntry() {
    if (!planData || !planData.plan) return null;
    const u = unlockedDay();
    return planData.plan.find(d => d.day === u) || null;
  }

  function dayStartedAt(day) {
    return Number(planProg.startedAt[String(day)]) || 0;
  }

  function msLeftForDay(day) {
    const t0 = dayStartedAt(day);
    if (!t0) return planMinReadMs();
    return Math.max(0, planMinReadMs() - (Date.now() - t0));
  }

  function formatMs(ms) {
    const s = Math.ceil(ms / 1000);
    const m = Math.floor(s / 60);
    const r = s % 60;
    return m + ':' + String(r).padStart(2, '0');
  }

  function showPlanPopup(message, opts) {
    opts = opts || {};
    const existing = document.querySelector('.bb-plan-popup-back');
    if (existing) existing.remove();
    const back = el('div', 'bb-plan-popup-back');
    const box = el('div', 'bb-plan-popup');
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-modal', 'true');
    const title = el('p', 'bb-plan-popup-title', opts.title || 'Lees het stuk echt');
    const msg = el('p', 'bb-plan-popup-msg', message);
    const row = el('div', 'bb-plan-popup-row');
    const close = () => back.remove();

    if (opts.confirm) {
      const cancel = el('button', 'bb-btn bb-ghost', opts.cancelLabel || 'Annuleren');
      cancel.type = 'button';
      cancel.onclick = () => {
        close();
        if (typeof opts.onCancel === 'function') opts.onCancel();
      };
      const ok = el('button', 'bb-btn', opts.okLabel || 'OK');
      ok.type = 'button';
      ok.onclick = () => {
        close();
        if (typeof opts.onConfirm === 'function') opts.onConfirm();
      };
      row.append(cancel, ok);
      back.onclick = (e) => { if (e.target === back) cancel.onclick(); };
      back.addEventListener('keydown', (e) => { if (e.key === 'Escape') cancel.onclick(); });
      box.append(title, msg, row);
      back.append(box);
      document.body.append(back);
      ok.focus();
    } else {
      const ok = el('button', 'bb-btn', opts.okLabel || 'Begrepen');
      ok.type = 'button';
      ok.onclick = close;
      row.append(ok);
      back.onclick = (e) => { if (e.target === back) close(); };
      back.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
      box.append(title, msg, row);
      back.append(box);
      document.body.append(back);
      ok.focus();
    }
  }

  /** Start de leestimer voor een dag (eenmalig). */
  function markDayStarted(day) {
    day = Number(day);
    if (!isDayUnlocked(day)) return false;
    if (isDayDone(day)) return true;
    if (!dayStartedAt(day)) {
      planProg.startedAt[String(day)] = Date.now();
      planProg.currentDay = day;
      savePlanProgress(planProg);
    }
    return true;
  }

  /** Probeer een dag af te vinken. Geeft { ok, reason }. */
  function tryCompleteDay(day) {
    day = Number(day);
    if (isDayDone(day)) {
      // al gedaan — mag niet terugdraaien in strikte modus? wel toestaan omvinken
      return { ok: true, undo: true };
    }
    if (!isDayUnlocked(day)) {
      return { ok: false, reason: 'Deze dag is nog niet vrij. Lees eerst de vorige dagen.' };
    }
    // Vorige dag moet af zijn (behalve dag 1)
    if (day > 1 && !isDayDone(day - 1)) {
      return { ok: false, reason: 'Rond eerst dag ' + (day - 1) + ' af voordat je verder gaat.' };
    }
    if (!dayStartedAt(day)) {
      return { ok: false, reason: 'Open eerst de lezing van deze dag en lees minstens ' + planMinReadLabel() + '.' };
    }
    const left = msLeftForDay(day);
    if (left > 0) {
      return {
        ok: false,
        reason: 'Lees het stuk echt. Je moet nog ' + formatMs(left) + ' minuten wachten voordat je deze dag mag afronden.',
      };
    }
    return { ok: true };
  }

  function completeDay(day) {
    day = Number(day);
    const set = new Set(planProg.completed);
    set.add(day);
    planProg.completed = [...set].sort((a, b) => a - b);
    planProg.currentDay = Math.min(((planData && planData.days) || 364), day + 1);
    savePlanProgress(planProg);
  }

  async function completeDayAndAdvance(day) {
    completeDay(day);
    buildPlanSide();
    const next = activeDayEntry();
    if (next && next.refs && next.refs[0]) {
      await openPlanRef(next.refs[0], next.day);
    }
  }

  function uncompleteDay(day) {
    day = Number(day);
    planProg.completed = planProg.completed.filter(d => d !== day);
    // als je een eerdere dag uncheckt, blijven latere completed staan — maar unlockedDay daalt
    savePlanProgress(planProg);
  }

  function startPlanToday() {
    const d = new Date();
    const iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    planProg.startDate = iso;
    planProg.currentDay = 1;
    planProg.completed = [];
    planProg.startedAt = {};
    savePlanProgress(planProg);
  }

  async function restartPlanFully() {
    startPlanToday();
    buildPlanSide();
    const entry = activeDayEntry(); // dag 1
    if (entry && entry.refs && entry.refs[0]) {
      await openPlanRef(entry.refs[0], 1);
    }
  }

  function formatRef(r) {
    const books = (state.idx && state.idx.books) || [];
    const b = books.find(x => x.osis === r.osis);
    const name = b ? (b.short || b.nl || r.osis) : r.osis;
    let s = name;
    if (r.from === r.to) {
      s += ' ' + r.from;
      if (r.verseFrom != null) {
        s += ':' + r.verseFrom;
        if (r.verseTo != null && r.verseTo !== r.verseFrom) s += '–' + r.verseTo;
      }
    } else {
      s += ' ' + r.from + '–' + r.to;
    }
    return s;
  }

  /** Alleen passages van de actieve leesdag (niet eerdere dagen). */
  function allowedPlanRefs() {
    if (!planData || !planData.plan) return [];
    const entry = activeDayEntry();
    if (!entry) return [];
    return (entry.refs || []).map(r => ({ ...r, day: entry.day }));
  }

  /** Mag dit hoofdstuk in planmodus bekeken worden? */
  function isChapterAllowedInPlan(osis, chapter) {
    const ch = Number(chapter);
    return allowedPlanRefs().some(r =>
      r.osis === osis && ch >= (r.from || 1) && ch <= (r.to || r.from || 1)
    );
  }

  function planGuardMessage() {
    const u = unlockedDay();
    const entry = activeDayEntry();
    const label = entry ? entry.label : ('dag ' + u);
    return 'In het leesplan lees je één dag tegelijk. Nu is alleen dag ' + u + ' open (' + label + '). Eerdere dagen zijn afgesloten. Lees het stuk echt — minstens ' + planMinReadLabel() + ' — voordat de volgende dag vrijkomt.';
  }

  async function openPlanRef(ref, day) {
    if (!ref || !ref.osis) return;
    const d = Number(day) || unlockedDay();
    if (isDayDone(d)) {
      showPlanPopup('Dag ' + d + ' is al afgerond. Ga verder met dag ' + unlockedDay() + '.');
      return;
    }
    if (!isDayReadable(d)) {
      showPlanPopup('Deze dag is nog vergrendeld. Lees eerst dag ' + unlockedDay() + ' af (minstens ' + planMinReadLabel() + ').');
      return;
    }
    markDayStarted(d);
    planProg.currentDay = d;
    savePlanProgress(planProg);
    const hi = ref.verseFrom != null
      ? { from: ref.verseFrom, to: ref.verseTo || ref.verseFrom }
      : null;
    await openBook(ref.osis, ref.from || 1, hi);
    if (planMode) buildPlanSide();
  }

  let planTimerId = null;
  function clearPlanTimer() {
    if (planTimerId) { clearInterval(planTimerId); planTimerId = null; }
  }

  function buildPlanSide() {
    side.replaceChildren();
    side.setAttribute('aria-label', 'Bijbelleesplan');
    clearPlanTimer();
    if (!planData || !planData.plan) {
      side.append(el('p', 'bb-status', 'Leesplan laden…'));
      return;
    }

    const head = el('div', 'bb-plan-head');
    head.append(el('h3', 'bb-side-h', planData.title || 'Bijbelleesplan'));

    const doneCount = planProg.completed.length;
    const total = planData.days || planData.plan.length;
    const pct = total ? Math.round((doneCount / total) * 100) : 0;
    const prog = el('div', 'bb-plan-progress');
    const barOuter = el('div', 'bb-plan-bar');
    const barInner = el('div', 'bb-plan-bar-fill');
    barInner.style.width = pct + '%';
    barOuter.append(barInner);
    const progLab = el('div', 'bb-plan-prog-lab', doneCount + ' / ' + total + ' dagen (' + pct + '%) · vrij t.e.m. dag ' + unlockedDay());
    prog.append(barOuter, progLab);
    head.append(prog);

    // Actieve leestimer
    const active = planProg.currentDay || unlockedDay();
    const timerBox = el('div', 'bb-plan-timer');
    const updateTimer = () => {
      if (isDayDone(active)) {
        timerBox.textContent = 'Dag ' + active + ' is afgerond.';
        timerBox.classList.add('done');
        clearPlanTimer();
        return;
      }
      const t0 = dayStartedAt(active);
      if (!t0) {
        timerBox.textContent = 'Open de lezing van dag ' + active + ' om de timer (' + planMinReadLabel() + ') te starten.';
        timerBox.classList.remove('ready');
        return;
      }
      const left = msLeftForDay(active);
      if (left <= 0) {
        timerBox.textContent = 'Klaar — je mag dag ' + active + ' nu afronden.';
        timerBox.classList.add('ready');
        clearPlanTimer();
      } else {
        timerBox.textContent = 'Nog ' + formatMs(left) + ' lezen op dag ' + active + '…';
        timerBox.classList.remove('ready');
      }
    };
    updateTimer();
    if (!isDayDone(active) && dayStartedAt(active) && msLeftForDay(active) > 0) {
      planTimerId = setInterval(() => {
        updateTimer();
        // als timer klaar is, herbouw check-knoppen
        if (msLeftForDay(active) <= 0) buildPlanSide();
      }, 1000);
    }
    head.append(timerBox);

    const actions = el('div', 'bb-plan-actions');
    const jumpBtn = el('button', 'bb-btn bb-btn-sm', 'Huidige dag');
    jumpBtn.type = 'button';
    jumpBtn.title = 'Spring naar de actieve leesdag';
    jumpBtn.onclick = () => {
      const d = unlockedDay();
      planProg.currentDay = d;
      savePlanProgress(planProg);
      buildPlanSide();
      const elDay = side.querySelector('[data-plan-day="' + d + '"]');
      if (elDay) elDay.scrollIntoView({ block: 'center', behavior: 'smooth' });
    };
    const startBtn = el('button', 'bb-btn bb-btn-sm bb-ghost', planProg.startDate ? 'Herstart plan' : 'Start plan');
    startBtn.type = 'button';
    startBtn.title = planProg.startDate || planProg.completed.length ? 'Plan opnieuw vanaf dag 1 (voortgang wissen)' : 'Plan starten vanaf vandaag';
    startBtn.onclick = () => {
      if (!planProg.startDate && planProg.completed.length === 0) {
        restartPlanFully();
        return;
      }
      showPlanPopup('Het plan opnieuw beginnen vanaf dag 1? Alle voortgang (afgeronde dagen en timers) wordt gewist.', {
        title: 'Herstart plan',
        confirm: true,
        okLabel: 'Herstarten',
        cancelLabel: 'Annuleren',
        onConfirm: () => { restartPlanFully(); },
      });
    };
    actions.append(jumpBtn, startBtn);
    head.append(actions);
    side.append(head);

    const list = el('div', 'bb-plan-list');
    let lastSec = null;
    const focusDay = planProg.currentDay || unlockedDay();

    for (const day of planData.plan) {
      if (day.section && day.section !== lastSec) {
        lastSec = day.section;
        list.append(el('h4', 'bb-plan-sec', day.section));
      }
      const row = el('div', 'bb-plan-day');
      row.dataset.planDay = String(day.day);
      const unlocked = isDayUnlocked(day.day);
      const done = isDayDone(day.day);
      if (done) row.classList.add('done');
      if (!unlocked) row.classList.add('locked');
      if (day.day === focusDay) row.classList.add('today');

      const check = el('button', 'bb-plan-check', done ? '✓' : (unlocked ? '' : '🔒'));
      check.type = 'button';
      if (!unlocked) {
        check.disabled = true;
        check.title = 'Nog vergrendeld';
      } else if (done) {
        check.title = 'Markeer als ongelezen';
        check.setAttribute('aria-pressed', 'true');
      } else {
        const left = msLeftForDay(day.day);
        check.title = left > 0
          ? 'Nog ' + formatMs(left) + ' lezen vóór afronden'
          : 'Markeer als gelezen';
        check.setAttribute('aria-pressed', 'false');
      }
      check.onclick = (ev) => {
        ev.stopPropagation();
        if (!unlocked) {
          showPlanPopup('Deze dag is nog vergrendeld. Lees het stuk echt — rond eerst de vorige dag af (minstens ' + planMinReadLabel() + ').');
          return;
        }
        if (done) {
          uncompleteDay(day.day);
          buildPlanSide();
          return;
        }
        const result = tryCompleteDay(day.day);
        if (!result.ok) {
          showPlanPopup(result.reason);
          return;
        }
        completeDayAndAdvance(day.day);
      };

      const body = el('div', 'bb-plan-body');
      const num = el('span', 'bb-plan-num', 'Dag ' + day.day + (unlocked ? '' : ' · vergrendeld'));
      const lab = el('div', 'bb-plan-label', day.label);
      body.append(num, lab);

      const readable = isDayReadable(day.day);
      if (day.refs && day.refs.length && readable) {
        const chips = el('div', 'bb-plan-chips');
        day.refs.forEach((ref) => {
          const chip = el('button', 'bb-chip bb-plan-chip', formatRef(ref));
          chip.type = 'button';
          chip.title = 'Open ' + formatRef(ref);
          chip.onclick = (ev) => {
            ev.stopPropagation();
            openPlanRef(ref, day.day);
          };
          chips.append(chip);
        });
        body.append(chips);
      } else if (done) {
        body.append(el('div', 'bb-plan-lock-hint', 'Afgerond — verder met dag ' + unlockedDay()));
      } else if (!unlocked) {
        body.append(el('div', 'bb-plan-lock-hint', 'Nog niet beschikbaar'));
      }

      row.append(check, body);
      row.onclick = () => {
        if (done) {
          showPlanPopup('Dag ' + day.day + ' is al afgerond. Je leest nu dag ' + unlockedDay() + '.');
          return;
        }
        if (!readable) {
          showPlanPopup('Dag ' + day.day + ' is nog vergrendeld. Lees het stuk echt: rond dag ' + unlockedDay() + ' eerst af (minstens ' + planMinReadLabel() + ').');
          return;
        }
        planProg.currentDay = day.day;
        savePlanProgress(planProg);
        if (day.refs && day.refs[0]) openPlanRef(day.refs[0], day.day);
        else buildPlanSide();
      };
      list.append(row);
    }
    side.append(list);

    requestAnimationFrame(() => {
      const elDay = side.querySelector('[data-plan-day="' + focusDay + '"]');
      if (elDay) elDay.scrollIntoView({ block: 'center' });
    });
  }

  async function loadBookData(osis, trId) {
    const tid = trId || state.tr.id;
    const key = tid + ':' + osis;
    if (state.cache.has(key)) return state.cache.get(key);
    const res = await fetch(`${BASE}${tid}/${osis}.json`);
    if (!res.ok) throw new Error(`Kan ${osis} niet laden (${res.status})`);
    const d = await res.json();
    const pack = { c: d.c, f: d.f || null, fnSource: d.fnSource || null };
    state.cache.set(key, pack);
    return pack;
  }

  async function openBook(osis, chapter, hi) {
    const b = bookByOsis(osis);
    if (!b) return;
    // alleen boeken van de huidige vertaling
    if (!booksForTr().some(x => x.osis === osis)) return;
    // Leesplan-modus: alleen vrijgegeven passages
    if (planMode) {
      const ch = Math.min(Math.max(1, chapter || 1), b.ch);
      if (!isChapterAllowedInPlan(osis, ch)) {
        showPlanPopup(planGuardMessage());
        return;
      }
    }
    state.book = b;
    state.chapter = Math.min(Math.max(1, chapter || 1), b.ch);
    state.hi = hi || null;
    for (const [o, btn] of bookBtns) btn.classList.toggle('on', o === osis);
    await renderChapter();
    // Geen zoekterm/from bewaren — voorkomt blijvende markering van bv. "de"
    const prev = loadPos();
    savePos({
      osis,
      chapter: state.chapter,
      tr: state.tr.id,
      tr2: prev.tr2,
      compare: prev.compare,
      flow: prev.flow,
      sideOpen: prev.sideOpen,
    });
  }

  /** Bouw één tekstkolom (vertaling) voor een hoofdstuk. */
  function buildTextColumn(pack, tr, myCh, idPrefix, showNotes, depthSet) {
    const chapters = pack.c;
    const chNotes = showNotes && pack.f ? (pack.f[String(myCh)] || null) : null;
    const verses = chapters[myCh - 1] || [];
    const col = el('div', 'bb-col');
    const label = el('div', 'bb-col-label', tr.name);
    col.append(label);
    const text = el('div', 'bb-text' + (flow ? ' flow' : ''));
    if (isRtlBook(tr, state.book)) {
      text.setAttribute('dir', 'rtl');
      text.setAttribute('lang', 'he');
      text.classList.add('bb-rtl');
    } else if (tr && (tr.language === 'he-gr' || tr.language === 'gr' || tr.language === 'grc' || tr.language === 'el')) {
      text.setAttribute('lang', 'grc');
      text.classList.add('bb-greek');
    }
    const hi = state.hi;
    let target = null;
    const usedNotes = [];
    const hasDepth = depthSet || new Set();
    let markDepth = true;
    try {
      const st = loadSettings();
      if (st && st.bibleMarkDepth === false) markDepth = false;
    } catch (_) {}
    verses.forEach((v, i) => {
      const n = i + 1;
      const p = el(flow ? 'span' : 'p', 'bb-verse');
      p.id = `${idPrefix}v${n}`;
      p.dataset.v = String(n);
      const deep = hasDepth.has(String(n));
      if (markDepth) {
        p.classList.toggle('bb-verse-has-depth', deep);
        p.classList.toggle('bb-verse-no-depth', !deep);
      }
      p.title = deep ? 'Verdieping beschikbaar — klik om te openen' : 'Nog geen verdieping voor dit vers';
      const vn = el('sup', 'bb-vn', String(n));
      vn.dataset.v = String(n);
      vn.title = p.title;
      const openStudy = (ev) => {
        if (ev.target.closest && ev.target.closest('.bb-fn-ref')) return;
        ev.stopPropagation();
        if (!state.book || !state.chapter) return;
        window.dispatchEvent(new CustomEvent('lc-open-verse-study', {
          detail: {
            osis: state.book.osis,
            chapter: state.chapter,
            verse: n,
            bookNl: state.book.nl,
            // q: null = geen zoekmarkering (voorkomt oude zoekterm uit localStorage)
            biblePos: {
              osis: state.book.osis,
              chapter: state.chapter,
              from: n,
              to: n,
              q: null,
              tr: state.tr && state.tr.id,
              compare: state.compare,
              tr2: state.tr2 && state.tr2.id,
              flow,
              sideOpen,
            },
          },
        }));
      };
      vn.onclick = openStudy;
      p.addEventListener('click', openStudy);
      p.append(vn, document.createTextNode(' '));
      // Alleen zoekwoorden markeren in het gekozen vers (niet elk teken van de query!)
      const inHit = hi && hi.from != null && n >= hi.from && n <= (hi.to || hi.from);
      if (inHit && hi.q) {
        const words = (Array.isArray(hi.q) ? hi.q : squash(String(hi.q)).split(/[^a-z0-9]+/))
          .filter(w => w && w.length >= 3);
        if (words.length) appendHighlighted(p, v, words);
        else p.append(document.createTextNode(v || ''));
      } else {
        p.append(document.createTextNode(v || ''));
      }
      const note = chNotes && chNotes[String(n)];
      if (note) {
        usedNotes.push({ n, note });
        const fnIdx = usedNotes.length;
        const roman = toRoman(fnIdx);
        const mark = el('sup', 'bb-fn-ref', roman);
        mark.title = `Voetnoot ${roman}`;
        mark.onclick = () => {
          const targetFn = col.querySelector(`#${idPrefix}fn${fnIdx}`);
          if (targetFn) targetFn.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
        };
        p.append(mark);
      }
      if (flow) p.append(document.createTextNode(' '));
      if (hi && n >= hi.from && n <= hi.to) { p.classList.add('hit'); if (!target) target = p; }
      text.append(p);
    });
    col.append(text);
    if (usedNotes.length) {
      const fnBox = el('aside', 'bb-footnotes');
      const title = el('h3', 'bb-fn-title', 'Voetnoten');
      fnBox.append(title);
      if (pack.fnSource === 'leo-crucis') {
        fnBox.append(el('p', 'bb-fn-disclaimer',
          'Aantekeningen van Leo Crucis — niet officieel en geen onderdeel van de Petrus Canisiusvertaling (1939). Geen kerkelijk leergezag.'));
      }
      const ol = el('ol', 'bb-fn-list');
      usedNotes.forEach((item, idx) => {
        const fnIdx = idx + 1;
        const roman = toRoman(fnIdx);
        const li = el('li', 'bb-fn-item');
        li.id = `${idPrefix}fn${fnIdx}`;
        const labelEl = el('span', 'bb-fn-num', roman + '.');
        const ref = el('button', 'bb-fn-back', `v. ${item.n}`);
        ref.type = 'button';
        ref.onclick = () => {
          const vEl = col.querySelector(`#${idPrefix}v${item.n}`);
          if (vEl) vEl.scrollIntoView({ block: 'center', behavior: 'smooth' });
        };
        // strip leading [Leo Crucis] for display cleanliness; disclaimer is above
        let noteText = item.note.replace(/^\[Leo Crucis\]\s*/i, '');
        li.append(labelEl, document.createTextNode(' '), ref, document.createTextNode(' '), document.createTextNode(noteText));
        ol.append(li);
      });
      fnBox.append(ol);
      col.append(fnBox);
    }
    return { col, target };
  }

  // ── hoofdstuk tonen ────────────────────────────────────
  async function renderChapter() {
    let b = state.book;
    if (!b) return;
    // Planmodus: als huidig hoofdstuk niet (meer) bij actieve dag hoort → spring naar actieve dag
    if (planMode && planData && !isChapterAllowedInPlan(b.osis, state.chapter)) {
      const entry = activeDayEntry();
      if (entry && entry.refs && entry.refs[0]) {
        const r = entry.refs[0];
        const nb = bookByOsis(r.osis);
        if (nb) {
          state.book = nb;
          state.chapter = r.from || 1;
          state.hi = r.verseFrom != null ? { from: r.verseFrom, to: r.verseTo || r.verseFrom } : null;
          b = nb;
        }
      }
    }
    const myBook = b.osis, myCh = state.chapter;
    const comparing = state.compare && state.tr2 && state.tr2.id !== state.tr.id;

    let packA, packB = null;
    try {
      packA = await loadBookData(b.osis, state.tr.id);
      if (comparing) packB = await loadBookData(b.osis, state.tr2.id);
    } catch (e) {
      main.replaceChildren(el('p', 'bb-status', 'Kon dit boek niet laden. ' + e.message));
      return;
    }
    if (state.book !== b || state.chapter !== myCh || myBook !== b.osis) return;

    // Welke verzen hebben verdieping? (zwart vs grijs)
    const depthSet = await loadMetaVerseSet(b.osis, myCh);
    if (state.book !== b || state.chapter !== myCh) return;

    main.replaceChildren();
    const head = el('div', 'bb-head');
    head.append(el('h2', 'bb-title', `${b.nl} ${myCh}`));
    let subLabel;
    if (comparing) {
      subLabel = `${state.tr.name} ↔ ${state.tr2.name}`;
    } else {
      if (state.tr.language === 'la') subLabel = `${b.la} · caput ${myCh}`;
      else if (state.tr.language === 'he-gr') subLabel = `${state.tr.name} · ${b.t === 'OT' ? 'פרק' : 'κεφ.'} ${myCh}`;
      else subLabel = `${state.tr.name} · hoofdstuk ${myCh}`;
    }
    head.append(el('span', 'bb-sub', subLabel));
    main.append(head);
    if (b.osis === 'Ps' && (state.tr.language === 'la' || (comparing && state.tr2.language === 'la'))) {
      main.append(el('p', 'bb-note', 'Nummering van de Vulgaat: vanaf Psalm 10 staat de Hebreeuwse (en moderne) nummering één hoger, bv. Vulgaat 22 = Psalm 23.'));
    }

    // hoofdstukkeuze — in leesplan-modus: alle passages van de (actieve) leesdag
    const maxCh = comparing && packB
      ? Math.max(b.ch, (packB.c && packB.c.length) || b.ch)
      : b.ch;
    const chips = el('div', 'bb-chips');

    if (planMode && planData && planData.plan) {
      // Alleen de actieve leesdag — alle boeken/hoofdstukken van die dag
      const dayEntry = activeDayEntry();

      if (dayEntry && dayEntry.refs && dayEntry.refs.length) {
        const dayLab = el('span', 'bb-plan-day-chip-lab', 'Dag ' + dayEntry.day + ':');
        chips.append(dayLab);

        for (const ref of dayEntry.refs) {
          const a = ref.from || 1;
          const z = ref.to || a;
          for (let ch = a; ch <= z; ch++) {
            const books = (state.idx && state.idx.books) || [];
            const bk = books.find(x => x.osis === ref.osis);
            const shortName = bk ? (bk.short || bk.nl || ref.osis) : ref.osis;
            const sameBook = ref.osis === b.osis;
            const label = sameBook ? String(ch) : (shortName + ' ' + ch);
            const isOn = ref.osis === b.osis && ch === myCh;
            const c = el('button', 'bb-chip' + (isOn ? ' on' : '') + (sameBook ? '' : ' bb-chip-other'), label);
            c.type = 'button';
            c.title = formatRef({ ...ref, from: ch, to: ch });
            if (ref.verseFrom != null && ch === a) {
              c.onclick = () => openBook(ref.osis, ch, {
                from: ref.verseFrom,
                to: ref.verseTo || ref.verseFrom,
              });
            } else {
              c.onclick = () => openBook(ref.osis, ch);
            }
            chips.append(c);
          }
        }
      } else {
        chips.append(el('span', 'bb-note', 'Geen actieve leesdag.'));
      }
    } else {
      // Normale modus: alle hoofdstukken
      for (let i = 1; i <= maxCh; i++) {
        const c = el('button', 'bb-chip' + (i === myCh ? ' on' : ''), String(i));
        c.type = 'button';
        c.onclick = () => openBook(b.osis, i);
        chips.append(c);
      }
    }
    main.append(chips);

    let target = null;
    if (comparing && packB) {
      const grid = el('div', 'bb-compare');
      const a = buildTextColumn(packA, state.tr, myCh, 'a-', true, depthSet);
      const bCol = buildTextColumn(packB, state.tr2, myCh, 'b-', true, depthSet);
      grid.append(a.col, bCol.col);
      main.append(grid);
      target = a.target || bCol.target;
      // synchroon scrollen van de twee kolommen
      const panes = [a.col.querySelector('.bb-text'), bCol.col.querySelector('.bb-text')];
      let lock = false;
      panes.forEach((pane, i) => {
        if (!pane) return;
        pane.classList.add('bb-text-scroll');
        pane.addEventListener('scroll', () => {
          if (lock) return;
          lock = true;
          const other = panes[1 - i];
          if (other) other.scrollTop = pane.scrollTop;
          lock = false;
        });
      });
    } else {
      const single = buildTextColumn(packA, state.tr, myCh, '', true, depthSet);
      // bij single mode geen kolomlabel nodig
      const label = single.col.querySelector('.bb-col-label');
      if (label) label.remove();
      single.col.classList.remove('bb-col');
      main.append(single.col);
      target = single.target;
    }

    main.append(navRow());
    if (target) target.scrollIntoView({ block: 'center' });
    else main.scrollTop = 0;
    if (!target) window.scrollTo(0, 0);
  }

  function navRow() {
    const row = el('div', 'bb-nav');
    const prev = el('button', 'bb-btn', '← Vorig hoofdstuk'); prev.type = 'button';
    const next = el('button', 'bb-btn', 'Volgend hoofdstuk →'); next.type = 'button';
    const books = state.idx.books;
    const i = books.indexOf(state.book);
    let hasPrev = state.chapter > 1 || i > 0;
    let hasNext = state.chapter < state.book.ch || i < books.length - 1;
    // In planmodus: alleen bladeren binnen vrijgegeven hoofdstukken
    if (planMode) {
      const tryPrev = state.chapter > 1
        ? { osis: state.book.osis, ch: state.chapter - 1 }
        : (i > 0 ? { osis: books[i - 1].osis, ch: books[i - 1].ch } : null);
      const tryNext = state.chapter < state.book.ch
        ? { osis: state.book.osis, ch: state.chapter + 1 }
        : (i < books.length - 1 ? { osis: books[i + 1].osis, ch: 1 } : null);
      hasPrev = !!(tryPrev && isChapterAllowedInPlan(tryPrev.osis, tryPrev.ch));
      hasNext = !!(tryNext && isChapterAllowedInPlan(tryNext.osis, tryNext.ch));
    }
    prev.disabled = !hasPrev; next.disabled = !hasNext;
    prev.onclick = () => {
      if (state.chapter > 1) openBook(state.book.osis, state.chapter - 1);
      else { const pb = books[i - 1]; openBook(pb.osis, pb.ch); }
    };
    next.onclick = () => {
      if (state.chapter < state.book.ch) openBook(state.book.osis, state.chapter + 1);
      else openBook(books[i + 1].osis, 1);
    };
    row.append(prev, next);
    return row;
  }

  // Markeer elk zoekwoord in de tekst (i/j en u/v tellen als gelijk).
  function appendHighlighted(parent, text, words) {
    // Vereenvoudigde tekst opbouwen met een verwijzing terug naar de originele tekenposities
    // (æ wordt "ae", dus de lengtes lopen uiteen).
    let s = '';
    const back = [];
    for (let i = 0; i < text.length; i++) {
      const piece = squash(text[i]);
      for (let k = 0; k < piece.length; k++) { s += piece[k]; back.push(i); }
    }
    const spans = [];
    for (const w of words) {
      let from = 0, at;
      while ((at = s.indexOf(w, from)) !== -1) {
        spans.push([back[at], back[at + w.length - 1] + 1]);
        from = at + w.length;
      }
    }
    spans.sort((a, b) => a[0] - b[0]);
    let cur = 0;
    for (const [a, b] of spans) {
      if (a < cur) continue;
      if (a > cur) parent.append(document.createTextNode(text.slice(cur, a)));
      parent.append(el('mark', 'bb-mark', text.slice(a, b)));
      cur = b;
    }
    if (cur < text.length) parent.append(document.createTextNode(text.slice(cur)));
  }

  // ── ga naar een plaats ─────────────────────────────────
  function findBook(token) {
    const k = bookKey(token);
    if (!k) return null;
    const cands = [];
    for (const b of booksForTr()) {
      const names = [b.nl, b.la, b.osis, ...(EXTRA_ALIASES[b.osis] || [])].map(bookKey);
      names.push(...b.la.split('(')[0].split('/').map(bookKey));
      if (names.some(n => n === k)) return b;
      if (k.length >= 2 && names.some(n => n.startsWith(k))) cands.push(b);
    }
    return cands[0] || null;
  }

  function parseRef(input) {
    const m = String(input).trim().match(/^(\d?\s*[^\d\s.][^\d]*?)\.?\s*(?:(\d+)(?:\s*[,.:]\s*(\d+)(?:\s*[-–]\s*(\d+))?)?)?$/);
    if (!m) return null;
    const book = findBook(m[1]);
    if (!book) return null;
    const chapter = m[2] ? parseInt(m[2], 10) : 1;
    const from = m[3] ? parseInt(m[3], 10) : null;
    const to = m[4] ? parseInt(m[4], 10) : from;
    return { book, chapter, from, to };
  }

  refForm.onsubmit = e => {
    e.preventDefault();
    const r = parseRef(refIn.value);
    if (!r) { refIn.classList.add('bad'); setTimeout(() => refIn.classList.remove('bad'), 900); return; }
    if (r.chapter < 1 || r.chapter > r.book.ch) { refIn.classList.add('bad'); setTimeout(() => refIn.classList.remove('bad'), 900); return; }
    if (planMode && !isChapterAllowedInPlan(r.book.osis, r.chapter)) {
      showPlanPopup(planGuardMessage());
      return;
    }
    openBook(r.book.osis, r.chapter, r.from ? { from: r.from, to: r.to } : null);
  };

  // ── zoeken ─────────────────────────────────────────────
  async function ensureAll(progress) {
    // cache per vertaling
    if (state.all && state.allTr === state.tr.id) return state.all;
    const out = [];
    let done = 0;
    const books = booksForTr();
    for (let i = 0; i < books.length; i += 8) {
      await Promise.all(books.slice(i, i + 8).map(async b => {
        const pack = await loadBookData(b.osis);
        pack.c.forEach((vs, ci) => vs.forEach((v, vi) => {
          if (v) out.push({ b, c: ci + 1, v: vi + 1, text: v, s: squash(v) });
        }));
        progress(++done, books.length);
      }));
    }
    state.all = out;
    state.allTr = state.tr.id;
    return out;
  }

  const MAX_HITS = 300;
  searchForm.onsubmit = async e => {
    e.preventDefault();
    const raw = qIn.value.trim();
    const words = squash(raw).split(/[^a-z0-9]+/).filter(w => w.length >= 2);
    if (!words.length) { qIn.classList.add('bad'); setTimeout(() => qIn.classList.remove('bad'), 900); return; }
    main.replaceChildren(el('p', 'bb-status', 'Bijbel doorzoeken…'));
    let all;
    try {
      all = await ensureAll((d, n) => { const s = main.querySelector('.bb-status'); if (s) s.textContent = `Bijbel indexeren… ${d}/${n}`; });
    } catch (err) { main.replaceChildren(el('p', 'bb-status', 'Zoeken mislukt. ' + err.message)); return; }

    const scope = scopeSel.value;
    const hits = [];
    let total = 0;
    for (const r of all) {
      if (scope === 'OT' && r.b.t !== 'OT') continue;
      if (scope === 'NT' && r.b.t !== 'NT') continue;
      if (scope === 'book' && state.book && r.b !== state.book) continue;
      // Leesplan: zoeken alleen in vrijgegeven hoofdstukken
      if (planMode && !isChapterAllowedInPlan(r.b.osis, r.c)) continue;
      if (words.every(w => r.s.includes(w))) { total++; if (hits.length < MAX_HITS) hits.push(r); }
    }

    main.replaceChildren();
    const head = el('div', 'bb-head');
    head.append(el('h2', 'bb-title', `Zoeken: “${raw}”`));
    const subTxt = total === 0 ? 'geen resultaten'
      : total > MAX_HITS ? `${total} verzen, de eerste ${MAX_HITS} getoond`
      : `${total} ${total === 1 ? 'vers' : 'verzen'}`;
    head.append(el('span', 'bb-sub', planMode ? subTxt + ' · alleen vrijgegeven lezingen' : subTxt));
    main.append(head);
    if (total === 0) {
      const tip = state.tr.language === 'la'
        ? 'Tip: de tekst is Latijn. Spelling met i/j en u/v maakt niet uit, en æ/œ kun je als ae/oe typen.'
        : 'Tip: zoek op Nederlandse woorden uit de Canisiusvertaling. Probeer kortere zoektermen.';
      main.append(el('p', 'bb-note', tip));
    }
    const list = el('ol', 'bb-hits');
    for (const r of hits) {
      const li = el('li', 'bb-hit');
      const a = el('button', 'bb-hit-ref', `${r.b.nl} ${r.c},${r.v}`);
      a.type = 'button';
      a.onclick = () => openBook(r.b.osis, r.c, { from: r.v, to: r.v, q: words });
      const t = el('span', 'bb-hit-text');
      appendHighlighted(t, r.text, words);
      li.append(a, t);
      list.append(li);
    }
    main.append(list);
    window.scrollTo(0, 0);
  };

  async function switchTranslation(trId, which) {
    const tr = state.idx.translations.find(t => t.id === trId);
    if (!tr) return;
    if (which === 2) {
      if (state.tr2 && state.tr2.id === trId) return;
      state.tr2 = tr;
      savePos({ ...loadPos(), tr2: tr.id });
      refreshSide();
      await renderChapter();
      return;
    }
    if (state.tr && state.tr.id === trId) return;
    state.tr = tr;
    state.all = null;
    state.allTr = null;
    syncSearchPlaceholder();
    savePos({ ...loadPos(), tr: tr.id });
    refreshSide();
    // In leesplan-modus: blijf op de actieve leesdag (niet terug naar Gen/boekenlijst)
    if (planMode) {
      const entry = activeDayEntry();
      if (entry && entry.refs && entry.refs[0]) {
        const r = entry.refs[0];
        const hi = r.verseFrom != null
          ? { from: r.verseFrom, to: r.verseTo || r.verseFrom }
          : null;
        // openBook zonder plan-guard te blokkeren: zelfde dag, andere vertaling
        const b = bookByOsis(r.osis);
        if (b && booksForTr().some(x => x.osis === r.osis)) {
          state.book = b;
          state.chapter = r.from || 1;
          state.hi = hi;
          await renderChapter();
        } else {
          await renderChapter();
        }
      } else {
        await renderChapter();
      }
      return;
    }
    const want = state.book && booksForTr().some(b => b.osis === state.book.osis)
      ? state.book.osis
      : (bookByOsis(pos.osis) && booksForTr().some(b => b.osis === pos.osis) ? pos.osis : 'Gen');
    await openBook(want, state.chapter || 1);
  }

  // ── start ──────────────────────────────────────────────
  (async () => {
    try {
      const res = await fetch(BASE + 'index.json');
      if (!res.ok) throw new Error(res.status);
      state.idx = await res.json();
    } catch (e) {
      status.textContent = 'De bijbeltekst kon niet worden geladen (data/bijbel/index.json ontbreekt).';
      return;
    }

    for (const t of state.idx.translations) {
      const o = el('option', '', t.name);
      o.value = t.id;
      trSel.append(o);
      const o2 = el('option', '', t.name);
      o2.value = t.id;
      trSel2.append(o2);
    }
    const startTr = state.idx.translations.find(t => t.id === pos.tr) || state.idx.translations[0];
    state.tr = startTr;
    trSel.value = startTr.id;
    // tweede vertaling: opgeslagen, of de andere dan de eerste
    const startTr2 = state.idx.translations.find(t => t.id === pos.tr2 && t.id !== startTr.id)
      || state.idx.translations.find(t => t.id !== startTr.id)
      || startTr;
    state.tr2 = startTr2;
    trSel2.value = startTr2.id;
    trSel.onchange = () => switchTranslation(trSel.value, 1);
    trSel2.onchange = () => switchTranslation(trSel2.value, 2);
    syncSearchPlaceholder();
    syncCmpBtn();
    buildSide();

    const available = booksForTr();
    const startOsis = (pos.osis && available.some(b => b.osis === pos.osis)) ? pos.osis : 'Gen';
    // Zoekmarkering ALLEEN als startPos expliciet een zoekterm meegaf
    // (niet uit localStorage — daar blijft anders "de" e.d. hangen)
    const incoming = startPos && typeof startPos === 'object' ? startPos : {};
    const hiQ = (incoming.q != null && incoming.q !== '' && !(Array.isArray(incoming.q) && !incoming.q.length))
      ? incoming.q : null;
    const hiFrom = incoming.from != null ? incoming.from : null;
    const hi = (hiFrom != null || hiQ)
      ? { from: hiFrom || 1, to: incoming.to || hiFrom || 1, q: hiQ }
      : null;
    await openBook(startOsis, pos.chapter || 1, hi);
  })();

  return { root };
}
