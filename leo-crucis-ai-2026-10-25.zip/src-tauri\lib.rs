// Opslag van eigen wijzigingen en eigen boeken: gewone bestanden in de gebruikersmap
// (Windows: %APPDATA%\be.leocrucis.bibliotheek, macOS: ~/Library/Application Support/be.leocrucis.bibliotheek).
//   world.json                       de secties en boeken zoals jij ze hebt aangepast
//   stad/<gebouw>/<boek>.html        elk eigen of aangepast boek, in de map van zijn gebouw
//   stad/<gebouw>/gebouw.json        (optioneel) beschrijving van een extra gebouw dat je zelf toevoegt
//   memory/<naam>.json               app-geheugen (bladwijzers, geschiedenis, positie, …)
// Deze map hoort niet bij de software: wat hier staat wordt nooit meegebouwd of meegeleverd.
use std::{fs, io::ErrorKind, path::PathBuf, process::Command};
use tauri::Manager;

fn base_dir(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    app.path().app_data_dir().map_err(|e| e.to_string())
}

// Een map- of bestandsnaam: letters, cijfers, - _ . en spatie; geen "..", geen verborgen namen, geen slashes.
fn seg_ok(s: &str) -> bool {
    !s.is_empty()
        && !s.starts_with('.')
        && !s.contains("..")
        && s.chars().all(|c| c.is_alphanumeric() || matches!(c, '-' | '_' | '.' | ' '))
}

// Toegestaan: "world.json", "stad/<gebouw>/<naam>.html", "stad/<gebouw>/gebouw.json",
// "books/<naam>.html" (oud), en "memory/<naam>.json" (app-geheugen: bladwijzers, geschiedenis, …).
fn safe_path(app: &tauri::AppHandle, rel: &str) -> Result<PathBuf, String> {
    let parts: Vec<&str> = rel.split('/').collect();
    let ok = match parts.as_slice() {
        ["world.json"] => true,
        ["books", name] => seg_ok(name) && name.ends_with(".html"),
        ["stad", dir, name] => seg_ok(dir) && seg_ok(name) && (name.ends_with(".html") || *name == "gebouw.json"),
        ["memory", name] => seg_ok(name) && name.ends_with(".json"),
        _ => false,
    };
    if !ok {
        return Err(format!("ongeldig pad: {rel}"));
    }
    // Segmenten één voor één joinen (betrouwbaarder op Windows dan join("a/b/c")).
    let mut p = base_dir(app)?;
    for part in parts {
        p = p.join(part);
    }
    Ok(p)
}

#[tauri::command]
fn read_user_file(app: tauri::AppHandle, path: String) -> Result<Option<String>, String> {
    let p = safe_path(&app, &path)?;
    match fs::read_to_string(&p) {
        Ok(s) => Ok(Some(s)),
        Err(e) if e.kind() == ErrorKind::NotFound => Ok(None),
        Err(e) => Err(e.to_string()),
    }
}

#[tauri::command]
fn write_user_file(app: tauri::AppHandle, path: String, contents: String) -> Result<(), String> {
    let p = safe_path(&app, &path)?;
    if let Some(dir) = p.parent() {
        fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    }
    fs::write(&p, contents).map_err(|e| e.to_string())
}

#[tauri::command]
fn delete_user_file(app: tauri::AppHandle, path: String) -> Result<(), String> {
    let p = safe_path(&app, &path)?;
    match fs::remove_file(&p) {
        Ok(_) => Ok(()),
        Err(e) if e.kind() == ErrorKind::NotFound => Ok(()),
        Err(e) => Err(e.to_string()),
    }
}

// Scant de map "stad" in de gebruikersmap. Per gebouwmap: (mapnaam, bestandsnamen zonder .html, inhoud van gebouw.json of None,
// volledige namen van andere bestanden die de app niet als boek kan lezen, bv. "rapport.pdf").
// Zo vindt de app boeken en gebouwen die je zelf in de mappen hebt gezet, en kan hij laten weten wat hij niet kan gebruiken.
#[tauri::command]
fn list_user_stad(app: tauri::AppHandle) -> Result<Vec<(String, Vec<String>, Option<String>, Vec<String>)>, String> {
    let root = base_dir(&app)?.join("stad");
    let entries = match fs::read_dir(&root) {
        Ok(e) => e,
        Err(e) if e.kind() == ErrorKind::NotFound => return Ok(vec![]),
        Err(e) => return Err(e.to_string()),
    };
    let mut out = vec![];
    for entry in entries.flatten() {
        let dir = entry.file_name().to_string_lossy().to_string();
        if !entry.path().is_dir() || !seg_ok(&dir) {
            continue;
        }
        let mut files: Vec<String> = vec![];
        let mut others: Vec<String> = vec![];
        for f in fs::read_dir(entry.path()).map_err(|e| e.to_string())?.flatten() {
            if !f.path().is_file() {
                continue;
            }
            let name = f.file_name().to_string_lossy().to_string();
            if name == "gebouw.json" || name.starts_with('.') {
                continue;
            }
            match name.strip_suffix(".html") {
                Some(stem) if seg_ok(&name) => files.push(stem.to_string()),
                _ if img_ext(&name).is_some() => {}
                _ => others.push(name),
            }
        }
        files.sort();
        others.sort();
        let gebouw = fs::read_to_string(entry.path().join("gebouw.json")).ok();
        out.push((dir, files, gebouw, others));
    }
    out.sort_by(|a, b| a.0.cmp(&b.0));
    Ok(out)
}

/// Leest een PDF uit stad/<gebouw>/<naam>.pdf en geeft de inhoud als base64 terug (de app zet er een boek van).
#[tauri::command]
fn read_user_pdf_b64(app: tauri::AppHandle, dir: String, name: String) -> Result<String, String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    if !seg_ok(&dir) || !seg_ok(&name) || !name.to_lowercase().ends_with(".pdf") {
        return Err(format!("ongeldig pad: {dir}/{name}"));
    }
    let bytes = fs::read(base_dir(&app)?.join("stad").join(&dir).join(&name)).map_err(|e| e.to_string())?;
    Ok(STANDARD.encode(bytes))
}

// ---- Cover-afbeeldingen van gebouwen ----
// Een afbeelding met dezelfde naam als de gebouwmap (stad/<gebouw>/<gebouw>.png, of los in stad/<gebouw>.png) wordt de cover van dat gebouw.
const IMG_EXT: [&str; 5] = ["png", "webp", "jpg", "jpeg", "gif"];

fn img_ext(name: &str) -> Option<String> {
    let ext = name.rsplit_once('.')?.1.to_lowercase();
    if IMG_EXT.contains(&ext.as_str()) { Some(ext) } else { None }
}

/// Zet een meegeleverde afbeelding (base64) in stad/<dir>/<name>, alleen als die er nog niet staat. Geeft terug of er geschreven is.
#[tauri::command]
fn export_user_image(app: tauri::AppHandle, dir: String, name: String, data_b64: String) -> Result<bool, String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    if !seg_ok(&dir) || !seg_ok(&name) || img_ext(&name).is_none() {
        return Err(format!("ongeldig pad: {dir}/{name}"));
    }
    let folder = base_dir(&app)?.join("stad").join(&dir);
    let path = folder.join(&name);
    if path.exists() {
        return Ok(false);
    }
    let bytes = STANDARD.decode(data_b64.trim()).map_err(|e| format!("Ongeldige afbeelding: {e}"))?;
    fs::create_dir_all(&folder).map_err(|e| e.to_string())?;
    fs::write(&path, bytes).map_err(|e| e.to_string())?;
    Ok(true)
}

/// Zoekt per gebouwmap een cover: eerst stad/<map>/<map>.<png|webp|jpg|jpeg|gif>, anders stad/<map>.<ext>.
/// Geeft (mapnaam, pad relatief aan stad/, laatst gewijzigd in seconden, grootte in bytes) terug, zodat de app weet of de afbeelding veranderd is.
#[tauri::command]
fn list_user_covers(app: tauri::AppHandle) -> Result<Vec<(String, String, u64, u64)>, String> {
    let root = base_dir(&app)?.join("stad");
    let entries = match fs::read_dir(&root) {
        Ok(e) => e,
        Err(e) if e.kind() == ErrorKind::NotFound => return Ok(vec![]),
        Err(e) => return Err(e.to_string()),
    };
    let rank = |name: &str| img_ext(name).and_then(|e| IMG_EXT.iter().position(|x| *x == e)).unwrap_or(99);
    let mut root_imgs: Vec<String> = vec![];
    let mut dirs: Vec<String> = vec![];
    for entry in entries.flatten() {
        let name = entry.file_name().to_string_lossy().to_string();
        if entry.path().is_dir() {
            if seg_ok(&name) {
                dirs.push(name);
            }
        } else if seg_ok(&name) && img_ext(&name).is_some() {
            root_imgs.push(name);
        }
    }
    let stem_is = |file: &str, dir: &str| file.rsplit_once('.').map(|(s, _)| s.eq_ignore_ascii_case(dir)).unwrap_or(false);
    let stamp = |rel: &str| -> (u64, u64) {
        let md = rel.split('/').fold(root.clone(), |p, part| p.join(part));
        match fs::metadata(md) {
            Ok(m) => {
                let t = m.modified().ok().and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok()).map(|d| d.as_secs()).unwrap_or(0);
                (t, m.len())
            }
            Err(_) => (0, 0),
        }
    };
    let mut out = vec![];
    for dir in dirs {
        let mut inside: Vec<String> = fs::read_dir(root.join(&dir))
            .map(|rd| rd.flatten().map(|f| f.file_name().to_string_lossy().to_string()).collect())
            .unwrap_or_default();
        inside.retain(|f| seg_ok(f) && img_ext(f).is_some() && stem_is(f, &dir));
        inside.sort_by_key(|f| rank(f));
        if let Some(f) = inside.first() {
            let rel = format!("{dir}/{f}");
            let (t, n) = stamp(&rel);
            out.push((dir.clone(), rel, t, n));
            continue;
        }
        let mut loose: Vec<&String> = root_imgs.iter().filter(|f| stem_is(f, &dir)).collect();
        loose.sort_by_key(|f| rank(f));
        if let Some(f) = loose.first() {
            let rel = (*f).clone();
            let (t, n) = stamp(&rel);
            out.push((dir.clone(), rel, t, n));
        }
    }
    out.sort();
    Ok(out)
}

/// Leest een afbeelding uit stad/<rel> (rel = "<map>/<bestand>" of "<bestand>") als base64.
#[tauri::command]
fn read_user_image_b64(app: tauri::AppHandle, rel: String) -> Result<String, String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    let parts: Vec<&str> = rel.split('/').collect();
    let ok = (parts.len() == 1 || parts.len() == 2) && parts.iter().all(|p| seg_ok(p)) && img_ext(parts[parts.len() - 1]).is_some();
    if !ok {
        return Err(format!("ongeldig pad: {rel}"));
    }
    let mut path = base_dir(&app)?.join("stad");
    for p in parts {
        path = path.join(p);
    }
    Ok(STANDARD.encode(fs::read(&path).map_err(|e| e.to_string())?))
}

// Wist je wijzigingen aan world.json en aan de meegeleverde boeken. `bundled` is de lijst "gebouw/boek" van de
// boeken die bij de software horen. Alleen die bestanden worden gewist: je eigen boeken en eigen gebouwen
// (de mappen in "stad") blijven altijd staan.
#[tauri::command]
fn reset_user_data(app: tauri::AppHandle, bundled: Vec<String>) -> Result<(), String> {
    let base = base_dir(&app)?;
    let ignore_missing = |r: std::io::Result<()>| match r {
        Err(e) if e.kind() != ErrorKind::NotFound => Err(e.to_string()),
        _ => Ok(()),
    };
    ignore_missing(fs::remove_file(base.join("world.json")))?;
    ignore_missing(fs::remove_dir_all(base.join("books")))?; // oude opslag van vorige versies
    for b in bundled {
        let parts: Vec<&str> = b.split('/').collect();
        if let [dir, name] = parts.as_slice() {
            if seg_ok(dir) && seg_ok(name) {
                ignore_missing(fs::remove_file(base.join("stad").join(dir).join(format!("{name}.html"))))?;
            }
        }
    }
    Ok(())
}

// Opent de hoofdmap van de app (be.leocrucis.bibliotheek) in de bestandsverkenner: daarin staan o.a. world.json, stad/ en media/.
#[tauri::command]
fn open_user_folder(app: tauri::AppHandle) -> Result<(), String> {
    let dir = base_dir(&app)?;
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    open_dir(&dir)
}


fn media_dir(app: &tauri::AppHandle, kind: &str) -> Result<PathBuf, String> {
    let sub = if kind == "video" { "media/video" } else { "media/music" };
    let dir = base_dir(app)?.join(sub);
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    Ok(dir)
}

fn safe_media_name(name: &str) -> Result<String, String> {
    let base = name.split(['/', '\\']).last().unwrap_or(name);
    if base.is_empty() || base.starts_with('.') || base.contains("..") {
        return Err(format!("ongeldige bestandsnaam: {name}"));
    }
    // letters, cijfers, spatie, - _ . ( )
    if !base.chars().all(|c| c.is_alphanumeric() || matches!(c, '-' | '_' | '.' | ' ' | '(' | ')')) {
        return Err(format!("ongeldige bestandsnaam: {name}"));
    }
    Ok(base.to_string())
}

/// Kies een vrije bestandsnaam in `dir` (naam-1.mp4 als de naam al bestaat).
fn unique_media_path(dir: &PathBuf, name: &str) -> Result<PathBuf, String> {
    let path = dir.join(name);
    if !path.exists() {
        return Ok(path);
    }
    let stem = path.file_stem().and_then(|s| s.to_str()).unwrap_or("file").to_string();
    let ext = path.extension().and_then(|s| s.to_str()).unwrap_or("").to_string();
    let mut n = 1;
    loop {
        let candidate = if ext.is_empty() {
            dir.join(format!("{stem}-{n}"))
        } else {
            dir.join(format!("{stem}-{n}.{ext}"))
        };
        if !candidate.exists() {
            return Ok(candidate);
        }
        n += 1;
        if n > 9999 {
            return Err("te veel bestanden met dezelfde naam".into());
        }
    }
}

/// Schrijf een mediabestand naar media/music of media/video. data = bytes.
#[tauri::command]
fn write_media_file(app: tauri::AppHandle, kind: String, file_name: String, data: Vec<u8>) -> Result<String, String> {
    let name = safe_media_name(&file_name)?;
    let dir = media_dir(&app, &kind)?;
    let path = unique_media_path(&dir, &name)?;
    fs::write(&path, &data).map_err(|e| e.to_string())?;
    Ok(path.to_string_lossy().to_string())
}

/// Start een groot mediabestand dat in stukken wordt weggeschreven (voor voortgang in het laadscherm).
/// Maakt een leeg bestand met een vrije naam en geeft het absolute pad terug.
#[tauri::command]
fn begin_media_file(app: tauri::AppHandle, kind: String, file_name: String) -> Result<String, String> {
    let name = safe_media_name(&file_name)?;
    let dir = media_dir(&app, &kind)?;
    let path = unique_media_path(&dir, &name)?;
    fs::File::create(&path).map_err(|e| e.to_string())?;
    Ok(path.to_string_lossy().to_string())
}

/// Voeg een stuk bytes toe aan een bestand dat met begin_media_file is gemaakt.
/// file_name = de naam op schijf (laatste deel van het pad dat begin_media_file teruggaf).
#[tauri::command]
fn append_media_file(app: tauri::AppHandle, kind: String, file_name: String, data: Vec<u8>) -> Result<(), String> {
    use std::io::Write;
    let name = safe_media_name(&file_name)?;
    let path = media_dir(&app, &kind)?.join(&name);
    let mut f = fs::OpenOptions::new().append(true).open(&path).map_err(|e| e.to_string())?;
    f.write_all(&data).map_err(|e| e.to_string())
}

/// Absoluut pad van een mediabestand (voor convertFileSrc).
#[tauri::command]
fn media_file_path(app: tauri::AppHandle, kind: String, file_name: String) -> Result<String, String> {
    let name = safe_media_name(&file_name)?;
    let path = media_dir(&app, &kind)?.join(&name);
    if !path.is_file() {
        return Err(format!("bestand niet gevonden: {name}"));
    }
    Ok(path.to_string_lossy().to_string())
}

/// Lees mediabestand als bytes (fallback als asset-protocol niet werkt).
#[tauri::command]
fn read_media_file(app: tauri::AppHandle, kind: String, file_name: String) -> Result<Vec<u8>, String> {
    let name = safe_media_name(&file_name)?;
    let path = media_dir(&app, &kind)?.join(&name);
    fs::read(&path).map_err(|e| e.to_string())
}

#[tauri::command]
fn delete_media_file(app: tauri::AppHandle, kind: String, file_name: String) -> Result<(), String> {
    let name = safe_media_name(&file_name)?;
    let path = media_dir(&app, &kind)?.join(&name);
    if path.is_file() {
        fs::remove_file(&path).map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
fn list_media_files(app: tauri::AppHandle, kind: String) -> Result<Vec<String>, String> {
    let dir = media_dir(&app, &kind)?;
    let mut names = Vec::new();
    for entry in fs::read_dir(&dir).map_err(|e| e.to_string())? {
        let entry = entry.map_err(|e| e.to_string())?;
        let path = entry.path();
        if path.is_file() {
            if let Some(n) = path.file_name().and_then(|s| s.to_str()) {
                names.push(n.to_string());
            }
        }
    }
    names.sort();
    Ok(names)
}


/// Opent media/music of media/video in de bestandsverkenner (gebruikersmap).
#[tauri::command]
fn open_media_folder(app: tauri::AppHandle, kind: String) -> Result<(), String> {
    let sub = match kind.as_str() {
        "video" => "media/video",
        _ => "media/music",
    };
    let dir = base_dir(&app)?.join(sub);
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    open_dir(&dir)
}

fn open_dir(dir: &PathBuf) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    let opener = "explorer";
    #[cfg(target_os = "macos")]
    let opener = "open";
    #[cfg(all(not(target_os = "windows"), not(target_os = "macos")))]
    let opener = "xdg-open";
    Command::new(opener).arg(dir).spawn().map_err(|e| e.to_string())?;
    Ok(())
}


/// Lijst geïnstalleerde printers (Windows: Get-Printer; elders: lpstat).
#[tauri::command]
fn list_printers() -> Result<Vec<String>, String> {
    #[cfg(target_os = "windows")]
    {
        let output = Command::new("powershell")
            .args([
                "-NoProfile",
                "-Command",
                "Get-Printer | Select-Object -ExpandProperty Name",
            ])
            .output()
            .map_err(|e| format!("Kan printers niet ophalen: {e}"))?;
        if !output.status.success() {
            let err = String::from_utf8_lossy(&output.stderr);
            return Err(format!("PowerShell-fout: {err}"));
        }
        let text = String::from_utf8_lossy(&output.stdout);
        let list: Vec<String> = text
            .lines()
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty())
            .collect();
        if list.is_empty() {
            return Err("Geen printers gevonden".into());
        }
        Ok(list)
    }
    #[cfg(target_os = "macos")]
    {
        let output = Command::new("lpstat")
            .args(["-a"])
            .output()
            .map_err(|e| format!("Kan printers niet ophalen: {e}"))?;
        let text = String::from_utf8_lossy(&output.stdout);
        let list: Vec<String> = text
            .lines()
            .filter_map(|l| l.split_whitespace().next().map(|s| s.to_string()))
            .collect();
        Ok(list)
    }
    #[cfg(all(not(target_os = "windows"), not(target_os = "macos")))]
    {
        let output = Command::new("lpstat")
            .args(["-a"])
            .output()
            .map_err(|e| format!("Kan printers niet ophalen: {e}"))?;
        let text = String::from_utf8_lossy(&output.stdout);
        let list: Vec<String> = text
            .lines()
            .filter_map(|l| l.split_whitespace().next().map(|s| s.to_string()))
            .collect();
        Ok(list)
    }
}

/// Druk een PDF af op de gekozen printer (base64-inhoud).
/// Windows: PrintTo-werkwoord; macOS/Linux: lpr.
#[tauri::command]
fn print_pdf(app: tauri::AppHandle, pdf_base64: String, printer: String) -> Result<(), String> {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    if printer.trim().is_empty() {
        return Err("Kies een printer".into());
    }
    let bytes = STANDARD
        .decode(pdf_base64.trim())
        .map_err(|e| format!("Ongeldige PDF-data: {e}"))?;
    let dir = base_dir(&app)?.join("temp");
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let path = dir.join("print-job.pdf");
    fs::write(&path, &bytes).map_err(|e| e.to_string())?;

    #[cfg(target_os = "windows")]
    {
        let path_str = path.to_string_lossy().replace('\'', "''");
        let printer_esc = printer.replace('\'', "''");
        // PrintTo stuurt naar de gekozen printer zonder het Edge-afdrukvenster.
        let script = format!(
            "Start-Process -FilePath '{path_str}' -Verb PrintTo -ArgumentList '{printer_esc}' -WindowStyle Hidden"
        );
        let output = Command::new("powershell")
            .args(["-NoProfile", "-Command", &script])
            .output()
            .map_err(|e| format!("Afdrukken mislukt: {e}"))?;
        if !output.status.success() {
            let err = String::from_utf8_lossy(&output.stderr);
            // Fallback: Print-werkwoord (standaardprinter / app-handler)
            let script2 = format!(
                "Start-Process -FilePath '{path_str}' -Verb Print -WindowStyle Hidden"
            );
            let output2 = Command::new("powershell")
                .args(["-NoProfile", "-Command", &script2])
                .output()
                .map_err(|e| format!("Afdrukken mislukt: {e}"))?;
            if !output2.status.success() {
                return Err(format!(
                    "Afdrukken mislukt. Installeer een PDF-lezer of controleer de printer. ({err})"
                ));
            }
        }
        Ok(())
    }
    #[cfg(target_os = "macos")]
    {
        let status = Command::new("lpr")
            .args(["-P", &printer, path.to_str().unwrap_or("")])
            .status()
            .map_err(|e| format!("Afdrukken mislukt: {e}"))?;
        if !status.success() {
            return Err("lpr mislukt".into());
        }
        Ok(())
    }
    #[cfg(all(not(target_os = "windows"), not(target_os = "macos")))]
    {
        let status = Command::new("lpr")
            .args(["-P", &printer, path.to_str().unwrap_or("")])
            .status()
            .map_err(|e| format!("Afdrukken mislukt: {e}"))?;
        if !status.success() {
            return Err("lpr mislukt".into());
        }
        Ok(())
    }
}



// Opent een URL in de standaard systeembrowser.
#[tauri::command]
fn open_url(url: String) -> Result<(), String> {
    let url = url.trim();
    if url.is_empty() {
        return Err("lege URL".into());
    }
    // Alleen http(s) en mailto toestaan
    let lower = url.to_ascii_lowercase();
    if !(lower.starts_with("http://") || lower.starts_with("https://") || lower.starts_with("mailto:")) {
        return Err("alleen http(s) of mailto toegestaan".into());
    }
    // Geen stuurtekens, spaties of aanhalingstekens: die horen niet in een geldige URL
    // (spaties horen als %20) en zijn de basis voor trucs met opdrachtregels.
    if url.chars().any(|c| c.is_control() || c.is_whitespace() || c == '"' || c == '\\' || c == '<' || c == '>') {
        return Err("ongeldige tekens in URL".into());
    }
    #[cfg(target_os = "windows")]
    {
        // Geen cmd.exe: die leest tekens als & en | als eigen opdrachten.
        // rundll32 geeft de URL rechtstreeks aan de standaardbrowser.
        Command::new("rundll32")
            .args(["url.dll,FileProtocolHandler", url])
            .spawn()
            .map_err(|e| format!("Kan browser niet openen: {e}"))?;
    }
    #[cfg(target_os = "macos")]
    {
        Command::new("open")
            .arg(url)
            .spawn()
            .map_err(|e| format!("Kan browser niet openen: {e}"))?;
    }
    #[cfg(all(not(target_os = "windows"), not(target_os = "macos")))]
    {
        Command::new("xdg-open")
            .arg(url)
            .spawn()
            .map_err(|e| format!("Kan browser niet openen: {e}"))?;
    }
    Ok(())
}

/// Maakt bij eerste start (en elke start) de gebruikersmappen aan, inclusief memory/
/// met lege JSON-bestanden als ze nog niet bestaan. Geen overschrijven van bestaande data.
fn ensure_user_dirs(app: &tauri::AppHandle) {
    let Ok(base) = base_dir(app) else { return };
    for sub in ["media", "stad", "memory"] {
        let _ = fs::create_dir_all(base.join(sub));
    }
    // Lege geheugenbestanden alleen aanmaken als ze ontbreken
    let seeds: &[(&str, &str)] = &[
        ("memory/woordenboek-bookmarks.json", "[]"),
        ("memory/woordenboek-history.json", "[]"),
        ("memory/woordenboek-pos.json", "{}"),
    ];
    for (rel, contents) in seeds {
        let p = base.join(rel);
        if !p.exists() {
            if let Some(parent) = p.parent() {
                let _ = fs::create_dir_all(parent);
            }
            let _ = fs::write(&p, contents);
        }
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            read_user_file,
            write_user_file,
            delete_user_file,
            list_user_stad,
            read_user_pdf_b64,
            export_user_image,
            list_user_covers,
            read_user_image_b64,
            reset_user_data,
            open_user_folder,
            open_media_folder,
            list_media_files,
            delete_media_file,
            read_media_file,
            media_file_path,
            write_media_file,
            begin_media_file,
            append_media_file,
            open_url,
            list_printers,
            print_pdf
        ])
        .setup(|app| {
            // Gebruikersmappen + lege memory-bestanden bij start
            ensure_user_dirs(app.handle());
            // Altijd fullscreen bij starten
            if let Some(win) = app.get_webview_window("main") {
                let _ = win.set_fullscreen(true);
                let _ = win.maximize();
            }
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("fout bij het starten van Leo Crucis");
}
