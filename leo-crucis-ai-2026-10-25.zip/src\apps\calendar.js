// Kalender — Google Agenda-stijl: dag-, week- en maandweergave, zijbalk met minikalender
// en takenlijst (to-do), afspraken met begin- en eindtijd (slepen om te maken, te
// verplaatsen en te verlengen), hele-dag-afspraken en de liturgische kalender als
// aparte agenda.
// Opslag: Tauri app_data/memory/*.json (zelfde FileMem als woordenboek) — geen localStorage.
// Taken: memory/calendar-todos.json via FileMem.

const KEY_OLD = 'lc-calendar-events-v1';   // legacy localStorage
const KEY = 'lc-calendar-events-v2';       // legacy localStorage (migratie)
const UI_KEY = 'lc-calendar-ui-v1';
const MEM_EVENTS = 'calendar-events';
const MEM_UI = 'calendar-ui';
const MEM_LIT = 'calendar-lit-prefs';
const MEM_TODOS = 'calendar-todos';
const MEM_ROS = 'calendar-rosary-prefs';

/** File-geheugen via Tauri (memory/*.json). Fallback: localStorage in de browser. */
const FileMem = (() => {
  function inTauri() {
    return !!(typeof window !== 'undefined' && window.__TAURI__?.core?.invoke);
  }
  async function invoke(cmd, args) {
    if (!inTauri()) return null;
    try {
      return await window.__TAURI__.core.invoke(cmd, args);
    } catch (e) {
      console.warn('[FileMem]', cmd, e);
      return null;
    }
  }
  function path(key) {
    const safe = String(key || '').replace(/[^a-zA-Z0-9_\- .]/g, '').trim();
    if (!safe) throw new Error('ongeldige memory-sleutel');
    return 'memory/' + safe + (safe.endsWith('.json') ? '' : '.json');
  }
  async function read(key) {
    if (inTauri()) {
      const s = await invoke('read_user_file', { path: path(key) });
      if (s == null || s === '') return null;
      try { return JSON.parse(s); } catch { return null; }
    }
    try {
      const raw = localStorage.getItem('lc-mem-' + key);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }
  async function write(key, data) {
    if (inTauri()) {
      await invoke('write_user_file', { path: path(key), contents: JSON.stringify(data, null, 1) });
      return;
    }
    try { localStorage.setItem('lc-mem-' + key, JSON.stringify(data)); } catch (e) { console.warn(e); }
  }
  return { read, write, inTauri };
})();

const MONTHS = ['januari','februari','maart','april','mei','juni','juli','augustus','september','oktober','november','december'];
const MONTHS_S = ['jan','feb','mrt','apr','mei','jun','jul','aug','sep','okt','nov','dec'];
const DOW_U = ['MA','DI','WO','DO','VR','ZA','ZO'];
const DOW_L = ['maandag','dinsdag','woensdag','donderdag','vrijdag','zaterdag','zondag'];
const MINI_DOW = ['M','D','W','D','V','Z','Z'];
const HOUR = 48; // pixels per uur (ook --h in de CSS)
const DEF_COLOR = '#3f51b5';
const COLORS = [
  ['Tomaat', '#d50000'], ['Flamingo', '#e67c73'], ['Mandarijn', '#f4511e'], ['Banaan', '#f6bf26'],
  ['Salie', '#33b679'], ['Basilicum', '#0b8043'], ['Pauw', '#039be5'], ['Bosbes', '#3f51b5'],
  ['Lavendel', '#7986cb'], ['Druif', '#8e24aa'], ['Grafiet', '#616161'],
];

const pad = n => String(n).padStart(2, '0');
const keyOf = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const parseKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const startOfDay = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const mondayOf = d => addDays(startOfDay(d), -((d.getDay() + 6) % 7));
const fmtT = min => pad(Math.floor(min / 60)) + ':' + pad(min % 60);
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const durLabel = min => min < 60 ? min + ' min' : (min % 60 === 0 ? (min / 60) + ' uur' : String(min / 60).replace('.', ',') + ' uur');
function textOn(hex) {
  const n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
  return (r * 299 + g * 587 + b * 114) / 1000 > 170 ? '#1a1410' : '#fff';
}
function longDate(d) {
  const s = DOW_L[(d.getDay() + 6) % 7] + ' ' + d.getDate() + ' ' + MONTHS[d.getMonth()];
  return d.getFullYear() === new Date().getFullYear() ? s : s + ' ' + d.getFullYear();
}

async function saveEvents(list) {
  try { await FileMem.write(MEM_EVENTS, list); } catch (e) { console.warn(e); }
}
/** Lees afspraken uit memory; eenmalig migreren vanuit localStorage. */
async function loadEvents() {
  try {
    const fromMem = await FileMem.read(MEM_EVENTS);
    if (Array.isArray(fromMem)) return fromMem;

    // Migratie: localStorage v2
    let out = [];
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const a = JSON.parse(raw);
        if (Array.isArray(a)) out = a;
      }
    } catch (_) {}

    // Migratie: localStorage v1 (notities per dag)
    if (!out.length) {
      try {
        const old = JSON.parse(localStorage.getItem(KEY_OLD) || '{}') || {};
        Object.keys(old).forEach(k => (old[k] || []).forEach(e =>
          out.push({ id: e.id || uid(), title: e.text || '', date: k, allDay: true, color: DEF_COLOR })));
      } catch (_) {}
    }

    if (out.length) {
      await saveEvents(out);
      try {
        localStorage.removeItem(KEY);
        localStorage.removeItem(KEY_OLD);
      } catch (_) {}
    }
    return out;
  } catch { return []; }
}
async function loadUi() {
  try {
    const fromMem = await FileMem.read(MEM_UI);
    if (fromMem && typeof fromMem === 'object') {
      return Object.assign({ view: 'week', mine: true }, fromMem);
    }
    // Migratie localStorage
    try {
      const raw = localStorage.getItem(UI_KEY);
      if (raw) {
        const u = Object.assign({ view: 'week', mine: true }, JSON.parse(raw));
        await FileMem.write(MEM_UI, u);
        try { localStorage.removeItem(UI_KEY); } catch (_) {}
        return u;
      }
    } catch (_) {}
  } catch (_) {}
  return { view: 'week', mine: true };
}
async function saveUi(ui) {
  try { await FileMem.write(MEM_UI, ui); } catch (e) { console.warn(e); }
}

function emptyTodoStore() {
  return { lists: [{ id: 'default', name: 'Mijn taken' }], tasks: [] };
}
async function loadTodos() {
  try {
    const fromMem = await FileMem.read(MEM_TODOS);
    if (!fromMem) return emptyTodoStore();
    // Migratie: oude platte array → nieuw formaat
    if (Array.isArray(fromMem)) {
      return {
        lists: [{ id: 'default', name: 'Mijn taken' }],
        tasks: fromMem.map(t => ({
          id: t.id || uid(),
          listId: 'default',
          text: t.text || '',
          done: !!t.done,
          starred: !!t.starred,
          due: t.due || null,
          created: t.created || Date.now(),
          parentId: t.parentId || null,
          attachments: Array.isArray(t.attachments) ? t.attachments : []
        }))
      };
    }
    if (fromMem && Array.isArray(fromMem.lists) && Array.isArray(fromMem.tasks)) {
      if (!fromMem.lists.length) fromMem.lists = [{ id: 'default', name: 'Mijn taken' }];
      return fromMem;
    }
  } catch (_) {}
  return emptyTodoStore();
}
async function saveTodos(store) {
  try { await FileMem.write(MEM_TODOS, store); } catch (e) { console.warn(e); }
}

const ICONS = {
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  chevL: '<path d="M15 6l-6 6 6 6"/>',
  chevR: '<path d="M9 6l6 6-6 6"/>',
  chevU: '<path d="M6 15l6-6 6 6"/>',
  chevD: '<path d="M6 9l6 6 6-6"/>',
  caret: '<path d="M7 10l5 5 5-5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  pencil: '<path d="M4 20l1-4L16 5l3 3L8 19z"/><path d="M14 7l3 3"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  text: '<path d="M4 7h16M4 12h16M4 17h10"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  cal: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  palette: '<circle cx="12" cy="12" r="9"/><circle cx="8.5" cy="10" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="15.5" cy="10" r="1"/>',
  star: '<path d="M12 3l2.4 4.9 5.4.8-3.9 3.8.9 5.4L12 15.9 7.2 18l.9-5.4-3.9-3.8 5.4-.8z"/>',
  starFill: '<path d="M12 3l2.4 4.9 5.4.8-3.9 3.8.9 5.4L12 15.9 7.2 18l.9-5.4-3.9-3.8 5.4-.8z" fill="currentColor" stroke="none"/>',
  more: '<circle cx="12" cy="5" r="1.5" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none"/><circle cx="12" cy="19" r="1.5" fill="currentColor" stroke="none"/>',
  checkCircle: '<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
  flag: '<path d="M5 21V4h9l-1 4 1 4H5"/><path d="M5 4h10"/>',
  subtask: '<path d="M8 6h12M8 12h12M8 18h12"/><path d="M4 6h.01M4 12h.01M4 18h.01"/>',
  attach: '<path d="M18 12.5V8a4 4 0 00-8 0v9a2.5 2.5 0 005 0V9"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11"/><path d="M5 6h.01M5 12h.01M5 18h.01"/>',
  deadline: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/>',
};
function icon(name) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('aria-hidden', 'true');
  s.innerHTML = ICONS[name] || '';
  return s;
}
function el(tag, cls, txt) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (txt != null) e.textContent = txt;
  return e;
}
function ibtn(name, label) {
  const b = el('button', 'gc-ibtn');
  b.type = 'button';
  b.title = label;
  b.setAttribute('aria-label', label);
  b.append(icon(name));
  return b;
}

// Naast elkaar liggende afspraken in één dag: banen toewijzen zodat ze niet over elkaar liggen.
function layoutDay(list) {
  const items = list.slice().sort((a, b) => a.start - b.start || b.end - a.end).map(ev => ({ ev, lane: 0, lanes: 1 }));
  let cluster = [], clusterEnd = -1;
  const flush = () => {
    const ends = [];
    cluster.forEach(it => {
      let l = ends.findIndex(e => e <= it.ev.start);
      if (l < 0) { l = ends.length; ends.push(0); }
      ends[l] = it.ev.end;
      it.lane = l;
    });
    cluster.forEach(it => { it.lanes = ends.length; });
    cluster = [];
  };
  items.forEach(it => {
    if (cluster.length && it.ev.start >= clusterEnd) { flush(); clusterEnd = -1; }
    cluster.push(it);
    clusterEnd = Math.max(clusterEnd, it.ev.end);
  });
  if (cluster.length) flush();
  return items;
}

// ---------- Liturgische kalender (data/liturgie-kalender.json: vaste feesten + Paasdata) ----------
const LIT_KEY = 'lc-calendar-lit-v1';
const BELG = ['Antwerpen', 'Brugge', 'Gent', 'Hasselt', 'Mechelen-Brussel'];
const NEDL = ['Breda', 'Groningen', 'Haarlem', 'Roermond', 'Rotterdam', "'s-Hertogenbosch", 'Utrecht'];
const RANK_NAME = { h: 'hoogfeest', f: 'feest', g: 'gedachtenis' };
let LIT = null;
let litPromise = null;
function loadLit() {
  if (!litPromise) {
    litPromise = fetch('data/liturgie-kalender.json')
      .then(r => (r.ok ? r.json() : null)).catch(() => null)
      .then(j => { LIT = j; return j; });
  }
  return litPromise;
}
async function loadLitPrefs() {
  try {
    const fromMem = await FileMem.read(MEM_LIT);
    if (fromMem && typeof fromMem === 'object') {
      return Object.assign({ on: true, bis: 'alle', tm: true }, fromMem);
    }
    try {
      const raw = localStorage.getItem(LIT_KEY);
      if (raw) {
        const p = Object.assign({ on: true, bis: 'alle', tm: true }, JSON.parse(raw));
        await FileMem.write(MEM_LIT, p);
        try { localStorage.removeItem(LIT_KEY); } catch (_) {}
        return p;
      }
    } catch (_) {}
  } catch (_) {}
  return { on: true, bis: 'alle', tm: true };
}
async function saveLitPrefs(p) {
  try { await FileMem.write(MEM_LIT, p); } catch (e) { console.warn(e); }
}

// Paasdatum (Gregoriaans): eerst de Paasdata-tabel, buiten of naast de tabel de berekening.
function computus(y) {
  const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4;
  const f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
  const t = h + l - 7 * m + 114;
  return [Math.floor(t / 31), (t % 31) + 1];
}
function easterOf(y) {
  const t = LIT && LIT.paas && LIT.paas[y];
  if (t) return new Date(y, Number(t.slice(0, 2)) - 1, Number(t.slice(3)));
  const [mo, da] = computus(y);
  return new Date(y, mo - 1, da);
}
const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const mmdd = d => String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const sundayOnOrBefore = d => addDays(d, -d.getDay());
const firstWeekdayAfter = (d, wd) => { let x = addDays(d, 1); while (x.getDay() !== wd) x = addDays(x, 1); return x; };

const GC_CSS = `/* Kalender in Google Agenda-stijl */
.cal-app.gc{display:flex;flex-direction:column;--h:48px;color:var(--ink);font-size:14px;line-height:1.35}
.gc [hidden]{display:none!important}
.gc button{font:inherit;color:inherit}
.gc-top{display:flex;align-items:center;gap:6px;height:56px;flex-shrink:0;padding:0 2px}
.gc-ibtn{width:40px;height:40px;flex:none;border-radius:50%;border:0;background:transparent;cursor:pointer;
  display:inline-flex;align-items:center;justify-content:center;color:var(--ink)}
.gc-ibtn:hover{background:var(--sel)}
.gc-ibtn:focus-visible,.gc-pill:focus-visible,.gc-create:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
.gc-ibtn svg,.gc-pill svg,.gc-row-ic svg,.gc-create svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.gc-brand{display:flex;align-items:center;gap:10px;margin:0 14px 0 4px;font-size:1.35rem;white-space:nowrap}
.gc-logo{width:32px;height:32px;border-radius:7px;background:var(--acc);color:#fff;font-weight:700;font-size:15px;
  display:inline-flex;align-items:center;justify-content:center;box-shadow:inset 0 -5px 0 color-mix(in srgb,#000 22%,transparent)}
.gc-pill{height:36px;padding:0 16px;border-radius:18px;border:1px solid var(--line);background:transparent;cursor:pointer;
  display:inline-flex;align-items:center;gap:4px;white-space:nowrap}
.gc-pill:hover{background:var(--sel)}
.gc-pill[aria-expanded="true"]{background:var(--sel)}
.gc-title{margin:0 8px;font-size:1.35rem;font-weight:400;text-transform:capitalize;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.gc-spacer{flex:1}
.gc-viewwrap{position:relative}
.gc-viewbtn{padding-right:8px}
.gc-menu{position:absolute;right:0;top:42px;z-index:40;min-width:170px;padding:6px 0;border-radius:8px;border:1px solid var(--line);
  background:var(--panel);box-shadow:0 6px 24px rgba(0,0,0,.25)}
.gc-menu button{display:flex;align-items:center;gap:8px;width:100%;padding:8px 14px;border:0;background:none;cursor:pointer;text-align:left}
.gc-menu button:hover{background:var(--sel)}
.gc-menu .gc-chk{width:18px;display:inline-flex}
.gc-menu .gc-chk svg{width:16px;height:16px;fill:none;stroke:var(--acc);stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}
.gc-menu .gc-key{margin-left:auto;color:var(--mute);font-size:12px}

.gc-main{flex:1;min-height:0;display:flex;position:relative}
.gc-side{width:256px;flex:none;display:flex;flex-direction:column;gap:18px;padding:6px 14px 8px 4px;overflow:auto;box-sizing:border-box;
  scrollbar-width:thin}
.gc-create{align-self:flex-start;height:52px;padding:0 22px 0 16px;border:0;border-radius:26px;display:inline-flex;align-items:center;gap:12px;
  background:var(--panel);cursor:pointer;font-weight:500;box-shadow:0 1px 3px rgba(0,0,0,.28),0 4px 10px rgba(0,0,0,.14)}
.gc-create:hover{box-shadow:0 2px 6px rgba(0,0,0,.32),0 6px 14px rgba(0,0,0,.18);background:color-mix(in srgb,var(--acc) 7%,var(--panel))}
.gc-create svg{width:24px;height:24px;color:var(--acc)}
.gc-scrim{display:none}

.gc-mini-head{display:flex;align-items:center;gap:2px;padding:0 0 4px 8px}
.gc-mini-title{flex:1;font-weight:500;text-transform:capitalize}
.gc-mini-head .gc-ibtn{width:30px;height:30px}
.gc-mini-head .gc-ibtn svg{width:18px;height:18px}
.gc-mini-grid{display:grid;grid-template-columns:repeat(7,1fr);row-gap:1px}
.gc-mini-dow{text-align:center;font-size:11px;color:var(--mute);padding:4px 0;font-weight:500}
.gc-mini-day{height:30px;padding:0;min-width:0;border:0;background:transparent;cursor:pointer;font-size:12px;position:relative;border-radius:0;display:flex;align-items:center;justify-content:center}
.gc-mini-day span{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center}
.gc-mini-day:hover span{background:var(--sel)}
.gc-mini-day.is-out{color:var(--mute)}
.gc-mini-day.in-range{background:color-mix(in srgb,var(--acc) 12%,transparent)}
.gc-mini-day.is-first{border-radius:15px 0 0 15px}
.gc-mini-day.is-last{border-radius:0 15px 15px 0}
.gc-mini-day.is-sel span{background:color-mix(in srgb,var(--acc) 22%,transparent);font-weight:600}
.gc-mini-day.is-today span,.gc-mini-day.is-today:hover span{background:var(--acc);color:#fff;font-weight:600}

.gc-lists-head{display:flex;align-items:center;justify-content:space-between;font-weight:500;padding:2px 8px;margin-bottom:2px}
.gc-list-item{display:flex;align-items:center;gap:12px;padding:6px 8px;cursor:pointer;border-radius:6px}
.gc-list-item:hover{background:var(--sel)}
.gc-list-item input{width:18px;height:18px;margin:0;cursor:pointer;flex:none}

.gc-view{flex:1;min-width:0;min-height:0;display:flex;flex-direction:column;overflow:hidden;
  background:var(--panel);border:1px solid var(--line);border-radius:16px}
.gc-time{flex:1;min-height:0;display:flex;flex-direction:column}
.gc-row{display:grid;grid-template-columns:56px repeat(var(--n),minmax(0,1fr))}
.gc-head{flex:none;padding-top:6px}
.gc-gmt{font-size:10px;color:var(--mute);align-self:end;text-align:right;padding:0 8px 8px 0}
.gc-dayhead{border:0;background:transparent;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:2px;padding:2px 0 6px}
.gc-dow{font-size:11px;font-weight:500;color:var(--mute);letter-spacing:.04em}
.gc-dnum{width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.6rem;line-height:1}
.gc-dayhead:hover .gc-dnum{background:var(--sel)}
.gc-dayhead.is-today .gc-dow{color:var(--acc)}
.gc-dayhead.is-today .gc-dnum{background:var(--acc);color:#fff}
.gc-allday{flex:none;border-bottom:1px solid var(--line);padding-bottom:4px;min-height:22px}
.gc-allgut{display:flex;align-items:flex-start;justify-content:flex-end;padding:0 4px 0 0}
.gc-allgut .gc-ibtn{width:26px;height:26px}
.gc-allgut .gc-ibtn svg{width:16px;height:16px}
.gc-allcell{border-left:1px solid var(--line);padding:0 3px;min-width:0}
.gc-scroll{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;position:relative}
.gc-grid{height:calc(var(--h)*24);padding-top:0}
.gc-hours{position:relative}
.gc-hour{position:absolute;right:8px;font-size:10px;color:var(--mute);line-height:14px}
.gc-col{position:relative;height:calc(var(--h)*24);border-left:1px solid var(--line);cursor:default;touch-action:pan-y;
  background-image:linear-gradient(to bottom,var(--line) 1px,transparent 1px);background-size:100% var(--h)}
.gc-col.is-today{background-color:color-mix(in srgb,var(--acc) 3%,transparent)}
.gc-ev{position:absolute;box-sizing:border-box;border-radius:6px;padding:2px 6px;font-size:12px;line-height:1.25;overflow:hidden;cursor:pointer;
  border:1px solid var(--panel);user-select:none;-webkit-user-select:none;touch-action:pan-y}
.gc-ev:hover{filter:brightness(1.08)}
.gc-ev-t{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.gc-ev-time{opacity:.92;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.gc-ev-inl{font-weight:400}
.gc-ev.is-dragging{z-index:6;opacity:.9;cursor:grabbing;box-shadow:0 4px 14px rgba(0,0,0,.35)}
.gc-ev.is-draft,.gc-ev.gc-ghost{z-index:5;pointer-events:none;box-shadow:0 2px 8px rgba(0,0,0,.3);left:0;width:calc(100% - 2px)}
.gc-resize{position:absolute;left:0;right:0;bottom:0;height:8px;cursor:ns-resize}
.gc-now{position:absolute;left:0;right:0;height:0;border-top:2px solid #d93025;z-index:4;pointer-events:none}
.gc-now::before{content:'';position:absolute;left:-7px;top:-6px;width:12px;height:12px;border-radius:50%;background:#d93025}

.gc-chip{display:block;width:100%;box-sizing:border-box;height:20px;line-height:20px;margin:0 0 2px;padding:0 6px;border:0;border-radius:4px;
  font-size:12px;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}
.gc-chip:hover{filter:brightness(1.08)}
.gc-chip.is-timed{background:transparent;color:var(--ink);padding-left:4px}
.gc-chip.is-timed:hover{background:var(--sel);filter:none}
.gc-chip.is-timed::before{content:'';display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--c);margin-right:6px}
.gc-chip.is-timed b{font-weight:400;color:var(--mute);margin-right:4px}
.gc-more{display:block;border:0;background:transparent;cursor:pointer;font-size:12px;font-weight:600;height:20px;line-height:20px;padding:0 6px;color:var(--ink);border-radius:4px}
.gc-more:hover{background:var(--sel)}
.gc-litchip{background:color-mix(in srgb,var(--mute) 18%,var(--panel));color:var(--ink)}
.gc-litchip.r-h{background:var(--acc);color:#fff;font-weight:600}
.gc-rosarychip{background:color-mix(in srgb,var(--acc2,#b8922a) 22%,var(--panel));color:var(--ink);border:1px solid color-mix(in srgb,var(--acc2,#b8922a) 45%,var(--line))}
.gc-rosarychip:hover{border-color:var(--acc2,#b8922a)}
.gc-litchip.r-e{background:color-mix(in srgb,var(--acc) 20%,var(--panel));color:var(--acc);font-weight:600}
.gc-litchip.r-f{background:color-mix(in srgb,var(--acc2) 30%,var(--panel))}
.gc-litchip.is-tm{background:color-mix(in srgb,#3f6bd1 20%,var(--panel))}

.gc-month{flex:1;min-height:0;display:flex;flex-direction:column}
.gc-mhead{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));flex:none;padding-top:6px}
.gc-mdow{text-align:center;font-size:11px;font-weight:500;color:var(--mute);padding:6px 0;letter-spacing:.04em}
.gc-mbody{flex:1;min-height:0;display:grid;grid-template-columns:repeat(7,minmax(0,1fr))}
.gc-mcell{border-top:1px solid var(--line);border-left:1px solid var(--line);padding:2px 4px 0;display:flex;flex-direction:column;min-height:0;min-width:0;cursor:pointer;overflow:hidden}
.gc-mcell:nth-child(7n+1){border-left:0}
.gc-mcell:hover{background:color-mix(in srgb,var(--sel) 55%,transparent)}
.gc-mnum{align-self:center;min-width:26px;height:26px;padding:0 6px;border:0;border-radius:13px;background:transparent;cursor:pointer;font-size:12px;font-weight:500;margin:2px 0 2px;flex:none}
.gc-mnum:hover{background:var(--sel)}
.gc-mcell.is-out .gc-mnum{color:var(--mute);font-weight:400}
.gc-mcell.is-today .gc-mnum{background:var(--acc);color:#fff}
.gc-mchips{flex:1;min-height:0;overflow:hidden}

.gc-pop{position:absolute;z-index:25;width:320px;max-width:calc(100% - 16px);box-sizing:border-box;background:var(--panel);color:var(--ink);
  border:1px solid var(--line);border-radius:12px;box-shadow:0 8px 28px rgba(0,0,0,.35);padding:6px 6px 16px}
.gc-pop-bar{display:flex;justify-content:flex-end;gap:2px}
.gc-pop-bar .gc-ibtn{width:34px;height:34px}
.gc-pop-bar .gc-ibtn svg{width:18px;height:18px}
.gc-pop-body{padding:2px 18px 0 18px}
.gc-pop-title{display:flex;align-items:flex-start;gap:12px;font-size:1.3rem;line-height:1.25;margin-bottom:6px;word-break:break-word}
.gc-dot{width:14px;height:14px;border-radius:4px;flex:none;margin-top:6px}
.gc-pop-when{color:var(--mute);font-size:13px;margin:0 0 0 26px}
.gc-pop-desc{margin:12px 0 0 26px;white-space:pre-wrap;word-break:break-word;font-size:13px}
.gc-pop-lit{margin:10px 0 0 0}
.gc-pop-lit .cal-lit-item{padding:5px 0;border-bottom:1px solid color-mix(in srgb,var(--line) 60%,transparent)}
.gc-pop-lit .cal-lit-item:last-child{border-bottom:0}

.gc-modal{position:absolute;inset:0;z-index:30;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.4);padding:12px;box-sizing:border-box}
.gc-dialog{width:min(520px,100%);max-height:100%;overflow:auto;box-sizing:border-box;background:var(--panel);color:var(--ink);border-radius:14px;
  box-shadow:0 12px 40px rgba(0,0,0,.45);padding:10px 20px 16px}
.gc-dialog-top{display:flex;justify-content:flex-end;margin-right:-10px}
.gc-title-in{width:100%;box-sizing:border-box;font:inherit;font-size:1.4rem;padding:6px 0 6px 34px;border:0;border-bottom:2px solid var(--line);
  background:transparent;color:var(--ink);outline:none;margin-bottom:14px}
.gc-title-in:focus{border-bottom-color:var(--acc)}
.gc-field{display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin:8px 0}
.gc-row-ic{width:26px;flex:none;color:var(--mute);display:inline-flex;align-self:flex-start;padding-top:6px}
.gc-field.is-top{align-items:flex-start}
.gc-field input[type=date],.gc-field select,.gc-field textarea{font:inherit;font-size:13px;color:var(--ink);background:var(--bg);
  border:1px solid var(--line);border-radius:8px;padding:7px 9px;box-sizing:border-box}
.gc-field input:focus,.gc-field select:focus,.gc-field textarea:focus{outline:2px solid var(--acc);outline-offset:-1px}
.gc-field textarea{flex:1;min-width:0;min-height:84px;resize:vertical}
.gc-field label.gc-check{display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:13px;margin-left:4px}
.gc-sep{color:var(--mute)}
.gc-swatches{display:flex;flex-wrap:wrap;gap:8px}
.gc-sw{width:24px;height:24px;border-radius:50%;border:0;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;padding:0}
.gc-sw svg{width:14px;height:14px;fill:none;stroke:#fff;stroke-width:3;stroke-linecap:round;stroke-linejoin:round}
.gc-sw:focus-visible{outline:2px solid var(--ink);outline-offset:2px}
.gc-actions{display:flex;align-items:center;gap:8px;margin-top:16px}
.gc-btn{height:36px;padding:0 18px;border-radius:18px;border:1px solid var(--line);background:transparent;cursor:pointer;font-weight:500}
.gc-btn:hover{background:var(--sel)}
.gc-btn.is-primary{background:var(--acc);border-color:var(--acc);color:#fff}
.gc-btn.is-primary:hover{filter:brightness(1.1);background:var(--acc)}
.gc-btn.is-danger{color:#c5221f;border-color:transparent}

.cal-app.gc .gc-top{flex-wrap:nowrap;margin-bottom:0;gap:6px}
.cal-app.gc .gc-logo{border:0;cursor:pointer;padding:0;font-family:inherit;color:#fff;flex:none}
.cal-app.gc .gc-top>*{flex-shrink:0}
.cal-app.gc .gc-top>.gc-title{flex-shrink:1}
.cal-app.gc .cal-libs-overlay{top:64px;border-radius:16px}
.cal-app.gc.is-narrow .cal-libs-overlay{top:60px}
.gc-logo:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
.gc-pill svg{width:18px;height:18px}
.cal-app.gc.is-narrow .gc-top{gap:2px}
.cal-app.gc.is-narrow .gc-today-pill,.cal-app.gc.is-narrow .gc-vlabel,.cal-app.gc.is-narrow .gc-lbl{display:none}
.cal-app.gc.is-narrow .gc-title{flex:1;font-size:1.05rem;margin:0 2px}
.cal-app.gc.is-narrow .gc-spacer{display:none}
.cal-app.gc.is-narrow .gc-pill{padding:0 10px}
.cal-app.gc.is-narrow .gc-ibtn{width:36px;height:36px}
@media(max-width:759px){
  .gc-brand-text,.gc-viewbtn .gc-vlabel{display:none}
  .gc-brand{margin:0 4px}
  .gc-title{font-size:1.1rem;margin:0 4px}
  .gc-pill{padding:0 12px}
  .cal-app.gc{padding:4px 6px 8px}
}
.cal-app.gc.is-narrow .gc-brand-text{display:none}
.cal-app.gc.is-narrow .gc-side{position:absolute;z-index:18;left:0;top:0;bottom:0;background:var(--panel);width:272px;max-width:86%;padding:12px 12px 12px 12px;
  border-radius:0 16px 16px 0;box-shadow:6px 0 26px rgba(0,0,0,.3)}
.cal-app.gc:not(.side-open) .gc-side{display:none}
.cal-app.gc.is-narrow.side-open .gc-scrim{display:block;position:absolute;inset:0;z-index:17;background:rgba(0,0,0,.3);border-radius:16px}
.cal-app.gc.is-narrow .gc-dnum{width:36px;height:36px;font-size:1.25rem}
.cal-app.gc.is-narrow .gc-row{grid-template-columns:44px repeat(var(--n),minmax(0,1fr))}
`;
const LIT_CSS = `/* Liturgische kalender in de Kalender-app */
.cal-lit-bar{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin:0 0 8px;font-size:13px;flex-shrink:0}
.cal-lit-opt{display:inline-flex;align-items:center;gap:4px;cursor:pointer;color:var(--ink)}
.cal-lit-bis{border:1px solid var(--line);border-radius:8px;background:var(--panel);color:var(--ink);font:inherit;font-size:13px;padding:4px 8px}
.cal-lit-info{flex-basis:100%;color:var(--mute);font-size:12px}
.cal-lit-info a{color:var(--acc);margin:0 2px}
.cal-lit-day{display:flex;flex-direction:column;gap:2px;border-bottom:1px solid var(--line);padding-bottom:8px}
.cal-lit-day:empty{display:none}
.cal-lit-item{font-size:13px;padding:3px 0}
.cal-lit-head{display:flex;gap:6px;align-items:baseline;list-style:none;cursor:default}
summary.cal-lit-head{cursor:pointer}
summary.cal-lit-head::-webkit-details-marker{display:none}
.cal-lit-badges{display:inline-flex;gap:3px;flex:none}
.cal-lit-badges:empty{display:none}
.cal-lit-text i{color:var(--mute)}
.cal-lit-item.r-h .cal-lit-text,.cal-lit-item.r-e .cal-lit-text{font-weight:700;color:var(--acc)}
.cal-lit-item.r-f .cal-lit-text{font-weight:700}
.cal-lit-item.is-tm .cal-lit-text{color:#1f3a7a}
:root[data-theme="dark"] .cal-lit-item.is-tm .cal-lit-text{color:#8fb0ff}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]):not([data-theme="dark"]) .cal-lit-item.is-tm .cal-lit-text{color:#8fb0ff}}
.bd{font-size:10px;line-height:1;padding:2px 4px;border-radius:4px;border:1px solid var(--line);font-weight:700}
.bd-h{background:var(--acc);border-color:var(--acc);color:#fff}
.bd-f{border-color:var(--acc2);color:var(--acc2)}
.bd-g{color:var(--mute)}
.bd-tm{border-color:#1f3a7a;color:#1f3a7a}
.bd-v{border-color:#2e7d4f;color:#2e7d4f}
:root[data-theme="dark"] .bd-tm{border-color:#8fb0ff;color:#8fb0ff}
:root[data-theme="dark"] .bd-v{border-color:#6fcf97;color:#6fcf97}
.cal-lit-detail{margin:4px 0 4px 0;font-size:12px;color:var(--mute);line-height:1.45}
.cal-lit-note{margin:4px 0 0;font-size:12px;color:var(--mute)}
.cal-libs-btn{
  border:1px solid var(--line);background:var(--panel);color:var(--ink);
  border-radius:8px;padding:6px 12px;cursor:pointer;font:inherit;font-size:13px;margin-left:4px;
}
.cal-libs-btn:hover,.cal-libs-btn[aria-expanded="true"]{border-color:var(--acc);color:var(--acc);background:color-mix(in srgb,var(--acc) 10%,var(--panel))}
/* Overlay vóór de agenda */
.cal-libs-overlay{
  display:none;position:absolute;inset:0;z-index:20;
  background:color-mix(in srgb,var(--bg) 92%,transparent);
  backdrop-filter:blur(2px);
  padding:16px 18px 24px;box-sizing:border-box;
  overflow:auto;flex-direction:column;gap:14px;
}
.cal-app.is-libs .cal-libs-overlay{display:flex}
.cal-libs-head{display:flex;align-items:center;gap:10px;flex-shrink:0}
.cal-libs-head h2{margin:0;font-size:1.15rem;flex:1}
.cal-libs-back{
  border:1px solid var(--line);background:var(--panel);color:var(--ink);
  border-radius:8px;padding:6px 12px;cursor:pointer;font:inherit;font-size:13px;
}
.cal-libs-back:hover{border-color:var(--acc);color:var(--acc)}
.cal-libs-intro{margin:0;color:var(--mute);font-size:13px;line-height:1.45;max-width:52rem}
.cal-lib-card{
  border:1px solid var(--line);border-radius:12px;background:var(--panel);
  padding:14px 16px;display:flex;flex-direction:column;gap:10px;
  max-width:52rem;box-shadow:0 4px 24px color-mix(in srgb,var(--ink) 8%,transparent);
}
.cal-lib-card-top{display:flex;align-items:flex-start;gap:12px}
.cal-lib-card-top > div{flex:1;min-width:0}
.cal-lib-card h3{margin:0;font-size:1rem}
.cal-lib-card p{margin:4px 0 0;font-size:13px;color:var(--mute);line-height:1.4}
.cal-lib-credit{margin:6px 0 0;font-size:12px;color:var(--mute);line-height:1.4;font-style:italic}
.cal-lib-refs{margin:6px 0 0;font-size:12px;display:flex;flex-wrap:wrap;gap:6px 12px;align-items:center}
.cal-lib-refs a{color:var(--acc);text-decoration:none}
.cal-lib-refs a:hover{text-decoration:underline}
.cal-lib-refs .cal-lib-ref-label{color:var(--mute)}
.cal-lib-switch{position:relative;width:44px;height:26px;flex-shrink:0}
.cal-lib-switch input{opacity:0;width:0;height:0;position:absolute}
.cal-lib-switch span{
  position:absolute;inset:0;border-radius:99px;background:var(--line);cursor:pointer;
  transition:background .15s;
}
.cal-lib-switch span::after{
  content:'';position:absolute;width:20px;height:20px;border-radius:50%;
  background:#fff;top:3px;left:3px;transition:transform .15s;
  box-shadow:0 1px 3px rgba(0,0,0,.2);
}
.cal-lib-switch input:checked + span{background:var(--acc)}
.cal-lib-switch input:checked + span::after{transform:translateX(18px)}
.cal-lib-opts{display:flex;flex-wrap:wrap;align-items:center;gap:10px 16px;padding-top:4px;
  border-top:1px solid color-mix(in srgb,var(--line) 70%,transparent)}
.cal-lib-opts label{display:inline-flex;align-items:center;gap:6px;font-size:13px;cursor:pointer}
.cal-lib-opts select{
  border:1px solid var(--line);border-radius:8px;background:var(--bg);color:var(--ink);
  font:inherit;font-size:13px;padding:4px 8px}
.cal-lib-empty{color:var(--mute);font-size:13px;padding:12px 0}

/* Takenweergave (Google Agenda Taken) */
.gc-seg{display:inline-flex;border-radius:20px;border:1px solid var(--line);overflow:hidden;height:36px;flex:none}
.gc-seg button{width:40px;height:36px;border:0;background:transparent;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;color:var(--mute);padding:0}
.gc-seg button:hover{background:var(--sel)}
.gc-seg button.is-on{background:color-mix(in srgb,var(--acc) 18%,var(--panel));color:var(--acc)}
.gc-seg button svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.cal-app.is-tasks .gc-main{display:none}
.cal-app.is-tasks .gc-tasks-app{display:flex}
.gc-tasks-app{display:none;flex:1;min-height:0;background:var(--bg)}
.gc-tasks-nav{width:240px;flex:none;padding:12px 10px;overflow:auto;border-right:1px solid var(--line);box-sizing:border-box}
.gc-tasks-nav-item{display:flex;align-items:center;gap:10px;width:100%;padding:10px 14px;border:0;border-radius:24px;background:transparent;cursor:pointer;text-align:left;font:inherit;font-size:14px;color:var(--ink)}
.gc-tasks-nav-item:hover{background:var(--sel)}
.gc-tasks-nav-item.is-on{background:color-mix(in srgb,var(--acc) 16%,var(--panel));color:var(--acc);font-weight:500}
.gc-tasks-nav-item svg{width:18px;height:18px;flex:none;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.gc-tasks-nav-count{margin-left:auto;font-size:12px;color:var(--mute)}
.gc-tasks-nav-label{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.gc-list-more{margin-left:4px;flex:none;width:28px;height:28px;border:0;border-radius:50%;background:transparent;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;color:var(--mute);opacity:0;padding:0}
.gc-tasks-nav-item:hover .gc-list-more,.gc-tasks-nav-item.is-menu-open .gc-list-more{opacity:1}
.gc-list-more:hover{background:var(--sel);color:var(--ink)}
.gc-list-more svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2}
.gc-tasks-nav-item{position:relative}
.gc-list-menu{position:absolute;z-index:50;min-width:180px;right:8px;top:100%;margin-top:2px}
.gc-tasks-nav-sec{margin:18px 8px 6px;font-size:12px;font-weight:500;color:var(--mute);display:flex;align-items:center;gap:6px}
.gc-tasks-nav-sec svg{width:14px;height:14px;flex:none;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.gc-tasks-nav-add{color:var(--mute);font-size:13px}
.gc-tasks-panel{flex:1;min-width:0;display:flex;flex-direction:column;padding:8px 24px 24px;overflow:auto}
.gc-tasks-panel-head{display:flex;align-items:center;gap:8px;padding:12px 4px 8px}
.gc-tasks-panel-head h2{margin:0;font-size:1.35rem;font-weight:400;flex:1}
.gc-list-panel-edit{width:36px;height:36px;border:0;border-radius:50%;background:transparent;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;color:var(--mute);padding:0}
.gc-list-panel-edit:hover{background:var(--sel);color:var(--ink)}
.gc-list-panel-edit svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.gc-tasks-addlink{display:inline-flex;align-items:center;gap:10px;border:0;background:transparent;color:var(--acc);cursor:pointer;font:inherit;font-size:14px;padding:10px 8px;border-radius:8px;align-self:flex-start}
.gc-tasks-addlink:hover{background:color-mix(in srgb,var(--acc) 8%,transparent)}
.gc-tasks-addlink svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.gc-tasks-composer{display:none;flex-direction:column;gap:8px;padding:10px 12px;margin:4px 0 12px;border:1px solid var(--line);border-radius:12px;background:var(--panel);box-shadow:0 2px 12px rgba(0,0,0,.08)}
.gc-tasks-composer.is-open{display:flex}
.gc-tasks-composer input[type="text"]{border:0;background:transparent;font:inherit;font-size:15px;color:var(--ink);padding:4px 0;outline:none;width:100%}
.gc-tasks-composer-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.gc-tasks-composer input[type="date"]{border:1px solid var(--line);border-radius:8px;background:var(--bg);color:var(--ink);font:inherit;font-size:13px;padding:4px 8px}
.gc-tasks-composer .gc-btn{height:32px;padding:0 14px;font-size:13px}
.gc-tasks-group{margin:14px 0 4px;font-size:12px;font-weight:500;color:var(--mute)}
.gc-tasks-group.is-late{color:#c5221f}
.gc-task-row{display:flex;align-items:flex-start;gap:12px;padding:12px 8px;border-radius:8px;border-bottom:1px solid color-mix(in srgb,var(--line) 60%,transparent)}
.gc-task-row:hover{background:var(--sel)}
.gc-task-row.is-done .gc-task-title{text-decoration:line-through;color:var(--mute)}
.gc-task-cb{flex:none;width:20px;height:20px;margin-top:2px;border:2px solid var(--mute);border-radius:50%;background:transparent;cursor:pointer;padding:0;display:inline-flex;align-items:center;justify-content:center;color:transparent}
.gc-task-cb:hover{border-color:var(--acc)}
.gc-task-row.is-done .gc-task-cb{background:var(--acc);border-color:var(--acc);color:#fff}
.gc-task-cb svg{width:12px;height:12px;fill:none;stroke:currentColor;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}
.gc-task-main{flex:1;min-width:0}
.gc-task-title{font-size:14px;line-height:1.4;word-break:break-word}
.gc-task-meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.gc-task-chip{display:inline-flex;align-items:center;gap:4px;font-size:12px;padding:2px 8px;border-radius:12px;border:1px solid var(--line);color:var(--mute);background:var(--panel)}
.gc-task-chip.is-late{border-color:#f6aea9;color:#c5221f;background:#fce8e6}
.gc-task-chip svg{width:12px;height:12px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.gc-task-actions{display:flex;gap:2px;opacity:0;flex:none}
.gc-task-row:hover .gc-task-actions{opacity:1}
.gc-task-actions button{width:32px;height:32px;border:0;border-radius:50%;background:transparent;cursor:pointer;color:var(--mute);display:inline-flex;align-items:center;justify-content:center;padding:0}
.gc-task-actions button:hover{background:color-mix(in srgb,var(--ink) 8%,transparent);color:var(--ink)}
.gc-task-actions button.is-star{color:#f9ab00}
.gc-task-actions button svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.gc-task-actions button.is-star svg path{fill:currentColor;stroke:none}
.gc-tasks-empty{padding:24px 8px;color:var(--mute);font-size:14px;line-height:1.5}
.gc-task-row.is-sub{padding-left:36px}
.gc-task-subs{margin:0 0 4px 32px;border-left:2px solid color-mix(in srgb,var(--line) 80%,transparent);padding-left:4px}
.gc-task-actions{opacity:0}
.gc-task-row:hover .gc-task-actions,.gc-task-row.is-menu-open .gc-task-actions{opacity:1}
.gc-task-menu{position:absolute;z-index:50;min-width:220px;padding:6px 0;border-radius:10px;border:1px solid var(--line);
  background:var(--panel);box-shadow:0 6px 24px rgba(0,0,0,.18);right:8px;top:36px}
.gc-task-menu button{display:flex;align-items:center;gap:12px;width:100%;padding:9px 16px;border:0;background:none;cursor:pointer;
  text-align:left;font:inherit;font-size:14px;color:var(--ink)}
.gc-task-menu button:hover{background:var(--sel)}
.gc-task-menu button svg{width:18px;height:18px;flex:none;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.gc-task-menu hr{border:0;border-top:1px solid var(--line);margin:6px 0}
.gc-task-row{position:relative}
.gc-task-chip.is-created{border-style:dashed}
.gc-task-attach{font-size:12px;color:var(--mute);display:flex;align-items:center;gap:4px;margin-top:4px}
.gc-task-attach svg{width:12px;height:12px;fill:none;stroke:currentColor;stroke-width:2}
.gc-task-due-edit{display:flex;align-items:center;gap:8px;padding:8px 12px;margin:4px 0 8px 32px;border:1px solid var(--line);border-radius:8px;background:var(--panel)}
.gc-task-due-edit input[type="date"]{border:1px solid var(--line);border-radius:6px;background:var(--bg);color:var(--ink);font:inherit;font-size:13px;padding:4px 8px}
.gc-task-sub-composer{display:flex;align-items:center;gap:8px;padding:6px 8px;margin:0 0 8px 36px}
.gc-task-sub-composer input{flex:1;border:0;border-bottom:1px solid var(--line);background:transparent;color:var(--ink);font:inherit;font-size:13px;padding:4px 0;outline:none}
.gc-task-sub-composer input:focus{border-bottom-color:var(--acc)}
.cal-app.is-narrow .gc-tasks-nav{width:200px}
@media (max-width:700px){
  .gc-tasks-nav{width:100%;border-right:0;border-bottom:1px solid var(--line);max-height:40%;}
  .gc-tasks-app{flex-direction:column}
}
`;
function ensureCss() {
  if (document.getElementById('lc-cal-gc-css')) return;
  const st = document.createElement('style');
  st.id = 'lc-cal-gc-css';
  st.textContent = LIT_CSS + '\n' + GC_CSS;
  document.head.append(st);
}

const movableCache = {};
// Beweeglijke vieringen van een jaar, afgeleid van Pasen (dagen-regels uit de kalender).
function movableOf(y) {
  if (movableCache[y] && movableCache[y].lit === LIT) return movableCache[y].map;
  const map = {};
  const put = (d, it) => { (map[mmdd(d)] = map[mmdd(d)] || []).push(it); };
  const E = easterOf(y);
  const rel = (n, it) => put(addDays(E, n), it);
  rel(-63, { t: 'Septuagesima', tm: 1, n: 'De 3e zondag vóór Aswoensdag (9 weken vóór Pasen). Begin van de boetevoorbereiding in de Tridentijnse kalender.' });
  rel(-56, { t: 'Sexagesima', tm: 1, n: 'De 2e zondag vóór Aswoensdag.' });
  rel(-49, { t: 'Quinquagesima', tm: 1, n: 'De zondag vóór Aswoensdag.' });
  rel(-46, { t: 'Aswoensdag', v: 1, e: 1, n: '46 dagen vóór Pasen.' });
  [-39, -37, -36].forEach(n => rel(n, { t: 'Lentekwaterdagen', tm: 1, v: 1, n: 'Woensdag, vrijdag en zaterdag na Aswoensdag: drie dagen van vasten en gebed bij het begin van de lente.' }));
  rel(-14, { t: 'Passiezondag', tm: 1 });
  rel(-9, { t: 'Zeven Smarten van Maria', tm: 1, n: 'Vrijdag na Passiezondag, twee weken vóór Pasen.' });
  rel(-7, { t: 'Palmzondag', e: 1, n: '7 dagen vóór Pasen.' });
  rel(-3, { t: 'Witte Donderdag', e: 1, n: '3 dagen vóór Pasen.' });
  rel(-2, { t: 'Goede Vrijdag', e: 1, v: 1, n: '2 dagen vóór Pasen.' });
  rel(-1, { t: 'Paaszaterdag', e: 1, n: '1 dag vóór Pasen.' });
  rel(0, { t: 'Pasen', r: 'h', n: 'Paasdatum ' + y + ': ' + E.getDate() + ' ' + MONTHS[E.getMonth()] + '.' });
  rel(7, { t: 'Beloken Pasen', e: 1, n: '2e zondag van Pasen.' });
  [36, 37, 38].forEach(n => rel(n, { t: 'Smeekdagen (Rogationdagen)', tm: 1, v: 1, n: 'Maandag, dinsdag en woensdag vóór Hemelvaart. Processies en gebed voor de oogst en het land.' }));
  rel(39, { t: 'Hemelvaart', r: 'h', n: 'Donderdag, 40 dagen na Pasen (Pasen meegeteld).' });
  rel(49, { t: 'Pinksteren', r: 'h', n: '50 dagen na Pasen (Pasen meegeteld).' });
  [52, 54, 55].forEach(n => rel(n, { t: 'Zomerkwaterdagen', tm: 1, v: 1, n: 'Woensdag, vrijdag en zaterdag na Pinksteren: vasten en gebed bij het begin van de zomer.' }));
  rel(56, { t: 'Heilige Drie-eenheid', r: 'h' });
  rel(60, { t: 'Sacramentsdag', r: 'h' });
  rel(68, { t: 'Heilig Hart van Jezus', r: 'h' });
  rel(69, { t: 'Onbevlekt Hart van Maria', r: 'g' });

  // Openbaring des Heren: zondag van 2 t/m 8 januari; Doop van de Heer daarna (of de maandag erna)
  const epi = addDays(new Date(y, 0, 2), (7 - new Date(y, 0, 2).getDay()) % 7);
  put(epi.getDate() >= 7 ? addDays(epi, 1) : addDays(epi, 7), { t: 'Doop van de Heer', r: 'f', n: 'Zondag na de Openbaring des Heren; valt die zondag op 7 of 8 januari, dan wordt het feest naar de maandag erna verplaatst.' });
  // Heilige Familie: zondag in het octaaf van Kerstmis, anders 30 december
  let fam = null;
  for (let d = 26; d <= 31; d++) { const x = new Date(y, 11, d); if (x.getDay() === 0) fam = x; }
  put(fam || new Date(y, 11, 30), { t: 'H. Familie, Jezus, Maria en Jozef', r: 'f', n: 'Zondag onder het octaaf van Kerstmis, of als deze ontbreekt op 30 december.' });
  // Advent en Christus Koning
  const adv1 = addDays(sundayOnOrBefore(new Date(y, 11, 24)), -21);
  put(adv1, { t: 'Eerste zondag van de Advent', e: 1, n: 'Begin van het kerkelijk jaar; de zondag tussen 27 november en 3 december.' });
  put(addDays(adv1, -7), { t: 'Christus, Koning van het heelal', r: 'h', n: 'Laatste zondag van het kerkelijk jaar.' });
  const lastOct = sundayOnOrBefore(new Date(y, 9, 31));
  put(lastOct, { t: 'Christus Koning', tm: 1, n: 'In de Tridentijnse kalender gevierd op de laatste zondag van oktober.' });
  const wint = addDays(adv1, 14);
  [3, 5, 6].forEach(n => put(addDays(wint, n), { t: 'Winterkwaterdagen', tm: 1, v: 1, n: 'Woensdag, vrijdag en zaterdag na de derde zondag van de Advent.' }));
  const herf = firstWeekdayAfter(new Date(y, 8, 14), 3);
  [0, 2, 3].forEach(n => put(addDays(herf, n), { t: 'Herfstkwaterdagen', tm: 1, v: 1, n: 'Woensdag, vrijdag en zaterdag na de Kruisverheffing (14 september).' }));
  // Eigen vieringen volgens een weekdag-regel
  put(firstWeekdayAfter(new Date(y, 2, 12), 3), { t: 'Mirakel van H. Sacrament te Amsterdam', reg: 'Haarlem' });
  put(firstWeekdayAfter(new Date(y, 4, 2), 1), { t: 'H. Bloed van onze Heer Jezus Christus', reg: 'Brugge', r: 'f', n: 'Brugse stadsfeest van de Heilig-Bloedprocessie, maandag na 2 mei.' });
  let lz = new Date(y, 4, 31); while (lz.getDay() !== 6) lz = addDays(lz, -1);
  put(lz, { t: 'Onze Lieve Vrouw ter Nood', reg: 'Haarlem', r: 'g' });
  movableCache[y] = { lit: LIT, map };
  return map;
}

function regOk(reg, bis) {
  if (!reg || bis === 'alle') return true;
  if (bis === 'alg') return false;
  if (reg.includes(bis)) return true;
  if (BELG.includes(bis)) return /Belg\. [Kk]erkprovincie|Vlaamse bisdommen/.test(reg);
  return /Ned\. [Kk]erkprovincie/.test(reg);
}
function litRank(it) { return it.r === 'h' ? 4 : it.e ? 3.5 : it.r === 'f' ? 3 : it.r === 'g' ? 2 : 1; }
// Alle zichtbare vieringen van een dag, hoogste rang eerst.
function litDay(y, m, d, prefs) {
  if (!LIT || !prefs.on) return [];
  const k = String(m + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
  const base = ((LIT.dagen[k] || {}).i || []).concat(movableOf(y)[k] || []);
  return base.filter(it => (prefs.tm || !it.tm) && regOk(it.reg, prefs.bis))
    .map((it, i) => ({ it, i })).sort((a, b) => litRank(b.it) - litRank(a.it) || a.i - b.i).map(x => x.it);
}


// ---------- Rozenkrans-mysteriën (welke set op welke dag) ----------
const ROSARY_SETS = [
  {
    id: 'blij',
    t: 'Blijde mysteriën',
    list: [
      'De boodschap van de engel aan Maria',
      'Maria bezoekt Elisabeth',
      'De geboorte van Jezus',
      'Jezus wordt opgedragen in de tempel',
      'Jezus wordt teruggevonden in de tempel'
    ]
  },
  {
    id: 'licht',
    t: 'Lichtende mysteriën',
    list: [
      'De doop van Jezus in de Jordaan',
      'De bruiloft van Kana',
      'De verkondiging van het Rijk Gods',
      'De gedaanteverandering op de berg Tabor',
      'De instelling van de Eucharistie'
    ]
  },
  {
    id: 'pijn',
    t: 'Pijnlijke mysteriën',
    list: [
      'Jezus’ doodsangst in de Hof van Olijven',
      'De geseling van Jezus',
      'De doornenkroning',
      'Jezus draagt het kruis',
      'De kruisiging en dood van Jezus'
    ]
  },
  {
    id: 'glorie',
    t: 'Glorievolle mysteriën',
    list: [
      'De verrijzenis van Jezus',
      'De hemelvaart van Jezus',
      'De nederdaling van de Heilige Geest',
      'Maria’s tenhemelopneming',
      'Maria’s kroning in de hemel'
    ]
  }
];
// zo..za → index in ROSARY_SETS (standaard)
const ROSARY_BY_DOW = [3, 0, 2, 3, 1, 2, 0];

function firstAdventSunday(y) {
  // Eerste zondag van de advent: zondag tussen 27 nov en 3 dec
  const start = new Date(y, 10, 27);
  return addDays(start, (7 - start.getDay()) % 7);
}

/** 'advent' | 'christmas' | 'lent' | 'easter' | 'ordinary' */
function liturgicalSeason(d) {
  const y = d.getFullYear();
  const day = startOfDay(d);
  const E = easterOf(y);
  const ash = addDays(E, -46);
  const holySat = addDays(E, -1);
  const pentecost = addDays(E, 49);
  if (day >= ash && day <= holySat) return 'lent';
  if (day >= E && day <= pentecost) return 'easter';
  const adv1 = firstAdventSunday(y);
  const christmas = new Date(y, 11, 25);
  if (day >= adv1 && day < christmas) return 'advent';
  // Kersttijd: 25 dec t/m doop van de Heer (zondag na 6 jan, of 6–13 jan)
  if (day >= christmas) {
    const nextY = y + 1;
    const epi = new Date(nextY, 0, 6);
    // doop: zondag na 6 jan als 6 jan geen zondag is, anders 6 of 7–13
    let baptism = epi;
    if (epi.getDay() !== 0) baptism = addDays(epi, (7 - epi.getDay()) % 7);
    // eenvoud: tot en met 13 januari van volgend jaar
    const endXmas = new Date(nextY, 0, 13);
    if (day <= endXmas) return 'christmas';
  }
  // jan 1–13 kan kersttijd zijn van vorig jaar
  if (day.getMonth() === 0 && day.getDate() <= 13) return 'christmas';
  return 'ordinary';
}

function rosaryForDate(d) {
  const wd = d.getDay();
  let idx = ROSARY_BY_DOW[wd];
  if (wd === 0) {
    const season = liturgicalSeason(d);
    if (season === 'advent' || season === 'christmas') idx = 0;
    else if (season === 'lent') idx = 2;
    else idx = 3;
  }
  const set = ROSARY_SETS[idx];
  const season = liturgicalSeason(d);
  let note = set.list.join(' · ');
  if (wd === 0) {
    if (season === 'advent' || season === 'christmas') {
      note = 'Zondag in advent/kersttijd: blijde mysteriën. ' + note;
    } else if (season === 'lent') {
      note = 'Zondag in de vastentijd: pijnlijke mysteriën. ' + note;
    } else {
      note = 'Zondag: glorievolle mysteriën. ' + note;
    }
  }
  return { t: set.t, n: note, id: set.id, list: set.list.slice(), season };
}

async function loadRosPrefs() {
  try {
    const fromMem = await FileMem.read(MEM_ROS);
    if (fromMem && typeof fromMem === 'object') {
      return Object.assign({ on: true }, fromMem);
    }
  } catch (_) {}
  return { on: true };
}
async function saveRosPrefs(p) {
  try { await FileMem.write(MEM_ROS, p); } catch (e) { console.warn(e); }
}

export function createCalendarApp() {
  ensureCss();
  const root = document.createElement('div');
  root.className = 'app-panel cal-app gc';

  let events = [];
  let todoStore = emptyTodoStore();           // { lists, tasks } — Google Agenda Taken
  let prefs = { on: true, bis: 'alle', tm: true };
  let rosPrefs = { on: true };
  const ui = { view: 'week', mine: true };
  let ready = false;
  ui.mine = true;                             // afspraken zijn altijd zichtbaar
  if (!['day', 'week', 'month'].includes(ui.view)) ui.view = 'week';
  let cur = startOfDay(new Date());           // de datum waarop de weergave gericht is
  let miniMonth = new Date(cur.getFullYear(), cur.getMonth(), 1);
  let mode = 'cal';                           // 'cal' | 'tasks' | 'libs'
  let taskFilter = { type: 'list', id: 'default' }; // 'all' | 'starred' | { type:'list', id }
  let taskComposerOpen = false;
  let draft = null;                           // voorlopig blok tijdens het maken van een afspraak
  let narrow = false, sideOpen = true, sideInit = false;
  let popEl = null, modalEl = null;
  let allExpanded = false;                    // hele-dag-rij uitgeklapt
  let scrollMem = null, scroller = null, pendingScroll = false;
  let suppressClick = false;
  let seenConnected = false;
  let timer = 0;
  const save = () => { saveEvents(events); };
  const saveTodoList = () => { saveTodos(todoStore); };

  // ---------- Bovenbalk ----------
  const top = el('div', 'cal-toolbar gc-top');
  const menuBtn = ibtn('menu', 'Zijbalk tonen of verbergen');
  const brand = el('div', 'gc-brand');
  const logo = el('button', 'gc-logo'); logo.type = 'button'; logo.title = 'Naar vandaag'; logo.setAttribute('aria-label', 'Naar vandaag');
  brand.append(logo, el('span', 'gc-brand-text', 'Agenda'));
  const todayBtn = el('button', 'gc-pill gc-today-pill', 'Vandaag'); todayBtn.type = 'button';
  const prev = ibtn('chevL', 'Vorige');
  const next = ibtn('chevR', 'Volgende');
  const title = el('h2', 'gc-title');
  const viewBtn = el('button', 'gc-pill gc-viewbtn'); viewBtn.type = 'button';
  viewBtn.setAttribute('aria-haspopup', 'true'); viewBtn.setAttribute('aria-expanded', 'false');
  const viewMenu = el('div', 'gc-menu'); viewMenu.hidden = true; viewMenu.setAttribute('role', 'menu');
  const viewWrap = el('div', 'gc-viewwrap'); viewWrap.append(viewBtn, viewMenu);
  // Agenda | Taken schakelaar (zoals Google)
  const seg = el('div', 'gc-seg');
  const segCal = el('button'); segCal.type = 'button'; segCal.title = 'Agenda'; segCal.setAttribute('aria-label', 'Agenda');
  segCal.append(icon('cal'));
  const segTasks = el('button'); segTasks.type = 'button'; segTasks.title = 'Taken'; segTasks.setAttribute('aria-label', 'Taken');
  segTasks.append(icon('checkCircle'));
  seg.append(segCal, segTasks);
  const libsBtn = el('button', 'gc-pill'); libsBtn.type = 'button';
  libsBtn.append(icon('cal'), el('span', 'gc-lbl', 'Bibliotheken'));
  libsBtn.title = 'Kalenderbibliotheken beheren';
  libsBtn.setAttribute('aria-label', 'Kalenderbibliotheken beheren');
  libsBtn.setAttribute('aria-expanded', 'false');
  top.append(menuBtn, brand, todayBtn, prev, next, title, el('div', 'gc-spacer'), viewWrap, seg, libsBtn);

  // ---------- Zijbalk (alleen agenda) ----------
  const side = el('aside', 'gc-side');
  const createBtn = el('button', 'gc-create'); createBtn.type = 'button';
  createBtn.append(icon('plus'), el('span', '', 'Maken'));
  const mini = el('div', 'gc-mini');
  side.append(createBtn, mini);
  const scrim = el('div', 'gc-scrim');
  const viewEl = el('section', 'gc-view');
  const main = el('div', 'gc-main');
  main.append(side, viewEl, scrim);

  // Takenweergave (volledig paneel, zoals Google)
  const tasksApp = el('div', 'gc-tasks-app');
  tasksApp.setAttribute('aria-label', 'Taken');

  // Overlay: kalenderbibliotheken aan/uit (vóór de agenda)
  const libsPanel = document.createElement('div');
  libsPanel.className = 'cal-libs-overlay';
  libsPanel.setAttribute('role', 'dialog');
  libsPanel.setAttribute('aria-label', 'Kalenderbibliotheken');

  root.append(top, main, tasksApp, libsPanel);

  // ---------- Navigatie ----------
  const nDays = () => ui.view === 'day' ? 1 : ui.view === 'week' ? (narrow ? 3 : 7) : 0;
  const rangeStart = () => ui.view === 'week' && !narrow ? mondayOf(cur) : cur;

  function go(d) {
    cur = startOfDay(d);
    miniMonth = new Date(cur.getFullYear(), cur.getMonth(), 1);
    render();
  }
  function goToday() { scrollMem = null; go(new Date()); }
  function step(dir) {
    if (ui.view === 'month') {
      const first = new Date(cur.getFullYear(), cur.getMonth() + dir, 1);
      const dim = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
      go(new Date(first.getFullYear(), first.getMonth(), Math.min(cur.getDate(), dim)));
    } else go(addDays(cur, dir * nDays()));
  }
  function setView(v) {
    ui.view = v; saveUi(ui);
    viewMenu.hidden = true; viewBtn.setAttribute('aria-expanded', 'false');
    render();
  }
  const VIEWS = [['day', 'Dag', 'D'], ['week', 'Week', 'W'], ['month', 'Maand', 'M']];

  function renderViewMenu() {
    viewMenu.replaceChildren();
    VIEWS.forEach(([v, label, key]) => {
      const b = el('button'); b.type = 'button'; b.setAttribute('role', 'menuitemradio');
      b.setAttribute('aria-checked', ui.view === v ? 'true' : 'false');
      const chk = el('span', 'gc-chk'); if (ui.view === v) chk.append(icon('check'));
      b.append(chk, el('span', '', label), el('span', 'gc-key', key));
      b.onclick = () => setView(v);
      viewMenu.append(b);
    });
    const cur_ = VIEWS.find(x => x[0] === ui.view);
    viewBtn.replaceChildren(el('span', 'gc-vlabel', cur_[1]), icon('caret'));
  }

  function titleText() {
    const y = cur.getFullYear(), m = cur.getMonth();
    if (ui.view === 'month') return MONTHS[m] + ' ' + y;
    if (ui.view === 'day') return cur.getDate() + ' ' + MONTHS[m] + ' ' + y;
    const s = rangeStart(), e = addDays(s, nDays() - 1);
    if (s.getMonth() === e.getMonth() && s.getFullYear() === e.getFullYear()) return MONTHS[s.getMonth()] + ' ' + s.getFullYear();
    if (s.getFullYear() === e.getFullYear()) return MONTHS_S[s.getMonth()] + ' – ' + MONTHS_S[e.getMonth()] + ' ' + s.getFullYear();
    return MONTHS_S[s.getMonth()] + ' ' + s.getFullYear() + ' – ' + MONTHS_S[e.getMonth()] + ' ' + e.getFullYear();
  }

  // ---------- Gegevens per dag ----------
  function dayItems(d) {
    const k = keyOf(d);
    const evs = ui.mine ? events.filter(e => e.date <= k && k <= (e.allDay && e.endDate ? e.endDate : e.date)) : [];
    const lit = prefs.on ? litDay(d.getFullYear(), d.getMonth(), d.getDate(), prefs) : [];
    const ros = rosPrefs.on ? [rosaryForDate(d)] : [];
    return {
      lit,
      ros,
      all: evs.filter(e => e.allDay),
      timed: evs.filter(e => !e.allDay).sort((a, b) => a.start - b.start),
    };
  }
  const pickLit = lit => (prefs.bis === 'alle' && lit.find(x => !x.reg)) || lit[0];
  const rankCls = it => (it.r === 'h' ? ' r-h' : it.e ? ' r-e' : it.r === 'f' ? ' r-f' : '') + (it.tm ? ' is-tm' : '');

  function whenText(ev) {
    const d = parseKey(ev.date);
    if (ev.allDay) {
      if (ev.endDate && ev.endDate > ev.date) return longDate(d) + ' – ' + longDate(parseKey(ev.endDate));
      return longDate(d);
    }
    return longDate(d) + ' ⋅ ' + fmtT(ev.start) + ' – ' + fmtT(ev.end);
  }

  // ---------- Minikalender en agenda-lijst ----------
  function renderMini() {
    mini.replaceChildren();
    const head = el('div', 'gc-mini-head');
    const mp = ibtn('chevL', 'Vorige maand'), mn = ibtn('chevR', 'Volgende maand');
    mp.onclick = () => { miniMonth = new Date(miniMonth.getFullYear(), miniMonth.getMonth() - 1, 1); renderMini(); };
    mn.onclick = () => { miniMonth = new Date(miniMonth.getFullYear(), miniMonth.getMonth() + 1, 1); renderMini(); };
    head.append(el('span', 'gc-mini-title', MONTHS[miniMonth.getMonth()] + ' ' + miniMonth.getFullYear()), mp, mn);
    const grid = el('div', 'gc-mini-grid');
    MINI_DOW.forEach(d => grid.append(el('div', 'gc-mini-dow', d)));
    const first = new Date(miniMonth.getFullYear(), miniMonth.getMonth(), 1);
    const gs = mondayOf(first);
    const todayK = keyOf(new Date()), curK = keyOf(cur);
    let rs = null, re = null;
    if (ui.view === 'week') { rs = keyOf(rangeStart()); re = keyOf(addDays(rangeStart(), nDays() - 1)); }
    for (let i = 0; i < 42; i++) {
      const d = addDays(gs, i), k = keyOf(d);
      if (i >= 35 && d.getMonth() !== miniMonth.getMonth()) break;
      const b = el('button', 'gc-mini-day'); b.type = 'button';
      b.append(el('span', '', String(d.getDate())));
      if (d.getMonth() !== miniMonth.getMonth()) b.classList.add('is-out');
      if (k === todayK) b.classList.add('is-today');
      if (k === curK && ui.view !== 'week') b.classList.add('is-sel');
      if (rs && k >= rs && k <= re) {
        b.classList.add('in-range');
        if (k === rs) b.classList.add('is-first');
        if (k === re) b.classList.add('is-last');
      }
      b.setAttribute('aria-label', longDate(d));
      b.onclick = () => { go(d); if (narrow) { sideOpen = false; applySide(); } };
      grid.append(b);
    }
    mini.append(head, grid);
  }

  // ---------- Taken (Google Agenda-stijl) ----------
  let openTaskMenuId = null;
  let openListMenuId = null;
  let dueEditId = null;
  let subComposerId = null;

  function createdLabel(ts) {
    if (!ts) return null;
    const d = startOfDay(new Date(ts));
    const today = startOfDay(new Date());
    const diff = Math.round((today - d) / 86400000);
    if (diff === 0) return 'Vandaag aangemaakt';
    if (diff === 1) return 'Gisteren aangemaakt';
    if (diff < 7) return diff + ' dagen geleden aangemaakt';
    if (diff < 14) return '1 week geleden aangemaakt';
    if (diff < 60) return Math.floor(diff / 7) + ' weken geleden aangemaakt';
    return d.getDate() + ' ' + MONTHS_S[d.getMonth()] + ' ' + d.getFullYear();
  }
  function dueLabel(due) {
    if (!due) return null;
    const d = parseKey(due);
    const today = startOfDay(new Date());
    const diff = Math.round((d - today) / 86400000);
    const abs = Math.abs(diff);
    let txt;
    if (diff === 0) txt = 'Vandaag';
    else if (diff === 1) txt = 'Morgen';
    else if (diff === -1) txt = 'Gisteren';
    else if (diff < 0) {
      if (abs < 7) txt = 'Deadline was ' + abs + ' dagen geleden';
      else if (abs < 14) txt = 'Deadline was 1 week geleden';
      else txt = 'Deadline was ' + Math.floor(abs / 7) + ' weken geleden';
    } else if (diff < 7) txt = DOW_L[(d.getDay() + 6) % 7] + ' ' + d.getDate() + ' ' + MONTHS_S[d.getMonth()];
    else txt = d.getDate() + ' ' + MONTHS_S[d.getMonth()];
    return { text: txt, late: diff < 0 };
  }
  function relativeAge(due) {
    if (!due) return null;
    const d = parseKey(due);
    const today = startOfDay(new Date());
    const diff = Math.round((d - today) / 86400000);
    if (diff >= 0) return null;
    const abs = Math.abs(diff);
    if (abs < 7) return abs + ' dagen geleden';
    if (abs < 14) return '1 week geleden';
    return Math.floor(abs / 7) + ' weken geleden';
  }
  function topLevelTasks(list) {
    return list.filter(t => !t.parentId);
  }
  function subtasksOf(parentId) {
    return todoStore.tasks.filter(t => t.parentId === parentId)
      .sort((a, b) => (a.done === b.done ? 0 : a.done ? 1 : -1) || (a.created || 0) - (b.created || 0));
  }
  function filteredTasks() {
    let list = todoStore.tasks.slice();
    if (taskFilter.type === 'starred') list = list.filter(t => t.starred && !t.done);
    else if (taskFilter.type === 'list') list = list.filter(t => t.listId === taskFilter.id);
    return list;
  }
  function panelTitle() {
    if (taskFilter.type === 'all') return 'Alle taken';
    if (taskFilter.type === 'starred') return 'Met ster';
    const L = todoStore.lists.find(l => l.id === taskFilter.id);
    return (L && L.name) || 'Mijn taken';
  }
  function deleteTaskDeep(id) {
    const kids = todoStore.tasks.filter(t => t.parentId === id).map(t => t.id);
    kids.forEach(deleteTaskDeep);
    todoStore.tasks = todoStore.tasks.filter(x => x.id !== id);
  }
  function groupTasks(list) {
    const tops = topLevelTasks(list);
    const open = tops.filter(t => !t.done);
    const done = tops.filter(t => t.done);
    const late = [], upcoming = {}, nodue = [];
    open.forEach(t => {
      if (!t.due) { nodue.push(t); return; }
      const d = parseKey(t.due);
      const today = startOfDay(new Date());
      if (d < today) late.push(t);
      else {
        const k = t.due;
        (upcoming[k] = upcoming[k] || []).push(t);
      }
    });
    late.sort((a, b) => (a.due || '').localeCompare(b.due || '') || (b.created || 0) - (a.created || 0));
    nodue.sort((a, b) => (b.created || 0) - (a.created || 0));
    const groups = [];
    if (late.length) groups.push({ title: 'Te laat', late: true, items: late });
    Object.keys(upcoming).sort().forEach(k => {
      const d = parseKey(k);
      const today = startOfDay(new Date());
      const diff = Math.round((d - today) / 86400000);
      let title;
      if (diff === 0) title = 'Vandaag';
      else if (diff === 1) title = 'Morgen';
      else title = 'Deadline is ' + DOW_L[(d.getDay() + 6) % 7].slice(0, 2) + ' ' + d.getDate() + ' ' + MONTHS_S[d.getMonth()];
      groups.push({ title, late: false, items: upcoming[k] });
    });
    if (nodue.length) groups.push({ title: 'Geen deadline', late: false, items: nodue });
    if (done.length) groups.push({ title: 'Voltooid', late: false, items: done.sort((a, b) => (b.created || 0) - (a.created || 0)) });
    return groups;
  }
  function closeTaskMenus() {
    openTaskMenuId = null;
    openListMenuId = null;
    dueEditId = null;
    subComposerId = null;
  }
  /** In-app dialoog voor een nieuwe of hernoemde takenlijst (geen window.prompt).
   *  opts.existingName: huidige naam bij hernoemen. */
  function openListDialog(onDone, opts) {
    opts = opts || {};
    const isEdit = !!(opts.existingName);
    if (modalEl) { modalEl.remove(); modalEl = null; }
    const back = el('div', 'gc-modal');
    const dlg = el('div', 'gc-dialog');
    dlg.setAttribute('role', 'dialog');
    dlg.setAttribute('aria-label', isEdit ? 'Lijst hernoemen' : 'Nieuwe lijst');
    const topRow = el('div', 'gc-dialog-top');
    const x = ibtn('close', 'Sluiten');
    x.onclick = () => { back.remove(); if (modalEl === back) modalEl = null; };
    topRow.append(x);
    const title = el('h3', '', isEdit ? 'Lijst hernoemen' : 'Nieuwe lijst');
    title.style.margin = '0 0 12px';
    title.style.fontWeight = '500';
    title.style.fontSize = '1.1rem';
    const nameIn = el('input', 'gc-title-in');
    nameIn.type = 'text';
    nameIn.maxLength = 80;
    nameIn.placeholder = 'Naam van de lijst';
    nameIn.value = isEdit ? opts.existingName : 'Nieuwe lijst';
    nameIn.setAttribute('aria-label', 'Naam van de lijst');
    const actions = el('div', 'gc-dialog-actions');
    actions.style.display = 'flex';
    actions.style.justifyContent = 'flex-end';
    actions.style.gap = '8px';
    actions.style.marginTop = '16px';
    const cancel = el('button', 'gc-btn', 'Annuleren'); cancel.type = 'button';
    const ok = el('button', 'gc-btn is-primary', isEdit ? 'Opslaan' : 'Maken'); ok.type = 'button';
    const finish = (okCreate) => {
      const name = (nameIn.value || '').trim();
      back.remove();
      if (modalEl === back) modalEl = null;
      if (okCreate && name && typeof onDone === 'function') onDone(name);
    };
    cancel.onclick = () => finish(false);
    ok.onclick = () => finish(true);
    nameIn.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      if (e.key === 'Escape') { e.preventDefault(); finish(false); }
    });
    actions.append(cancel, ok);
    dlg.append(topRow, title, nameIn, actions);
    back.append(dlg);
    back.addEventListener('pointerdown', e => { if (e.target === back) finish(false); });
    root.append(back);
    modalEl = back;
    requestAnimationFrame(() => {
      try { nameIn.focus(); nameIn.select(); } catch (_) {}
    });
  }
  function renderListMenu(L) {
    const menu = el('div', 'gc-task-menu gc-list-menu');
    menu.setAttribute('role', 'menu');
    const item = (ico, label, fn) => {
      const b = el('button'); b.type = 'button'; b.setAttribute('role', 'menuitem');
      b.append(icon(ico), el('span', '', label));
      b.onclick = e => { e.stopPropagation(); closeTaskMenus(); fn(); };
      return b;
    };
    menu.append(
      item('pencil', 'Hernoemen', () => {
        openListDialog(name => {
          L.name = name;
          saveTodoList();
          renderTasks();
        }, { existingName: L.name });
      })
    );
    // Verwijderen alleen als er meer dan één lijst is
    if (todoStore.lists.length > 1) {
      menu.append(item('trash', 'Verwijderen', () => {
        const fallback = todoStore.lists.find(x => x.id !== L.id);
        // Verplaats taken naar de eerste andere lijst
        todoStore.tasks.forEach(t => {
          if (t.listId === L.id) t.listId = fallback.id;
        });
        todoStore.lists = todoStore.lists.filter(x => x.id !== L.id);
        if (taskFilter.type === 'list' && taskFilter.id === L.id) {
          taskFilter = { type: 'list', id: fallback.id };
        }
        saveTodoList();
        renderTasks();
      }));
    }
    return menu;
  }
  function renderTaskMenu(t) {
    const menu = el('div', 'gc-task-menu');
    menu.setAttribute('role', 'menu');
    const item = (ico, label, fn) => {
      const b = el('button'); b.type = 'button'; b.setAttribute('role', 'menuitem');
      b.append(icon(ico), el('span', '', label));
      b.onclick = e => { e.stopPropagation(); closeTaskMenus(); fn(); };
      return b;
    };
    menu.append(
      item('deadline', 'Deadline bewerken', () => { dueEditId = t.id; renderTasks(); }),
      item('subtask', 'Subtaak toevoegen', () => { subComposerId = t.id; renderTasks(); }),
      item('attach', 'Bijlage toevoegen', () => {
        const inp = document.createElement('input');
        inp.type = 'file';
        inp.multiple = true;
        inp.onchange = () => {
          const files = Array.from(inp.files || []);
          if (!files.length) return;
          if (!Array.isArray(t.attachments)) t.attachments = [];
          files.forEach(f => {
            t.attachments.push({ id: uid(), name: f.name, size: f.size || 0, mime: f.type || '' });
          });
          saveTodoList();
          renderTasks();
        };
        inp.click();
      }),
      item('trash', 'Verwijderen', () => {
        deleteTaskDeep(t.id);
        saveTodoList();
        renderTasks();
      })
    );
    menu.append(document.createElement('hr'));
    todoStore.lists.forEach(L => {
      menu.append(item('check', L.name, () => {
        t.listId = L.id;
        subtasksOf(t.id).forEach(s => { s.listId = L.id; });
        saveTodoList();
        renderTasks();
      }));
    });
    menu.append(item('list', 'Nieuwe lijst', () => {
      openListDialog(name => {
        const id = uid();
        todoStore.lists.push({ id, name });
        t.listId = id;
        subtasksOf(t.id).forEach(s => { s.listId = id; });
        saveTodoList();
        renderTasks();
      });
    }));
    return menu;
  }
  function renderTaskRow(t, isSub) {
    const row = el('div', 'gc-task-row' + (t.done ? ' is-done' : '') + (isSub ? ' is-sub' : '') + (openTaskMenuId === t.id ? ' is-menu-open' : ''));
    const cb = el('button', 'gc-task-cb');
    cb.type = 'button';
    cb.title = t.done ? 'Markeer als open' : 'Markeer als voltooid';
    cb.setAttribute('aria-label', cb.title);
    cb.append(icon('check'));
    cb.onclick = () => {
      t.done = !t.done;
      if (t.done) subtasksOf(t.id).forEach(s => { s.done = true; });
      saveTodoList();
      renderTasks();
    };
    const main_ = el('div', 'gc-task-main');
    main_.append(el('div', 'gc-task-title', t.text || ''));
    const meta = el('div', 'gc-task-meta');
    const cl = createdLabel(t.created);
    if (cl) {
      const chip = el('span', 'gc-task-chip is-created');
      chip.append(icon('clock'), document.createTextNode(' ' + cl));
      chip.title = t.created ? new Date(t.created).toLocaleString('nl-BE') : '';
      meta.append(chip);
    }
    const age = relativeAge(t.due);
    if (age && !t.done) {
      const chip = el('span', 'gc-task-chip');
      chip.append(icon('clock'), document.createTextNode(' ' + age));
      meta.append(chip);
    }
    const dl = dueLabel(t.due);
    if (dl) {
      const chip = el('span', 'gc-task-chip' + (dl.late && !t.done ? ' is-late' : ''));
      chip.append(icon('deadline'), document.createTextNode(' ' + dl.text));
      meta.append(chip);
    }
    if (meta.childNodes.length) main_.append(meta);
    if (t.attachments && t.attachments.length) {
      t.attachments.forEach(a => {
        const att = el('div', 'gc-task-attach');
        att.append(icon('attach'), document.createTextNode(a.name || 'Bijlage'));
        main_.append(att);
      });
    }
    const actions = el('div', 'gc-task-actions');
    const starBtn = el('button'); starBtn.type = 'button';
    starBtn.title = t.starred ? 'Ster verwijderen' : 'Ster toevoegen';
    starBtn.className = t.starred ? 'is-star' : '';
    starBtn.append(icon(t.starred ? 'starFill' : 'star'));
    starBtn.onclick = e => { e.stopPropagation(); t.starred = !t.starred; saveTodoList(); renderTasks(); };
    const moreBtn = el('button'); moreBtn.type = 'button'; moreBtn.title = 'Meer acties';
    moreBtn.append(icon('more'));
    moreBtn.onclick = e => {
      e.stopPropagation();
      openTaskMenuId = openTaskMenuId === t.id ? null : t.id;
      dueEditId = null;
      subComposerId = null;
      renderTasks();
    };
    actions.append(starBtn, moreBtn);
    row.append(cb, main_, actions);
    if (openTaskMenuId === t.id) row.append(renderTaskMenu(t));
    return row;
  }
  function renderTaskBlock(t, panel) {
    panel.append(renderTaskRow(t, false));
    if (dueEditId === t.id) {
      const box = el('div', 'gc-task-due-edit');
      const lab = el('span', '', 'Deadline:');
      const dueIn = el('input'); dueIn.type = 'date'; dueIn.value = t.due || '';
      const ok = el('button', 'gc-btn is-primary', 'Opslaan'); ok.type = 'button';
      const clear = el('button', 'gc-btn', 'Wissen'); clear.type = 'button';
      const cancel = el('button', 'gc-btn', 'Annuleren'); cancel.type = 'button';
      ok.onclick = () => { t.due = dueIn.value || null; dueEditId = null; saveTodoList(); renderTasks(); };
      clear.onclick = () => { t.due = null; dueEditId = null; saveTodoList(); renderTasks(); };
      cancel.onclick = () => { dueEditId = null; renderTasks(); };
      box.append(lab, dueIn, ok, clear, cancel);
      panel.append(box);
    }
    const kids = subtasksOf(t.id);
    if (kids.length) {
      const wrap = el('div', 'gc-task-subs');
      kids.forEach(s => wrap.append(renderTaskRow(s, true)));
      panel.append(wrap);
    }
    if (subComposerId === t.id) {
      const box = el('div', 'gc-task-sub-composer');
      const inp = el('input'); inp.type = 'text'; inp.placeholder = 'Subtaak toevoegen'; inp.maxLength = 500;
      const add = el('button', 'gc-btn is-primary', 'Toevoegen'); add.type = 'button';
      const cancel = el('button', 'gc-btn', 'Annuleren'); cancel.type = 'button';
      const commit = () => {
        const text = (inp.value || '').trim();
        if (!text) return;
        todoStore.tasks.push({
          id: uid(), listId: t.listId, text, done: false, starred: false,
          due: null, created: Date.now(), parentId: t.id, attachments: []
        });
        subComposerId = null;
        saveTodoList();
        renderTasks();
      };
      add.onclick = commit;
      cancel.onclick = () => { subComposerId = null; renderTasks(); };
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); commit(); } });
      box.append(inp, add, cancel);
      panel.append(box);
      requestAnimationFrame(() => { try { inp.focus(); } catch (_) {} });
    }
  }
  function renderTasks() {
    tasksApp.replaceChildren();
    const nav = el('nav', 'gc-tasks-nav');
    const mkNav = (label, ico, on, count, fn) => {
      const b = el('button', 'gc-tasks-nav-item' + (on ? ' is-on' : ''));
      b.type = 'button';
      b.append(icon(ico), el('span', '', label));
      if (count != null && count > 0) b.append(el('span', 'gc-tasks-nav-count', String(count)));
      b.onclick = () => { closeTaskMenus(); fn(); };
      return b;
    };
    const openAll = todoStore.tasks.filter(t => !t.done && !t.parentId).length;
    const openStar = todoStore.tasks.filter(t => t.starred && !t.done).length;
    nav.append(
      mkNav('Alle taken', 'checkCircle', taskFilter.type === 'all', openAll, () => { taskFilter = { type: 'all' }; renderTasks(); }),
      mkNav('Met ster', 'star', taskFilter.type === 'starred', openStar, () => { taskFilter = { type: 'starred' }; renderTasks(); })
    );
    const sec = el('div', 'gc-tasks-nav-sec');
    sec.append(el('span', '', 'Lijsten'), icon('chevD'));
    nav.append(sec);
    todoStore.lists.forEach(L => {
      const c = todoStore.tasks.filter(t => t.listId === L.id && !t.done && !t.parentId).length;
      const isOn = taskFilter.type === 'list' && taskFilter.id === L.id;
      const row = el('div', 'gc-tasks-nav-item' + (isOn ? ' is-on' : '') + (openListMenuId === L.id ? ' is-menu-open' : ''));
      row.setAttribute('role', 'button');
      row.tabIndex = 0;
      row.append(icon('check'), el('span', 'gc-tasks-nav-label', L.name));
      if (c > 0) row.append(el('span', 'gc-tasks-nav-count', String(c)));
      const more = el('button', 'gc-list-more');
      more.type = 'button';
      more.title = 'Lijstopties';
      more.setAttribute('aria-label', 'Lijstopties');
      more.append(icon('more'));
      more.onclick = e => {
        e.stopPropagation();
        if (openListMenuId === L.id) { openListMenuId = null; renderTasks(); return; }
        closeTaskMenus();
        openListMenuId = L.id;
        renderTasks();
      };
      row.append(more);
      if (openListMenuId === L.id) {
        row.append(renderListMenu(L));
      }
      const select = () => {
        closeTaskMenus();
        taskFilter = { type: 'list', id: L.id };
        renderTasks();
      };
      row.onclick = e => {
        if (e.target.closest('.gc-list-more') || e.target.closest('.gc-list-menu')) return;
        select();
      };
      row.onkeydown = e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(); }
      };
      row.oncontextmenu = e => {
        e.preventDefault();
        closeTaskMenus();
        openListMenuId = L.id;
        renderTasks();
      };
      nav.append(row);
    });
    const addList = el('button', 'gc-tasks-nav-item gc-tasks-nav-add');
    addList.type = 'button';
    addList.append(icon('plus'), el('span', '', 'Nieuwe lijst maken'));
    addList.onclick = () => {
      openListDialog(name => {
        const id = uid();
        todoStore.lists.push({ id, name });
        taskFilter = { type: 'list', id };
        saveTodoList();
        renderTasks();
      });
    };
    nav.append(addList);

    const panel = el('div', 'gc-tasks-panel');
    const head = el('div', 'gc-tasks-panel-head');
    head.append(el('h2', '', panelTitle()));
    if (taskFilter.type === 'list') {
      const L = todoStore.lists.find(l => l.id === taskFilter.id);
      if (L) {
        const editBtn = el('button', 'gc-list-panel-edit');
        editBtn.type = 'button';
        editBtn.title = 'Lijst hernoemen';
        editBtn.setAttribute('aria-label', 'Lijst hernoemen');
        editBtn.append(icon('pencil'));
        editBtn.onclick = () => {
          openListDialog(name => {
            L.name = name;
            saveTodoList();
            renderTasks();
          }, { existingName: L.name });
        };
        head.append(editBtn);
        if (todoStore.lists.length > 1) {
          const delBtn = el('button', 'gc-list-panel-edit');
          delBtn.type = 'button';
          delBtn.title = 'Lijst verwijderen';
          delBtn.setAttribute('aria-label', 'Lijst verwijderen');
          delBtn.append(icon('trash'));
          delBtn.onclick = () => {
            const fallback = todoStore.lists.find(x => x.id !== L.id);
            todoStore.tasks.forEach(t => {
              if (t.listId === L.id) t.listId = fallback.id;
            });
            todoStore.lists = todoStore.lists.filter(x => x.id !== L.id);
            taskFilter = { type: 'list', id: fallback.id };
            saveTodoList();
            renderTasks();
          };
          head.append(delBtn);
        }
      }
    }
    panel.append(head);

    const addLink = el('button', 'gc-tasks-addlink');
    addLink.type = 'button';
    addLink.append(icon('plus'), el('span', '', 'Taak toevoegen'));
    addLink.onclick = () => { closeTaskMenus(); taskComposerOpen = true; renderTasks(); };
    panel.append(addLink);

    const composer = el('div', 'gc-tasks-composer' + (taskComposerOpen ? ' is-open' : ''));
    const textIn = el('input'); textIn.type = 'text'; textIn.placeholder = 'Taak toevoegen'; textIn.maxLength = 500;
    textIn.setAttribute('aria-label', 'Taaktitel');
    const row = el('div', 'gc-tasks-composer-row');
    const dueIn = el('input'); dueIn.type = 'date'; dueIn.title = 'Deadline'; dueIn.setAttribute('aria-label', 'Deadline');
    const saveBtn = el('button', 'gc-btn is-primary', 'Toevoegen'); saveBtn.type = 'button';
    const cancelBtn = el('button', 'gc-btn', 'Annuleren'); cancelBtn.type = 'button';
    const commit = () => {
      const text = (textIn.value || '').trim();
      if (!text) return;
      const listId = taskFilter.type === 'list' ? taskFilter.id : (todoStore.lists[0] && todoStore.lists[0].id) || 'default';
      todoStore.tasks.unshift({
        id: uid(), listId, text, done: false, starred: taskFilter.type === 'starred',
        due: dueIn.value || null, created: Date.now(), parentId: null, attachments: []
      });
      taskComposerOpen = false;
      saveTodoList();
      renderTasks();
    };
    saveBtn.onclick = commit;
    cancelBtn.onclick = () => { taskComposerOpen = false; renderTasks(); };
    textIn.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); commit(); } });
    row.append(el('span', '', 'Deadline'), dueIn, saveBtn, cancelBtn);
    composer.append(textIn, row);
    panel.append(composer);

    const groups = groupTasks(filteredTasks());
    if (!groups.length || groups.every(g => !g.items.length)) {
      panel.append(el('div', 'gc-tasks-empty', 'Nog geen taken. Klik op „Taak toevoegen” om te beginnen.'));
    } else {
      groups.forEach(g => {
        if (!g.items.length) return;
        if (g.title) {
          const h = el('div', 'gc-tasks-group' + (g.late ? ' is-late' : ''));
          h.textContent = g.title;
          panel.append(h);
        }
        g.items.forEach(t => renderTaskBlock(t, panel));
      });
    }

    tasksApp.append(nav, panel);
    if (taskComposerOpen) {
      requestAnimationFrame(() => { try { textIn.focus(); } catch (_) {} });
    }
  }
  function updateSeg() {
    segCal.classList.toggle('is-on', mode === 'cal' || mode === 'libs');
    segTasks.classList.toggle('is-on', mode === 'tasks');
    // Agenda-navigatie verbergen in takenmodus
    todayBtn.hidden = mode === 'tasks';
    prev.hidden = mode === 'tasks';
    next.hidden = mode === 'tasks';
    title.hidden = mode === 'tasks';
    viewWrap.hidden = mode === 'tasks';
    menuBtn.hidden = mode === 'tasks';
    brand.querySelector('.gc-brand-text').textContent = mode === 'tasks' ? 'Taken' : 'Agenda';
  }

  function getComputedAccent() {
    try { return getComputedStyle(root).getPropertyValue('--acc').trim() || '#7a1f2b'; } catch { return '#7a1f2b'; }
  }

  function applySide() { root.classList.toggle('side-open', sideOpen); }

  // ---------- Hoofdweergave ----------
  function render() {
    updateSeg();
    if (mode === 'tasks') {
      root.classList.add('is-tasks');
      root.classList.remove('is-libs');
      renderTasks();
      return;
    }
    root.classList.remove('is-tasks');
    if (mode !== 'cal') return;
    logo.textContent = String(new Date().getDate());
    title.textContent = titleText();
    renderViewMenu();
    renderMini();
    if (!pendingScroll && scroller && scroller.isConnected && scroller.clientHeight) scrollMem = scroller.scrollTop;
    viewEl.replaceChildren();
    scroller = null;
    if (ui.view === 'month') renderMonth(); else renderTime();
  }

  function gmtLabel() {
    const o = -new Date().getTimezoneOffset() / 60;
    return 'GMT' + (o >= 0 ? '+' : '−') + pad(Math.abs(Math.trunc(o)));
  }

  function evChip(ev) {
    const b = el('button', 'gc-chip'); b.type = 'button';
    b.style.background = ev.color || DEF_COLOR;
    b.style.color = textOn(ev.color || DEF_COLOR);
    b.textContent = ev.title || '(Geen titel)';
    b.title = ev.title || '(Geen titel)';
    b.onclick = e => { e.stopPropagation(); showEvPop(ev, b); };
    return b;
  }
  function litChip(it, d) {
    const b = el('button', 'gc-chip gc-litchip' + rankCls(it)); b.type = 'button';
    b.textContent = (it.reg ? it.reg + ': ' : '') + it.t;
    b.title = b.textContent;
    b.onclick = e => { e.stopPropagation(); showLitPop(d, b); };
    return b;
  }
  function rosaryChip(it, d) {
    const b = el('button', 'gc-chip gc-rosarychip'); b.type = 'button';
    b.textContent = '🕊 ' + it.t;
    b.title = it.n || it.t;
    b.onclick = e => { e.stopPropagation(); showRosaryPop(d, it, b); };
    return b;
  }
  function monthTimedChip(ev) {
    const b = el('button', 'gc-chip is-timed'); b.type = 'button';
    b.style.setProperty('--c', ev.color || DEF_COLOR);
    b.append(el('b', '', fmtT(ev.start)), document.createTextNode(ev.title || '(Geen titel)'));
    b.title = (ev.title || '(Geen titel)') + ' ' + fmtT(ev.start) + ' – ' + fmtT(ev.end);
    b.onclick = e => { e.stopPropagation(); showEvPop(ev, b); };
    return b;
  }

  // --- Dag- en weekweergave (tijdlijn) ---
  function renderTime() {
    const n = nDays(), start = rangeStart();
    const days = Array.from({ length: n }, (_, i) => addDays(start, i));
    const todayK = keyOf(new Date());
    const wrap = el('div', 'gc-time');
    wrap.style.setProperty('--n', n);

    const head = el('div', 'gc-row gc-head');
    head.append(el('div', 'gc-gmt', gmtLabel()));
    days.forEach(d => {
      const idx = (d.getDay() + 6) % 7;
      const c = el('button', 'gc-dayhead' + (keyOf(d) === todayK ? ' is-today' : '')); c.type = 'button';
      c.append(el('span', 'gc-dow', DOW_U[idx]), el('span', 'gc-dnum', String(d.getDate())));
      c.title = longDate(d);
      c.onclick = () => { if (ui.view !== 'day') { ui.view = 'day'; saveUi(ui); } go(d); };
      head.append(c);
    });

    // Hele-dag-rij (afspraken zonder tijd + liturgische feesten)
    const allRow = el('div', 'gc-row gc-allday');
    const gut = el('div', 'gc-allgut');
    allRow.append(gut);
    let anyMany = false;
    days.forEach(d => {
      const it = dayItems(d);
      const chips = [];
      it.lit.forEach(l => chips.push(litChip(l, d)));
      (it.ros || []).forEach(r => chips.push(rosaryChip(r, d)));
      it.all.forEach(ev => chips.push(evChip(ev)));
      if (chips.length > 3) anyMany = true;
      const cell = el('div', 'gc-allcell');
      if (!allExpanded && chips.length > 3) {
        chips.slice(0, 2).forEach(c => cell.append(c));
        const more = el('button', 'gc-more', '+' + (chips.length - 2) + ' meer'); more.type = 'button';
        more.onclick = () => { allExpanded = true; render(); };
        cell.append(more);
      } else chips.forEach(c => cell.append(c));
      allRow.append(cell);
    });
    if (anyMany) {
      const tg = ibtn(allExpanded ? 'chevU' : 'chevD', allExpanded ? 'Hele-dag-rij inklappen' : 'Hele-dag-rij uitklappen');
      tg.onclick = () => { allExpanded = !allExpanded; render(); };
      gut.append(tg);
    }

    // Tijdraster
    scroller = el('div', 'gc-scroll');
    const grid = el('div', 'gc-row gc-grid');
    const hours = el('div', 'gc-hours');
    for (let h = 1; h < 24; h++) {
      const l = el('span', 'gc-hour', fmtT(h * 60));
      l.style.top = (h * HOUR - 7) + 'px';
      hours.append(l);
    }
    grid.append(hours);
    days.forEach((d, i) => {
      const k = keyOf(d);
      const col = el('div', 'gc-col' + (k === todayK ? ' is-today' : ''));
      col.dataset.date = k;
      layoutDay(dayItems(d).timed).forEach(it => col.append(timedEl(it, col, i, n)));
      if (draft && draft.date === k) col.append(draftEl(draft));
      if (k === todayK) { const now = el('div', 'gc-now'); setNowTop(now); col.append(now); }
      col.addEventListener('pointerdown', e => { if (e.target === col) startCreate(e, col, d); });
      grid.append(col);
    });
    scroller.append(grid);
    const sc = scroller;
    sc.addEventListener('scroll', () => { if (sc.isConnected) scrollMem = sc.scrollTop; });
    wrap.append(head, allRow, scroller);
    wrap.headEls = [head, allRow];
    viewEl.append(wrap);
    pendingScroll = true;
    requestAnimationFrame(applyScroll);
  }

  function applyScroll() {
    if (!scroller || !scroller.isConnected || !scroller.clientHeight) return;
    const sbw = scroller.offsetWidth - scroller.clientWidth;
    scroller.parentNode.headEls.forEach(r => { r.style.paddingRight = sbw + 'px'; });
    if (pendingScroll) {
      pendingScroll = false;
      const now = new Date();
      const hr = now.getHours() + now.getMinutes() / 60;
      scroller.scrollTop = scrollMem != null ? scrollMem : clamp((hr - 2.5) * HOUR, 0, 24 * HOUR);
    }
  }
  function setNowTop(node) {
    const n = new Date();
    node.style.top = ((n.getHours() * 60 + n.getMinutes()) / 60 * HOUR) + 'px';
  }

  function paintBlock(node, s, e) {
    node.style.top = (s / 60 * HOUR) + 'px';
    node.style.height = Math.max((e - s) / 60 * HOUR - 1, 14) + 'px';
  }
  function draftEl(dr) {
    const e = el('div', 'gc-ev is-draft');
    e.style.background = dr.color || DEF_COLOR; e.style.color = textOn(dr.color || DEF_COLOR);
    paintBlock(e, dr.start, dr.end);
    e.append(el('div', 'gc-ev-t', dr.title || '(Geen titel)'), el('div', 'gc-ev-time', fmtT(dr.start) + ' – ' + fmtT(dr.end)));
    return e;
  }
  function timedEl(it, col, idx, n) {
    const ev = it.ev;
    const color = ev.color || DEF_COLOR;
    const e = el('div', 'gc-ev'); e.tabIndex = 0; e.setAttribute('role', 'button');
    paintBlock(e, ev.start, ev.end);
    const h = parseFloat(e.style.height);
    e.style.left = (it.lane / it.lanes * 100) + '%';
    e.style.width = 'calc(' + (100 / it.lanes) + '% - 2px)';
    e.style.background = color; e.style.color = textOn(color);
    const t = el('div', 'gc-ev-t', ev.title || '(Geen titel)');
    if (h >= 34) e.append(t, el('div', 'gc-ev-time', fmtT(ev.start) + ' – ' + fmtT(ev.end)));
    else { t.append(el('span', 'gc-ev-inl', ', ' + fmtT(ev.start))); e.append(t); }
    e.title = (ev.title || '(Geen titel)') + '\n' + fmtT(ev.start) + ' – ' + fmtT(ev.end);
    e.append(el('div', 'gc-resize'));
    e.onclick = ce => { if (suppressClick) return; ce.stopPropagation(); showEvPop(ev, e); };
    e.onkeydown = ke => { if (ke.key === 'Enter' || ke.key === ' ') { ke.preventDefault(); showEvPop(ev, e); } };
    attachDrag(e, ev, col, idx, n);
    return e;
  }

  // Slepen in een lege plek: nieuwe afspraak; klikken: standaard een uur.
  function startCreate(e, col, d) {
    if (e.button !== 0) return;
    closePop();
    const touch = e.pointerType === 'touch';
    const rect = col.getBoundingClientRect();
    const toMin = y => clamp((y - rect.top) / HOUR * 60, 0, 1440);
    const anchor = Math.floor(toMin(e.clientY) / 15) * 15;
    const sy = e.clientY;
    let moved = false, s = anchor, en = Math.min(anchor + 15, 1440);
    const ghost = el('div', 'gc-ev gc-ghost');
    ghost.style.background = DEF_COLOR; ghost.style.color = '#fff';
    const paint = () => {
      paintBlock(ghost, s, en);
      ghost.replaceChildren(el('div', 'gc-ev-t', '(Geen titel)'), el('div', 'gc-ev-time', fmtT(s) + ' – ' + fmtT(en)));
    };
    const cleanup = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', cancel);
      ghost.remove();
    };
    const move = ev => {
      if (touch) return;
      if (!moved && Math.abs(ev.clientY - sy) < 5) return;
      if (!moved) { moved = true; col.append(ghost); }
      const m = Math.round(toMin(ev.clientY) / 15) * 15;
      if (m >= anchor) { s = anchor; en = Math.max(m, anchor + 15); } else { s = m; en = anchor + 15; }
      en = Math.min(en, 1440);
      paint();
    };
    const cancel = () => cleanup();
    const up = ev => {
      cleanup();
      if (touch && Math.abs(ev.clientY - sy) > 8) return;
      if (!moved) { s = Math.floor(toMin(sy) / 30) * 30; en = s + 60; }
      if (en > 1440) { en = 1440; s = Math.min(s, 1380); }
      openEditor({ date: keyOf(d), allDay: false, start: s, end: en });
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', cancel);
  }

  // Slepen van een afspraak: verplaatsen (ook naar een andere dag) of onderaan verlengen.
  function attachDrag(node, ev, col, idx, n) {
    node.addEventListener('pointerdown', e => {
      if (e.button !== 0 || e.pointerType === 'touch') return;
      e.stopPropagation();
      const isResize = e.target.classList.contains('gc-resize');
      const sx = e.clientX, sy = e.clientY;
      const colW = col.getBoundingClientRect().width;
      const orig = { start: ev.start, end: ev.end, date: ev.date };
      let moved = false, dd = 0, dm = 0;
      const move = m => {
        const dx = m.clientX - sx, dy = m.clientY - sy;
        if (!moved && Math.hypot(dx, dy) < 5) return;
        if (!moved) { moved = true; node.classList.add('is-dragging'); closePop(); }
        dm = Math.round(dy / HOUR * 60 / 15) * 15;
        if (isResize) {
          const ne = clamp(orig.end + dm, orig.start + 15, 1440);
          dm = ne - orig.end;
          node.style.height = Math.max((ne - orig.start) / 60 * HOUR - 1, 14) + 'px';
        } else {
          dd = clamp(Math.round(dx / colW), -idx, n - 1 - idx);
          const dur = orig.end - orig.start;
          dm = clamp(orig.start + dm, 0, 1440 - dur) - orig.start;
          node.style.transform = 'translate(' + (dd * colW) + 'px,' + (dm / 60 * HOUR) + 'px)';
        }
      };
      const cleanup = () => {
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        window.removeEventListener('pointercancel', cleanup);
      };
      const up = () => {
        cleanup();
        if (!moved) return;
        suppressClick = true; setTimeout(() => { suppressClick = false; }, 50);
        if (isResize) ev.end = orig.end + dm;
        else {
          ev.start = orig.start + dm; ev.end = orig.end + dm;
          if (dd) ev.date = keyOf(addDays(parseKey(orig.date), dd));
        }
        save(); render();
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
      window.addEventListener('pointercancel', cleanup);
    });
  }

  // --- Maandweergave ---
  function renderMonth() {
    const y = cur.getFullYear(), m = cur.getMonth();
    const first = new Date(y, m, 1);
    const gs = mondayOf(first);
    const dim = new Date(y, m + 1, 0).getDate();
    const weeks = Math.ceil((((first.getDay() + 6) % 7) + dim) / 7);
    const wrap = el('div', 'gc-month');
    const head = el('div', 'gc-mhead');
    DOW_U.forEach(d => head.append(el('div', 'gc-mdow', d)));
    const body = el('div', 'gc-mbody');
    body.style.gridTemplateRows = 'repeat(' + weeks + ',minmax(0,1fr))';
    const todayK = keyOf(new Date());
    for (let i = 0; i < weeks * 7; i++) {
      const d = addDays(gs, i), k = keyOf(d);
      const cell = el('div', 'gc-mcell' + (d.getMonth() !== m ? ' is-out' : '') + (k === todayK ? ' is-today' : ''));
      const num = el('button', 'gc-mnum', d.getDate() === 1 ? d.getDate() + ' ' + MONTHS_S[d.getMonth()] : String(d.getDate()));
      num.type = 'button'; num.title = longDate(d);
      num.onclick = e => { e.stopPropagation(); ui.view = 'day'; saveUi(ui); go(d); };
      const box = el('div', 'gc-mchips'); box.dataset.date = k;
      const it = dayItems(d);
      if (it.lit.length) box.append(litChip(pickLit(it.lit), d));
      if (it.ros && it.ros.length) box.append(rosaryChip(it.ros[0], d));
      it.all.forEach(ev => box.append(evChip(ev)));
      it.timed.forEach(ev => box.append(monthTimedChip(ev)));
      cell.append(num, box);
      cell.onclick = () => openEditor({ date: k, allDay: true });
      body.append(cell);
    }
    wrap.append(head, body);
    viewEl.append(wrap);
    requestAnimationFrame(fitMonth);
  }
  // Te veel afspraken voor één cel: toon er zoveel als passen en de rest als "+N meer".
  function fitMonth() {
    viewEl.querySelectorAll('.gc-mchips').forEach(box => {
      box.querySelectorAll('.gc-more').forEach(x => x.remove());
      const kids = Array.from(box.children);
      kids.forEach(k => { k.hidden = false; });
      const capN = Math.max(1, Math.floor(box.clientHeight / 22));
      if (kids.length > capN) {
        const keep = Math.max(0, capN - 1);
        kids.slice(keep).forEach(k => { k.hidden = true; });
        const more = el('button', 'gc-more', '+' + (kids.length - keep) + ' meer'); more.type = 'button';
        more.onclick = e => { e.stopPropagation(); ui.view = 'day'; saveUi(ui); go(parseKey(box.dataset.date)); };
        box.append(more);
      }
    });
  }

  // ---------- Pop-ups ----------
  function closePop() { if (popEl) { popEl.remove(); popEl = null; } }
  function placePop(pop, anchor) {
    root.append(pop); popEl = pop;
    const rr = root.getBoundingClientRect(), ar = anchor.getBoundingClientRect();
    const w = pop.offsetWidth, h = pop.offsetHeight;
    let x = ar.right - rr.left + 8;
    if (x + w > rr.width - 8) x = ar.left - rr.left - w - 8;
    if (x < 8) x = Math.max(8, (rr.width - w) / 2);
    let y = ar.top - rr.top;
    if (y + h > rr.height - 8) y = rr.height - h - 8;
    pop.style.left = x + 'px'; pop.style.top = Math.max(8, y) + 'px';
  }
  function showEvPop(ev, anchor) {
    closePop();
    const pop = el('div', 'gc-pop');
    const bar = el('div', 'gc-pop-bar');
    const edit = ibtn('pencil', 'Bewerken'), del = ibtn('trash', 'Verwijderen'), close = ibtn('close', 'Sluiten');
    edit.onclick = () => openEditor(ev);
    del.onclick = () => { events = events.filter(x => x.id !== ev.id); save(); closePop(); render(); };
    close.onclick = closePop;
    bar.append(edit, del, close);
    const body = el('div', 'gc-pop-body');
    const h = el('div', 'gc-pop-title');
    const dot = el('span', 'gc-dot'); dot.style.background = ev.color || DEF_COLOR;
    h.append(dot, el('span', '', ev.title || '(Geen titel)'));
    body.append(h, el('div', 'gc-pop-when', whenText(ev)));
    if (ev.desc) body.append(el('div', 'gc-pop-desc', ev.desc));
    pop.append(bar, body);
    placePop(pop, anchor);
  }
  function showLitPop(d, anchor) {
    closePop();
    const pop = el('div', 'gc-pop');
    const bar = el('div', 'gc-pop-bar');
    const close = ibtn('close', 'Sluiten'); close.onclick = closePop;
    bar.append(close);
    const body = el('div', 'gc-pop-body');
    const h = el('div', 'gc-pop-title');
    const dot = el('span', 'gc-dot'); dot.style.background = getComputedAccent();
    h.append(dot, el('span', '', 'Liturgische kalender'));
    body.append(h, el('div', 'gc-pop-when', longDate(d)));
    const box = el('div', 'gc-pop-lit');
    litDay(d.getFullYear(), d.getMonth(), d.getDate(), prefs).forEach(it => box.append(litRow(it)));
    const k = String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const info = LIT && LIT.dagen && LIT.dagen[k];
    if (info && info.n) box.append(el('p', 'cal-lit-note', info.n));
    body.append(box);
    pop.append(bar, body);
    placePop(pop, anchor);
  }
  function showRosaryPop(d, it, anchor) {
    closePop();
    const pop = el('div', 'gc-pop');
    const bar = el('div', 'gc-pop-bar');
    const close = ibtn('close', 'Sluiten'); close.onclick = closePop;
    bar.append(close);
    const body = el('div', 'gc-pop-body');
    const h = el('div', 'gc-pop-title');
    const dot = el('span', 'gc-dot');
    dot.style.background = 'var(--acc2, #b8922a)';
    h.append(dot, el('span', '', 'Rozenkrans'));
    body.append(h, el('div', 'gc-pop-when', longDate(d)));
    body.append(el('div', 'gc-pop-title', it.t));
    const box = el('div', 'gc-pop-lit');
    const ol = document.createElement('ol');
    ol.style.margin = '8px 0 0';
    ol.style.paddingLeft = '1.25rem';
    (it.list || []).forEach(name => {
      const li = document.createElement('li');
      li.textContent = name;
      ol.append(li);
    });
    box.append(ol);
    if (it.n) box.append(el('p', 'cal-lit-note', it.n));
    body.append(box);
    pop.append(bar, body);
    placePop(pop, anchor);
  }

  // ---------- Afspraak maken / bewerken ----------
  function closeModal() {
    if (modalEl) { modalEl.remove(); modalEl = null; }
    if (draft) { draft = null; render(); }
  }
  function openEditor(src) {
    closePop();
    if (modalEl) { modalEl.remove(); modalEl = null; }
    const isNew = !src.id;
    const s = {
      title: src.title || '', date: src.date, endDate: src.endDate || src.date, allDay: !!src.allDay,
      start: src.start != null ? src.start : 540,
      end: src.end != null ? src.end : (src.start != null ? Math.min(1440, src.start + 60) : 600),
      color: src.color || DEF_COLOR, desc: src.desc || '',
    };
    if (s.end <= s.start) s.end = Math.min(1440, s.start + 60);

    const back = el('div', 'gc-modal');
    const dlg = el('div', 'gc-dialog'); dlg.setAttribute('role', 'dialog'); dlg.setAttribute('aria-label', isNew ? 'Nieuwe afspraak' : 'Afspraak bewerken');
    const topRow = el('div', 'gc-dialog-top');
    const x = ibtn('close', 'Sluiten'); x.onclick = closeModal; topRow.append(x);

    const titleIn = el('input', 'gc-title-in'); titleIn.type = 'text'; titleIn.maxLength = 200;
    titleIn.placeholder = 'Titel toevoegen'; titleIn.value = s.title; titleIn.setAttribute('aria-label', 'Titel');

    const field = (ic, top_) => {
      const f = el('div', 'gc-field' + (top_ ? ' is-top' : ''));
      const i = el('span', 'gc-row-ic'); if (ic) i.append(icon(ic));
      f.append(i);
      return f;
    };

    // Datum en tijd
    const fWhen = field('clock');
    const dateIn = document.createElement('input'); dateIn.type = 'date'; dateIn.value = s.date; dateIn.setAttribute('aria-label', 'Datum');
    const startSel = document.createElement('select'); startSel.setAttribute('aria-label', 'Begintijd');
    const endSel = document.createElement('select'); endSel.setAttribute('aria-label', 'Eindtijd');
    const sep = el('span', 'gc-sep', '–');
    const endDateIn = document.createElement('input'); endDateIn.type = 'date'; endDateIn.value = s.endDate; endDateIn.setAttribute('aria-label', 'Einddatum');
    const tot = el('span', 'gc-sep', 't/m');
    fWhen.append(dateIn, startSel, sep, endSel, tot, endDateIn);

    const fAll = field(null);
    const allLab = el('label', 'gc-check');
    const allCb = document.createElement('input'); allCb.type = 'checkbox'; allCb.checked = s.allDay;
    allLab.append(allCb, document.createTextNode('Hele dag'));
    fAll.append(allLab);

    const fillStart = () => {
      startSel.replaceChildren();
      for (let m = 0; m < 1440; m += 15) { const o = el('option', '', fmtT(m)); o.value = String(m); startSel.append(o); }
      startSel.value = String(s.start);
    };
    const fillEnd = () => {
      endSel.replaceChildren();
      for (let m = s.start + 15; m <= 1440; m += 15) {
        const o = el('option', '', (m === 1440 ? '24:00' : fmtT(m)) + ' (' + durLabel(m - s.start) + ')');
        o.value = String(m); endSel.append(o);
      }
      if (s.end <= s.start || s.end > 1440) s.end = Math.min(1440, s.start + 60);
      endSel.value = String(s.end);
    };
    const toggle = () => {
      startSel.hidden = endSel.hidden = sep.hidden = s.allDay;
      endDateIn.hidden = tot.hidden = !s.allDay;
    };
    const updateDraft = () => {
      draft = s.allDay || !s.date ? null : { date: s.date, start: s.start, end: s.end, color: s.color, title: titleIn.value.trim() };
      render();
    };
    fillStart(); fillEnd(); toggle();
    startSel.onchange = () => {
      const dur = s.end - s.start;
      s.start = Number(startSel.value);
      s.end = Math.min(1440, s.start + dur);
      fillEnd(); updateDraft();
    };
    endSel.onchange = () => { s.end = Number(endSel.value); updateDraft(); };
    dateIn.onchange = () => {
      if (!dateIn.value) { dateIn.value = s.date; return; }
      s.date = dateIn.value;
      if (s.endDate < s.date) s.endDate = s.date;
      endDateIn.value = s.endDate; endDateIn.min = s.date; updateDraft();
    };
    endDateIn.min = s.date;
    endDateIn.onchange = () => { s.endDate = endDateIn.value && endDateIn.value >= s.date ? endDateIn.value : s.date; endDateIn.value = s.endDate; };
    allCb.onchange = () => { s.allDay = allCb.checked; toggle(); updateDraft(); };
    titleIn.oninput = () => { if (draft) { draft.title = titleIn.value.trim(); updateDraft(); titleIn.focus(); } };

    // Kleur
    const fColor = field('palette', true);
    const sw = el('div', 'gc-swatches');
    const paintSw = () => {
      sw.replaceChildren();
      COLORS.forEach(([name, c]) => {
        const b = el('button', 'gc-sw'); b.type = 'button'; b.style.background = c;
        b.title = name; b.setAttribute('aria-label', name); b.setAttribute('aria-pressed', s.color === c ? 'true' : 'false');
        if (s.color === c) b.append(icon('check'));
        b.onclick = () => { s.color = c; paintSw(); if (draft) { draft.color = c; updateDraft(); } };
        sw.append(b);
      });
    };
    paintSw();
    fColor.append(sw);

    // Beschrijving
    const fDesc = field('text', true);
    const descIn = document.createElement('textarea'); descIn.placeholder = 'Beschrijving toevoegen'; descIn.value = s.desc;
    descIn.setAttribute('aria-label', 'Beschrijving'); descIn.maxLength = 4000;
    fDesc.append(descIn);

    const actions = el('div', 'gc-actions');
    if (!isNew) {
      const del = el('button', 'gc-btn is-danger', 'Verwijderen'); del.type = 'button';
      del.onclick = () => { events = events.filter(e => e.id !== src.id); save(); closeModal(); render(); };
      actions.append(del);
    }
    actions.append(el('div', 'gc-spacer'));
    const cancel = el('button', 'gc-btn', 'Annuleren'); cancel.type = 'button'; cancel.onclick = closeModal;
    const ok = el('button', 'gc-btn is-primary', 'Opslaan'); ok.type = 'button';
    const doSave = () => {
      if (!s.date) return;
      const out = { id: src.id || uid(), title: titleIn.value.trim(), date: s.date, allDay: s.allDay, color: s.color, desc: descIn.value.trim() };
      if (s.allDay) { if (s.endDate > s.date) out.endDate = s.endDate; } else { out.start = s.start; out.end = s.end; }
      if (isNew) events.push(out); else events = events.map(e => e.id === out.id ? out : e);
      save();
      draft = null;
      if (modalEl) { modalEl.remove(); modalEl = null; }
      if (!ui.mine) { ui.mine = true; saveUi(ui); }
      go(parseKey(out.date));
    };
    ok.onclick = doSave;
    actions.append(cancel, ok);
    titleIn.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); doSave(); } };
    descIn.onkeydown = e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); doSave(); } };

    dlg.append(topRow, titleIn, fWhen, fAll, fColor, fDesc, actions);
    back.append(dlg);
    back.addEventListener('pointerdown', e => { if (e.target === back) closeModal(); });
    root.append(back);
    modalEl = back;
    if (isNew && !s.allDay) updateDraft();
    titleIn.focus();
  }

  // ---------- Bibliotheken (liturgische kalender) ----------
  function setMode(m) {
    mode = m;
    const isLibs = mode === 'libs';
    const isTasks = mode === 'tasks';
    root.classList.toggle('is-libs', isLibs);
    root.classList.toggle('is-tasks', isTasks);
    libsBtn.setAttribute('aria-expanded', isLibs ? 'true' : 'false');
    closePop();
    if (isLibs) renderLibs();
    else if (isTasks) render();
    else render();
  }
  function renderLibs() {
    libsPanel.replaceChildren();
    const head = document.createElement('div');
    head.className = 'cal-libs-head';
    const back = document.createElement('button');
    back.type = 'button'; back.className = 'cal-libs-back'; back.textContent = '← Terug';
    back.onclick = () => setMode('cal');
    const h = document.createElement('h2');
    h.textContent = 'Kalenderbibliotheken';
    head.append(back, h);

    const intro = document.createElement('p');
    intro.className = 'cal-libs-intro';
    intro.textContent = 'Zet bronnen voor de kalender aan of uit. Aangezette bibliotheken tonen hun feesten en notities in de maandweergave.';

    // --- Liturgische kalender ---
    const card = document.createElement('div');
    card.className = 'cal-lib-card';
    const top = document.createElement('div');
    top.className = 'cal-lib-card-top';
    const meta = document.createElement('div');
    const titleEl = document.createElement('h3');
    titleEl.textContent = 'Liturgische kalender';
    const desc = document.createElement('p');
    desc.textContent = 'Feesten, heiligen en rangen van de Katholieke Kerk (algemene kalender, bisdomkalenders en optioneel Tridentijnse Mis).';
    const credit = document.createElement('p');
    credit.className = 'cal-lib-credit';
    credit.textContent = 'Gemaakt door de Liturgische Raad Nederland, met toevoegingen en aanpassingen door Leo Crucis.';
    const refs = document.createElement('div');
    refs.className = 'cal-lib-refs';
    const refLab = document.createElement('span');
    refLab.className = 'cal-lib-ref-label';
    refLab.textContent = 'Boeken in de stad:';
    const a1 = document.createElement('a');
    a1.href = '#kerk-liturgie-rituelen-kalender';
    a1.textContent = 'Kalender';
    a1.title = 'Open het kalenderboek in de Kerk';
    const a2 = document.createElement('a');
    a2.href = '#kerk-liturgie-rituelen-paasdata';
    a2.textContent = 'Paasdata';
    a2.title = 'Open Paasdata in de Kerk';
    const a3 = document.createElement('a');
    a3.href = '#kerk-liturgie-rituelen-liturgisch-jaar';
    a3.textContent = 'Liturgisch jaar';
    a3.title = 'Open Liturgisch jaar in de Kerk';
    refs.append(refLab, a1, a2, a3);
    meta.append(titleEl, desc, credit, refs);
    const sw = document.createElement('label');
    sw.className = 'cal-lib-switch';
    sw.title = 'Liturgische kalender aan/uit';
    const swIn = document.createElement('input');
    swIn.type = 'checkbox'; swIn.checked = !!prefs.on;
    swIn.setAttribute('aria-label', 'Liturgische kalender');
    const swUi = document.createElement('span');
    sw.append(swIn, swUi);
    swIn.onchange = () => {
      prefs.on = swIn.checked;
      saveLitPrefs(prefs);
      opts.hidden = !prefs.on;
    };
    top.append(meta, sw);
    card.append(top);

    const opts = document.createElement('div');
    opts.className = 'cal-lib-opts';
    opts.hidden = !prefs.on;

    const bisLabel = document.createElement('label');
    bisLabel.append(document.createTextNode('Bisdom '));
    const bisSel = document.createElement('select');
    bisSel.className = 'cal-lit-bis';
    bisSel.setAttribute('aria-label', 'Bisdom');
    [['alle', 'Alle bisdommen'], ['alg', 'Alleen algemene kalender']]
      .concat(BELG.map(b => [b, b]), NEDL.map(b => [b, b]))
      .forEach(([v, t]) => { const o = document.createElement('option'); o.value = v; o.textContent = t; bisSel.append(o); });
    bisSel.value = prefs.bis;
    bisSel.onchange = () => { prefs.bis = bisSel.value; saveLitPrefs(prefs); };
    bisLabel.append(bisSel);

    const tmLabel = document.createElement('label');
    const tmIn = document.createElement('input');
    tmIn.type = 'checkbox'; tmIn.checked = !!prefs.tm;
    tmIn.onchange = () => { prefs.tm = tmIn.checked; saveLitPrefs(prefs); };
    tmLabel.append(tmIn, document.createTextNode(' Tridentijnse Mis'));

    opts.append(bisLabel, tmLabel);
    card.append(opts);

    // --- Rozenkrans-mysteriën ---
    const cardR = document.createElement('div');
    cardR.className = 'cal-lib-card';
    const topR = document.createElement('div');
    topR.className = 'cal-lib-card-top';
    const metaR = document.createElement('div');
    const titleR = document.createElement('h3');
    titleR.textContent = 'Rozenkrans-mysteriën';
    const descR = document.createElement('p');
    descR.textContent = 'Welke mysteriën je volgens de gebruikelijke weekindeling bidt. Op zondag: blijde (advent/kerst), pijnlijke (vasten) of glorievolle mysteriën.';
    const creditR = document.createElement('p');
    creditR.className = 'cal-lib-credit';
    creditR.textContent = 'Ma · blijde · Di · pijnlijke · Wo · glorievolle · Do · lichtende · Vr · pijnlijke · Za · blijde · Zo · seizoensgebonden.';
    metaR.append(titleR, descR, creditR);
    const swR = document.createElement('label');
    swR.className = 'cal-lib-switch';
    swR.title = 'Rozenkrans-mysteriën aan/uit';
    const swRIn = document.createElement('input');
    swRIn.type = 'checkbox';
    swRIn.checked = !!rosPrefs.on;
    swRIn.setAttribute('aria-label', 'Rozenkrans-mysteriën');
    const swRUi = document.createElement('span');
    swR.append(swRIn, swRUi);
    swRIn.onchange = () => {
      rosPrefs.on = swRIn.checked;
      saveRosPrefs(rosPrefs);
      render();
    };
    topR.append(metaR, swR);
    cardR.append(topR);

    libsPanel.append(head, intro, card, cardR);
  }

  function litRow(it) {
    const row = document.createElement(it.n ? 'details' : 'div');
    row.className = 'cal-lit-item' + (it.r ? ' r-' + it.r : it.e ? ' r-e' : '') + (it.tm ? ' is-tm' : '');
    const head = document.createElement(it.n ? 'summary' : 'div');
    head.className = 'cal-lit-head';
    const badges = document.createElement('span');
    badges.className = 'cal-lit-badges';
    if (it.r) { const b = document.createElement('b'); b.className = 'bd bd-' + it.r; b.textContent = it.r; b.title = RANK_NAME[it.r]; badges.append(b); }
    if (it.tm) { const b = document.createElement('b'); b.className = 'bd bd-tm'; b.textContent = 'TM'; b.title = 'Tridentijnse Mis'; badges.append(b); }
    if (it.v) { const b = document.createElement('b'); b.className = 'bd bd-v'; b.textContent = 'V'; b.title = 'Vasten'; badges.append(b); }
    const txt = document.createElement('span');
    txt.className = 'cal-lit-text';
    if (it.reg) { const i = document.createElement('i'); i.textContent = it.reg + ': '; txt.append(i); }
    txt.append(document.createTextNode(it.t));
    head.append(badges, txt);
    row.append(head);
    if (it.n) { const n = document.createElement('p'); n.className = 'cal-lit-detail'; n.textContent = it.n; row.append(n); }
    return row;
  }


  // ---------- Events ----------
  prev.onclick = () => step(-1);
  next.onclick = () => step(1);
  todayBtn.onclick = goToday;
  logo.onclick = goToday;
  menuBtn.onclick = () => { sideOpen = !sideOpen; applySide(); };
  scrim.onclick = () => { sideOpen = false; applySide(); };
  createBtn.onclick = () => {
    const now = new Date();
    let s = 540;
    if (keyOf(cur) === keyOf(now)) s = clamp(Math.ceil((now.getHours() * 60 + now.getMinutes()) / 30) * 30, 0, 1380);
    openEditor({ date: keyOf(cur), allDay: false, start: s, end: Math.min(1440, s + 60) });
    if (narrow) { sideOpen = false; applySide(); }
  };
  viewBtn.onclick = e => {
    e.stopPropagation();
    viewMenu.hidden = !viewMenu.hidden;
    viewBtn.setAttribute('aria-expanded', viewMenu.hidden ? 'false' : 'true');
  };
  libsBtn.onclick = () => setMode(mode === 'libs' ? 'cal' : 'libs');
  segCal.onclick = () => setMode('cal');
  segTasks.onclick = () => setMode('tasks');
  libsPanel.addEventListener('click', e => { if (e.target === libsPanel) setMode('cal'); });
  root.addEventListener('pointerdown', e => {
    if (popEl && !popEl.contains(e.target)) closePop();
    if (!viewMenu.hidden && !viewWrap.contains(e.target)) { viewMenu.hidden = true; viewBtn.setAttribute('aria-expanded', 'false'); }
    if ((openTaskMenuId || openListMenuId) && !e.target.closest('.gc-task-menu') && !e.target.closest('.gc-task-actions') && !e.target.closest('.gc-list-more')) {
      openTaskMenuId = null;
      openListMenuId = null;
      renderTasks();
    }
  });

  const onKey = e => {
    if (!root.isConnected) return;
    if (e.key === 'Escape') {
      if (modalEl) closeModal();
      else if (popEl) closePop();
      else if (!viewMenu.hidden) { viewMenu.hidden = true; viewBtn.setAttribute('aria-expanded', 'false'); }
      else if (mode === 'libs') setMode('cal');
      else if (mode === 'tasks' && (taskComposerOpen || openTaskMenuId || openListMenuId || dueEditId || subComposerId)) {
        taskComposerOpen = false; closeTaskMenus(); renderTasks();
      }
      return;
    }
    if (e.ctrlKey || e.metaKey || e.altKey || modalEl || mode !== 'cal') return;
    const t = e.target;
    if (t && t.closest && t.closest('input,textarea,select,[contenteditable="true"]')) return;
    if (!root.getClientRects().length) return;
    switch (e.key.toLowerCase()) {
      case 't': goToday(); break;
      case 'd': setView('day'); break;
      case 'w': setView('week'); break;
      case 'm': setView('month'); break;
      case 'j': case 'n': step(1); break;
      case 'k': case 'p': step(-1); break;
      case 'c': e.preventDefault(); createBtn.click(); break;
      default: return;
    }
  };
  document.addEventListener('keydown', onKey);

  function cleanup() {
    document.removeEventListener('keydown', onKey);
    clearInterval(timer);
    if (ro) ro.disconnect();
  }
  // Rode "nu"-lijn bijwerken, en opruimen zodra de kalender uit de pagina is.
  timer = setInterval(() => {
    if (!root.isConnected) { if (seenConnected) cleanup(); return; }
    viewEl.querySelectorAll('.gc-now').forEach(setNowTop);
  }, 30000);

  // Smalle schermen: zijbalk als lade, week toont dan 3 dagen.
  let ro = null;
  if (typeof ResizeObserver !== 'undefined') {
    ro = new ResizeObserver(() => {
      if (root.isConnected) seenConnected = true;
      else { if (seenConnected) cleanup(); return; }
      const w = root.clientWidth;
      if (!w) return;
      const nn = w < 760;
      if (!sideInit || nn !== narrow) {
        sideInit = true; narrow = nn; sideOpen = !nn;
        root.classList.toggle('is-narrow', nn);
        applySide(); render();
      } else {
        applyScroll();
        if (ui.view === 'month') fitMonth();
      }
    });
    ro.observe(root);
  }

  applySide();
  render();
  (async () => {
    try {
      const [ev, pr, u, td, rp] = await Promise.all([
        loadEvents(), loadLitPrefs(), loadUi(), loadTodos(), loadRosPrefs()
      ]);
      events = ev;
      prefs = pr;
      rosPrefs = rp || { on: true };
      Object.assign(ui, u);
      todoStore = td && td.lists ? td : emptyTodoStore();
      if (!todoStore.lists.some(l => l.id === 'default') && todoStore.lists.length) {
        taskFilter = { type: 'list', id: todoStore.lists[0].id };
      }
      ready = true;
    } catch (e) { console.warn('Kalender memory:', e); ready = true; }
    await loadLit();
    render();
  })();
  return { root };
}
