/**
 * ui/settings-view.js — instellingenscherm (fase 3 nieuw)
 */
import { el } from '../core/dom.js';
import { APP_VERSION, APP_NAME } from '../version.js';

/**
 * @param {object} deps
 */
export function createSettingsViewApi(deps) {
  const {
    loadSettings,
    saveSettings,
    applySettings,
    viewContent,
    home,
    view,
    canOpenNewRecent,
    pushRecentApp,
    showHome,
    setHash = (h) => { try { location.hash = h; } catch (_) {} },
    setCurrentSection = () => {},
    getRecentAppsMax = () => 3,
    getRecentApps = () => [],
    ask,
    inTauri = false,
    clearAppCache = async () => {},
    getTauriWindow = () => null,
    openFolder = async () => {},
    renderHeaderFavorites = () => {},
    persist = async () => {},
    renderWorld = () => {},
    clearSplitState = () => {},
    getSplitLeft = () => null,
    getSplitRight = () => null,
    setSplitRight = () => {},
    renderMiniAppView = () => {},
    getFps = () => 0,
    openMediaFolder = async () => {},
    restartOnboarding = null,
    showShortcutsHelp = null,
  } = deps;

  function showSettings(force) {
    if (!force && !canOpenNewRecent('app-settings')) return;
    clearSplitState();
    document.body.classList.remove('search-open');
    document.body.classList.remove('browser-open');
    document.body.classList.remove('pdf-open');
    setCurrentSection(null);
    viewContent.replaceChildren();
    const head = el('div', 'view-head settings-head');
    const back = el('button', 'back', '← Terug');
    back.type = 'button';
    back.onclick = showHome;
    head.append(back, el('h1', '', 'Instellingen'));
    viewContent.append(head);

    let st = loadSettings();
    const panel = el('div', 'settings-page');

    const mkSection = (title) => {
      const sec = el('div', 'settings-section');
      sec.append(el('h2', '', title));
      return sec;
    };

    /** Info-knop: uitleg alleen bij hover (of focus voor toetsenbord). */
    const mkInfo = (text) => {
      const wrap = el('div', 'settings-info-wrap');
      const btn = el('button', 'settings-info-btn', 'i');
      btn.type = 'button';
      btn.setAttribute('aria-label', text);
      btn.tabIndex = 0;
      const tip = el('div', 'settings-info-tip');
      tip.textContent = text;
      tip.setAttribute('role', 'tooltip');
      // Geen click: CSS :hover / :focus-within toont de tip
      btn.onclick = (e) => { e.preventDefault(); e.stopPropagation(); };
      wrap.append(btn, tip);
      return wrap;
    };

    /** Rij: titel links, controls rechts, optioneel info. */
    const mkRow = (title, control, infoText) => {
      const row = el('div', 'settings-row clean');
      const left = el('span', 'settings-row-title', title);
      const right = el('div', 'settings-row-controls');
      if (control) right.append(control);
      if (infoText) right.append(mkInfo(infoText));
      row.append(left, right);
      return row;
    };

    const mkSwitch = (checked, onChange, id) => {
      const lab = el('label', 'settings-switch');
      const inp = document.createElement('input');
      inp.type = 'checkbox';
      inp.role = 'switch';
      if (id) inp.id = id;
      inp.checked = !!checked;
      inp.onchange = () => onChange(inp.checked, inp);
      lab.append(inp, el('span', 'switch'));
      lab._input = inp;
      return lab;
    };

    const mkSelect = (options, current, onChange) => {
      const sel = document.createElement('select');
      sel.className = 'settings-select';
      for (const [val, label] of options) {
        const o = document.createElement('option');
        o.value = String(val);
        o.textContent = label;
        if (String(current) === String(val)) o.selected = true;
        sel.append(o);
      }
      sel.onchange = () => onChange(sel.value, sel);
      return sel;
    };

    /** Segmented choice (compact buttons). */
    const mkChoice = (options, current, onPick) => {
      const wrap = el('div', 'settings-choice');
      const buttons = [];
      options.forEach(([val, label]) => {
        const b = el('button', current === val ? 'active' : '', label);
        b.type = 'button';
        b.onclick = () => {
          buttons.forEach(x => x.classList.remove('active'));
          b.classList.add('active');
          onPick(val);
        };
        buttons.push(b);
        wrap.append(b);
      });
      return wrap;
    };

    const persist = () => {
      saveSettings(st);
      applySettings(st);
    };

    // Tabbladen
    const tabs = el('div', 'settings-tabs');
    const tabMain = el('button', 'settings-tab active', 'Main');
    const tabView = el('button', 'settings-tab', 'Weergave');
    const tabBible = el('button', 'settings-tab', 'Bijbel');
    const tabPerf = el('button', 'settings-tab', 'Prestaties');
    const tabInfo = el('button', 'settings-tab', 'Info');
    [tabMain, tabView, tabBible, tabPerf, tabInfo].forEach(t => { t.type = 'button'; });
    tabs.append(tabMain, tabView, tabBible, tabPerf, tabInfo);
    panel.append(tabs);

    const paneMain = el('div', 'settings-pane');
    const paneView = el('div', 'settings-pane');
    const paneBible = el('div', 'settings-pane');
    const panePerf = el('div', 'settings-pane');
    const paneInfo = el('div', 'settings-pane settings-pane-info-compact');
    paneView.hidden = true;
    paneBible.hidden = true;
    panePerf.hidden = true;
    paneInfo.hidden = true;

    const showTab = (which) => {
      tabMain.classList.toggle('active', which === 'main');
      tabView.classList.toggle('active', which === 'view');
      tabBible.classList.toggle('active', which === 'bible');
      tabPerf.classList.toggle('active', which === 'perf');
      tabInfo.classList.toggle('active', which === 'info');
      paneMain.hidden = which !== 'main';
      paneView.hidden = which !== 'view';
      paneBible.hidden = which !== 'bible';
      panePerf.hidden = which !== 'perf';
      paneInfo.hidden = which !== 'info';
    };
    tabMain.onclick = () => showTab('main');
    tabView.onclick = () => showTab('view');
    tabBible.onclick = () => showTab('bible');
    tabPerf.onclick = () => showTab('perf');
    tabInfo.onclick = () => showTab('info');

    // ========== WEERGAVE ==========
    const cardView = el('div', 'settings-card');

    const secTheme = mkSection('Uiterlijk');
    const choiceTheme = mkChoice(
      [['light', 'Licht'], ['dark', 'Donker'], ['system', 'Systeem']],
      st.theme,
      v => { st.theme = v; persist(); }
    );
    secTheme.append(mkRow('Thema', choiceTheme, 'Licht, donker, of het thema van je systeem volgen.'));
    const selFont = mkSelect(
      [['small', 'Klein'], ['normal', 'Normaal'], ['large', 'Groot'], ['xlarge', 'Zeer groot']],
      st.fontSize || 'normal',
      v => { st.fontSize = v; persist(); }
    );
    secTheme.append(mkRow('Lettergrootte', selFont, 'Tekstgrootte in de hele app.'));
    cardView.append(secTheme);

    const secSplit = mkSection('Scherm');
    secSplit.append(mkRow('Splitscreen',
      mkSwitch(st.splitScreen !== false, v => {
        st.splitScreen = v;
        persist();
        if (!st.splitScreen && getSplitLeft() && getSplitRight()) {
          setSplitRight(null);
          renderMiniAppView();
        }
      }),
      'Naast de terugknop een knop om twee apps naast elkaar te openen.'));
    const recentMaxRow = mkRow('Max. open apps',
      mkSelect(
        [[1, '1'], [2, '2'], [3, '3'], [4, '4'], [5, '5'], [6, '6'], [7, '7'], [8, '8']],
        Math.min(8, Math.max(1, Number(st.recentAppsMax) || 3)),
        v => {
          st.recentAppsMax = Number(v) || 3;
          persist();
          // Als limiet lager is dan huidige stack: oudste sluiten
          const max = getRecentAppsMax();
          while (getRecentApps().length > max) {
            const dropped = getRecentApps().pop();
            try { if (dropped && typeof dropped.close === 'function') dropped.close(); } catch (_) {}
          }
        }
      ),
      'Hoeveel apps tegelijk in Recente apps mogen staan. Bij een extra app krijg je een melding om er één te sluiten of dit limiet te verhogen.');
    recentMaxRow.id = 'settings-recent-apps-max';
    secSplit.append(recentMaxRow);
    cardView.append(secSplit);

    const secAcc = mkSection('Toegankelijkheid');
    const swMotionView = mkSwitch(!!st.reduceMotion, (v, inp) => {
      st.reduceMotion = v;
      const o = document.getElementById('settings-reduce-motion-perf');
      if (o) o.checked = v;
      persist();
    }, 'settings-reduce-motion-view');
    secAcc.append(mkRow('Minder beweging', swMotionView, 'Schakelt animaties en overgangen uit.'));
    cardView.append(secAcc);
    paneView.append(cardView);

    // ========== PRESTATIES ==========
    const cardPerf = el('div', 'settings-card');

    const secStatus = mkSection('Status');
    const fpsVal = el('span', 'settings-status-val', '…');
    fpsVal.id = 'settings-fps-live';
    const thrVal = el('span', 'settings-status-val', 'normaal');
    thrVal.id = 'settings-thr-live';
    secStatus.append(mkRow('Framerate', fpsVal, 'Live gemeten beelden per seconde. Wordt elke 100 ms bijgewerkt.'));
    secStatus.append(mkRow('Laden', thrVal, 'Of de app momenteel downloads/verwerking vertraagt om soepel te blijven.'));
    cardPerf.append(secStatus);

    const secThr = mkSection('Laden vertragen');
    secThr.append(mkRow('Automatisch vertragen',
      mkSwitch(st.loadThrottle !== false, v => { st.loadThrottle = v; persist(); }),
      'Als de framerate onder de drempel zakt, pauzeert het laden even. Uit = zo snel mogelijk laden.'));
    secThr.append(mkRow('Drempel (FPS)',
      mkSelect(
        [[20, '20 fps'], [24, '24 fps'], [30, '30 fps'], [40, '40 fps'], [50, '50 fps']],
        Number(st.loadMinFps) || 30,
        v => { st.loadMinFps = Number(v) || 30; persist(); }
      ),
      'Onder deze framerate wordt laden vertraagd. Hoger = soepeler UI, lager = sneller laden.'));
    secThr.append(mkRow('Max. pauze',
      mkSelect(
        [[60, 'Kort (60 ms)'], [120, 'Normaal (120 ms)'], [200, 'Lang (200 ms)'], [350, 'Zeer lang (350 ms)']],
        Number(st.loadThrottleMs) || 120,
        v => { st.loadThrottleMs = Number(v) || 120; persist(); }
      ),
      'Maximale wachttijd per adempauze bij lage FPS. Hoger = minder vastlopers, trager laden.'));
    cardPerf.append(secThr);

    const secCap = mkSection('CPU & multitasking');
    secCap.append(mkRow('Maximum FPS',
      mkSelect(
        [[0, 'Onbeperkt'], [30, '30 fps'], [60, '60 fps'], [90, '90 fps'], [120, '120 fps']],
        Number(st.maxFps) || 0,
        v => { st.maxFps = Number(v) || 0; persist(); }
      ),
      'Plafond voor de framerate. Lager = minder CPU, handig als je naast Leo Crucis andere apps open hebt.'));
    secCap.append(mkRow('Laadkracht',
      mkSelect(
        [['low', 'Laag'], ['normal', 'Normaal'], ['high', 'Hoog'], ['max', 'Maximaal']],
        st.loadPower || 'normal',
        v => { st.loadPower = v; persist(); }
      ),
      'Hoe hard de app downloads en zwaar werk doorzet. Laag = meer ruimte voor andere programma\'s; Maximaal = snelst laden.'));
    secCap.append(mkRow('Parallelle downloads',
      mkSelect(
        [[1, '1 tegelijk'], [2, '2 tegelijk'], [3, '3 tegelijk'], [4, '4 tegelijk']],
        Number(st.loadConcurrency) || 2,
        v => { st.loadConcurrency = Number(v) || 2; persist(); }
      ),
      'Hoeveel bestanden (bijv. woordenboek-letters) tegelijk worden opgehaald. Lager = rustiger voor CPU en schijf.'));
    secCap.append(mkRow('Hardwareversnelling',
      mkSwitch(st.hwAccel !== false, v => { st.hwAccel = v; persist(); }),
      'Gebruik GPU voor weergave. Uitzetten kan helpen bij rare stuurprogramma\'s of oververhitting.'));
    secCap.append(mkRow('Mediakwaliteit',
      mkSelect(
        [['high', 'Hoog'], ['normal', 'Normaal'], ['low', 'Laag']],
        st.mediaQuality || 'normal',
        v => { st.mediaQuality = v; persist(); }
      ),
      'Kwaliteit van afbeeldingen in galerij en media. Lager = sneller en minder geheugen.'));
    cardPerf.append(secCap);

    const secCache = mkSection('Onderhoud');
    const btnClear = el('button', 'menu-reset settings-action-btn', 'Cache wissen');
    btnClear.type = 'button';
    btnClear.onclick = async () => {
      const ok = await ask('Tijdelijke cache wissen? Instellingen, boeken en studie blijven bewaard.', { yes: 'Wissen', no: 'Annuleren' });
      if (!ok) return;
      const removed = clearAppCache();
      try { await ask('Cache gewist (' + removed.length + ' items). Herlaad zware onderdelen indien nodig.', { yes: 'OK' }); } catch (_) {}
    };
    secCache.append(mkRow('Tijdelijke data', btnClear,
      'Wist zoekgeschiedenis, posities en andere tijdelijke caches. Instellingen en inhoud blijven intact.'));
    cardPerf.append(secCache);

    const secLoad = mkSection('Start & laden');
    secLoad.append(mkRow('Zoekindex',
      mkSelect(
        [['ondemand', 'Op aanvraag'], ['startup', 'Bij opstarten']],
        st.searchIndexMode || 'ondemand',
        v => { st.searchIndexMode = v; persist(); }
      ),
      'Op aanvraag: index laadt pas bij zoeken (snellere start). Bij opstarten: meteen laden op de achtergrond.'));
    secLoad.append(mkRow('Sessie herstellen',
      mkSwitch(st.restoreSession !== false, v => { st.restoreSession = v; persist(); }),
      'Bij de volgende start het laatst geopende scherm proberen te herstellen.'));
    secLoad.append(mkRow('Achtergrondtaken',
      mkSwitch(st.backgroundTasks !== false, v => { st.backgroundTasks = v; persist(); }),
      'Periodieke map-scans en auto-refresh. Uit = minder CPU als de app open blijft.'));
    cardPerf.append(secLoad);

    const secPdf = mkSection('Documenten');
    secPdf.append(mkRow('PDF-kwaliteit',
      mkSelect(
        [['fast', 'Snel'], ['normal', 'Normaal'], ['sharp', 'Scherp']],
        st.pdfQuality || 'normal',
        v => { st.pdfQuality = v; persist(); }
      ),
      'Snel = sneller bladeren, minder scherp. Scherp = hogere resolutie, meer geheugen.'));
    cardPerf.append(secPdf);

    const secMotion = mkSection('Beweging');
    const swMotionPerf = mkSwitch(!!st.reduceMotion, (v) => {
      st.reduceMotion = v;
      const o = document.getElementById('settings-reduce-motion-view');
      if (o) o.checked = v;
      persist();
    }, 'settings-reduce-motion-perf');
    secMotion.append(mkRow('Minder beweging', swMotionPerf, 'Schakelt animaties volledig uit — lichter voor de processor.'));
    secMotion.append(mkRow('Animatieduur',
      mkSelect(
        [['off', 'Uit'], ['short', 'Kort'], ['normal', 'Normaal']],
        st.animDuration || 'normal',
        v => { st.animDuration = v; persist(); }
      ),
      'Korter of uit = snellere, lichtere interface. "Minder beweging" zet alles uit ongeacht deze keuze.'));
    cardPerf.append(secMotion);
    panePerf.append(cardPerf);

    const fpsTimer = setInterval(() => {
      if (!document.getElementById('settings-fps-live')) { clearInterval(fpsTimer); return; }
      try {
        const f = getFps();
        const fpsEl = document.getElementById('settings-fps-live');
        const thrEl = document.getElementById('settings-thr-live');
        if (fpsEl) fpsEl.textContent = f + ' fps';
        if (thrEl) {
          const thr = isThrottling();
          thrEl.textContent = thr
            ? 'vertraagd'
            : (st.loadThrottle === false ? 'vertragen uit' : 'normaal');
          thrEl.style.color = thr ? 'var(--acc)' : '';
        }
      } catch (_) {}
    }, 100);

    // ========== MAIN ==========
    const card2 = el('div', 'settings-card');
    const secApp = mkSection('App');
    if (inTauri) {
      secApp.append(mkRow('Volledig scherm',
        mkSwitch(st.fullscreen !== false, async (v) => {
          st.fullscreen = v;
          persist();
          try {
            const win = getTauriWindow();
            if (win?.setFullscreen) await win.setFullscreen(!!st.fullscreen || !!st.focusMode);
          } catch (e) { console.warn(e); }
        }),
        'De bibliotheek opent in fullscreen. Uit = venstermodus.'));
    } else {
      secApp.append(el('p', 'settings-hint', 'Volledig scherm is alleen beschikbaar in de desktop-app.'));
    }
    card2.append(secApp);

    const secDev = mkSection('Ontwikkeling');
    secDev.append(el('p', 'settings-hint',
      'Editor is altijd actief: je kunt boeken, secties en teksten aanpassen. Hieronder extra hulpmiddelen.'));

    const mkActionBtn = (label, title, onClick) => {
      const b = el('button', 'menu-reset settings-action-btn', label);
      b.type = 'button';
      b.title = title;
      b.onclick = onClick;
      return b;
    };
    const mkActionsRow = (...btns) => {
      const actions = el('div', 'settings-actions');
      for (const b of btns) if (b) actions.append(b);
      return actions;
    };

    if (inTauri) {
      secDev.append(mkRow('Stad-map',
        mkActionsRow(mkActionBtn('📂 Map openen', 'Open de map met gebouwen en boeken (stad)', () => {
          openFolder().catch(e => ask('Map openen mislukt: ' + e, { yes: 'OK' }));
        })),
        'Map met gebouwen en boeken. Nieuwe mappen en .html/.pdf verschijnen automatisch (of na “Opnieuw scannen”).'));

      secDev.append(mkRow('Stad opnieuw scannen',
        mkActionsRow(mkActionBtn('🔄 Scannen', 'Lees de stad-map opnieuw en voeg nieuwe bestanden toe', async () => {
          try {
            await rescanStad(true);
            await ask('Stad-map opnieuw gelezen. Nieuwe bestanden en covers zijn bijgewerkt.', { yes: 'OK' });
            if (home.style.display !== 'none') renderWorld();
          } catch (e) {
            await ask('Scannen mislukt: ' + e, { yes: 'OK' });
          }
        })),
        'Zoekt nieuwe HTML/PDF’s en covers in de gebruikersmap zonder de app te herstarten.'));

      secDev.append(mkRow('Media-mappen',
        mkActionsRow(
          mkActionBtn('🎵 Audio', 'Open de map media/music', () => {
            openMediaFolder('audio').catch(e => ask('Map openen mislukt: ' + e, { yes: 'OK' }));
          }),
          mkActionBtn('🎬 Video', 'Open de map media/video', () => {
            openMediaFolder('video').catch(e => ask('Map openen mislukt: ' + e, { yes: 'OK' }));
          })
        ),
        'Open de mappen voor audiobestanden en video’s in de bestandsverkenner.'));

      secDev.append(mkRow('Gebundelde boeken opnieuw exporteren',
        mkActionsRow(mkActionBtn('📤 Opnieuw exporteren', 'Kopieer ontbrekende meegeleverde boeken opnieuw naar de stad-map', async () => {
          const ok = await ask('Ontbrekende meegeleverde boeken opnieuw naar de stad-map kopiëren? Bestaande bestanden worden niet overschreven.', { yes: 'Exporteren', no: 'Annuleren' });
          if (!ok) return;
          try {
            try { localStorage.removeItem('lc-stad-exported'); } catch (_) {}
            await exportBundledBooks();
            await ask('Export afgerond. Ontbrekende boeken staan in de stad-map.', { yes: 'OK' });
          } catch (e) {
            await ask('Exporteren mislukt: ' + e, { yes: 'OK' });
          }
        })),
        'Eenmalige export-vlag wissen en ontbrekende standaardboeken opnieuw wegschrijven.'));
    } else {
      secDev.append(el('p', 'settings-hint',
        'Bestands- en map-opties zijn alleen beschikbaar in de desktop-app (Tauri). In de browser blijven bewerkingen in localStorage.'));
    }

    secDev.append(mkRow('Bibliotheek hertekenen',
      mkActionsRow(mkActionBtn('🔃 Vernieuwen', 'Teken de stad en secties opnieuw', () => {
        try { renderWorld(); } catch (e) { console.warn(e); }
      })),
      'Forceert een hertekening van de huidige weergave (handig na handmatige wijzigingen).'));

    card2.append(secDev);
    paneMain.append(card2);

    // ========== INFO ==========
    const cardInfo = el('div', 'settings-card settings-card-info-compact');
    const secAbout = mkSection('Over');
    secAbout.append(el('p', 'settings-hint', APP_NAME + ' · versie ' + APP_VERSION));
    secAbout.append(el('p', 'settings-hint', inTauri ? 'Desktop-app (Tauri)' : 'Browserversie'));

    const helpActions = [];
    if (typeof showShortcutsHelp === 'function') {
      helpActions.push(mkActionBtn('⌨️ Sneltoetsen', 'Toon sneltoetsen', () => {
        try { showShortcutsHelp(); } catch (e) { console.warn(e); }
      }));
    }
    if (typeof restartOnboarding === 'function') {
      helpActions.push(mkActionBtn('👋 Rondleiding', 'Start de introductie opnieuw', () => {
        try { restartOnboarding(); } catch (e) { console.warn(e); }
      }));
    }
    if (helpActions.length) {
      secAbout.append(mkRow(
        'Hulp',
        mkActionsRow(...helpActions),
        'Sneltoetsen (ook via ?) en de eerste-keer-rondleiding.'
      ));
    }

    const secSources = mkSection('Bronnen');
    secSources.append(el('p', 'settings-hint',
      'Teksten en data in Leo Crucis komen uit open of publiekdomein-bronnen. Hieronder een overzicht.'));

    const sourceGroups = [
      {
        title: 'Bijbelteksten',
        items: [
          ['Petrus Canisiusvertaling (1939)', 'Nederlandse katholieke vertaling; in de app als vertaling “Canisius”.'],
          ['Vulgaat (Clementina)', 'Latijnse Bijbeltekst via @bible-api/bible-api-version-vulgate (MIT-0); tekst publiek domein.'],
          ['Oorspronkelijke talen — OT', 'Westminster Leningrad Codex (Hebreeuws), publiek domein; via midvash/bible-data.'],
          ['Oorspronkelijke talen — deuterocanoniek', 'Septuaginta (editie H. B. Swete), Grieks; via nathans/lxx-swete (CC BY-SA 4.0 op de digitale bewerking).'],
          ['Oorspronkelijke talen — NT', 'Textus Receptus (Stephanus 1550), Grieks; publiek domein via midvash/bible-data.'],
        ],
      },
      {
        title: 'Bijbelstudie & verdieping',
        items: [
          ['Verdiepingsmeta (kruisverwijzingen, context, woordstudie)', 'Eigen samengestelde metadata per vers in data/bijbel-meta/.'],
          ['Bijbelleesplan (364 dagen)', 'Eigen leesplan op RKK-canon (inclusief deuterocanonieke boeken).'],
        ],
      },
      {
        title: 'Canoniek recht',
        items: [
          ['Codex Iuris Canonici 1917 (Latijn)', 'Volledige Latijnse tekst, public domain (Typis Polyglottis Vaticanis 1917 / Wikisource). Canones 1–2414.'],
          ['Nederlandse vertaling (can. 1–10)', 'Vertaling van Leo Crucis zelf, op basis van de Latijnse tekst van 1917. Meer canones volgen.'],
        ],
      },
      {
        title: 'Woordenboeken',
        items: [
          ['Nederlands woordenboek', 'Ingebouwde woorddata van de app (data/woordenboek/).'],
          ['Nederlands → Latijn', 'FreeDict (GNU GPL v2+), via Engels/Duits-routes, aangevuld met handmatige nagekeken lemma’s.'],
          ['Nederlands → Frans', 'FreeDict (GNU GPL v2+), vergelijkbare opbouw als het Latijnse woordenboek.'],
          ['Hebreeuws & Grieks → Nederlands (Strong’s)', 'Open Scriptures Strong’s Dictionaries (CC BY-SA / tekst publiek domein 1890–1894); Nederlandse gloss als studiehulp.'],
        ],
      },
      {
        title: 'Overig',
        items: [
          ['App-framework', 'Web-UI; desktop via Tauri waar van toepassing.'],
          ['Lettertypes (oorspronkelijke talen)', 'Aanbevolen: SBL Hebrew / SBL Greek of vergelijkbare open lettertypes op het systeem.'],
        ],
      },
    ];

    for (const g of sourceGroups) {
      const box = el('div', 'settings-sources-group');
      box.append(el('h3', 'settings-sources-title', g.title));
      const ul = el('ul', 'settings-sources-list');
      for (const [name, note] of g.items) {
        const li = el('li', 'settings-sources-item');
        li.append(el('strong', '', name));
        li.append(el('span', 'settings-sources-note', note));
        ul.append(li);
      }
      box.append(ul);
      secSources.append(box);
    }
    secSources.append(el('p', 'settings-hint',
      'Licenties van brondata blijven van toepassing. Controleer bij hergebruik altijd de originele voorwaarden.'));

    // ---------- Functies-overzicht ----------
    const secFeatures = mkSection('Functies');
    secFeatures.append(el('p', 'settings-hint',
      'Overzicht van de belangrijkste mogelijkheden in Leo Crucis.'));

    const featureGroups = [
      {
        title: 'Stad & bibliotheek',
        items: [
          ['Gebouw-carrousel', 'Op het startscherm bladert u tussen gebouwtegels (cover, secties, boeken). Tik om te openen.'],
          ['Kamers & kasten', 'Elk gebouw heeft themakamers met documenten, boeken en naslag.'],
          ['Documenten lezen', 'HTML-boeken, PDF’s, presentaties (PowerPoint) en spreadsheets (Excel).'],
          ['Eigen bestanden', 'Desktop-app: zet mappen en .html/.pdf in de stad-map; ze verschijnen als sectie “Eigen boeken”. Nieuwe gebouwen verschijnen in de start-carrousel.'],
          ['Zoeken', 'Doorzoek boeken, documenten en inhoud met de zoekindex.'],
        ],
      },
      {
        title: 'Bijbel & studie',
        items: [
          ['Bijbellezer', 'Meerdere vertalingen (o.a. Canisius, Vulgaat) en oorspronkelijke talen.'],
          ['Verdieping', 'Kruisverwijzingen, context, woordstudie en manuscriptinfo per vers.'],
          ['Bijbelgrafieken', 'Visuele kaart van kruisverwijzingen en verbanden tussen verzen.'],
          ['Bijbelleesplan', '364-dagen leesplan op RKK-canon (inclusief deuterocanonieke boeken).'],
          ['Codex 1917', 'Codex Iuris Canonici 1917 (Latijn; NL-vertaling Leo Crucis voor can. 1–10).'],
          ['Focus / studieblok', 'Getimede studiemodi met prestaties en weekoverzicht.'],
        ],
      },
      {
        title: 'Woordenboeken & taal',
        items: [
          ['Nederlands woordenboek', 'Ingebouwde lemma’s met uitleg.'],
          ['Nederlands → Latijn', 'Vertaling en opzoeken van Latijnse woorden.'],
          ['Nederlands → Frans', 'Vertaling en opzoeken van Franse woorden.'],
          ['Strong’s (Hebreeuws & Grieks)', 'Originele-taal lemma’s met Nederlandse gloss in woordstudie.'],
        ],
      },
      {
        title: 'Media & beeld',
        items: [
          ['Audiospeler', 'Afspelen van audiobestanden uit de mediabibliotheek.'],
          ['Videospeler', 'Video afspelen (beperkt tijdens focusblok).'],
          ['Kunstgalerij', 'Bekijk en blader door afbeeldingen.'],
          ['Fotoalbum', 'Persoonlijke of thematische fotoalbums.'],
          ['Atlas', 'Atlas met kaarten en geografische overzichten.'],
        ],
      },
      {
        title: 'Productiviteit & overig',
        items: [
          ['Kalender', 'Agenda met liturgische kalender en feestdagen.'],
          ['Notities', 'Snel notities maken en bewaren.'],
          ['Gamemanager', 'Spellen (o.a. Tetris) als ontspanning.'],
          ['Splitscreen', 'Twee mini-apps naast elkaar openen.'],
          ['Instellingen', 'Weergave, Bijbel, prestaties, cache en meer.'],
          ['Editor (altijd aan)', 'Boeken, secties en teksten bewerken; developer-opties onder Instellingen → Main → Ontwikkeling.'],
        ],
      },
    ];

    for (const g of featureGroups) {
      const box = el('div', 'settings-sources-group');
      box.append(el('h3', 'settings-sources-title', g.title));
      const ul = el('ul', 'settings-sources-list');
      for (const [name, note] of g.items) {
        const li = el('li', 'settings-sources-item');
        li.append(el('strong', '', name));
        li.append(el('span', 'settings-sources-note', note));
        ul.append(li);
      }
      box.append(ul);
      secFeatures.append(box);
    }

    const secStats = mkSection('Inhoud & opslag');
    const statsBox = el('div', 'settings-stats');
    statsBox.append(el('p', 'settings-hint', 'Gegevens worden berekend…'));
    secStats.append(statsBox);

    // 2 kolommen: links Over + Inhoud, rechts Bronnen; Functies over volle breedte
    const colLeft = el('div', 'settings-info-col');
    colLeft.append(secAbout, secStats);
    const colRight = el('div', 'settings-info-col');
    colRight.append(secSources);
    cardInfo.append(colLeft, colRight);
    secFeatures.classList.add('settings-features-full');
    cardInfo.append(secFeatures);
    paneInfo.append(cardInfo);

    // Asynchroon statistieken vullen
    (async () => {
      const fmtN = n => new Intl.NumberFormat('nl-BE').format(n || 0);
      const fmtBytes = n => {
        n = Number(n) || 0;
        if (n < 1024) return n + ' B';
        if (n < 1024 * 1024) return (n / 1024).toFixed(1).replace('.', ',') + ' KB';
        if (n < 1024 * 1024 * 1024) return (n / (1024 * 1024)).toFixed(1).replace('.', ',') + ' MB';
        return (n / (1024 * 1024 * 1024)).toFixed(2).replace('.', ',') + ' GB';
      };
      const row = (label, value) => {
        const r = el('div', 'settings-stat-row');
        r.append(el('span', 'settings-stat-label', label), el('span', 'settings-stat-value', value));
        return r;
      };
      const head = t => el('h3', 'settings-stat-group', t);

      const items = allItems();
      const byType = { doc: 0, pdf: 0, pptx: 0, xlsx: 0, bible: 0, dictionary: 0, other: 0 };
      for (const it of items) {
        const t = it.type || 'doc';
        if (byType[t] != null) byType[t]++;
        else byType.other++;
      }
      const buildings = (world.buildings || []).length;
      const rooms = (world.buildings || []).reduce((s, b) => s + ((b.rooms || []).length), 0);

      let wbWords = 0, wbLetters = 0, wbLa = 0, wbFr = 0;
      try {
        const idx = await fetch('data/woordenboek/index.json').then(r => r.ok ? r.json() : null);
        if (idx) {
          wbWords = idx.words || 0;
          wbLetters = Object.keys(idx.letters || {}).length;
        }
      } catch (_) {}
      try {
        const la = await fetch('data/woordenboek-latijn/nl-la.json').then(r => r.ok ? r.json() : null);
        if (la) wbLa = (la.meta && la.meta.entries) || (la.entries && la.entries.length) || 0;
      } catch (_) {}
      try {
        const fr = await fetch('data/woordenboek-frans/nl-fr.json').then(r => r.ok ? r.json() : null);
        if (fr) wbFr = (fr.meta && fr.meta.entries) || (fr.entries && fr.entries.length) || 0;
      } catch (_) {}

      let bbBooks = 0, bbTr = 0, bbVerses = 0;
      try {
        const idx = await fetch('data/bijbel/index.json').then(r => r.ok ? r.json() : null);
        if (idx) {
          bbBooks = (idx.books || []).length;
          bbTr = (idx.translations || []).length;
          bbVerses = (idx.books || []).reduce((s, b) => s + (b.v || 0), 0);
        }
      } catch (_) {}

      // Bijbel-verdieping (meta): verzen met diepte, kruisverwijzingen, manuscripten, context, woordstudies
      let bbMetaVerses = 0, bbMetaXrefs = 0, bbMetaMss = 0, bbMetaContext = 0, bbMetaWords = 0, bbMetaChapters = 0;
      try {
        const metaIdx = await fetch('data/bijbel-meta/index.json').then(r => r.ok ? r.json() : null);
        if (metaIdx && metaIdx.stats) {
          const s = metaIdx.stats;
          bbMetaVerses = s.verses_with_depth || 0;
          bbMetaXrefs = s.cross_references || 0;
          bbMetaMss = s.unique_manuscripts || 0;
          bbMetaContext = s.verses_with_context || 0;
          bbMetaWords = s.word_studies || 0;
          bbMetaChapters = s.chapters_with_meta || 0;
        }
      } catch (_) {}

      let fotos = 0;
      try {
        const g = await fetch('data/media-library.json').then(r => r.ok ? r.json() : null);
        if (g && Array.isArray(g.items)) fotos = g.items.length;
        else if (g && Array.isArray(g)) fotos = g.length;
      } catch (_) {}

      let searchDocs = 0;
      try {
        const docs = await fetch('data/search-index.json').then(r => r.ok ? r.json() : null);
        if (docs) searchDocs = Array.isArray(docs) ? docs.length : (docs.docs ? docs.docs.length : 0);
      } catch (_) {}

      async function sizeOf(url) {
        try {
          const res = await fetch(url);
          if (!res.ok) return 0;
          const buf = await res.arrayBuffer();
          return buf.byteLength;
        } catch { return 0; }
      }
      const sizes = await Promise.all([
        sizeOf('data/woordenboek/index.json'),
        sizeOf('data/search-index.json'),
        sizeOf('data/bijbel/index.json'),
        sizeOf('data/book-paths.json'),
        sizeOf('data/woordenboek-latijn/nl-la.json'),
        sizeOf('data/woordenboek-frans/nl-fr.json'),
      ]);
      let wbDataBytes = sizes[0];
      try {
        const letters = 'abcdefghijklmnopqrstuvwxyz#'.split('');
        const letterSizes = await Promise.all(letters.map(L => sizeOf('data/woordenboek/' + encodeURIComponent(L) + '.json')));
        wbDataBytes = letterSizes.reduce((a, b) => a + b, sizes[0]);
      } catch (_) {}

      let bijbelDataBytes = sizes[2];
      try {
        const idx = await fetch('data/bijbel/index.json').then(r => r.ok ? r.json() : null);
        if (idx && idx.translations && idx.books) {
          const tr = idx.translations[0];
          const sample = (idx.books || []).slice(0, 8);
          const sampleSizes = await Promise.all(sample.map(b => sizeOf(`data/bijbel/${tr.id}/${b.osis}.json`)));
          const avg = sampleSizes.filter(x => x > 0).reduce((a, b) => a + b, 0) / Math.max(1, sampleSizes.filter(x => x > 0).length);
          bijbelDataBytes = Math.round(avg * (idx.books || []).length * (idx.translations || []).length);
        }
      } catch (_) {}

      let lsBytes = 0;
      try {
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          lsBytes += (k || '').length * 2 + (localStorage.getItem(k) || '').length * 2;
        }
      } catch (_) {}

      const totalData = wbDataBytes + bijbelDataBytes + sizes[1] + sizes[3] + (sizes[4]||0) + (sizes[5]||0) + lsBytes;

      statsBox.replaceChildren();
      const col = (title, rows) => {
        const c = el('div', 'settings-stat-col');
        c.append(head(title));
        for (const [lab, val] of rows) c.append(row(lab, val));
        return c;
      };

      statsBox.append(col('Bibliotheek', [
        ['Gebouwen', fmtN(buildings)],
        ['Secties (kamers)', fmtN(rooms)],
        ['Boeken & documenten (totaal)', fmtN(items.length)],
        ['— Documenten', fmtN(byType.doc)],
        ["— PDF's", fmtN(byType.pdf)],
        ['— Presentaties (PowerPoint)', fmtN(byType.pptx)],
        ['— Spreadsheets (Excel)', fmtN(byType.xlsx)],
        ...(byType.bible ? [['— Bijbel-items', fmtN(byType.bible)]] : []),
        ...(byType.dictionary ? [['— Woordenboek-items', fmtN(byType.dictionary)]] : []),
        ...(byType.other ? [['— Overig', fmtN(byType.other)]] : []),
      ]));
      statsBox.append(col('Woordenboek', [
        ['Nederlands (lemma\'s)', fmtN(wbWords)],
        ['Nederlands → Latijn', fmtN(wbLa)],
        ['Nederlands → Frans', fmtN(wbFr)],
        ['Letterbestanden (NL)', fmtN(wbLetters)],
        ['Geschatte data (NL)', fmtBytes(wbDataBytes)],
      ]));
      statsBox.append(col('Bijbel', [
        ['Boeken', fmtN(bbBooks)],
        ['Vertalingen', fmtN(bbTr)],
        ['Verzen (totaal)', fmtN(bbVerses)],
        ['Geschatte data', fmtBytes(bijbelDataBytes)],
      ]));
      statsBox.append(col('Bijbelinfo (verdieping)', [
        ['Verzen met verdieping', fmtN(bbMetaVerses)],
        ['Kruisverwijzingen (totaal)', fmtN(bbMetaXrefs)],
        ['Verschillende manuscripten', fmtN(bbMetaMss)],
        ['Verzen met context', fmtN(bbMetaContext)],
        ['Woorden met woordstudie', fmtN(bbMetaWords)],
        ['Hoofdstukken met meta', fmtN(bbMetaChapters)],
      ]));
      statsBox.append(col('Overig', [
        ["Foto's (kunstgalerij)", fmtN(fotos)],
        ['Zoekindex-fragmenten', fmtN(searchDocs)],
        ['Zoekindex-bestand', fmtBytes(sizes[1])],
      ]));
      statsBox.append(col('Opslag', [
        ['localStorage (instellingen & cache)', fmtBytes(lsBytes)],
        ['Geschatte offline data (totaal)', fmtBytes(totalData)],
      ]));
      const note = el('p', 'settings-stats-note');
      note.textContent = 'Opslagcijfers zijn schattingen op basis van geladen bestanden. Eigen toegevoegde boeken in de desktop-app tellen hier niet volledig mee.';
      statsBox.append(note);
    })().catch(err => {
      statsBox.replaceChildren(el('p', 'settings-hint', 'Statistieken laden mislukt: ' + ((err && err.message) || err)));
    });

    // ========== BIJBEL ==========
    const cardBible = el('div', 'settings-card');
    const secDepth = mkSection('Verdieping');
    secDepth.append(mkRow(
      'Markeer verzen met/zonder verdieping',
      mkSwitch(st.bibleMarkDepth !== false, v => {
        st.bibleMarkDepth = v;
        persist();
      }),
      'Aan: verzen mét verdieping in zwart, verzen zonder in grijs. Uit: alle tekst dezelfde kleur. Versnummers blijven altijd rood.'
    ));
    cardBible.append(secDepth);

    const secPlan = mkSection('Leesplan');
    const minReadSel = el('select', 'settings-select');
    minReadSel.setAttribute('aria-label', 'Minimale leestijd per dag');
    const minReadOpts = [
      [1, '1 minuut'],
      [2, '2 minuten'],
      [3, '3 minuten'],
      [5, '5 minuten'],
      [10, '10 minuten'],
      [15, '15 minuten'],
      [20, '20 minuten'],
      [30, '30 minuten'],
    ];
    const curMin = Math.max(1, Math.min(120, Number(st.biblePlanMinReadMin) || 5));
    for (const [v, lab] of minReadOpts) {
      const o = el('option', '', lab);
      o.value = String(v);
      if (v === curMin) o.selected = true;
      minReadSel.append(o);
    }
    // custom waarde behouden als die niet in de lijst zit
    if (!minReadOpts.some(([v]) => v === curMin)) {
      const o = el('option', '', curMin + ' minuten');
      o.value = String(curMin);
      o.selected = true;
      minReadSel.append(o);
    }
    minReadSel.onchange = () => {
      st.biblePlanMinReadMin = Math.max(1, Math.min(120, parseInt(minReadSel.value, 10) || 5));
      persist();
    };
    secPlan.append(mkRow(
      'Minimale leestijd per dag',
      minReadSel,
      'Hoe lang je een leesplan-dag moet open hebben vóór je die mag afronden. Voorkomt te snel doorklikken.'
    ));
    cardBible.append(secPlan);
    paneBible.append(cardBible);

    panel.append(paneMain, paneView, paneBible, panePerf, paneInfo);
    viewContent.append(panel);
    home.style.display = 'none';
    view.style.display = 'block';
    setHash('#settings');
    const settingsEntry = {
      id: 'app-settings',
      kind: 'app',
      iconKind: 'focus',
      title: 'Instellingen',
      hint: 'App',
      activate: () => showSettings(),
      close: () => {
        try {
          const h = (location.hash || '').replace(/^#/, '');
          if (h === 'settings' || h === 'instellingen') showHome();
        } catch (_) {}
      }
    };
    if (force) {
      // Altijd toelaten (vanaf limiet-popup); maak ruimte door oudste andere app te sluiten
      recentApi.setList(recentApi.getList().filter(e => e.id !== 'app-settings')); getRecentApps() = recentApi.getList();
      getRecentApps().unshift(settingsEntry);
      const max = getRecentAppsMax();
      while (getRecentApps().length > max) {
        let dropped = null;
        for (let j = getRecentApps().length - 1; j >= 0; j--) {
          if (getRecentApps()[j].id !== 'app-settings') {
            dropped = getRecentApps().splice(j, 1)[0];
            break;
          }
        }
        if (!dropped) break;
        try { if (dropped.close) dropped.close(); } catch (_) {}
      }
    } else {
      pushRecentApp(settingsEntry);
    }

    window.scrollTo(0, 0);
    back.focus();
  }

  return { showSettings };
}
