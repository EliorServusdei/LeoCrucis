/**
 * apps/registry.js — catalogus van mini-apps + factory.
 *
 * De *run*-acties (showMiniApp, showFocus, …) blijven in app.js;
 * hier staat alleen metadata + createMiniAppInstance.
 *
 * Fase 1: zware apps worden lazy geladen via dynamic import().
 *
 * Gebruik:
 *   import { MINI_APP_ICONS, miniAppIconSvg, APP_CATALOG, createMiniAppInstance } from '../apps/registry.js';
 */

import { svgIcon } from '../core/dom.js';
import { normalizeMiniApp, restoreMiniApp } from '../core/mini-app.js';

/** SVG-paden — strakkere Lucide-achtige iconen (header + apps). */
export const MINI_APP_ICONS = {
  audio: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  video: '<path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5"/><rect x="2" y="6" width="14" height="12" rx="2"/>',
  calendar: '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/>',
  notes: '<path d="M15.5 3H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2V8.5L15.5 3z"/><path d="M15 3v6h6"/><path d="M10 13h4"/><path d="M10 17h4"/><path d="M8 13h.01"/><path d="M8 17h.01"/>',
  'verse-study': '<path d="M12 7v14"/><path d="M16 12h2"/><path d="M16 8h2"/><path d="M16 16h2"/><path d="M8 12H6"/><path d="M8 8H6"/><path d="M8 16H6"/><path d="M19 17V5a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v12a4 4 0 0 0 4 4h6a4 4 0 0 0 4-4z"/>',
  bible: '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"/><path d="M8 7h6"/><path d="M8 11h8"/>',
  woordenboek: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/><path d="M8 11h6"/><path d="M11 8v6"/>',
  codex: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
  'xref-map': '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.59 13.51 15.42 17.49"/><path d="M15.41 6.51 8.59 10.49"/>',
  memory: '<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/>',
  snake: '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" x2="4" y1="22" y2="15"/>',
  bke: '<path d="M4 4l16 16"/><path d="M20 4L4 20"/><circle cx="12" cy="12" r="9"/>',
  tetris: '<rect x="4" y="4" width="6" height="6"/><rect x="10" y="4" width="6" height="6"/><rect x="10" y="10" width="6" height="6"/><rect x="16" y="10" width="4" height="6"/>',
  mastermind: '<circle cx="8" cy="8" r="3"/><circle cx="16" cy="8" r="3"/><circle cx="8" cy="16" r="3"/><circle cx="16" cy="16" r="3"/>',
  connect4: '<circle cx="6" cy="6" r="2.5"/><circle cx="12" cy="6" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="12" cy="12" r="2.5"/><circle cx="18" cy="12" r="2.5"/><circle cx="6" cy="18" r="2.5"/><circle cx="12" cy="18" r="2.5"/><circle cx="18" cy="18" r="2.5"/>',
  speeltoestel: '<path d="M6 12h4"/><path d="M8 10v4"/><path d="M15 13h.01"/><path d="M18 11h.01"/><rect width="20" height="12" x="2" y="6" rx="2"/>',
  gallery: '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
  album: '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
  maps: '<path d="m3 7 6-3 6 3 6-3v13l-6 3-6-3-6 3z"/><path d="M9 4v13"/><path d="M15 7v13"/>',
  focus: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
  doc: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
  pptx: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M8 12h8"/><path d="M8 16h5"/>',
  xlsx: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M8 13h2"/><path d="M14 13h2"/><path d="M8 17h2"/><path d="M14 17h2"/>',
  worldbuilding: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
  budgetter: '<rect x="4" y="2" width="16" height="20" rx="2"/><line x1="8" y1="6" x2="16" y2="6"/><line x1="8" y1="10" x2="16" y2="10"/><line x1="8" y1="14" x2="12" y2="14"/>',
  todo: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
  calculator: '<rect x="4" y="2" width="16" height="20" rx="2"/><line x1="8" y1="6" x2="16" y2="6"/><line x1="8" y1="10" x2="10" y2="10"/><line x1="14" y1="10" x2="16" y2="10"/><line x1="8" y1="14" x2="10" y2="14"/><line x1="14" y1="14" x2="16" y2="14"/><line x1="8" y1="18" x2="16" y2="18"/>',
  timer: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  browser: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  rozenkrans: '<circle cx="12" cy="8" r="2.5"/><circle cx="8" cy="12" r="2"/><circle cx="16" cy="12" r="2"/><circle cx="9" cy="16" r="2"/><circle cx="15" cy="16" r="2"/><path d="M12 10.5v3"/><path d="M10 20h4"/><path d="M12 17v3"/>',
};

export function miniAppIconSvg(kind, size = 28) {
  const paths = MINI_APP_ICONS[kind];
  if (!paths) return null;
  return svgIcon(paths, { width: size, height: size });
}

/**
 * Statische catalogus (zonder run-closures).
 * app.js vult `run` in bij listLeoApps().
 */
export const APP_CATALOG = [
  { kind: 'album', label: 'Album' },
  { kind: 'worldbuilding', label: 'Worldbuilding Studio' },
  { kind: 'audio', label: 'Audio' },
  { kind: 'bible', label: 'Bijbel' },
  { kind: 'codex', label: 'Codex' },
  { kind: 'xref-map', label: 'Xref-kaart' },
  { kind: 'calendar', label: 'Kalender' },
  { kind: 'doc', label: 'Document', create: true },
  { kind: 'focus', label: 'Focus / Studie' },
  { kind: 'memory', label: 'Memory' },
  { kind: 'snake', label: 'Slang' },
  { kind: 'bke', label: 'BKE' },
  { kind: 'tetris', label: 'Tetris' },
  { kind: 'mastermind', label: 'Mastermind' },
  { kind: 'connect4', label: '4 op een rij' },
  { kind: 'speeltoestel', label: 'Speeltoestel' },
  { kind: 'gallery', label: 'Galerij' },
  { kind: 'maps', label: 'Kaarten' },
  { kind: 'notes', label: 'Notities' },
  { kind: 'budgetter', label: 'Slim Budgetter' },
  { kind: 'todo', label: 'Taken' },
  { kind: 'calculator', label: 'Rekenmachine' },
  { kind: 'timer', label: 'Timer' },
  { kind: 'browser', label: 'Browser' },
  { kind: 'pptx', label: 'Presentatie', create: true },
  { kind: 'xlsx', label: 'Rekenblad', create: true },
  { kind: 'video', label: 'Video' },
  { kind: 'woordenboek', label: 'Woordenboek' },
  { kind: 'rozenkrans', label: 'Rozenkrans' }
];

/** Cache voor geladen factories (module-level). */
const _factoryCache = new Map();

/**
 * Lazy loaders voor zware apps. Lichte apps kunnen hier ook in,
 * maar de winst zit vooral bij calendar, spellen, xref-map, woordenboek, maps, album, bijbel.
 */
const LOADERS = {
  calendar: () => import('./calendar.js').then(m => m.createCalendarApp),
  notes: () => import('./notes.js').then(m => m.createNotesApp),
  budgetter: () => import('./budgetter.js').then(m => m.createBudgetterApp),
  todo: () => import('./todo.js').then(m => m.createTodoApp),
  calculator: () => import('./calculator.js').then(m => m.createCalculatorApp),
  timer: () => import('./timer.js').then(m => m.createTimerApp),
  browser: () => import('./browser.js').then(m => m.createBrowserApp),
  bible: () => import('./bijbel.js').then(m => m.createBijbelApp),
  'verse-study': () => import('./verse-study.js').then(m => m.createVerseStudyApp),
  woordenboek: () => import('./woordenboek.js').then(m => m.createWoordenboekApp),
  codex: () => import('./codex.js').then(m => m.createCodexApp),
  memory: () => import('../games/memory.js').then(m => m.createMemoryApp),
  snake: () => import('../games/snake.js').then(m => m.createSnakeApp),
  bke: () => import('../games/bke.js').then(m => m.createBkeApp),
  tetris: () => import('../games/tetris.js').then(m => m.createTetrisApp),
  mastermind: () => import('../games/mastermind.js').then(m => m.createMastermindApp),
  connect4: () => import('../games/connect4.js').then(m => m.createConnect4App),
  speeltoestel: () => import('../games/speeltoestel.js').then(m => m.createSpeeltoestelApp),
  gallery: () => import('./gallery.js').then(m => m.createGalleryApp),
  album: () => import('./album.js').then(m => m.createAlbumApp),
  maps: () => import('./maps.js').then(m => m.createMapsApp),
  worldbuilding: () => import('./worldbuilding/index.js').then(m => m.createWorldbuildingApp),
  'xref-map': () => import('./xref-map.js').then(m => m.createXrefMapApp),
  audio: () => import('../media/player.js').then(m => (kind, pos) => m.createMediaPlayer(kind || 'audio', pos)),
  video: () => import('../media/player.js').then(m => (kind, pos) => m.createMediaPlayer(kind || 'video', pos)),
  rozenkrans: () => import('./rozenkrans.js').then(m => m.createRozenkransApp),
};

/**
 * Laad de factory voor een kind (cached).
 * @param {string} kind
 * @returns {Promise<Function|null>}
 */
export async function loadMiniAppFactory(kind) {
  if (_factoryCache.has(kind)) return _factoryCache.get(kind);
  const loader = LOADERS[kind];
  if (!loader) return null;
  try {
    const factory = await loader();
    _factoryCache.set(kind, factory);
    return factory;
  } catch (e) {
    console.warn('Mini-app laden mislukt:', kind, e);
    return null;
  }
}

/**
 * Roep de factory aan en normaliseer naar MiniApp-contract.
 * @param {Function} factory
 * @param {string} kind
 * @param {*} startPos
 * @param {object|null} [saved]
 */
function invokeFactory(factory, kind, startPos, saved) {
  let raw;
  if (kind === 'audio' || kind === 'video') raw = factory(kind, startPos || null);
  else if (kind === 'bible' || kind === 'verse-study' || kind === 'codex' || kind === 'browser') raw = factory(startPos || null);
  else raw = factory();

  const app = normalizeMiniApp(raw, kind);
  if (app) restoreMiniApp(app, { startPos, saved });
  return app;
}

/**
 * Factory: maak een mini-app instantie (async-aware).
 * Altijd een genormaliseerd MiniApp-object (el/root/close/getState/…).
 *
 * @param {string} kind
 * @param {*} [startPos]
 * @param {{ saved?: object|null }} [opts]
 * @returns {import('../core/mini-app.js').MiniApp|null}
 */
export function createMiniAppInstance(kind, startPos, opts = {}) {
  const saved = opts && opts.saved ? opts.saved : null;
  const cached = _factoryCache.get(kind);
  if (cached) {
    try {
      return invokeFactory(cached, kind, startPos, saved);
    } catch (e) {
      console.warn('createMiniAppInstance', kind, e);
      return null;
    }
  }

  // Nog niet geladen: placeholder + async load
  const root = document.createElement('div');
  root.className = 'mini-app-root mini-app-loading';
  root.setAttribute('data-kind', kind);
  const label = document.createElement('p');
  label.className = 'mini-app-loading-label';
  label.textContent = 'Laden…';
  root.appendChild(label);

  const shell = normalizeMiniApp({ el: root, root, kind }, kind) || {
    el: root,
    root,
    kind,
    close: null,
  };
  shell._loading = true;

  loadMiniAppFactory(kind).then(factory => {
    if (!factory || (!root.isConnected && !root.parentNode)) return;
    try {
      const app = invokeFactory(factory, kind, startPos, saved);
      if (!app) {
        label.textContent = 'Kon app niet openen';
        return;
      }

      const appEl = app.el;
      const parent = root.parentNode;
      if (parent) {
        parent.replaceChild(appEl, root);
      } else {
        root.replaceChildren();
        root.appendChild(appEl);
        root.classList.remove('mini-app-loading');
      }

      // Shell bijwerken zodat host dezelfde referentie houdt
      Object.keys(shell).forEach(k => { try { delete shell[k]; } catch (_) {} });
      Object.assign(shell, app);
      shell._loading = false;
    } catch (e) {
      console.warn('Mini-app mount mislukt:', kind, e);
      label.textContent = 'Laden mislukt';
    }
  });

  return shell;
}

/**
 * Preload een of meer apps op de achtergrond (optioneel, bij idle).
 * @param {string[]} kinds
 */
export function preloadMiniApps(kinds = []) {
  for (const k of kinds) {
    if (!_factoryCache.has(k) && LOADERS[k]) {
      loadMiniAppFactory(k).catch(() => {});
    }
  }
}
