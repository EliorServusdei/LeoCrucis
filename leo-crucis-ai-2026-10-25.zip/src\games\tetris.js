// Tetris — zelfstandige mini-app.
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}


function injectGameBaseStyles() {
  if (document.getElementById('lc-game-base-styles')) return;
  const s = document.createElement('style');
  s.id = 'lc-game-base-styles';
  s.textContent = `
.app-panel.games-app{
  display:flex;flex-direction:column;gap:0;min-height:0;height:100%;
  background:var(--bg);color:var(--ink);
  font-family:"Courier New",Courier,ui-monospace,monospace;
  position:relative;overflow:auto;
  padding:12px;box-sizing:border-box;
}
.games-app .game-status{
  font-weight:800;font-size:13px;letter-spacing:.1em;text-transform:uppercase;
  color:var(--acc);text-align:center;padding:10px 12px 4px;
  text-shadow:0 0 8px rgba(155,188,15,.3);
}
.games-app .game-hint{
  margin:0;font-size:11px;color:var(--mute);opacity:.65;text-align:center;
  letter-spacing:.06em;padding:0 12px 8px;
}
.games-app .game-reset{
  border:2px solid var(--line);background:var(--panel);color:var(--acc);
  border-radius:4px;padding:8px 16px;cursor:pointer;font:inherit;
  font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;
  align-self:center;margin-top:8px;
}
.games-app .game-reset:hover{border-color:var(--acc);background:var(--sel);color:var(--acc2);}
.games-app .ttt-board{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:240px;margin:12px auto;width:100%;}
.games-app .ttt-cell{
  aspect-ratio:1;border:1px solid var(--line);border-radius:4px;
  background:var(--panel);color:var(--acc);font-weight:800;font-size:1.6rem;
  cursor:pointer;font-family:inherit;
}
.games-app .ttt-cell:hover:not(:disabled){
  border-color:var(--acc);background:var(--sel);
  box-shadow:0 0 10px rgba(155,188,15,.2);
}
.games-app .ttt-cell:disabled{cursor:default;opacity:.9;}
.games-app .snake-canvas{
  border:1px solid var(--line);border-radius:4px;
  box-shadow:0 0 12px rgba(155,188,15,.15);
  margin:0 auto;display:block;
}
`;
  document.head.append(s);
}

// ---------- Tetris ----------
const TT_COLS = 10, TT_ROWS = 20, TT_CELL = 24, TT_PREV = 20;
const TT_SHAPES = {
  I: [[0,0,0,0],[1,1,1,1],[0,0,0,0],[0,0,0,0]],
  O: [[1,1],[1,1]],
  T: [[0,1,0],[1,1,1],[0,0,0]],
  S: [[0,1,1],[1,1,0],[0,0,0]],
  Z: [[1,1,0],[0,1,1],[0,0,0]],
  J: [[1,0,0],[1,1,1],[0,0,0]],
  L: [[0,0,1],[1,1,1],[0,0,0]]
};
// Gedempte kleuren die bij het warme thema passen
const TT_COLORS = { I: '#4f9aa8', O: '#d3a63c', T: '#8a5a9e', S: '#5f9a55', Z: '#c45c4a', J: '#4f6fb0', L: '#d98a3d' };
const TT_BEST_KEY = 'lc-tetris-best';

function ttInjectStyles() {
  if (document.getElementById('tetris-styles')) return;
  const s = document.createElement('style');
  s.id = 'tetris-styles';
  s.textContent = `
.tt-wrap{display:flex;gap:16px;flex-wrap:wrap;justify-content:center;align-items:flex-start}
.tt-board{border:1px solid var(--line);border-radius:8px;max-width:100%;height:auto;outline:none;touch-action:none}
.tt-board:focus-visible{border-color:var(--acc)}
.tt-side{display:flex;flex-direction:column;gap:10px;min-width:130px}
.tt-stat{border:1px solid var(--line);border-radius:10px;background:var(--bg);padding:6px 12px}
.tt-stat small{display:block;font-size:11px;color:var(--mute);text-transform:uppercase;letter-spacing:.04em}
.tt-stat b{font-size:18px;font-variant-numeric:tabular-nums}
.tt-next{border:1px solid var(--line);border-radius:10px;background:var(--bg);padding:6px 12px}
.tt-next small{display:block;font-size:11px;color:var(--mute);text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px}
.tt-next canvas{display:block;margin:0 auto}
.tt-pad{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}
.tt-btn{
  min-width:48px;height:44px;border:1px solid var(--line);border-radius:10px;
  background:var(--bg);color:var(--ink);font:inherit;font-size:18px;cursor:pointer;
  user-select:none;-webkit-user-select:none;touch-action:manipulation;
}
.tt-btn:active{border-color:var(--acc);background:var(--sel)}
.tt-start{
  border:1px solid var(--acc);background:var(--acc);color:#fff;border-radius:8px;
  padding:8px 14px;cursor:pointer;font:inherit;font-size:13px;font-weight:600;
}
`;
  document.head.append(s);
}

function ttRotate(m) {
  const n = m.length;
  const r = Array.from({ length: n }, () => Array(n).fill(0));
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) r[x][n - 1 - y] = m[y][x];
  return r;
}

function tetrisGame(host) {
  host.replaceChildren();
  ttInjectStyles();

  const status = el('div', 'game-status', 'Tetris');
  const wrap = el('div', 'tt-wrap');
  const canvas = document.createElement('canvas');
  canvas.width = TT_COLS * TT_CELL;
  canvas.height = TT_ROWS * TT_CELL;
  canvas.className = 'tt-board';
  canvas.tabIndex = 0;
  canvas.setAttribute('aria-label', 'Tetris-speelveld');

  const side = el('div', 'tt-side');
  const mkStat = label => {
    const box = el('div', 'tt-stat');
    const v = el('b', '', '0');
    box.append(el('small', '', label), v);
    side.append(box);
    return v;
  };
  const scoreEl = mkStat('Score');
  const linesEl = mkStat('Lijnen');
  const levelEl = mkStat('Niveau');
  const bestEl = mkStat('Beste');
  const nextBox = el('div', 'tt-next');
  const nextCanvas = document.createElement('canvas');
  nextCanvas.width = nextCanvas.height = 4 * TT_PREV;
  nextBox.append(el('small', '', 'Volgende'), nextCanvas);
  const startBtn = el('button', 'tt-start', 'Start');
  startBtn.type = 'button';
  side.append(nextBox, startBtn);
  wrap.append(canvas, side);

  const pad = el('div', 'tt-pad');
  const hint = el('p', 'game-hint', '← → bewegen · ↑ draaien (Z andersom) · ↓ sneller · spatie = vallen · P = pauze');
  host.append(status, wrap, pad, hint);

  // ---- toestand ----
  let board, cur, nextType, bag, score, lines, level, state, acc, last, raf;
  let best = 0;
  try { best = parseInt(localStorage.getItem(TT_BEST_KEY) || '0', 10) || 0; } catch (_) {}
  bestEl.textContent = String(best);
  state = 'idle'; // idle | running | paused | over

  const emptyBoard = () => Array.from({ length: TT_ROWS }, () => Array(TT_COLS).fill(null));

  function nextFromBag() {
    if (!bag || !bag.length) {
      bag = Object.keys(TT_SHAPES);
      for (let i = bag.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [bag[i], bag[j]] = [bag[j], bag[i]];
      }
    }
    return bag.pop();
  }

  function collides(m, px, py) {
    for (let y = 0; y < m.length; y++) {
      for (let x = 0; x < m.length; x++) {
        if (!m[y][x]) continue;
        const nx = px + x, ny = py + y;
        if (nx < 0 || nx >= TT_COLS || ny >= TT_ROWS) return true;
        if (ny >= 0 && board[ny][nx]) return true;
      }
    }
    return false;
  }

  function spawn() {
    const t = nextType;
    nextType = nextFromBag();
    const m = TT_SHAPES[t].map(r => r.slice());
    const firstRow = m.findIndex(r => r.some(Boolean));
    cur = { t, m, x: Math.floor((TT_COLS - m.length) / 2), y: -firstRow };
    drawNext();
    if (collides(cur.m, cur.x, cur.y)) gameOver();
  }

  function dropInterval() { return Math.max(70, 800 - (level - 1) * 70); }

  function move(dx) {
    if (state !== 'running') return false;
    if (!collides(cur.m, cur.x + dx, cur.y)) { cur.x += dx; draw(); return true; }
    return false;
  }

  function rotate(dir) {
    if (state !== 'running' || cur.t === 'O') return;
    let m = cur.m;
    m = dir > 0 ? ttRotate(m) : ttRotate(ttRotate(ttRotate(m)));
    // eenvoudige "wall kicks": probeer opzij of omhoog te schuiven
    for (const [dx, dy] of [[0,0],[-1,0],[1,0],[-2,0],[2,0],[0,-1]]) {
      if (!collides(m, cur.x + dx, cur.y + dy)) {
        cur.m = m; cur.x += dx; cur.y += dy; draw(); return;
      }
    }
  }

  function softDrop() {
    if (state !== 'running') return;
    if (!collides(cur.m, cur.x, cur.y + 1)) { cur.y++; score += 1; updateStats(); draw(); }
    else lock();
    acc = 0;
  }

  function hardDrop() {
    if (state !== 'running') return;
    let n = 0;
    while (!collides(cur.m, cur.x, cur.y + 1)) { cur.y++; n++; }
    score += n * 2;
    lock();
    acc = 0;
  }

  function lock() {
    cur.m.forEach((row, y) => row.forEach((v, x) => {
      const by = cur.y + y, bx = cur.x + x;
      if (v && by >= 0 && by < TT_ROWS) board[by][bx] = cur.t;
    }));
    let cleared = 0;
    for (let y = TT_ROWS - 1; y >= 0; y--) {
      if (board[y].every(Boolean)) { board.splice(y, 1); board.unshift(Array(TT_COLS).fill(null)); cleared++; y++; }
    }
    if (cleared) {
      score += [0, 100, 300, 500, 800][cleared] * level;
      lines += cleared;
      level = 1 + Math.floor(lines / 10);
    }
    updateStats();
    if (state === 'running') spawn();
    draw();
  }

  function updateStats() {
    scoreEl.textContent = String(score);
    linesEl.textContent = String(lines);
    levelEl.textContent = String(level);
    if (score > best) {
      best = score;
      bestEl.textContent = String(best);
      try { localStorage.setItem(TT_BEST_KEY, String(best)); } catch (_) {}
    }
  }

  function gameOver() {
    state = 'over';
    status.textContent = 'Game over · score ' + score;
    startBtn.textContent = 'Opnieuw';
    draw();
  }

  // ---- tekenen ----
  function paintCell(ctx, x, y, size, color, alpha) {
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.fillStyle = color;
    ctx.fillRect(x * size + 1, y * size + 1, size - 2, size - 2);
    ctx.fillStyle = 'rgba(255,255,255,.22)';
    ctx.fillRect(x * size + 1, y * size + 1, size - 2, 3);
    ctx.fillStyle = 'rgba(0,0,0,.18)';
    ctx.fillRect(x * size + 1, y * size + size - 4, size - 2, 3);
    ctx.globalAlpha = 1;
  }

  function overlay(ctx, text, sub) {
    ctx.fillStyle = 'rgba(0,0,0,.55)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'center';
    ctx.font = '700 22px system-ui, sans-serif';
    ctx.fillText(text, canvas.width / 2, canvas.height / 2 - 6);
    if (sub) { ctx.font = '13px system-ui, sans-serif'; ctx.fillText(sub, canvas.width / 2, canvas.height / 2 + 18); }
  }

  function draw() {
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--panel').trim() || '#1a1814';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = 'rgba(128,128,128,.15)';
    for (let x = 0; x <= TT_COLS; x++) { ctx.beginPath(); ctx.moveTo(x * TT_CELL, 0); ctx.lineTo(x * TT_CELL, canvas.height); ctx.stroke(); }
    for (let y = 0; y <= TT_ROWS; y++) { ctx.beginPath(); ctx.moveTo(0, y * TT_CELL); ctx.lineTo(canvas.width, y * TT_CELL); ctx.stroke(); }
    if (board) {
      for (let y = 0; y < TT_ROWS; y++) for (let x = 0; x < TT_COLS; x++) if (board[y][x]) paintCell(ctx, x, y, TT_CELL, TT_COLORS[board[y][x]]);
    }
    if (cur && state !== 'over') {
      let gy = cur.y;
      while (!collides(cur.m, cur.x, gy + 1)) gy++;
      cur.m.forEach((row, y) => row.forEach((v, x) => {
        if (!v) return;
        if (gy + y >= 0) paintCell(ctx, cur.x + x, gy + y, TT_CELL, TT_COLORS[cur.t], 0.25);
      }));
      cur.m.forEach((row, y) => row.forEach((v, x) => {
        if (v && cur.y + y >= 0) paintCell(ctx, cur.x + x, cur.y + y, TT_CELL, TT_COLORS[cur.t]);
      }));
    }
    if (state === 'idle') overlay(ctx, 'Tetris', 'Druk op Start of Enter');
    else if (state === 'paused') overlay(ctx, 'Pauze', 'P of Start om verder te gaan');
    else if (state === 'over') overlay(ctx, 'Game over', 'Druk op Enter voor een nieuw spel');
  }

  function drawNext() {
    const ctx = nextCanvas.getContext('2d');
    ctx.clearRect(0, 0, nextCanvas.width, nextCanvas.height);
    if (!nextType) return;
    const m = TT_SHAPES[nextType];
    const rows = m.filter(r => r.some(Boolean)).length;
    const offY = Math.floor((4 - rows) / 2) - m.findIndex(r => r.some(Boolean));
    const offX = Math.floor((4 - m.length) / 2);
    m.forEach((row, y) => row.forEach((v, x) => { if (v) paintCell(ctx, x + offX, y + offY, TT_PREV, TT_COLORS[nextType]); }));
  }

  // ---- spelverloop ----
  function frame(ts) {
    if (!canvas.isConnected) { stopLoop(); return; }
    raf = requestAnimationFrame(frame);
    if (state !== 'running') { last = ts; return; }
    acc += ts - (last || ts);
    last = ts;
    const iv = dropInterval();
    while (acc >= iv && state === 'running') {
      acc -= iv;
      if (!collides(cur.m, cur.x, cur.y + 1)) cur.y++;
      else lock();
      draw();
    }
  }
  function stopLoop() {
    if (raf) cancelAnimationFrame(raf);
    raf = null;
    document.removeEventListener('keydown', onKey);
    document.removeEventListener('visibilitychange', onHidden);
  }

  function start() {
    board = emptyBoard();
    bag = [];
    score = 0; lines = 0; level = 1; acc = 0; last = 0;
    nextType = nextFromBag();
    state = 'running';
    status.textContent = 'Veel succes!';
    startBtn.textContent = 'Opnieuw';
    updateStats();
    spawn();
    draw();
    canvas.focus();
    if (!raf) raf = requestAnimationFrame(frame);
  }

  function togglePause() {
    if (state === 'running') { state = 'paused'; status.textContent = 'Pauze'; draw(); }
    else if (state === 'paused') { state = 'running'; status.textContent = 'Veel succes!'; last = 0; draw(); canvas.focus(); }
  }

  function onHidden() { if (document.hidden && state === 'running') togglePause(); }

  function onKey(e) {
    if (!host.isConnected) { stopLoop(); return; }
    const t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    if (k === 'Enter' && (state === 'idle' || state === 'over') && (t === canvas || t === document.body)) {
      e.preventDefault(); start(); return;
    }
    if (state !== 'running' && state !== 'paused') return;
    if (k === 'p' || k === 'Escape') { if (k === 'p') { e.preventDefault(); togglePause(); } else if (state === 'running') { togglePause(); } return; }
    if (state !== 'running') return;
    if (k === 'ArrowLeft' || k === 'a') { e.preventDefault(); move(-1); }
    else if (k === 'ArrowRight' || k === 'd') { e.preventDefault(); move(1); }
    else if (k === 'ArrowDown' || k === 's') { e.preventDefault(); softDrop(); }
    else if (k === 'ArrowUp' || k === 'w' || k === 'x') { e.preventDefault(); rotate(1); }
    else if (k === 'z') { e.preventDefault(); rotate(-1); }
    else if (k === ' ' || k === 'Spacebar') { e.preventDefault(); hardDrop(); }
  }
  document.addEventListener('keydown', onKey);
  document.addEventListener('visibilitychange', onHidden);

  // ---- knoppen (aanraken) ----
  const mkBtn = (label, title, fn, repeat) => {
    const b = el('button', 'tt-btn', label);
    b.type = 'button'; b.title = title; b.setAttribute('aria-label', title);
    b.addEventListener('mousedown', e => e.preventDefault()); // focus blijft op het speelveld
    let timer = null, delay = null;
    const stop = () => { clearTimeout(delay); clearInterval(timer); delay = timer = null; };
    b.addEventListener('pointerdown', e => {
      e.preventDefault(); fn();
      if (repeat) { delay = setTimeout(() => { timer = setInterval(fn, 70); }, 250); }
    });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => b.addEventListener(ev, stop));
    pad.append(b);
  };
  mkBtn('◀', 'Links', () => move(-1), true);
  mkBtn('⟳', 'Draaien', () => rotate(1), false);
  mkBtn('▶', 'Rechts', () => move(1), true);
  mkBtn('▼', 'Sneller', softDrop, true);
  mkBtn('⤓', 'Laten vallen', hardDrop, false);

  startBtn.onclick = () => {
    if (state === 'paused') togglePause();
    else start();
  };
  canvas.addEventListener('click', () => { canvas.focus(); if (state === 'idle' || state === 'over') start(); });

  draw();
}

/** Mastermind — raad de geheime kleurencode (4 posities, 6 kleuren, max. 10 beurten). */

export function createTetrisApp() {
  injectGameBaseStyles();
  const root = document.createElement('div');
  root.className = 'app-panel games-app';
  tetrisGame(root);
  return { root };
}
