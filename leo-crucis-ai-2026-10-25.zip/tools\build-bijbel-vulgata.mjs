// Zet de Latijnse Vulgaat (npm: @bible-api/bible-api-version-vulgate, MIT-0, tekst: publiek domein)
// om naar losse boekbestanden voor de bijbellezer.
//
//   npm pack @bible-api/bible-api-version-vulgate && tar xzf bible-api-bible-api-version-vulgate-*.tgz
//   node tools/build-bijbel-vulgata.mjs package/vulgate.json
//
// Uitvoer: src/data/bijbel/index.json en src/data/bijbel/vulgata/<osis>.json  ({"c":[[vers,...],...]})
// Hoofdstuk n staat op positie n-1, vers m op positie m-1. Ontbrekende verzen blijven "" (zie "gaps" in de index).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const src = process.argv[2];
if (!src) { console.error('Gebruik: node tools/build-bijbel-vulgata.mjs <pad naar vulgate.json>'); process.exit(1); }
const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'src', 'data', 'bijbel');
const out = path.join(root, 'vulgata');
fs.mkdirSync(out, { recursive: true });

// [bronnaam, osis, Nederlandse naam, Latijnse naam, testament]
const BOOKS = [
  ['Genesis','Gen','Genesis','Genesis','OT'], ['Exodus','Exod','Exodus','Exodus','OT'],
  ['Leviticus','Lev','Leviticus','Leviticus','OT'], ['Numbers','Num','Numeri','Numeri','OT'],
  ['Deuteronomy','Deut','Deuteronomium','Deuteronomium','OT'], ['Joshua','Josh','Jozua','Josue','OT'],
  ['Judges','Judg','Rechters','Judicum','OT'], ['Ruth','Ruth','Rut','Ruth','OT'],
  ['1 Samuel','1Sam','1 Samuël','1 Samuelis (1 Regum)','OT'], ['2 Samuel','2Sam','2 Samuël','2 Samuelis (2 Regum)','OT'],
  ['1 Kings','1Kgs','1 Koningen','1 Regum (3 Regum)','OT'], ['2 Kings','2Kgs','2 Koningen','2 Regum (4 Regum)','OT'],
  ['1 Chronicles','1Chr','1 Kronieken','1 Paralipomenon','OT'], ['2 Chronicles','2Chr','2 Kronieken','2 Paralipomenon','OT'],
  ['Ezra','Ezra','Ezra','Esdrae','OT'], ['Nehemiah','Neh','Nehemia','Nehemiae','OT'],
  ['Esther','Esth','Ester','Esther','OT'], ['Job','Job','Job','Job','OT'],
  ['Psalms','Ps','Psalmen','Psalmi','OT'], ['Proverbs','Prov','Spreuken','Proverbia','OT'],
  ['Ecclesiastes','Eccl','Prediker','Ecclesiastes','OT'], ['Song of Solomon','Song','Hooglied','Canticum Canticorum','OT'],
  ['Isaiah','Isa','Jesaja','Isaias','OT'], ['Jeremiah','Jer','Jeremia','Jeremias','OT'],
  ['Lamentations','Lam','Klaagliederen','Lamentationes','OT'], ['Ezekiel','Ezek','Ezechiël','Ezechiel','OT'],
  ['Daniel','Dan','Daniël','Daniel','OT'], ['Hosea','Hos','Hosea','Osee','OT'],
  ['Joel','Joel','Joël','Joel','OT'], ['Amos','Amos','Amos','Amos','OT'],
  ['Obadiah','Obad','Obadja','Abdias','OT'], ['Jonah','Jonah','Jona','Jonas','OT'],
  ['Micah','Mic','Micha','Michaeas','OT'], ['Nahum','Nah','Nahum','Nahum','OT'],
  ['Habakkuk','Hab','Habakuk','Habacuc','OT'], ['Zephaniah','Zeph','Sefanja','Sophonias','OT'],
  ['Haggai','Hag','Haggai','Aggaeus','OT'], ['Zechariah','Zech','Zacharia','Zacharias','OT'],
  ['Malachi','Mal','Maleachi','Malachias','OT'],
  ['Matthew','Matt','Matteüs','Matthaeum','NT'], ['Mark','Mark','Marcus','Marcum','NT'],
  ['Luke','Luke','Lucas','Lucam','NT'], ['John','John','Johannes','Joannem','NT'],
  ['Acts','Acts','Handelingen','Actus Apostolorum','NT'], ['Romans','Rom','Romeinen','ad Romanos','NT'],
  ['1 Corinthians','1Cor','1 Korintiërs','1 ad Corinthios','NT'], ['2 Corinthians','2Cor','2 Korintiërs','2 ad Corinthios','NT'],
  ['Galatians','Gal','Galaten','ad Galatas','NT'], ['Ephesians','Eph','Efeziërs','ad Ephesios','NT'],
  ['Philippians','Phil','Filippenzen','ad Philippenses','NT'], ['Colossians','Col','Kolossenzen','ad Colossenses','NT'],
  ['1 Thessalonians','1Thess','1 Tessalonicenzen','1 ad Thessalonicenses','NT'], ['2 Thessalonians','2Thess','2 Tessalonicenzen','2 ad Thessalonicenses','NT'],
  ['1 Timothy','1Tim','1 Timoteüs','1 ad Timotheum','NT'], ['2 Timothy','2Tim','2 Timoteüs','2 ad Timotheum','NT'],
  ['Titus','Titus','Titus','ad Titum','NT'], ['Philemon','Phlm','Filemon','ad Philemonem','NT'],
  ['Hebrews','Heb','Hebreeën','ad Hebraeos','NT'], ['James','Jas','Jakobus','Jacobi','NT'],
  ['1 Peter','1Pet','1 Petrus','1 Petri','NT'], ['2 Peter','2Pet','2 Petrus','2 Petri','NT'],
  ['1 John','1John','1 Johannes','1 Joannis','NT'], ['2 John','2John','2 Johannes','2 Joannis','NT'],
  ['3 John','3John','3 Johannes','3 Joannis','NT'], ['Jude','Jude','Judas','Judae','NT'],
  ['Revelation','Rev','Openbaring','Apocalypsis','NT']
];

const data = JSON.parse(fs.readFileSync(src, 'utf8')).booksData;
const unknown = Object.keys(data).filter(k => !BOOKS.some(b => b[0] === k));
if (unknown.length) throw new Error('Onbekende boeken in de bron: ' + unknown.join(', '));

const clean = s => String(s ?? '').replace(/\s+/g, ' ').trim();
const index = [];
let totalVerses = 0;
BOOKS.forEach(([key, osis, nl, la, t], i) => {
  const b = data[key];
  if (!b) throw new Error('Boek ontbreekt in de bron: ' + key);
  const chapters = b.chaptersData.slice(1).map(c => (c || []).slice(1).map(clean));
  const gaps = [];
  chapters.forEach((c, ci) => c.forEach((v, vi) => { if (!v) gaps.push(`${ci + 1}:${vi + 1}`); }));
  const verses = chapters.reduce((n, c) => n + c.length - c.filter(v => !v).length, 0);
  totalVerses += verses;
  fs.writeFileSync(path.join(out, osis + '.json'), JSON.stringify({ c: chapters }));
  index.push({ n: i + 1, osis, nl, la, t, ch: chapters.length, v: verses, ...(gaps.length ? { gaps } : {}) });
});

fs.writeFileSync(path.join(root, 'index.json'), JSON.stringify({
  version: 1,
  translations: [{
    id: 'vulgata', name: 'Vulgaat (Clementina)', language: 'la',
    license: 'publiek domein',
    source: 'npm @bible-api/bible-api-version-vulgate (MIT-0)',
    psalms: 'vulgaat',
    note: 'Bevat 66 boeken. De deuterocanonieke boeken (Tobit, Judit, Wijsheid, Sirach, Baruch, 1–2 Makkabeeën) en de toevoegingen bij Ester en Daniël ontbreken in deze bron.'
  }],
  books: index
}));
console.log(`${index.length} boeken, ${totalVerses} verzen`);
for (const b of index) if (b.gaps) console.log('lege verzen', b.osis, b.gaps.join(' '));
