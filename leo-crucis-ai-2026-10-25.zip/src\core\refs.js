// Referentiegegevens per boek: auteurs, herkomst (bron) en bibliografie, opgemaakt volgens APA 7.
// De gegevens staan in elk boekbestand als <script type="application/json" id="lc-ref"> (ook als ze leeg zijn).
import { ask } from './edit.js';

export const emptyRef = () => ({ v: 1, authors: [], origin: null, bibliography: [] });
export const parseRef = doc => {
  try { const s = doc.querySelector('script#lc-ref'); return s ? Object.assign(emptyRef(), JSON.parse(s.textContent)) : emptyRef(); }
  catch (e) { return emptyRef(); }
};
export const refScript = ref => `<script type="application/json" id="lc-ref">${JSON.stringify(ref || emptyRef()).replace(/</g, '\\u003c')}</script>`;
export const hasRef = r => !!(r && ((r.authors || []).length || r.origin || (r.bibliography || []).length));

// ---------- APA-opmaak ----------
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const end = s => /[.?!]$/.test(s) ? s : s + '.';
const initials = g => (g || '').replace(/\./g, '. ').split(/\s+/).filter(Boolean)
  .map(w => w.split('-').map(p => p[0].toUpperCase() + '.').join('-')).join(' ');
const apaName = a => a.given ? `${a.family}, ${initials(a.given)}` : a.family;
export function apaNames(list) {
  const n = (list || []).map(apaName);
  if (n.length < 2) return n[0] || '';
  return n.slice(0, -1).join(', ') + ', & ' + n[n.length - 1];
}
const MONTHS = ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'];
const fmtDate = d => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d || ''); return m ? `${+m[3]} ${MONTHS[+m[2] - 1]} ${m[1]}` : d; };
const linkOf = l => !l ? '' : /^10\.\d+\//.test(l) ? 'https://doi.org/' + l : l.replace(/^doi:\s*/i, 'https://doi.org/');

// Eén bron als HTML-string (alles geëscaped; titel cursief zoals APA voorschrijft).
export function apa(e) {
  const au = apaNames(e.authors), yr = `(${e.year ? esc(e.year) : 'z.d.'}).`;
  const art = e.type === 'artikel';
  const title = e.title ? (art ? esc(end(e.title)) : `<i>${esc(end(e.title))}</i>`) : '';
  const link = linkOf(e.link);
  const parts = au ? [esc(end(au)), yr, title] : [title, yr];
  if (e.container) parts.push(`<i>${esc(end(e.container))}</i>`);
  if (e.publisher) parts.push(esc(end(e.publisher)));
  if (link) parts.push((e.accessed && !/doi\.org/.test(link) ? `Opgehaald op ${esc(fmtDate(e.accessed))} van ` : '') + esc(link));
  return parts.filter(Boolean).join(' ');
}
const sortKey = e => (apaNames(e.authors) || e.title || '').toLowerCase();

// ---------- kleine DOM-hulpjes ----------
const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text) e.textContent = text; return e; };
const btn = (label, title, fn, cls = '') => { const b = h('button', 'dev-btn ' + cls, label); b.type = 'button'; b.title = title; b.setAttribute('aria-label', title); b.onclick = fn; return b; };
export function infoButton(filled, fn) {
  const b = h('button', 'info-btn' + (filled ? ' has' : '')); b.type = 'button';
  b.title = 'Auteur, herkomst en bibliografie'; b.setAttribute('aria-label', 'Auteur, herkomst en bibliografie');
  b.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9.5"/><path d="M12 11v6"/><circle cx="12" cy="7.6" r=".6" fill="currentColor"/></svg>';
  b.onclick = fn; return b;
}

// ---------- invulformulieren ----------
const AUTHOR_FIELDS = [['family', 'Achternaam', 'text', true], ['given', 'Voornaam of voorletters', 'text']];
const SOURCE_FIELDS = [
  ['type', 'Soort bron', 'select', false, ['boek', 'artikel', 'website', 'document']],
  ['authors', 'Auteur(s) — één per regel: Achternaam, Voornaam', 'textarea'],
  ['year', 'Jaar (leeg = z.d.)', 'text'],
  ['title', 'Titel', 'text', true],
  ['container', 'Tijdschrift of boek (bij een artikel of hoofdstuk)', 'text'],
  ['publisher', 'Uitgever of website', 'text'],
  ['link', 'URL of DOI', 'text'],
  ['accessed', 'Opgehaald op (bij websites)', 'date'],
];
const linesToAuthors = t => t.split('\n').map(l => l.trim()).filter(Boolean).map(l => {
  const [family, ...rest] = l.split(','); return { family: family.trim(), given: rest.join(',').trim() };
});
const authorsToLines = a => (a || []).map(x => x.given ? `${x.family}, ${x.given}` : x.family).join('\n');

function form(fields, init, label, onSubmit, onCancel) {
  const f = h('form', 'ref-form');
  for (const [name, text, kind, req, opts] of fields) {
    const l = h('label'); l.append(h('span', '', text));
    const i = kind === 'select' ? h('select') : kind === 'textarea' ? h('textarea') : h('input');
    if (kind === 'select') opts.forEach(o => { const op = h('option', '', o); op.value = o; i.append(op); });
    else if (kind === 'textarea') i.rows = 3; else i.type = kind;
    i.name = name; i.required = !!req; i.value = init[name] || '';
    l.append(i); f.append(l);
  }
  const row = h('div', 'dlg-row');
  const no = h('button', 'back', 'Annuleren'); no.type = 'button'; no.onclick = onCancel;
  const ok = h('button', 'dlg-ok', label); ok.type = 'submit';
  row.append(no, ok); f.append(row);
  f.onsubmit = e => { e.preventDefault(); const v = {}; fields.forEach(([n]) => { v[n] = f.elements[n].value.trim(); }); onSubmit(v); };
  setTimeout(() => f.elements[fields[0][0]].focus(), 0);
  return f;
}

// ---------- het infovenster ----------
// openInfo({ title, ref, dev, save }): save(ref) bewaart de wijziging; het venster ververst zichzelf.
export function openInfo({ title, ref, dev, save }) {
  ref.authors = ref.authors || []; ref.bibliography = ref.bibliography || [];
  const back = h('div', 'dlg-back'), box = h('div', 'dlg info-panel'); box.setAttribute('role', 'dialog'); box.setAttribute('aria-label', 'Referentiegegevens');
  back.append(box); document.body.append(back);
  const close = () => { back.remove(); document.removeEventListener('keydown', esc_); };
  const esc_ = e => { if (e.key === 'Escape' && !document.querySelector('.dlg-back ~ .dlg-back')) close(); };
  document.addEventListener('keydown', esc_);
  back.onclick = e => { if (e.target === back) close(); };
  let editing = null;                                   // { sec, i }  (i = -1: nieuw)

  const commit = async () => { editing = null; await save(ref); render(); };
  const section = (name, hint) => { const s = h('section', 'ref-sec'); s.append(h('h3', '', name)); if (hint) s.append(h('p', 'ref-hint', hint)); box.append(s); return s; };
  const row = (html, onEdit, onDel) => {
    const r = h('div', 'ref-row'); const t = h('div', 'ref-text'); t.innerHTML = html; r.append(t);   // html is geëscaped door apa()
    if (dev) { const a = h('span', 'ref-actions'); a.append(btn('✎', 'Bewerken', onEdit, 'pencil'), btn('✕', 'Verwijderen', onDel)); r.append(a); }
    return r;
  };
  const addBtn = (s, label, sec) => { if (dev && !(editing && editing.sec === sec && editing.i === -1)) s.append(btn(label, label, () => { editing = { sec, i: -1 }; render(); })); };
  const del = async (list, i, what) => { if (await ask(`${what} verwijderen?`, { yes: 'Verwijderen' })) { list.splice(i, 1); commit(); } };

  function render() {
    box.replaceChildren();
    const top = h('div', 'ref-top'); top.append(h('h2', '', 'Over dit boek'), h('p', 'ref-title', title));
    const x = btn('✕', 'Sluiten', close); x.classList.add('ref-close'); top.append(x); box.append(top);
    if (!dev) box.append(h('p', 'ref-hint', 'Gegevens toevoegen of aanpassen kan via Profiel › Developer.'));

    // 1. Auteurs
    const sa = section('Auteur(s)', 'Wie schreef dit boek?');
    ref.authors.forEach((a, i) => {
      if (editing && editing.sec === 'a' && editing.i === i) return sa.append(form(AUTHOR_FIELDS, a, 'Opslaan', v => { ref.authors[i] = v; commit(); }, () => { editing = null; render(); }));
      sa.append(row(esc(apaName(a)), () => { editing = { sec: 'a', i }; render(); }, () => del(ref.authors, i, `Auteur "${apaName(a)}"`)));
    });
    if (!ref.authors.length) sa.append(h('p', 'ref-empty', 'Nog geen auteur ingevuld.'));
    if (editing && editing.sec === 'a' && editing.i === -1) sa.append(form(AUTHOR_FIELDS, {}, 'Toevoegen', v => { ref.authors.push(v); commit(); }, () => { editing = null; render(); }));
    addBtn(sa, '+ Auteur toevoegen', 'a');

    // 2. Herkomst
    const so = section('Herkomst (referentiegegevens)', 'Waar komt dit boek of document vandaan?');
    if (editing && editing.sec === 'o') so.append(form(SOURCE_FIELDS.concat([['note', 'Opmerking', 'textarea']]), Object.assign({}, ref.origin, { authors: authorsToLines(ref.origin && ref.origin.authors) }), 'Opslaan',
      v => { v.authors = linesToAuthors(v.authors); ref.origin = v; commit(); }, () => { editing = null; render(); }));
    else if (ref.origin) {
      so.append(row(apa(ref.origin), () => { editing = { sec: 'o' }; render(); }, async () => { if (await ask('Herkomst verwijderen?', { yes: 'Verwijderen' })) { ref.origin = null; commit(); } }));
      if (ref.origin.note) so.append(h('p', 'ref-hint', ref.origin.note));
    } else { so.append(h('p', 'ref-empty', 'Nog geen herkomst ingevuld.')); if (dev) so.append(btn('+ Herkomst invullen', 'Herkomst invullen', () => { editing = { sec: 'o' }; render(); })); }

    // 3. Bibliografie
    const sb = section('Bibliografie', 'Bronnen die voor dit boek gebruikt zijn (APA 7, alfabetisch).');
    const order = ref.bibliography.map((e, i) => i).sort((p, q) => sortKey(ref.bibliography[p]).localeCompare(sortKey(ref.bibliography[q]), 'nl'));
    order.forEach(i => {
      const e = ref.bibliography[i];
      if (editing && editing.sec === 'b' && editing.i === i) return sb.append(form(SOURCE_FIELDS, Object.assign({}, e, { authors: authorsToLines(e.authors) }), 'Opslaan',
        v => { v.authors = linesToAuthors(v.authors); ref.bibliography[i] = v; commit(); }, () => { editing = null; render(); }));
      sb.append(row(apa(e), () => { editing = { sec: 'b', i }; render(); }, () => del(ref.bibliography, i, 'Deze bron')));
    });
    if (!ref.bibliography.length) sb.append(h('p', 'ref-empty', 'Nog geen bronnen ingevuld.'));
    if (editing && editing.sec === 'b' && editing.i === -1) sb.append(form(SOURCE_FIELDS, {}, 'Toevoegen', v => { v.authors = linesToAuthors(v.authors); ref.bibliography.push(v); commit(); }, () => { editing = null; render(); }));
    addBtn(sb, '+ Bron toevoegen', 'b');

    // 4. Zo verwijs je naar dit boek
    const sc = section('Zo verwijs je naar dit boek', 'APA 7, automatisch opgebouwd uit bovenstaande gegevens.');
    const cite = apa({ type: 'boek', authors: ref.authors, year: ref.origin && ref.origin.year, title, publisher: 'Bibliotheek Leo Crucis' });
    const r = h('div', 'ref-row'); const t = h('div', 'ref-text'); t.innerHTML = cite; r.append(t);
    const cp = btn('Kopieer', 'Kopieer de verwijzing', async () => { try { await navigator.clipboard.writeText(t.textContent); cp.textContent = 'Gekopieerd'; setTimeout(() => cp.textContent = 'Kopieer', 1500); } catch (e) {} });
    r.append(h('span', 'ref-actions')); r.lastChild.append(cp); sc.append(r);
  }
  render();
}
