/**
 * Leo Crucis — Bijbelgrafieken
 * Hub: kies welke grafiek je wilt bekijken.
 * Momenteel: Kruisverwijzingenkaart (per boek / per hoofdstuk).
 */
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

/** Beschikbare grafieken (makkelijk uit te breiden). */
const BIBLE_GRAPHS = [
  {
    id: 'xref',
    title: 'Kruisverwijzingen',
    desc: 'Bogen tussen boeken of hoofdstukken op basis van kruisverwijzingen. Kleur op hoeveelheid of afstand.',
    icon: '<path d="M3 17c4-8 6-12 9-12s5 4 9 12"/><circle cx="3" cy="17" r="1.2"/><circle cx="12" cy="5" r="1.2"/><circle cx="21" cy="17" r="1.2"/>',
  },
  {
    id: 'verses',
    title: 'Verzen per hoofdstuk',
    desc: 'Staafdiagram: hoeveel verzen elk hoofdstuk heeft, per bijbelboek.',
    icon: '<path d="M4 19V5"/><path d="M4 19h16"/><path d="M8 17V11"/><path d="M12 17V8"/><path d="M16 17v-5"/><path d="M20 17v-3"/>',
  },
  {
    id: 'genealogy',
    title: 'Bijbelse stamboom',
    desc: 'Stamboom van God en Adam tot Jezus — zondvloed, stammen, priester- en koningslijn.',
    icon: '<path d="M12 22V12"/><path d="M12 12c-3-2-5-5-5-8"/><path d="M12 12c3-2 5-5 5-8"/><circle cx="12" cy="4" r="2"/><circle cx="7" cy="10" r="1.5"/><circle cx="17" cy="10" r="1.5"/><circle cx="12" cy="16" r="1.5"/>',
  },
];

/**
 * Bijbelse stamboom — structuur naar klassieke “Biblical Family Tree”
 * (Adam→zondvloed→patriarchen→stammen→priester-/koningslijn→ballingschap→Jezus).
 * role: king | priest | prophet | tribe | messiah | god
 */
function n(name, opts, children) {
  const o = opts && !Array.isArray(opts) ? opts : {};
  const ch = Array.isArray(opts) ? opts : (children || []);
  return {
    name,
    note: o.note || '',
    spouse: o.spouse || '',
    role: o.role || '',
    highlight: !!o.highlight || o.role === 'messiah' || o.role === 'god',
    open: o.open !== false,
    banner: o.banner || '',
    children: ch,
  };
}

const ROLE_COLORS = {
  god: '#e8b923',
  king: '#c9a227',
  priest: '#c41e1e',
  prophet: '#6b3fa0',
  tribe: '#2f7a45',
  messiah: '#7a1f2b',
  royal: '#2d5fa8',
  default: '#5a4a4c',
};

const BIBLE_FAMILY_TREE = n('God', { role: 'god', note: 'Schepper', open: true, highlight: true }, [
  n('Adam', { spouse: 'Eva', note: 'Eerste mens (Gen. 1–5)', open: true, highlight: true }, [
    n('Kaïn', { spouse: 'Awan', note: 'Sloeg Abel dood (Gen. 4)', open: false }, [
      n('Henoch (Kaïn)', { note: 'Stad naar hem genoemd' }, [
        n('Irad', {}, [
          n('Mechujaël', {}, [
            n('Metusaël', {}, [
              n('Lamech (Kaïn)', { spouse: 'Ada & Silla', note: 'Gen. 4' }, [
                n('Jabal', { note: 'Tentbewoners / veehouders' }),
                n('Jubal', { note: 'Musici' }),
                n('Tubal-Kaïn', { note: 'Smid' }),
                n('Naäma'),
              ]),
            ]),
          ]),
        ]),
      ]),
    ]),
    n('Abel', { note: 'Gedood door Kaïn' }),
    n('Seth', { spouse: 'Azura', note: 'In plaats van Abel (Gen. 5)', open: true, highlight: true }, [
      n('Enos', { open: true }, [
        n('Kenan', { open: true }, [
          n('Mahalalel', { open: true }, [
            n('Jered', { open: true }, [
              n('Henoch', { note: 'Wandelaar met God; opgenomen', open: true, highlight: true }, [
                n('Metusalem', { open: true }, [
                  n('Lamech', { open: true }, [
                    n('Noach', {
                      spouse: 'zijn vrouw',
                      note: 'De ark — Gen. 6–9',
                      open: true,
                      highlight: true,
                      banner: 'DE ZONDVLOED',
                    }, [
                      n('Sem', { note: 'Voorouder van Abraham', open: true, highlight: true }, [
                        n('Elam'),
                        n('Assur'),
                        n('Arfachsad', { open: true }, [
                          n('Selach', { open: true }, [
                            n('Eber', { open: true }, [
                              n('Peleg', { note: 'Verdeelde aarde', open: true }, [
                                n('Rehu', { open: true }, [
                                  n('Serug', { open: true }, [
                                    n('Nahor', { open: true }, [
                                      n('Terah', { open: true }, [
                                        n('Abraham', {
                                          spouse: 'Sara',
                                          note: 'Vader van geloof (Gen. 12–25)',
                                          open: true,
                                          highlight: true,
                                        }, [
                                          n('Ismaël', { note: 'Zoon van Hagar', open: false }, [
                                            n('Nebajot'), n('Kedar'), n('Adbeël'), n('Mibsam'),
                                            n('Misma'), n('Duma'), n('Massa'), n('Hadad'),
                                            n('Tema'), n('Jetur'), n('Nafis'), n('Kedma'),
                                          ]),
                                          n('Isaak', { spouse: 'Rebekka', note: 'Kind der belofte', open: true, highlight: true }, [
                                            n('Ezau', { note: 'Edom', open: false }, [
                                              n('Elifaz'), n('Reüel'), n('Jeüs'), n('Jaëlam'), n('Korach'),
                                            ]),
                                            n('Jakob', {
                                              spouse: 'Lea & Rachel',
                                              note: 'Israël — twaalf zonen',
                                              open: true,
                                              highlight: true,
                                            }, [
                                              n('Ruben', { role: 'tribe', note: 'Stam van Ruben' }),
                                              n('Simeon', { role: 'tribe', note: 'Stam van Simeon' }),
                                              n('Levi', {
                                                role: 'priest',
                                                note: 'Priesterstam',
                                                open: true,
                                                highlight: true,
                                              }, [
                                                n('Gerson'),
                                                n('Kehat', { open: true, role: 'priest' }, [
                                                  n('Amram', { spouse: 'Jochebed', role: 'priest', open: true }, [
                                                    n('Mozes', {
                                                      spouse: 'Sippora',
                                                      role: 'prophet',
                                                      note: 'Uittocht; wetgever',
                                                      highlight: true,
                                                      banner: 'SLAVERNIJ IN EGYPTE',
                                                    }, [n('Gersom'), n('Eliëzer')]),
                                                    n('Aäron', {
                                                      spouse: 'Eliseba',
                                                      role: 'priest',
                                                      note: 'Eerste hogepriester',
                                                      highlight: true,
                                                    }, [
                                                      n('Nadab', { role: 'priest' }),
                                                      n('Abihu', { role: 'priest' }),
                                                      n('Eleazar', { role: 'priest' }, [
                                                        n('Pinechas', { role: 'priest' }),
                                                      ]),
                                                      n('Itamar', { role: 'priest' }),
                                                    ]),
                                                    n('Mirjam', { role: 'prophet', note: 'Profetes' }),
                                                  ]),
                                                  n('Jishar'), n('Hebron'), n('Uzziel'),
                                                ]),
                                                n('Merari'),
                                              ]),
                                              n('Judah', {
                                                role: 'royal',
                                                spouse: 'Tamar',
                                                note: 'Koningsstam',
                                                open: true,
                                                highlight: true,
                                              }, [
                                                n('Er'), n('Onan'), n('Sela'),
                                                n('Perez', { role: 'royal', open: true, highlight: true }, [
                                                  n('Hesron', { role: 'royal', open: true }, [
                                                    n('Ram', { role: 'royal', open: true }, [
                                                      n('Amminadab', { role: 'royal', open: true }, [
                                                        n('Nachson', { role: 'royal', open: true }, [
                                                          n('Salmon', { spouse: 'Rachab', role: 'royal', open: true }, [
                                                            n('Boaz', { spouse: 'Ruth', role: 'royal', open: true, highlight: true }, [
                                                              n('Obed', { role: 'royal', open: true }, [
                                                                n('Isaï', { role: 'royal', open: true }, [
                                                                  n('David', {
                                                                    spouse: 'Batseba e.a.',
                                                                    role: 'king',
                                                                    note: 'Koning van Israël',
                                                                    open: true,
                                                                    highlight: true,
                                                                  }, [
                                                                    n('Salomo', {
                                                                      role: 'king',
                                                                      note: 'Tempelbouwer; lijn Mat. 1',
                                                                      open: true,
                                                                      highlight: true,
                                                                    }, [
                                                                      n('Rehobeam', { role: 'king', open: true }, [
                                                                        n('Abia', { role: 'king', open: true }, [
                                                                          n('Asa', { role: 'king', open: true }, [
                                                                            n('Josafat', { role: 'king', open: true }, [
                                                                              n('Joram', { role: 'king', open: true }, [
                                                                                n('Uzzia', { role: 'king', open: true }, [
                                                                                  n('Jotam', { role: 'king', open: true }, [
                                                                                    n('Achaz', { role: 'king', open: true }, [
                                                                                      n('Hizkia', { role: 'king', open: true, highlight: true }, [
                                                                                        n('Manasse', { role: 'king', open: true }, [
                                                                                          n('Amon', { role: 'king', open: true }, [
                                                                                            n('Josia', { role: 'king', open: true, highlight: true }, [
                                                                                              n('Jojachin', {
                                                                                                role: 'king',
                                                                                                note: 'Ballingschap',
                                                                                                open: true,
                                                                                                banner: 'BALLINGSCHAP NAAR BABYLON',
                                                                                              }, [
                                                                                                n('Sealtiel', { role: 'royal', open: true }, [
                                                                                                  n('Zerubbabel', {
                                                                                                    role: 'royal',
                                                                                                    note: 'Tempelherbouw',
                                                                                                    open: true,
                                                                                                    highlight: true,
                                                                                                  }, [
                                                                                                    n('Abuid', { role: 'royal', open: true }, [
                                                                                                      n('Eljakim', { role: 'royal', open: true }, [
                                                                                                        n('Azor', { role: 'royal', open: true }, [
                                                                                                          n('Sadok', { role: 'royal', open: true }, [
                                                                                                            n('Achim', { role: 'royal', open: true }, [
                                                                                                              n('Eliud', { role: 'royal', open: true }, [
                                                                                                                n('Eleazar', { role: 'royal', open: true }, [
                                                                                                                  n('Mattan', { role: 'royal', open: true }, [
                                                                                                                    n('Jakob', { role: 'royal', open: true }, [
                                                                                                                      n('Jozef', {
                                                                                                                        spouse: 'Maria',
                                                                                                                        role: 'royal',
                                                                                                                        note: 'Wettelijke vader van Jezus',
                                                                                                                        open: true,
                                                                                                                        highlight: true,
                                                                                                                      }, [
                                                                                                                        n('Jezus', {
                                                                                                                          role: 'messiah',
                                                                                                                          note: 'Christus — Zoon van God',
                                                                                                                          highlight: true,
                                                                                                                        }),
                                                                                                                      ]),
                                                                                                                    ]),
                                                                                                                  ]),
                                                                                                                ]),
                                                                                                              ]),
                                                                                                            ]),
                                                                                                          ]),
                                                                                                        ]),
                                                                                                      ]),
                                                                                                    ]),
                                                                                                  ]),
                                                                                                ]),
                                                                                              ]),
                                                                                              n('Jojakim', { role: 'king' }),
                                                                                              n('Sedekia', { role: 'king' }),
                                                                                            ]),
                                                                                          ]),
                                                                                        ]),
                                                                                      ]),
                                                                                    ]),
                                                                                  ]),
                                                                                ]),
                                                                              ]),
                                                                            ]),
                                                                          ]),
                                                                        ]),
                                                                      ]),
                                                                    ]),
                                                                    n('Nathan', { role: 'royal', note: 'Lijn van Lucas 3', open: false }, [
                                                                      n('… (Luc. 3)', { note: 'via Heli' }, [
                                                                        n('Jezus', { role: 'messiah', note: 'Christus (Luc. 3)', highlight: true }),
                                                                      ]),
                                                                    ]),
                                                                    n('Absalom'),
                                                                    n('Adonia'),
                                                                  ]),
                                                                ]),
                                                              ]),
                                                            ]),
                                                          ]),
                                                        ]),
                                                      ]),
                                                    ]),
                                                  ]),
                                                ]),
                                                n('Zerach'),
                                              ]),
                                              n('Dan', { role: 'tribe', note: 'Stam van Dan' }),
                                              n('Naftali', { role: 'tribe', note: 'Stam van Naftali' }),
                                              n('Gad', { role: 'tribe', note: 'Stam van Gad' }),
                                              n('Aser', { role: 'tribe', note: 'Stam van Aser' }),
                                              n('Issachar', { role: 'tribe', note: 'Stam van Issachar' }),
                                              n('Zebulon', { role: 'tribe', note: 'Stam van Zebulon' }),
                                              n('Dina', { note: 'Dochter van Lea' }),
                                              n('Jozef', {
                                                spouse: 'Asnat',
                                                role: 'tribe',
                                                note: 'Egypte — Manasse & Efraïm',
                                                open: false,
                                                highlight: true,
                                              }, [
                                                n('Manasse', { role: 'tribe' }),
                                                n('Efraïm', { role: 'tribe' }),
                                              ]),
                                              n('Benjamin', { role: 'tribe', note: 'Stam van Benjamin' }),
                                            ]),
                                          ]),
                                          n('Zimran', { note: 'Ketura' }),
                                          n('Joksan', { note: 'Ketura' }),
                                          n('Medan', { note: 'Ketura' }),
                                          n('Midian', { note: 'Ketura — Midianieten' }),
                                          n('Isbak', { note: 'Ketura' }),
                                          n('Suah', { note: 'Ketura' }),
                                        ]),
                                        n('Nahor', { spouse: 'Milka', open: false }, [
                                          n('Betuël', {}, [
                                            n('Rebekka', { note: 'Vrouw van Isaak' }),
                                            n('Laban', {}, [n('Lea'), n('Rachel')]),
                                          ]),
                                        ]),
                                        n('Haran', {}, [
                                          n('Lot', { note: 'Sodom' }, [
                                            n('Moab'), n('Ben-Ammi'),
                                          ]),
                                        ]),
                                      ]),
                                    ]),
                                  ]),
                                ]),
                              ]),
                              n('Joktan', { open: false }, [
                                n('Almodad'), n('Selef'), n('Hazarmavet'), n('Ofir'), n('Havila'), n('Jobab'),
                              ]),
                            ]),
                          ]),
                        ]),
                        n('Lud'),
                        n('Aram'),
                      ]),
                      n('Cham', { open: false }, [
                        n('Kus', {}, [n('Nimrod', { note: 'Babel' })]),
                        n('Misraïm', { note: 'Egypte' }),
                        n('Put'),
                        n('Kanaän'),
                      ]),
                      n('Jafet', { open: false }, [
                        n('Gomer'), n('Magog'), n('Madai'), n('Javan'),
                        n('Tubal'), n('Mesech'), n('Tiras'),
                      ]),
                    ]),
                  ]),
                ]),
              ]),
            ]),
          ]),
        ]),
      ]),
    ]),
  ]),
]);

/**
 * Aantal verzen per hoofdstuk (1-geïndexeerd via array-index 0 = hfdst 1).
 * Canon zoals in Leo Crucis (73 boeken, met deuterocanonieke).
 * Bron: standaard protestantse/katholieke tekstindeling.
 */
const VERSE_COUNTS = {
  Gen: [31,25,24,26,32,22,24,22,29,32,32,20,18,24,21,16,27,33,38,18,34,24,20,67,34,35,46,22,35,43,55,32,20,31,29,43,36,30,23,23,57,38,34,34,28,34,31,22,33,26],
  Exod: [22,25,22,31,23,30,25,32,35,29,10,51,22,31,27,36,16,27,25,26,36,31,33,18,40,37,21,43,46,38,18,35,23,35,35,38,29,31,43,38],
  Lev: [17,16,17,35,19,30,38,36,24,20,47,8,59,57,33,34,16,30,37,27,24,33,44,23,55,46,34],
  Num: [54,34,51,49,31,27,89,26,23,36,35,16,33,45,41,50,13,32,22,29,35,41,30,25,18,65,23,31,40,16,54,42,56,29,34,13],
  Deut: [46,37,29,49,33,25,26,20,29,22,32,32,18,29,23,22,20,22,21,20,23,30,25,22,19,19,26,68,55,20,30,52,29,12],
  Josh: [18,24,17,24,15,27,26,35,27,43,23,24,33,15,63,10,18,28,51,9,45,34,16,33],
  Judg: [36,23,31,24,31,40,25,35,57,18,40,15,25,20,20,31,13,31,30,48,25],
  Ruth: [22,23,18,22],
  '1Sam': [28,36,21,22,12,21,17,33,15,37,27,19,18,16,24,23,21,13,26,17,14,34,15,22,35,19,37,22,31,22,26,20,38,26,22,19,26,41],
  '2Sam': [27,32,39,12,25,23,29,18,13,19,27,31,39,33,37,23,29,33,43,26,22,51,39,25],
  '1Kgs': [53,46,28,34,18,38,51,66,28,29,43,33,34,31,34,34,24,46,21,43,29,53],
  '2Kgs': [18,25,27,44,27,33,20,29,37,36,21,21,25,29,38,20,41,37,37,21,26,20,37,20,30],
  '1Chr': [54,55,24,43,26,81,40,40,44,14,47,40,14,17,29,43,27,17,19,8,30,19,32,31,31,32,34,21,30],
  '2Chr': [17,18,17,22,14,42,22,18,31,19,23,16,22,15,19,14,19,34,11,37,20,12,21,27,28,23,9,27,36,27,21,14,11,19,21,22,35,22,38],
  Ezra: [11,70,13,24,17,22,16,13],
  Neh: [11,20,32,23,19,19,73,18,38,39,36,47,29],
  Tob: [22,14,17,21,22,17,18,21,6,13,12,15,14],
  Jdt: [16,28,10,15,16,29,14,16,13,20,19,16,16],
  Esth: [22,23,15,17,14,14,10,17,32,3],
  '1Macc': [64,70,60,61,68,63,50,32,73,89,74,53,53,49,41,24],
  '2Macc': [36,32,40,50,27,31,42,36,29,38,38,45,26,46,39],
  Job: [22,13,26,21,27,30,21,22,35,22,20,25,28,22,35,22,16,21,29,29,34,30,17,25,6,14,23,28,25,31,40,22,33,37,16,33,24,41,30,24,34,17],
  Ps: [6,12,8,8,12,10,17,9,20,18,7,8,6,7,5,11,15,50,14,9,13,31,6,10,22,12,14,9,11,12,24,11,22,22,28,12,40,22,13,17,13,11,5,26,17,11,9,14,20,23,19,9,6,7,23,13,11,11,17,12,8,12,11,10,13,20,7,35,36,5,24,20,28,23,10,12,20,72,13,19,16,8,18,12,13,17,7,18,52,17,16,15,5,23,11,13,12,9,9,5,8,28,22,35,45,48,43,13,31,7,10,10,9,8,18,19,2,29,176,7,8,9,4,8,5,6,5,6,8,8,3,18,3,3,21,26,9,8,24,13,10,7,12,28,15,21,10,20,14,9,9],
  Prov: [33,22,35,27,23,35,27,36,18,32,31,28,25,35,33,33,28,24,29,30,31,29,35,34,28,28,27,28,27,33,31],
  Eccl: [18,26,22,16,20,12,29,17,18,20,10,14],
  Song: [17,17,11,16,16,13,13,14],
  Wis: [16,24,19,20,23,25,30,21,18,21,26,27,19,31,19,29,21,25,22],
  Sir: [30,18,31,31,15,37,36,19,18,30,27,29,18,22,23,17,19,20,16,18,24,20,15,32,25,20,26,32,21,27,29,16,23,21,32,28,26,21,28,28,27,27,33,31,24,33,29,22],
  Isa: [31,22,26,6,30,13,25,22,35,16,21,35,23,24,21,13,26,22,19,14,23,25,17,18,31,40,16,38,25,42,11,20,21,29,13,35,22,37,21,43,22,29,23,16,8,29,25,22,26,13,25,21,30,20,21,34,35,30,14,32,21,26,36,26,21,25],
  Jer: [19,37,25,31,31,30,34,22,26,25,23,17,27,22,21,21,27,23,15,18,14,30,40,10,38,24,22,17,32,24,40,44,26,22,19,32,21,28,18,16,18,22,13,30,5,28,7,47,39,46,64,34],
  Lam: [22,22,66,22,22],
  Bar: [22,35,38,37,9,72],
  Ezek: [28,10,27,17,17,14,27,18,11,22,25,28,23,23,8,63,24,32,14,41,21,23,15,17,33,26,18,30,22,26,35,30,20,21,34,29,27,25,29,34,15,29,30,31,23,25,22,26,28,27,27,23,19],
  Dan: [21,49,30,37,31,28,28,27,27,21,45,13],
  Hos: [11,23,5,19,15,11,16,14,17,15,12,14,16,9],
  Joel: [20,26,21],
  Amos: [15,16,15,13,27,14,17,14,15],
  Obad: [21],
  Jonah: [17,10,10,11],
  Mic: [16,13,12,13,15,16,20],
  Nah: [15,13,19],
  Hab: [17,20,19],
  Zeph: [18,15,20],
  Hag: [15,23],
  Zech: [21,13,10,14,11,15,14,23,17,12,17,14,9,21],
  Mal: [14,17,18,6],
  Matt: [25,23,17,25,48,34,29,34,38,42,30,50,58,36,39,28,27,35,30,34,46,46,39,51,46,75,66,20],
  Mark: [45,28,35,41,43,55,47,38,28,41,36,47,52,33,37,52,52,44,28,38,23,25],
  Luke: [80,52,40,41,29,41,51,53,50,42,38,31,28,23,34,42,15,26,33,26,37,48,34,29,32,22,44,25],
  John: [51,25,36,54,47,71,53,59,41,42,57,50,38,31,27,33,26,40,42,31,25],
  Acts: [26,47,26,37,42,15,60,40,43,48,30,25,52,28,41,40,34,28,41,38,40,30,35,27,27,32,44,31],
  Rom: [32,29,31,25,21,23,25,39,33,29,20,27,32,21],
  '1Cor': [31,16,23,21,13,20,40,13,27,33,34,31,13,40,58,24],
  '2Cor': [24,17,18,18,21,18,16,24,15,18,33,21,14],
  Gal: [24,21,29,31,26,18],
  Eph: [23,22,21,32,33,24],
  Phil: [30,30,21,23],
  Col: [29,23,25,18],
  '1Thess': [10,20,13,18,28],
  '2Thess': [12,17,18],
  '1Tim': [20,15,16,16,25,21],
  '2Tim': [18,26,17,22],
  Titus: [16,15,15],
  Phlm: [25],
  Heb: [14,18,19,16,14,20,28,13,28,39,40,29,25],
  Jas: [27,26,18,17,20],
  '1Pet': [25,25,22,19,4],
  '2Pet': [21,22,18],
  '1John': [10,29,24,21,21],
  '2John': [13],
  '3John': [15],
  Jude: [25],
  Rev: [20,29,22,11,14,17,17,13,21,11,19,17,18,20,8,21,18,24,21,15,27,21],
};

const BOOK_LABELS_NL = {
  Gen: 'Genesis', Exod: 'Exodus', Lev: 'Leviticus', Num: 'Numeri', Deut: 'Deuteronomium',
  Josh: 'Jozua', Judg: 'Richteren', Ruth: 'Ruth', '1Sam': '1 Samuël', '2Sam': '2 Samuël',
  '1Kgs': '1 Koningen', '2Kgs': '2 Koningen', '1Chr': '1 Kronieken', '2Chr': '2 Kronieken',
  Ezra: 'Ezra', Neh: 'Nehemia', Tob: 'Tobit', Jdt: 'Judit', Esth: 'Esther',
  '1Macc': '1 Makkabeeën', '2Macc': '2 Makkabeeën', Job: 'Job', Ps: 'Psalmen', Prov: 'Spreuken',
  Eccl: 'Prediker', Song: 'Hooglied', Wis: 'Wijsheid', Sir: 'Sirach', Isa: 'Jesaja',
  Jer: 'Jeremia', Lam: 'Klaagliederen', Bar: 'Baruch', Ezek: 'Ezechiël', Dan: 'Daniël',
  Hos: 'Hosea', Joel: 'Joël', Amos: 'Amos', Obad: 'Obadja', Jonah: 'Jona', Mic: 'Micha',
  Nah: 'Nahum', Hab: 'Habakuk', Zeph: 'Sefanja', Hag: 'Haggai', Zech: 'Zacharia', Mal: 'Maleachi',
  Matt: 'Matteüs', Mark: 'Marcus', Luke: 'Lucas', John: 'Johannes', Acts: 'Handelingen',
  Rom: 'Romeinen', '1Cor': '1 Korintiërs', '2Cor': '2 Korintiërs', Gal: 'Galaten', Eph: 'Efeziërs',
  Phil: 'Filippenzen', Col: 'Kolossenzen', '1Thess': '1 Tessalonicenzen', '2Thess': '2 Tessalonicenzen',
  '1Tim': '1 Timoteüs', '2Tim': '2 Timoteüs', Titus: 'Titus', Phlm: 'Filemon', Heb: 'Hebreeën',
  Jas: 'Jakobus', '1Pet': '1 Petrus', '2Pet': '2 Petrus', '1John': '1 Johannes', '2John': '2 Johannes',
  '3John': '3 Johannes', Jude: 'Judas', Rev: 'Openbaring',
};

const BOOK_ORDER = Object.keys(VERSE_COUNTS);

export function createXrefMapApp() {
  const root = el('div', 'mini-app-root xref-map-app bible-graphs-app');

  // —— Hub: kies een grafiek ——
  const hub = el('div', 'bible-graphs-hub');
  const hubHead = el('div', 'bible-graphs-hub-head');
  hubHead.append(el('h2', 'xref-map-title', 'Bijbelgrafieken'));
  hubHead.append(el('p', 'bible-graphs-hub-sub', 'Kies een grafiek om te bekijken.'));
  hub.append(hubHead);

  const hubGrid = el('div', 'bible-graphs-grid');
  BIBLE_GRAPHS.forEach((g) => {
    const card = el('button', 'bible-graph-card');
    card.type = 'button';
    const ic = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    ic.setAttribute('viewBox', '0 0 24 24');
    ic.setAttribute('width', '28');
    ic.setAttribute('height', '28');
    ic.setAttribute('fill', 'none');
    ic.setAttribute('stroke', 'currentColor');
    ic.setAttribute('stroke-width', '1.75');
    ic.setAttribute('stroke-linecap', 'round');
    ic.setAttribute('stroke-linejoin', 'round');
    ic.setAttribute('aria-hidden', 'true');
    ic.innerHTML = g.icon;
    const body = el('div', 'bible-graph-card-body');
    body.append(el('span', 'bible-graph-card-title', g.title));
    body.append(el('span', 'bible-graph-card-desc', g.desc));
    card.append(ic, body);
    card.onclick = () => openGraph(g.id);
    hubGrid.append(card);
  });
  hub.append(hubGrid);
  root.append(hub);

  // —— Graph host (wordt gevuld bij openen) ——
  const graphHost = el('div', 'bible-graphs-view');
  graphHost.hidden = true;
  root.append(graphHost);

  /** true = we zitten in een grafiek (niet op de hub) */
  let inGraph = false;

  function goToHub() {
    inGraph = false;
    graphHost.hidden = true;
    hub.hidden = false;
    graphHost.replaceChildren();
  }

  function openGraph(id) {
    inGraph = true;
    hub.hidden = true;
    graphHost.hidden = false;
    graphHost.replaceChildren();
    if (id === 'xref') {
      graphHost.append(buildXrefMapView());
    } else if (id === 'verses') {
      graphHost.append(buildVersesBarView());
    } else if (id === 'genealogy') {
      graphHost.append(buildGenealogyView());
    }
  }

  /**
   * Header ← : eerst terug naar grafieken-hub, daarna pas startscherm.
   * Zelfde patroon als Gamemanager.
   */
  function handleBack() {
    if (inGraph) {
      goToHub();
      return true; // verwerkt — blijf in de app
    }
    return false; // op de hub → app afsluiten
  }

  return { root, handleBack };
}

/** Bijbelse stamboom — vertakkende boom met in-/uitklappen, zoom en pan. */
function buildGenealogyView() {
  const layout = el('div', 'xref-map-layout');
  const main = el('div', 'xref-map-main');
  const side = el('div', 'xref-map-side');
  layout.append(main, side);

  const head = el('div', 'xref-map-head');
  const headTop = el('div', 'xref-map-head-top');
  headTop.append(el('h2', 'xref-map-title', 'Bijbelse stamboom'));

  const modeSeg = el('div', 'xref-mode-seg');
  const btnExpandMain = el('button', 'xref-mode-btn is-active', 'Hoofdlijn');
  btnExpandMain.type = 'button';
  btnExpandMain.title = 'Klap bijkomstige takken in; houd de lijn naar Jezus open';
  const btnExpandAll = el('button', 'xref-mode-btn', 'Alles open');
  btnExpandAll.type = 'button';
  btnExpandAll.title = 'Klap alle knooppunten open';
  modeSeg.append(btnExpandMain, btnExpandAll);
  headTop.append(modeSeg);

  const btnToggleFilter = el('button', 'xref-filter-toggle');
  btnToggleFilter.type = 'button';
  btnToggleFilter.title = 'Instellingen';
  btnToggleFilter.setAttribute('aria-label', 'Instellingen openen of sluiten');
  btnToggleFilter.setAttribute('aria-expanded', 'true');
  btnToggleFilter.innerHTML = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`;
  headTop.append(btnToggleFilter);
  head.append(headTop);

  const statsRow = el('div', 'xref-map-stats');
  head.append(statsRow);
  main.append(head);

  const canvasWrap = el('div', 'xref-map-canvas-wrap');
  const canvasBar = el('div', 'xref-map-canvas-bar');
  const canvasTitle = el('span', 'xref-map-canvas-bar-title', 'Adam & Eva en hun nakomelingen');
  const zoomTools = el('div', 'gene-zoom-tools');
  const btnZoomOut = el('button', 'gene-zoom-btn', '−');
  btnZoomOut.type = 'button';
  btnZoomOut.title = 'Uitzoomen';
  const zoomLabel = el('span', 'gene-zoom-label', '100%');
  const btnZoomIn = el('button', 'gene-zoom-btn', '+');
  btnZoomIn.type = 'button';
  btnZoomIn.title = 'Inzoomen';
  const btnZoomReset = el('button', 'gene-zoom-btn', '⌂');
  btnZoomReset.type = 'button';
  btnZoomReset.title = 'Reset weergave';
  zoomTools.append(btnZoomOut, zoomLabel, btnZoomIn, btnZoomReset);
  const btnExport = el('button', 'xref-export-btn');
  btnExport.type = 'button';
  btnExport.title = 'Grafiek downloaden als PNG';
  btnExport.setAttribute('aria-label', 'Grafiek downloaden als PNG');
  btnExport.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 19h14"/></svg>';
  canvasBar.append(canvasTitle, zoomTools, btnExport);
  const svgHost = el('div', 'xref-map-svg-host gene-pan-viewport');
  svgHost.title = 'Klik op ▶/▼ om takken te openen · sleep om te verschuiven · scroll om te zoomen';
  canvasWrap.append(canvasBar, svgHost);
  main.append(canvasWrap);

  const tip = el('div', 'xref-map-tip');
  tip.hidden = true;
  layout.append(tip);
  btnExport.onclick = () => exportGraphPng(svgHost, btnExport);

  // Zijpaneel — toont biografie bij klik op een persoon
  const sideHead = el('div', 'xref-side-head');
  const sideTitle = el('h3', 'xref-filter-title', 'Biografie');
  sideHead.append(sideTitle);
  const btnCollapse = el('button', 'xref-side-collapse', '‹');
  btnCollapse.type = 'button';
  btnCollapse.title = 'Paneel inklappen';
  sideHead.append(btnCollapse);
  side.append(sideHead);
  const sideBody = el('div', 'xref-side-body');
  side.append(sideBody);

  function setFilterOpen(open) {
    layout.classList.toggle('filters-collapsed', !open);
    btnToggleFilter.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  btnToggleFilter.onclick = () => {
    // ⚙ toont uitleg / help in het paneel
    showHelp();
    setFilterOpen(true);
  };
  btnCollapse.onclick = () => setFilterOpen(false);

  function showHelp() {
    sideTitle.textContent = 'Uitleg';
    sideBody.replaceChildren();
    sideBody.append(el('p', 'xref-filter-hint', 'Bron'));
    sideBody.append(el('p', 'xref-filter-hint', 'Stamboom op basis van Genesis 4–11, 1 Kronieken 1, de aartsvaders, stammen van Israël, en de lijnen naar Jezus (Mat. 1 / Luc. 3).'));
    sideBody.append(el('p', 'xref-filter-hint', 'Klik op een persoon voor de biografie. Klik op +/− om takken te openen of te sluiten. Sleep om te verschuiven, scroll om te zoomen.'));
    sideBody.append(el('p', 'xref-filter-hint', '“Hoofdlijn” houdt de route naar Jezus open; zijtakken (Kaïn, Cham, Jafet, …) kun je zelf uitklappen.'));
  }

  const ROLE_LABELS = {
    god: 'God',
    king: 'Koning',
    priest: 'Priester / hogepriester',
    prophet: 'Profeet',
    tribe: 'Stamvader',
    messiah: 'Messias',
    royal: 'Koninklijke lijn',
  };

  /** @param {ReturnType<typeof cloneTree>} person */
  function showBio(person) {
    sideTitle.textContent = 'Biografie';
    sideBody.replaceChildren();
    const nameEl = el('p', 'gene-bio-name', person.name);
    sideBody.append(nameEl);
    if (person.role && ROLE_LABELS[person.role]) {
      sideBody.append(el('p', 'gene-bio-row', `Rol: ${ROLE_LABELS[person.role]}`));
    }
    if (person.spouse) {
      sideBody.append(el('p', 'gene-bio-row', `Partner: ${person.spouse}`));
    }
    if (person.note) {
      sideBody.append(el('p', 'gene-bio-note', person.note));
    } else {
      sideBody.append(el('p', 'xref-filter-hint', 'Geen extra bijbelnotitie voor deze persoon in de stamboomdata.'));
    }
    const kids = person.children || [];
    if (kids.length) {
      sideBody.append(el('p', 'xref-filter-hint', `Kinderen (${kids.length})`));
      const list = el('ul', 'gene-bio-kids');
      kids.forEach((c) => {
        const li = document.createElement('li');
        li.textContent = c.name + (c.note ? ` — ${c.note}` : '');
        list.appendChild(li);
      });
      sideBody.append(list);
    }
    setFilterOpen(true);
  }

  showHelp();

  // Diepe kopie van de boom zodat open/dicht state lokaal is
  function cloneTree(node) {
    return {
      name: node.name,
      note: node.note || '',
      spouse: node.spouse || '',
      role: node.role || '',
      banner: node.banner || '',
      highlight: !!node.highlight,
      open: node.open !== false,
      children: (node.children || []).map(cloneTree),
    };
  }
  let root = cloneTree(BIBLE_FAMILY_TREE);

  function walk(node, fn) {
    fn(node);
    (node.children || []).forEach((c) => walk(c, fn));
  }

  function setAllOpen(open) {
    walk(root, (n) => { if (n.children && n.children.length) n.open = open; });
  }

  /** Houd pad naar Jezus open; klap rest in */
  function openMainLineOnly() {
    setAllOpen(false);
    function markPath(node) {
      if (node.name === 'Jezus' || node.highlight) {
        node.open = !!(node.children && node.children.length);
        return node.name === 'Jezus' || node.highlight;
      }
      let found = false;
      (node.children || []).forEach((c) => {
        if (markPath(c)) found = true;
      });
      if (found) node.open = true;
      return found;
    }
    markPath(root);
    root.open = true;
  }

  btnExpandMain.onclick = () => {
    btnExpandMain.classList.add('is-active');
    btnExpandAll.classList.remove('is-active');
    openMainLineOnly();
    render();
  };
  btnExpandAll.onclick = () => {
    btnExpandAll.classList.add('is-active');
    btnExpandMain.classList.remove('is-active');
    setAllOpen(true);
    render();
  };

  // Zoom / pan
  let contentW = 900;
  let contentH = 600;
  let viewX = 0;
  let viewY = 0;
  let viewW = 900;
  let viewH = 600;
  let dragging = false;
  let dragLastX = 0;
  let dragLastY = 0;
  /** @type {SVGSVGElement|null} */
  let liveSvg = null;

  function currentZoom() { return contentW / Math.max(1, viewW); }
  function applyViewBox() {
    if (liveSvg) liveSvg.setAttribute('viewBox', `${viewX} ${viewY} ${viewW} ${viewH}`);
    zoomLabel.textContent = Math.round(currentZoom() * 100) + '%';
  }
  function setZoom(next, clientX, clientY) {
    // Tot 50× (5000%) — diep inzoomen op takken
    const z = Math.max(0.25, Math.min(50, next));
    const rect = svgHost.getBoundingClientRect();
    const mx = clientX != null
      ? viewX + ((clientX - rect.left) / Math.max(1, rect.width)) * viewW
      : viewX + viewW / 2;
    const my = clientY != null
      ? viewY + ((clientY - rect.top) / Math.max(1, rect.height)) * viewH
      : viewY + viewH / 2;
    const newW = contentW / z;
    const newH = (contentH / contentW) * newW;
    const fx = clientX != null ? (clientX - rect.left) / Math.max(1, rect.width) : 0.5;
    const fy = clientY != null ? (clientY - rect.top) / Math.max(1, rect.height) : 0.5;
    viewX = mx - fx * newW;
    viewY = my - fy * newH;
    viewW = newW;
    viewH = newH;
    applyViewBox();
  }
  function resetView() {
    viewX = 0;
    viewY = 0;
    viewW = contentW;
    viewH = Math.min(contentH, 640);
    applyViewBox();
  }
  btnZoomIn.onclick = () => setZoom(currentZoom() * 1.25);
  btnZoomOut.onclick = () => setZoom(currentZoom() / 1.25);
  btnZoomReset.onclick = () => resetView();
  svgHost.addEventListener('wheel', (ev) => {
    ev.preventDefault();
    setZoom(currentZoom() * (ev.deltaY < 0 ? 1.12 : 1 / 1.12), ev.clientX, ev.clientY);
  }, { passive: false });
  svgHost.addEventListener('pointerdown', (ev) => {
    if (ev.button !== 0) return;
    // niet slepen als op knop
    if (ev.target && ev.target.closest && ev.target.closest('.gene-toggle')) return;
    dragging = true;
    dragLastX = ev.clientX;
    dragLastY = ev.clientY;
    svgHost.classList.add('is-panning');
    svgHost.setPointerCapture(ev.pointerId);
  });
  svgHost.addEventListener('pointermove', (ev) => {
    if (!dragging) return;
    const rect = svgHost.getBoundingClientRect();
    const dx = ((ev.clientX - dragLastX) / Math.max(1, rect.width)) * viewW;
    const dy = ((ev.clientY - dragLastY) / Math.max(1, rect.height)) * viewH;
    dragLastX = ev.clientX;
    dragLastY = ev.clientY;
    viewX -= dx;
    viewY -= dy;
    applyViewBox();
  });
  function endPan(ev) {
    if (!dragging) return;
    dragging = false;
    svgHost.classList.remove('is-panning');
    try { svgHost.releasePointerCapture(ev.pointerId); } catch (_) {}
  }
  svgHost.addEventListener('pointerup', endPan);
  svgHost.addEventListener('pointercancel', endPan);

  /**
   * Layout: top-down, strak ingepakt.
   * Sibling-subbomen met minimale tussenruimte — geen grote lege gaten.
   */
  function layoutTree(node) {
    const V_GAP = 72; // ruimte voor label onder de knoop
    const X_SP = 34;  // horizontale eenheid — compact
    const SIB_GAP = 0.7; // spleet tussen sibling-subbomen (in eenheden)

    function place(n, depth) {
      n._depth = depth;
      n._y = depth;
      const kids = (n.open && n.children && n.children.length) ? n.children : [];
      if (!kids.length) {
        n._w = 1;
        return;
      }
      kids.forEach((c) => place(c, depth + 1));
      let w = 0;
      kids.forEach((c, i) => {
        if (i > 0) w += SIB_GAP;
        w += c._w;
      });
      n._w = Math.max(1, w);
    }

    function setAbsolute(n, left) {
      n._xAbs = left + n._w / 2;
      const kids = (n.open && n.children && n.children.length) ? n.children : [];
      let cursor = left;
      // centreer kinderen binnen de ouder-breedte
      const kidsW = kids.reduce((s, c, i) => s + c._w + (i > 0 ? SIB_GAP : 0), 0);
      if (kidsW < n._w) cursor = left + (n._w - kidsW) / 2;
      kids.forEach((c, i) => {
        if (i > 0) cursor += SIB_GAP;
        setAbsolute(c, cursor);
        cursor += c._w;
      });
    }

    place(node, 0);
    setAbsolute(node, 0);

    const nodes = [];
    function collect(n, parent) {
      n._px = 24 + n._xAbs * X_SP;
      n._py = 40 + n._y * V_GAP;
      nodes.push({ node: n, parent });
      if (n.open && n.children) n.children.forEach((c) => collect(c, n));
    }
    collect(node, null);
    const maxX = Math.max(...nodes.map((o) => o.node._px), 120);
    const maxY = Math.max(...nodes.map((o) => o.node._py), 80);
    return { nodes, width: maxX + 40, height: maxY + 48, V_GAP };
  }

  function countNodes(n) {
    let c = 1;
    (n.children || []).forEach((ch) => { c += countNodes(ch); });
    return c;
  }

  function render() {
    const { nodes, width, height } = layoutTree(root);
    contentW = Math.max(640, width);
    contentH = Math.max(400, height);
    if (!liveSvg) {
      viewX = 0;
      viewY = 0;
      viewW = contentW;
      viewH = Math.min(contentH, 640);
    }

    const visible = nodes.length;
    const total = countNodes(root);
    statsRow.replaceChildren();
    [
      [String(visible), 'zichtbaar'],
      [String(total), 'personen in boom'],
      [String(nodes.filter((o) => o.node.highlight).length), 'kernfiguren'],
      ['Adam–Jezus', 'span'],
    ].forEach(([val, lab]) => {
      const c = el('div', 'xref-map-stat');
      c.append(el('span', 'xref-map-stat-val', val));
      c.append(el('span', 'xref-map-stat-lab', lab));
      statsRow.append(c);
    });

    svgHost.replaceChildren();
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', `${viewX} ${viewY} ${viewW} ${viewH}`);
    svg.setAttribute('class', 'xref-map-svg gene-tree-svg');
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', 'Bijbelse stamboom');
    svg.style.touchAction = 'none';
    svg.setAttribute('preserveAspectRatio', 'xMinYMin meet');
    liveSvg = svg;

    // Takken (ouder → kind)
    nodes.forEach(({ node: n, parent }) => {
      if (!parent) return;
      const x1 = parent._px;
      const y1 = parent._py + 14;
      const x2 = n._px;
      const y2 = n._py - 14;
      const midY = (y1 + y2) / 2;
      const path = document.createElementNS(ns, 'path');
      path.setAttribute('d', `M ${x1} ${y1} V ${midY} H ${x2} V ${y2}`);
      path.setAttribute('fill', 'none');
      const lineCol = (n.role && ROLE_COLORS[n.role])
        || (parent.role && ROLE_COLORS[parent.role])
        || (n.highlight || parent.highlight ? ROLE_COLORS.messiah : '#c4b4b0');
      path.setAttribute('stroke', lineCol);
      path.setAttribute('stroke-width', n.highlight || parent.highlight ? '2' : '1.25');
      path.setAttribute('stroke-opacity', '0.8');
      svg.appendChild(path);
    });

    // Knopen
    nodes.forEach(({ node: n }) => {
      const g = document.createElementNS(ns, 'g');
      g.setAttribute('transform', `translate(${n._px},${n._py})`);

      const hasKids = n.children && n.children.length > 0;
      const roleCol = (n.role && ROLE_COLORS[n.role]) || (n.highlight ? ROLE_COLORS.messiah : ROLE_COLORS.default);
      const filled = n.highlight || n.role === 'king' || n.role === 'messiah' || n.role === 'god' || n.role === 'priest';

      // Tijdvak-banner (Zondvloed, Egypte, Ballingschap)
      if (n.banner) {
        const bw = Math.max(140, n.banner.length * 8);
        const br = document.createElementNS(ns, 'rect');
        br.setAttribute('x', String(-bw / 2));
        br.setAttribute('y', '-40');
        br.setAttribute('width', String(bw));
        br.setAttribute('height', '16');
        br.setAttribute('rx', '8');
        br.setAttribute('fill', '#2a2a2a');
        g.appendChild(br);
        const bt = document.createElementNS(ns, 'text');
        bt.setAttribute('x', '0');
        bt.setAttribute('y', '-28');
        bt.setAttribute('text-anchor', 'middle');
        bt.setAttribute('font-size', '9');
        bt.setAttribute('font-weight', '700');
        bt.setAttribute('fill', '#fff');
        bt.setAttribute('font-family', 'system-ui,sans-serif');
        bt.textContent = n.banner;
        g.appendChild(bt);
      }

      // Toggle links van de knoop
      if (hasKids) {
        const tog = document.createElementNS(ns, 'g');
        tog.setAttribute('class', 'gene-toggle');
        tog.style.cursor = 'pointer';
        const bg = document.createElementNS(ns, 'circle');
        bg.setAttribute('cx', '-18');
        bg.setAttribute('cy', '0');
        bg.setAttribute('r', '7');
        bg.setAttribute('fill', '#fff');
        bg.setAttribute('stroke', roleCol);
        bg.setAttribute('stroke-width', '1.5');
        const txt = document.createElementNS(ns, 'text');
        txt.setAttribute('x', '-18');
        txt.setAttribute('y', '3.5');
        txt.setAttribute('text-anchor', 'middle');
        txt.setAttribute('font-size', '11');
        txt.setAttribute('font-weight', '700');
        txt.setAttribute('fill', roleCol);
        txt.setAttribute('font-family', 'system-ui,sans-serif');
        txt.textContent = n.open ? '−' : '+';
        tog.append(bg, txt);
        tog.addEventListener('click', (ev) => {
          ev.stopPropagation();
          n.open = !n.open;
          render();
        });
        g.appendChild(tog);
      }

      const circle = document.createElementNS(ns, 'circle');
      circle.setAttribute('r', n.highlight ? '10' : '7');
      circle.setAttribute('fill', filled ? roleCol : '#fff');
      circle.setAttribute('stroke', roleCol);
      circle.setAttribute('stroke-width', n.highlight ? '2.5' : '1.75');
      g.appendChild(circle);

      // Naam onder de knoop (geen tekst rechts → smallere boom)
      const label = document.createElementNS(ns, 'text');
      label.setAttribute('x', '0');
      label.setAttribute('y', '22');
      label.setAttribute('text-anchor', 'middle');
      label.setAttribute('font-size', n.highlight ? '11' : '10');
      label.setAttribute('font-weight', n.highlight ? '700' : '600');
      label.setAttribute('fill', roleCol);
      label.setAttribute('font-family', 'system-ui,sans-serif');
      label.textContent = n.name;
      label.style.cursor = 'pointer';
      circle.style.cursor = 'pointer';
      g.appendChild(label);

      // Geen notitietekst onder de naam — biografie in het zijpaneel
      const openBio = (ev) => {
        if (dragging) return;
        ev.stopPropagation();
        tip.hidden = true;
        showBio(n);
      };
      circle.addEventListener('click', openBio);
      label.addEventListener('click', openBio);

      const tipText = n.name + (n.spouse ? ` · ${n.spouse}` : '') + ' — klik voor biografie';
      const showTip = (ev) => {
        if (dragging) return;
        tip.hidden = false;
        tip.textContent = tipText;
        tip.style.left = (ev.clientX + 12) + 'px';
        tip.style.top = (ev.clientY + 12) + 'px';
      };
      const hideTip = () => { tip.hidden = true; };
      circle.addEventListener('mouseenter', showTip);
      circle.addEventListener('mousemove', showTip);
      circle.addEventListener('mouseleave', hideTip);
      label.addEventListener('mouseenter', showTip);
      label.addEventListener('mousemove', showTip);
      label.addEventListener('mouseleave', hideTip);

      svg.appendChild(g);
    });

    svgHost.appendChild(svg);
    applyViewBox();

    const legend = el('div', 'xref-map-legend');
    legend.innerHTML = `
      <div class="xref-leg-scale">
        <p class="xref-leg-scale-hint">
          <span style="color:${ROLE_COLORS.god}">●</span> God ·
          <span style="color:${ROLE_COLORS.king}">●</span> koning ·
          <span style="color:${ROLE_COLORS.priest}">●</span> priester ·
          <span style="color:${ROLE_COLORS.prophet}">●</span> profeet ·
          <span style="color:${ROLE_COLORS.royal}">●</span> koningslijn ·
          <span style="color:${ROLE_COLORS.tribe}">●</span> stam ·
          <span style="color:${ROLE_COLORS.messiah}">●</span> Messias.
          Klik op een persoon voor biografie. +/− opent takken.
          Banners: Zondvloed · Slavernij in Egypte · Ballingschap.
        </p>
      </div>
    `;
    svgHost.appendChild(legend);
  }

  openMainLineOnly();
  render();
  return layout;
}

/** Staafdiagram: verzen per hoofdstuk — zelfde layout-template als kruisverwijzingen. */
function buildVersesBarView() {
  const layout = el('div', 'xref-map-layout');
  const main = el('div', 'xref-map-main');
  const side = el('div', 'xref-map-side');
  layout.append(main, side);

  const head = el('div', 'xref-map-head');
  const headTop = el('div', 'xref-map-head-top');
  headTop.append(el('h2', 'xref-map-title', 'Verzen per hoofdstuk'));

  // Modus: per boek | per hoofdstuk | alle boeken
  const modeSeg = el('div', 'xref-mode-seg');
  const btnModeBook = el('button', 'xref-mode-btn is-active', 'Per boek');
  btnModeBook.type = 'button';
  btnModeBook.title = 'Eén staaf per boek (totaal aantal verzen)';
  const btnModeChap = el('button', 'xref-mode-btn', 'Per hoofdstuk');
  btnModeChap.type = 'button';
  btnModeChap.title = 'Hoofdstukken van één boek';
  const btnModeAll = el('button', 'xref-mode-btn', 'Alle boeken');
  btnModeAll.type = 'button';
  btnModeAll.title = 'Alle hoofdstukken van alle gekozen boeken in één grafiek';
  modeSeg.append(btnModeBook, btnModeChap, btnModeAll);
  headTop.append(modeSeg);

  const btnToggleFilter = el('button', 'xref-filter-toggle');
  btnToggleFilter.type = 'button';
  btnToggleFilter.title = 'Instellingen';
  btnToggleFilter.setAttribute('aria-label', 'Instellingen openen of sluiten');
  btnToggleFilter.setAttribute('aria-expanded', 'true');
  btnToggleFilter.innerHTML = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`;
  headTop.append(btnToggleFilter);
  head.append(headTop);

  const statsRow = el('div', 'xref-map-stats');
  head.append(statsRow);
  main.append(head);

  const canvasWrap = el('div', 'xref-map-canvas-wrap');
  const canvasBar = el('div', 'xref-map-canvas-bar');
  const canvasTitle = el('span', 'xref-map-canvas-bar-title', 'Verzen per hoofdstuk');
  const btnExport = el('button', 'xref-export-btn');
  btnExport.type = 'button';
  btnExport.title = 'Grafiek downloaden als PNG';
  btnExport.setAttribute('aria-label', 'Grafiek downloaden als PNG');
  btnExport.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 19h14"/></svg>';
  canvasBar.append(canvasTitle, btnExport);
  const svgHost = el('div', 'xref-map-svg-host');
  canvasWrap.append(canvasBar, svgHost);
  main.append(canvasWrap);

  const tip = el('div', 'xref-map-tip');
  tip.hidden = true;
  layout.append(tip);

  btnExport.onclick = () => exportGraphPng(svgHost, btnExport);

  // —— Zijpaneel (Instellingen) ——
  const sideHead = el('div', 'xref-side-head');
  sideHead.append(el('h3', 'xref-filter-title', 'Instellingen'));
  const btnCollapse = el('button', 'xref-side-collapse', '‹');
  btnCollapse.type = 'button';
  btnCollapse.title = 'Paneel inklappen';
  sideHead.append(btnCollapse);
  side.append(sideHead);
  const sideBody = el('div', 'xref-side-body');

  // Kleur-uitleg (zelfde stijl als xref)
  const colorBox = el('div', 'xref-stroke-box');
  colorBox.append(el('p', 'xref-filter-hint', 'Kleur van de staven'));
  colorBox.append(el('p', 'xref-filter-hint', 'Groen (weinig verzen) → rood (veel verzen), relatief binnen de huidige weergave.'));
  sideBody.append(colorBox);

  // Boekfilter
  sideBody.append(el('p', 'xref-filter-hint', 'Per boek / Alle boeken: vink boeken aan of uit. Per hoofdstuk: kies één boek.'));
  const filterActions = el('div', 'xref-filter-actions');
  const btnAll = el('button', 'xref-filter-btn', 'Alles');
  btnAll.type = 'button';
  const btnOt = el('button', 'xref-filter-btn', 'OT');
  btnOt.type = 'button';
  const btnNt = el('button', 'xref-filter-btn', 'NT');
  btnNt.type = 'button';
  filterActions.append(btnAll, btnOt, btnNt);
  sideBody.append(filterActions);

  const bookList = el('div', 'xref-filter-list');
  sideBody.append(bookList);
  side.append(sideBody);

  // OT eindigt bij Maleachi in deze canon
  const OT_END = 'Mal';
  const otBooks = [];
  const ntBooks = [];
  let seenNt = false;
  BOOK_ORDER.forEach((b) => {
    if (!seenNt) otBooks.push(b);
    else ntBooks.push(b);
    if (b === OT_END) seenNt = true;
  });

  /** @type {'book'|'chapter'|'all'} */
  let mode = 'book';
  let selectedBook = 'Gen';
  /** @type {Set<string>} */
  let enabled = new Set(BOOK_ORDER);

  function setFilterOpen(open) {
    layout.classList.toggle('filters-collapsed', !open);
    btnToggleFilter.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  btnToggleFilter.onclick = () => setFilterOpen(layout.classList.contains('filters-collapsed'));
  btnCollapse.onclick = () => setFilterOpen(false);

  function setMode(m) {
    if (m === 'chapter') mode = 'chapter';
    else if (m === 'all') mode = 'all';
    else mode = 'book';
    btnModeBook.classList.toggle('is-active', mode === 'book');
    btnModeChap.classList.toggle('is-active', mode === 'chapter');
    btnModeAll.classList.toggle('is-active', mode === 'all');
    // Per hoofdstuk: radio (één boek). Per boek / Alle boeken: checkboxes.
    buildBookList();
    render();
  }
  btnModeBook.onclick = () => setMode('book');
  btnModeChap.onclick = () => setMode('chapter');
  btnModeAll.onclick = () => setMode('all');

  function buildBookList() {
    bookList.replaceChildren();
    BOOK_ORDER.forEach((osis) => {
      const row = el('label', 'xref-filter-row');
      const input = document.createElement('input');
      if (mode === 'chapter') {
        input.type = 'radio';
        input.name = 'verses-book';
        input.checked = osis === selectedBook;
        input.onchange = () => {
          if (input.checked) {
            selectedBook = osis;
            render();
          }
        };
      } else {
        input.type = 'checkbox';
        input.checked = enabled.has(osis);
        input.onchange = () => {
          if (input.checked) enabled.add(osis);
          else enabled.delete(osis);
          render();
        };
      }
      input.dataset.book = osis;
      const name = el('span', 'xref-filter-name', BOOK_LABELS_NL[osis] || osis);
      row.append(input, name);
      bookList.append(row);
    });
  }

  btnAll.onclick = () => {
    if (mode === 'chapter') {
      selectedBook = 'Gen';
    } else {
      enabled = new Set(BOOK_ORDER);
    }
    buildBookList();
    render();
  };
  btnOt.onclick = () => {
    if (mode === 'chapter') {
      selectedBook = otBooks[0] || 'Gen';
    } else {
      enabled = new Set(otBooks);
    }
    buildBookList();
    render();
  };
  btnNt.onclick = () => {
    if (mode === 'chapter') {
      selectedBook = ntBooks[0] || 'Matt';
    } else {
      enabled = new Set(ntBooks);
    }
    buildBookList();
    render();
  };

  /**
   * Tekent staven voor hoofdstukken.
   * @param {{ label: string, value: number, bookOsis?: string, chapter?: number }[]} items
   * @param {{ bookStarts?: { index: number, osis: string, name: string }[], subtitle?: string }} opts
   */
  function renderBars(items, opts) {
    opts = opts || {};
    svgHost.replaceChildren();
    const n = items.length;
    if (n < 1) {
      svgHost.append(el('p', 'xref-map-empty', 'Geen gegevens om te tonen. Zet minstens één boek aan in de filter.'));
      return;
    }
    const values = items.map((it) => it.value);
    const maxV = Math.max(1, ...values);
    const total = values.reduce((a, b) => a + b, 0);
    const avg = total / n;
    const maxIdx = values.indexOf(maxV);
    const bookStarts = opts.bookStarts || [];

    statsRow.replaceChildren();
    const isBookTotals = mode === 'book';
    const nBooks = bookStarts.length || (mode === 'chapter' ? 1 : 0);
    [
      isBookTotals ? [String(n), 'boeken'] : [String(n), 'hoofdstukken'],
      !isBookTotals && nBooks > 1 ? [String(nBooks), 'boeken'] : null,
      [String(total), 'verzen'],
      [avg.toFixed(1), 'gemiddelde'],
      [items[maxIdx].label, `max (${maxV})`],
    ].filter(Boolean).forEach(([val, lab]) => {
      const c = el('div', 'xref-map-stat');
      c.append(el('span', 'xref-map-stat-val', val));
      c.append(el('span', 'xref-map-stat-lab', lab));
      statsRow.append(c);
    });

    // Breed genoeg zodat alle hoofdstukken zichtbaar zijn (horizontaal scrollen)
    const minBar = n > 400 ? 3 : n > 200 ? 4 : n > 80 ? 6 : 10;
    const barGap = n > 400 ? 0.5 : n > 200 ? 1 : n > 80 ? 1.5 : 3;
    const W = Math.max(900, Math.ceil(n * (minBar + barGap) + 100));
    const H = 560;
    const padL = 52, padR = 20, padT = 36, padB = 88;
    const plotW = W - padL - padR;
    const plotH = H - padT - padB;
    const barW = Math.max(minBar, (plotW / n) - barGap);

    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    svg.setAttribute('class', 'xref-map-svg verses-bar-svg');
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', canvasTitle.textContent);

    // Raster
    const ticks = 5;
    for (let i = 0; i <= ticks; i++) {
      const v = Math.round((maxV * i) / ticks);
      const y = padT + plotH - (plotH * i) / ticks;
      const line = document.createElementNS(ns, 'line');
      line.setAttribute('x1', String(padL));
      line.setAttribute('x2', String(W - padR));
      line.setAttribute('y1', y.toFixed(1));
      line.setAttribute('y2', y.toFixed(1));
      line.setAttribute('stroke', '#e8ddd8');
      line.setAttribute('stroke-width', '1');
      svg.appendChild(line);
      const lab = document.createElementNS(ns, 'text');
      lab.setAttribute('x', String(padL - 8));
      lab.setAttribute('y', (y + 4).toFixed(1));
      lab.setAttribute('text-anchor', 'end');
      lab.setAttribute('font-size', '12');
      lab.setAttribute('fill', '#7a6a6c');
      lab.setAttribute('font-family', 'system-ui,sans-serif');
      lab.textContent = String(v);
      svg.appendChild(lab);
    }

    // Boekscheiders + boeklabels (boven de staven)
    bookStarts.forEach((bs, bi) => {
      const x = padL + bs.index * (barW + barGap);
      if (bs.index > 0) {
        const div = document.createElementNS(ns, 'line');
        div.setAttribute('x1', x.toFixed(1));
        div.setAttribute('x2', x.toFixed(1));
        div.setAttribute('y1', String(padT - 4));
        div.setAttribute('y2', String(padT + plotH));
        div.setAttribute('stroke', '#c4b4b0');
        div.setAttribute('stroke-width', '1');
        div.setAttribute('stroke-dasharray', '3 3');
        svg.appendChild(div);
      }
      // Einde van dit boekblok
      const nextIdx = bi + 1 < bookStarts.length ? bookStarts[bi + 1].index : n;
      const midX = padL + ((bs.index + nextIdx) / 2) * (barW + barGap);
      const tx = document.createElementNS(ns, 'text');
      tx.setAttribute('x', midX.toFixed(1));
      tx.setAttribute('y', String(padT - 12));
      tx.setAttribute('text-anchor', 'middle');
      tx.setAttribute('font-size', n > 300 ? '9' : '11');
      tx.setAttribute('font-weight', '600');
      tx.setAttribute('fill', '#7a1f2b');
      tx.setAttribute('font-family', 'system-ui,sans-serif');
      tx.textContent = bs.name;
      svg.appendChild(tx);
    });

    // Verticale stippellijn OT ↔ NT (50% zichtbaarheid), zoals bij kruisverwijzingen
    // otEndIndex = index van laatste OT-staaf; lijn tussen die en de volgende
    const otEndIndex = typeof opts.otEndIndex === 'number' ? opts.otEndIndex : -1;
    if (otEndIndex >= 0 && otEndIndex < n - 1) {
      const x1 = padL + otEndIndex * (barW + barGap) + barGap / 2 + barW / 2;
      const x2 = padL + (otEndIndex + 1) * (barW + barGap) + barGap / 2 + barW / 2;
      const divX = (x1 + x2) / 2;
      const div = document.createElementNS(ns, 'line');
      div.setAttribute('x1', divX.toFixed(1));
      div.setAttribute('x2', divX.toFixed(1));
      div.setAttribute('y1', String(padT - 4));
      div.setAttribute('y2', String(padT + plotH));
      div.setAttribute('stroke', '#7a1f2b');
      div.setAttribute('stroke-width', '1.25');
      div.setAttribute('stroke-dasharray', '4 5');
      div.setAttribute('stroke-opacity', '0.5');
      div.setAttribute('class', 'xref-ot-nt-divider');
      svg.appendChild(div);
      // Korte labels bovenaan naast de lijn — niet door de boeknamen heen
      const tOt = document.createElementNS(ns, 'text');
      tOt.setAttribute('x', (divX - 8).toFixed(1));
      tOt.setAttribute('y', String(padT - 10));
      tOt.setAttribute('text-anchor', 'end');
      tOt.setAttribute('font-size', '11');
      tOt.setAttribute('font-weight', '600');
      tOt.setAttribute('fill', '#7a1f2b');
      tOt.setAttribute('fill-opacity', '0.75');
      tOt.setAttribute('font-family', 'system-ui,sans-serif');
      tOt.textContent = 'OT';
      svg.appendChild(tOt);
      const tNt = document.createElementNS(ns, 'text');
      tNt.setAttribute('x', (divX + 8).toFixed(1));
      tNt.setAttribute('y', String(padT - 10));
      tNt.setAttribute('text-anchor', 'start');
      tNt.setAttribute('font-size', '11');
      tNt.setAttribute('font-weight', '600');
      tNt.setAttribute('fill', '#7a1f2b');
      tNt.setAttribute('fill-opacity', '0.75');
      tNt.setAttribute('font-family', 'system-ui,sans-serif');
      tNt.textContent = 'NT';
      svg.appendChild(tNt);
    }

    const bars = [];
    items.forEach((it, i) => {
      const v = it.value;
      const x = padL + i * (barW + barGap) + barGap / 2;
      const h = (v / maxV) * plotH;
      const y = padT + plotH - h;
      const t = v / maxV;
      const hue = 120 * (1 - t);
      const rect = document.createElementNS(ns, 'rect');
      rect.setAttribute('x', x.toFixed(1));
      rect.setAttribute('y', y.toFixed(1));
      rect.setAttribute('width', barW.toFixed(1));
      rect.setAttribute('height', Math.max(1, h).toFixed(1));
      rect.setAttribute('rx', barW > 4 ? '2' : '1');
      rect.setAttribute('fill', `hsl(${hue.toFixed(0)}, 62%, 42%)`);
      rect.setAttribute('class', 'verses-bar');
      rect.style.cursor = 'default';
      const tipText = `${it.label} · ${v} verzen`;
      rect.addEventListener('mouseenter', () => {
        bars.forEach((b) => { b.style.opacity = '0.22'; });
        rect.style.opacity = '1';
        tip.hidden = false;
        tip.textContent = tipText;
      });
      rect.addEventListener('mousemove', (ev) => {
        tip.style.left = (ev.clientX + 12) + 'px';
        tip.style.top = (ev.clientY + 12) + 'px';
      });
      rect.addEventListener('mouseleave', () => {
        bars.forEach((b) => { b.style.opacity = '1'; });
        tip.hidden = true;
      });
      svg.appendChild(rect);
      bars.push(rect);

      // X-labels
      const isBookStart = bookStarts.some((bs) => bs.index === i);
      const showEvery = n > 200 ? 20 : n > 80 ? 10 : n > 30 ? 5 : 1;
      let showLab = false;
      let labText = '';
      if (mode === 'book') {
        // Eén staaf per boek: label = boeknaam
        showLab = true;
        labText = BOOK_LABELS_NL[it.bookOsis] || it.bookOsis || it.label;
      } else if (mode === 'chapter') {
        showLab = (i + 1) % showEvery === 0 || i === 0 || i === n - 1;
        labText = String(i + 1);
      } else {
        showLab = isBookStart || (it.chapter && it.chapter % showEvery === 0);
        labText = isBookStart ? (BOOK_LABELS_NL[it.bookOsis] || it.bookOsis) : String(it.chapter || '');
      }
      if (showLab) {
        const tx = document.createElementNS(ns, 'text');
        tx.setAttribute('x', (x + barW / 2).toFixed(1));
        tx.setAttribute('y', String(H - padB + 14));
        tx.setAttribute('text-anchor', 'start');
        tx.setAttribute('font-size', n > 200 ? '9' : '10');
        tx.setAttribute('fill', '#5a4a4c');
        tx.setAttribute('font-family', 'system-ui,sans-serif');
        tx.setAttribute('transform', `rotate(58 ${x + barW / 2} ${H - padB + 14})`);
        tx.textContent = labText;
        svg.appendChild(tx);
      }
    });

    svgHost.appendChild(svg);

    const legend = el('div', 'xref-map-legend');
    legend.innerHTML = `
      <div class="xref-leg-scale">
        <div class="xref-leg-gradient-row">
          <span class="xref-leg-end">weinig</span>
          <span class="xref-leg-gradient xref-leg-gradient-amount" aria-hidden="true"></span>
          <span class="xref-leg-end">veel</span>
        </div>
        <div class="xref-leg-gradient-labels">
          <span style="color:#2d8a3e">groen</span>
          <span style="color:#c4a020">geel</span>
          <span style="color:#c41e1e">rood</span>
        </div>
        <p class="xref-leg-scale-hint">Hoe roder, hoe meer verzen (max. ${maxV}). ${
          opts.subtitle || ''
        }</p>
      </div>
    `;
    svgHost.appendChild(legend);
  }

  /** Index van laatste OT-item in een items-lijst, of -1 als OT/NT grens niet zichtbaar is. */
  function findOtEndIndex(items) {
    let lastOt = -1;
    for (let i = 0; i < items.length; i++) {
      const osis = items[i].bookOsis;
      if (!osis) continue;
      if (otBooks.includes(osis)) lastOt = i;
      else if (ntBooks.includes(osis) && lastOt >= 0) return lastOt;
    }
    return -1;
  }

  function render() {
    if (mode === 'book') {
      // Eén staaf per boek: totaal aantal verzen
      const books = BOOK_ORDER.filter((b) => enabled.has(b));
      const items = books.map((osis) => {
        const counts = VERSE_COUNTS[osis] || [];
        const total = counts.reduce((a, c) => a + c, 0);
        return {
          label: BOOK_LABELS_NL[osis] || osis,
          value: total,
          bookOsis: osis,
        };
      });
      canvasTitle.textContent = 'Totaal verzen per boek';
      renderBars(items, {
        otEndIndex: findOtEndIndex(items),
        subtitle: `${items.length} boeken. Elke staaf = totaal verzen in dat boek.`,
      });
    } else if (mode === 'chapter') {
      // Hoofdstukken van één gekozen boek — geen OT/NT-lijn nodig
      const counts = VERSE_COUNTS[selectedBook] || [];
      const items = counts.map((v, i) => ({
        label: `${BOOK_LABELS_NL[selectedBook] || selectedBook} ${i + 1}`,
        value: v,
        bookOsis: selectedBook,
        chapter: i + 1,
      }));
      canvasTitle.textContent = `Verzen per hoofdstuk — ${BOOK_LABELS_NL[selectedBook] || selectedBook}`;
      renderBars(items, {
        subtitle: `Boek: ${BOOK_LABELS_NL[selectedBook] || selectedBook}. Elke staaf = één hoofdstuk.`,
      });
    } else {
      // Alle hoofdstukken van alle aangevinkte boeken in één grafiek
      const books = BOOK_ORDER.filter((b) => enabled.has(b));
      const items = [];
      const bookStarts = [];
      books.forEach((osis) => {
        const counts = VERSE_COUNTS[osis] || [];
        if (!counts.length) return;
        bookStarts.push({
          index: items.length,
          osis,
          name: BOOK_LABELS_NL[osis] || osis,
        });
        counts.forEach((v, i) => {
          items.push({
            label: `${BOOK_LABELS_NL[osis] || osis} ${i + 1}`,
            value: v,
            bookOsis: osis,
            chapter: i + 1,
          });
        });
      });
      canvasTitle.textContent = 'Verzen per hoofdstuk — alle boeken';
      renderBars(items, {
        bookStarts,
        otEndIndex: findOtEndIndex(items),
        subtitle: `${items.length} hoofdstukken in ${bookStarts.length} boeken, naast elkaar in één grafiek.`,
      });
    }
  }

  buildBookList();
  render();
  return layout;
}

/** Bouwt de bestaande kruisverwijzingenkaart (geen eigen terug-knop: header ← doet dat). */
function buildXrefMapView() {
  const layout = el('div', 'xref-map-layout');

  const main = el('div', 'xref-map-main');
  const side = el('div', 'xref-map-side');
  layout.append(main, side);

  const head = el('div', 'xref-map-head');
  const headTop = el('div', 'xref-map-head-top');

  headTop.append(el('h2', 'xref-map-title', 'Kruisverwijzingen'));

  // Modus: boek | hoofdstuk
  const modeSeg = el('div', 'xref-mode-seg');
  const btnModeBook = el('button', 'xref-mode-btn is-active', 'Per boek');
  btnModeBook.type = 'button';
  const btnModeChap = el('button', 'xref-mode-btn', 'Per hoofdstuk');
  btnModeChap.type = 'button';
  modeSeg.append(btnModeBook, btnModeChap);
  headTop.append(modeSeg);

  const btnToggleFilter = el('button', 'xref-filter-toggle');
  btnToggleFilter.type = 'button';
  btnToggleFilter.title = 'Instellingen';
  btnToggleFilter.setAttribute('aria-label', 'Instellingen openen of sluiten');
  btnToggleFilter.setAttribute('aria-expanded', 'true');
  btnToggleFilter.innerHTML = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`;
  headTop.append(btnToggleFilter);
  head.append(headTop);

  const statsRow = el('div', 'xref-map-stats');
  head.append(statsRow);
  main.append(head);

  const canvasWrap = el('div', 'xref-map-canvas-wrap');
  const canvasBar = el('div', 'xref-map-canvas-bar');
  const canvasTitle = el('span', 'xref-map-canvas-bar-title', 'Aantal verbindingen tussen boeken');
  const btnExport = el('button', 'xref-export-btn');
  btnExport.type = 'button';
  btnExport.title = 'Grafiek downloaden als PNG';
  btnExport.setAttribute('aria-label', 'Grafiek downloaden als PNG');
  btnExport.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 19h14"/></svg>';
  canvasBar.append(canvasTitle, btnExport);
  const svgHost = el('div', 'xref-map-svg-host');
  canvasWrap.append(canvasBar, svgHost);
  main.append(canvasWrap);

  const tip = el('div', 'xref-map-tip');
  tip.hidden = true;
  layout.append(tip);

  btnExport.onclick = () => exportGraphPng(svgHost, btnExport);

  const sideHead = el('div', 'xref-side-head');
  sideHead.append(el('h3', 'xref-filter-title', 'Instellingen'));
  const btnCollapse = el('button', 'xref-side-collapse', '‹');
  btnCollapse.type = 'button';
  btnCollapse.title = 'Paneel inklappen';
  sideHead.append(btnCollapse);
  side.append(sideHead);
  const sideBody = el('div', 'xref-side-body');

  const strokeBox = el('div', 'xref-stroke-box');
  strokeBox.append(el('p', 'xref-filter-hint', 'Dikte van de bogen'));
  const strokeRow = el('div', 'xref-stroke-row');
  const strokeLabel = el('span', 'xref-stroke-val', 'Dun');
  const strokeRange = document.createElement('input');
  strokeRange.type = 'range';
  strokeRange.min = '1';
  strokeRange.max = '5';
  strokeRange.step = '1';
  strokeRange.value = '2';
  strokeRange.className = 'xref-stroke-range';
  strokeRange.title = 'Dunner ← → Dikker';
  strokeRow.append(el('span', 'xref-stroke-end', 'Dun'), strokeRange, el('span', 'xref-stroke-end', 'Dik'));
  strokeBox.append(strokeRow, strokeLabel);
  sideBody.append(strokeBox);

  const colorBox = el('div', 'xref-stroke-box');
  colorBox.append(el('p', 'xref-filter-hint', 'Kleur van de lijntjes'));
  const colorSeg = el('div', 'xref-mode-seg xref-color-seg');
  const btnColorAmount = el('button', 'xref-mode-btn is-active', 'Hoeveelheid');
  btnColorAmount.type = 'button';
  btnColorAmount.title = 'Groen (weinig) → rood (veel verbindingen)';
  const btnColorDist = el('button', 'xref-mode-btn', 'Afstand');
  btnColorDist.type = 'button';
  btnColorDist.title = 'Paars (dichtbij) → andere kant regenboog (ver uit elkaar)';
  colorSeg.append(btnColorAmount, btnColorDist);
  colorBox.append(colorSeg);
  const colorHint = el('p', 'xref-filter-hint', 'Groen–rood = aantal verbindingen. Regenboog = hoe ver de boeken uit elkaar staan.');
  colorBox.append(colorHint);
  sideBody.append(colorBox);

  sideBody.append(el('p', 'xref-filter-hint', 'Boeken — uit = verdwijnt uit de grafiek'));
  const filterActions = el('div', 'xref-filter-actions');
  const btnAll = el('button', 'xref-filter-btn', 'Alles aan');
  btnAll.type = 'button';
  const btnNone = el('button', 'xref-filter-btn', 'Alles uit');
  btnNone.type = 'button';
  const btnOt = el('button', 'xref-filter-btn', 'OT');
  btnOt.type = 'button';
  const btnNt = el('button', 'xref-filter-btn', 'NT');
  btnNt.type = 'button';
  const btnActive = el('button', 'xref-filter-btn', 'Met data');
  btnActive.type = 'button';
  filterActions.append(btnAll, btnNone, btnOt, btnNt, btnActive);
  sideBody.append(filterActions);

  const chapFilterBox = el('div', 'xref-chap-filter');
  chapFilterBox.hidden = true;
  chapFilterBox.append(el('p', 'xref-filter-hint', 'Hoofdstukmodus'));
  const chapSeg = el('div', 'xref-mode-seg xref-chap-seg');
  const btnChapAll = el('button', 'xref-mode-btn is-active', 'Alle hfdst.');
  btnChapAll.type = 'button';
  btnChapAll.title = 'Toon alle hoofdstukken van aangevinkte boeken (ook zonder links)';
  const btnChapData = el('button', 'xref-mode-btn', 'Met links');
  btnChapData.type = 'button';
  btnChapData.title = 'Alleen hoofdstukken die minstens één kruisverwijzing hebben';
  chapSeg.append(btnChapAll, btnChapData);
  chapFilterBox.append(chapSeg);
  sideBody.append(chapFilterBox);

  const filterList = el('div', 'xref-filter-list');
  sideBody.append(filterList);
  side.append(sideBody);

  function syncChapFilterUi() {
    chapFilterBox.hidden = mode !== 'chapter';
    btnChapAll.classList.toggle('is-active', !chapterOnlyWithData);
    btnChapData.classList.toggle('is-active', chapterOnlyWithData);
  }
  btnChapAll.onclick = () => { chapterOnlyWithData = false; syncChapFilterUi(); render(); };
  btnChapData.onclick = () => { chapterOnlyWithData = true; syncChapFilterUi(); render(); };

  function setFilterOpen(open) {
    layout.classList.toggle('filters-collapsed', !open);
    side.classList.toggle('is-collapsed', !open);
    btnToggleFilter.setAttribute('aria-expanded', open ? 'true' : 'false');
    btnToggleFilter.classList.toggle('is-open', open);
    btnCollapse.textContent = open ? '‹' : '›';
    btnCollapse.title = open ? 'Filterpaneel inklappen' : 'Filterpaneel uitklappen';
  }
  btnToggleFilter.onclick = () => setFilterOpen(layout.classList.contains('filters-collapsed'));
  btnCollapse.onclick = () => setFilterOpen(layout.classList.contains('filters-collapsed'));


  /** @type {'book'|'chapter'} */
  let mode = 'book';
  let dataBook = null;
  let dataChapter = null;
  /** @type {Set<string>} book OSIS ids enabled */
  let enabled = new Set();
  /** In hoofdstukmodus: alleen hoofdstukken met minstens 1 link */
  let chapterOnlyWithData = false;
  /** 1=zeer dun … 5=dik (default 2) */
  let strokeLevel = 2;
  try {
    const s = localStorage.getItem('lc-xref-stroke');
    if (s) strokeLevel = Math.max(1, Math.min(5, parseInt(s, 10) || 2));
  } catch (_) {}

  /** 'amount' = groen→rood op hoeveelheid; 'distance' = regenboog op afstand */
  let colorMode = 'amount';
  try {
    const c = localStorage.getItem('lc-xref-color');
    if (c === 'distance' || c === 'amount') colorMode = c;
  } catch (_) {}

  const strokeNames = { 1: 'Zeer dun', 2: 'Dun', 3: 'Normaal', 4: 'Dik', 5: 'Zeer dik' };
  strokeRange.value = String(strokeLevel);
  strokeLabel.textContent = strokeNames[strokeLevel] || 'Normaal';
  strokeRange.oninput = () => {
    strokeLevel = parseInt(strokeRange.value, 10) || 2;
    strokeLabel.textContent = strokeNames[strokeLevel] || 'Normaal';
    try { localStorage.setItem('lc-xref-stroke', String(strokeLevel)); } catch (_) {}
    render();
  };

  function setColorMode(m) {
    colorMode = m === 'distance' ? 'distance' : 'amount';
    btnColorAmount.classList.toggle('is-active', colorMode === 'amount');
    btnColorDist.classList.toggle('is-active', colorMode === 'distance');
    try { localStorage.setItem('lc-xref-color', colorMode); } catch (_) {}
    render();
  }
  btnColorAmount.onclick = () => setColorMode('amount');
  btnColorDist.onclick = () => setColorMode('distance');
  // init active state
  btnColorAmount.classList.toggle('is-active', colorMode === 'amount');
  btnColorDist.classList.toggle('is-active', colorMode === 'distance');

  function currentData() {
    return mode === 'chapter' ? dataChapter : dataBook;
  }

  async function load() {
    try {
      const [rb, rc] = await Promise.all([
        fetch('data/bijbel-meta/xref-graph.json'),
        fetch('data/bijbel-meta/xref-graph-chapters.json'),
      ]);
      if (!rb.ok) throw new Error('Kon boek-grafiek niet laden');
      dataBook = await rb.json();
      dataChapter = rc.ok ? await rc.json() : null;
      enabled = new Set(dataBook.books || []);
      buildFilters();
      setMode('book');
    } catch (e) {
      main.append(el('p', 'xref-map-error', 'Kon de kaart niet laden. ' + (e.message || e)));
    }
  }

  function setMode(m) {
    mode = m;
    btnModeBook.classList.toggle('is-active', mode === 'book');
    btnModeChap.classList.toggle('is-active', mode === 'chapter');
    btnModeChap.disabled = !dataChapter;
    canvasTitle.textContent = mode === 'chapter'
      ? 'Aantal verbindingen tussen hoofdstukken'
      : 'Aantal verbindingen tussen boeken';
    if (typeof syncChapFilterUi === 'function') syncChapFilterUi();
    render();
  }
  btnModeBook.onclick = () => setMode('book');
  btnModeChap.onclick = () => { if (dataChapter) setMode('chapter'); };

  function buildFilters() {
    filterList.replaceChildren();
    const BOOKS = dataBook.books || [];
    const NL = dataBook.labels_nl || {};
    const otEnd = BOOKS.indexOf(dataBook.ot_end_book || 'Mal');
    const matrix = dataBook.matrix || [];
    const active = new Set();
    for (let i = 0; i < BOOKS.length; i++) {
      for (let j = 0; j < BOOKS.length; j++) {
        if ((matrix[i] && matrix[i][j]) > 0) active.add(BOOKS[i]);
      }
    }
    // also mark books that appear only in chapter graph
    if (dataChapter && dataChapter.nodes) {
      dataChapter.nodes.forEach((n) => active.add(n.book));
    }

    BOOKS.forEach((b, i) => {
      const row = el('label', 'xref-filter-row' + (active.has(b) ? ' has-data' : ''));
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = enabled.has(b);
      cb.dataset.book = b;
      cb.onchange = () => {
        if (cb.checked) enabled.add(b);
        else enabled.delete(b);
        render();
      };
      row.append(cb, el('span', 'xref-filter-name', NL[b] || b));
      if (active.has(b)) row.append(el('span', 'xref-filter-badge', 'data'));
      filterList.append(row);
      if (i === otEnd) filterList.append(el('div', 'xref-filter-sep', '— Nieuwe Testament —'));
    });

    btnAll.onclick = () => {
      enabled = new Set(BOOKS);
      filterList.querySelectorAll('input[type=checkbox]').forEach((c) => { c.checked = true; });
      render();
    };
    btnNone.onclick = () => {
      enabled = new Set();
      filterList.querySelectorAll('input[type=checkbox]').forEach((c) => { c.checked = false; });
      render();
    };
    btnOt.onclick = () => {
      enabled = new Set(BOOKS.slice(0, otEnd + 1));
      filterList.querySelectorAll('input[type=checkbox]').forEach((c) => {
        c.checked = enabled.has(c.dataset.book);
      });
      render();
    };
    btnNt.onclick = () => {
      enabled = new Set(BOOKS.slice(otEnd + 1));
      filterList.querySelectorAll('input[type=checkbox]').forEach((c) => {
        c.checked = enabled.has(c.dataset.book);
      });
      render();
    };
    btnActive.onclick = () => {
      enabled = new Set(active);
      filterList.querySelectorAll('input[type=checkbox]').forEach((c) => {
        c.checked = enabled.has(c.dataset.book);
      });
      render();
    };
  }

  function render() {
    const data = currentData();
    if (!data) return;
    const st = data.stats || {};
    const stBook = (dataBook && dataBook.stats) || {};
    statsRow.replaceChildren();
    const totalBooks = stBook.books_total || st.books_total || 73;
    const links = st.cross_reference_entries || stBook.cross_reference_entries || 0;
    const pct = Math.min(100, (links / 340000) * 100);
    const cards = mode === 'chapter'
      ? [
          [String(st.chapter_nodes || (data.nodes || []).length), 'hfdst. totaal'],
          [String(st.chapters_with_links || 0), 'met links'],
          [String(st.unique_chapter_pairs || 0), 'paren'],
          [(pct < 1 ? pct.toFixed(2) : pct.toFixed(1)) + '%', 'vs TSK'],
        ]
      : [
          [String(stBook.cross_reference_entries || 0), 'links'],
          [String(stBook.verses_with_depth || 0), 'verzen'],
          [`${stBook.books_with_meta || 0}/${totalBooks}`, 'boeken'],
          [(pct < 1 ? pct.toFixed(2) : pct.toFixed(1)) + '%', 'vs TSK'],
        ];
    for (const [val, lab] of cards) {
      const c = el('div', 'xref-map-stat');
      c.append(el('span', 'xref-map-stat-val', val));
      c.append(el('span', 'xref-map-stat-lab', lab));
      statsRow.append(c);
    }

    if (mode === 'chapter') drawChapterSvg(svgHost, data, tip, enabled, chapterOnlyWithData, strokeLevel, colorMode);
    else drawBookSvg(svgHost, data, tip, enabled, strokeLevel, colorMode);
  }

  load();
  return layout;
}

/** Kleur op basis van hoeveelheid verbindingen: groen (weinig) → rood (veel) */
function weightColor(w, mx, alpha) {
  const t = Math.min(1, Math.log1p(w) / Math.log1p(mx || 1));
  const hue = 120 * (1 - t);
  const sat = 62 + t * 18;
  const light = 38 + t * 4;
  return `hsla(${hue.toFixed(1)}, ${sat.toFixed(0)}%, ${light.toFixed(0)}%, ${alpha})`;
}

/** Kleur op basis van afstand tussen boeken/hoofdstukken: paars (dichtbij) → andere kant regenboog (ver) */
function distanceColor(dist, maxDist, alpha) {
  const t = Math.min(1, dist / (maxDist || 1));
  // Dichtbij (t≈0) = paars (~280°), ver (t≈1) = rood (~0°) via de regenboog
  const hue = 280 * (1 - t);
  const sat = 70 + t * 8;
  const light = 42;
  return `hsla(${hue.toFixed(1)}, ${sat.toFixed(0)}%, ${light.toFixed(0)}%, ${alpha})`;
}

function drawBookSvg(host, data, tip, enabled, strokeLevel, colorMode) {
  host.replaceChildren();
  const BOOKS_ALL = data.books || [];
  const NL = data.labels_nl || {};
  const matrixFull = data.matrix || [];
  const BOOKS = BOOKS_ALL.filter((b) => enabled.has(b));
  const n = BOOKS.length;
  if (n < 2) {
    host.append(el('p', 'xref-map-empty', 'Zet minstens twee boeken aan in de filter om bogen te zien.'));
    return;
  }
  const idxFull = {};
  BOOKS_ALL.forEach((b, i) => { idxFull[b] = i; });

  const edges = [];
  let mx = 1;
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const fi = idxFull[BOOKS[i]], fj = idxFull[BOOKS[j]];
      const w = (matrixFull[fi] && matrixFull[fi][fj]) || 0;
      if (w > 0) {
        edges.push([i, j, w]);
        if (w > mx) mx = w;
      }
    }
  }
  edges.sort((a, b) => a[2] - b[2]);

  const labels = BOOKS.map((b) => NL[b] || b);
  const otEnd = BOOKS.indexOf(data.ot_end_book || 'Mal');
  renderArcSvg(host, tip, {
    n, edges, mx, labels, otEnd,
    activeSet: (() => {
      const s = new Set();
      edges.forEach(([i, j]) => { s.add(i); s.add(j); });
      return s;
    })(),
    unit: 'boek',
    totalAll: BOOKS_ALL.length,
    strokeLevel: strokeLevel || 2,
    colorMode: colorMode || 'amount',
  });
}

function drawChapterSvg(host, data, tip, enabled, onlyWithData, strokeLevel, colorMode) {
  host.replaceChildren();
  const nodesAll = data.nodes || [];
  const edgeList = data.edges || [];
  // Books enabled
  let nodes = nodesAll.filter((nd) => enabled.has(nd.book));

  // Map key -> weight for pairs among full node list
  const pairW = new Map();
  edgeList.forEach((e) => {
    const a = e.a[0] + '.' + e.a[1];
    const b = e.b[0] + '.' + e.b[1];
    const k = a < b ? a + '|' + b : b + '|' + a;
    pairW.set(k, e.w || 1);
  });

  if (onlyWithData) {
    const withLink = new Set();
    edgeList.forEach((e) => {
      withLink.add(e.a[0] + '.' + e.a[1]);
      withLink.add(e.b[0] + '.' + e.b[1]);
    });
    nodes = nodes.filter((nd) => withLink.has(nd.book + '.' + nd.chapter));
  }

  const n = nodes.length;
  if (n < 2) {
    host.append(el('p', 'xref-map-empty', 'Zet minstens twee boeken aan, of kies “Alle hfdst.”.'));
    return;
  }

  const keyOf = (nd) => nd.book + '.' + nd.chapter;
  const idxVis = {};
  nodes.forEach((nd, i) => { idxVis[keyOf(nd)] = i; });

  const edges = [];
  let mx = 1;
  edgeList.forEach((e) => {
    const ka = e.a[0] + '.' + e.a[1];
    const kb = e.b[0] + '.' + e.b[1];
    if (!(ka in idxVis) || !(kb in idxVis)) return;
    const i = idxVis[ka], j = idxVis[kb];
    if (i === j) return;
    const lo = Math.min(i, j), hi = Math.max(i, j);
    const w = e.w || 1;
    edges.push([lo, hi, w]);
    if (w > mx) mx = w;
  });
  // dedupe
  const seen = new Map();
  edges.forEach(([i, j, w]) => {
    const k = i + ',' + j;
    seen.set(k, Math.max(seen.get(k) || 0, w));
  });
  const edgesU = [...seen.entries()].map(([k, w]) => {
    const [i, j] = k.split(',').map(Number);
    return [i, j, w];
  });
  edgesU.sort((a, b) => a[2] - b[2]);

  // As-labels: alleen boeknaam (niet elk hoofdstuk)
  const NL = (data.labels_nl) || {};
  // Prefer Dutch names from book graph if present on window of caller - nodes already have labels like "Genesis 1"
  const bookLabel = (b) => {
    const sample = nodes.find((nd) => nd.book === b);
    if (sample && sample.label) {
      // "Genesis 1" -> "Genesis"
      return String(sample.label).replace(/\s+\d+$/, '');
    }
    return b;
  };
  const labels = nodes.map((nd) => bookLabel(nd.book));
  // Toon label alleen bij eerste hoofdstuk van elk boek
  const labelAt = new Set();
  let prevB = null;
  for (let i = 0; i < n; i++) {
    if (nodes[i].book !== prevB) {
      labelAt.add(i);
      prevB = nodes[i].book;
    }
  }

  let otEnd = -1;
  for (let i = 0; i < n; i++) {
    if (nodes[i].book === 'Matt') { otEnd = i - 1; break; }
  }

  const activeSet = new Set();
  edgesU.forEach(([i, j]) => { activeSet.add(i); activeSet.add(j); });

  const tipLabels = nodes.map((nd) => nd.label || (nd.book + ' ' + nd.chapter));
  renderArcSvg(host, tip, {
    n, edges: edgesU, mx, labels, tipLabels, otEnd, activeSet,
    unit: 'hoofdstuk',
    totalAll: nodesAll.length,
    dense: true,
    labelAt,
    strokeLevel: strokeLevel || 2,
    colorMode: colorMode || 'amount',
  });
}

function renderArcSvg(host, tip, opts) {
  const { n, edges, mx, labels, tipLabels, otEnd, activeSet, unit, totalAll, dense, labelAt, strokeLevel, colorMode } = opts;
  const W = 2000, H = 900;
  const M = 28;
  const axisY = H - 120;
  const span = W - 2 * M;
  const bookX = (i) => M + (i + 0.5) / n * span;
  const maxDist = Math.max(1, n - 1);

  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svg.setAttribute('class', 'xref-map-svg');
  svg.setAttribute('role', 'img');

  const ghost = document.createElementNS(ns, 'g');
  ghost.setAttribute('opacity', '0.10');
  const step = Math.max(1, Math.floor(n / 8));
  for (let a = 0; a < n; a += step) {
    for (let b = a + step; b < n; b += step) {
      const x1 = bookX(a), x2 = bookX(b), mid = (x1 + x2) / 2;
      const ry = 40 + Math.abs(x2 - x1) * 0.42;
      const p = document.createElementNS(ns, 'path');
      p.setAttribute('d', `M ${x1.toFixed(1)} ${axisY} Q ${mid.toFixed(1)} ${(axisY - ry).toFixed(1)} ${x2.toFixed(1)} ${axisY}`);
      p.setAttribute('fill', 'none');
      p.setAttribute('stroke', '#9a8a88');
      p.setAttribute('stroke-width', '0.6');
      ghost.appendChild(p);
    }
  }
  svg.appendChild(ghost);

  const gArcs = document.createElementNS(ns, 'g');
  const paths = [];
  edges.forEach(([i, j, w]) => {
    const x1 = bookX(i), x2 = bookX(j), mid = (x1 + x2) / 2;
    const dist = Math.abs(j - i);
    const ry = 48 + Math.abs(x2 - x1) * 0.48;
    const t = Math.min(1, Math.log1p(w) / Math.log1p(mx || 1));
    const lvl = Math.max(1, Math.min(5, strokeLevel || 2));
    const scale = { 1: 0.4, 2: 0.65, 3: 1, 4: 1.4, 5: 1.85 }[lvl] || 0.65;
    // Standaard dunner: 0.45–1.6 i.p.v. 1.1–4.3
    const sw = (0.45 + t * 1.15) * scale;
    const al = 0.35 + t * 0.50;
    const strokeCol = (colorMode === 'distance')
      ? distanceColor(dist, maxDist, al)
      : weightColor(w, mx, al);
    const p = document.createElementNS(ns, 'path');
    p.setAttribute('d', `M ${x1.toFixed(1)} ${axisY} Q ${mid.toFixed(1)} ${(axisY - ry).toFixed(1)} ${x2.toFixed(1)} ${axisY}`);
    p.setAttribute('fill', 'none');
    p.setAttribute('stroke', strokeCol);
    p.setAttribute('stroke-width', sw.toFixed(2));
    p.setAttribute('stroke-linecap', 'round');
    p.setAttribute('class', 'xref-arc');
    p.style.cursor = 'pointer';
    const tipL = tipLabels || labels;
    const label = `${tipL[i]} ↔ ${tipL[j]} · ${w} verbinding${w === 1 ? '' : 'en'}`;
    p.addEventListener('mouseenter', () => {
      paths.forEach((q) => { q.style.opacity = '0.12'; });
      p.style.opacity = '1';
      tip.hidden = false;
      tip.textContent = label;
    });
    p.addEventListener('mousemove', (ev) => {
      tip.style.left = (ev.clientX + 12) + 'px';
      tip.style.top = (ev.clientY + 12) + 'px';
    });
    p.addEventListener('mouseleave', () => {
      paths.forEach((q) => { q.style.opacity = '1'; });
      tip.hidden = true;
    });
    gArcs.appendChild(p);
    paths.push(p);
  });
  svg.appendChild(gArcs);

  const axis = document.createElementNS(ns, 'line');
  axis.setAttribute('x1', M);
  axis.setAttribute('x2', W - M);
  axis.setAttribute('y1', axisY);
  axis.setAttribute('y2', axisY);
  axis.setAttribute('stroke', '#c4b8b0');
  axis.setAttribute('stroke-width', '1');
  svg.appendChild(axis);

  if (otEnd >= 0 && otEnd < n - 1) {
    const divX = (bookX(otEnd) + bookX(otEnd + 1)) / 2;
    // Verticale stippellijn OT ↔ NT (50% zichtbaarheid), over de hele grafiekhoogte
    const div = document.createElementNS(ns, 'line');
    div.setAttribute('x1', divX);
    div.setAttribute('x2', divX);
    div.setAttribute('y1', 24);
    div.setAttribute('y2', axisY + 10);
    div.setAttribute('stroke', '#7a1f2b');
    div.setAttribute('stroke-width', '1.25');
    div.setAttribute('stroke-dasharray', '4 5');
    div.setAttribute('stroke-opacity', '0.5');
    div.setAttribute('class', 'xref-ot-nt-divider');
    svg.appendChild(div);
    const tOt = document.createElementNS(ns, 'text');
    tOt.setAttribute('x', (M + divX) / 2);
    tOt.setAttribute('y', axisY + 88);
    tOt.setAttribute('text-anchor', 'middle');
    tOt.setAttribute('font-size', '11');
    tOt.setAttribute('fill', '#7a1f2b');
    tOt.setAttribute('font-family', 'system-ui,sans-serif');
    tOt.textContent = 'Oude Testament';
    svg.appendChild(tOt);
    const tNt = document.createElementNS(ns, 'text');
    tNt.setAttribute('x', (divX + W - M) / 2);
    tNt.setAttribute('y', axisY + 88);
    tNt.setAttribute('text-anchor', 'middle');
    tNt.setAttribute('font-size', '11');
    tNt.setAttribute('fill', '#3a5a9a');
    tNt.setAttribute('font-family', 'system-ui,sans-serif');
    tNt.textContent = 'Nieuwe Testament';
    svg.appendChild(tNt);
  }

  labels.forEach((lab, i) => {
    const x = bookX(i);
    const tick = document.createElementNS(ns, 'line');
    tick.setAttribute('x1', x);
    tick.setAttribute('x2', x);
    tick.setAttribute('y1', axisY);
    tick.setAttribute('y2', axisY + (activeSet.has(i) ? 7 : 3));
    tick.setAttribute('stroke', activeSet.has(i) ? '#3d2c2e' : '#d4ccc6');
    tick.setAttribute('stroke-width', activeSet.has(i) ? '1.2' : '0.5');
    svg.appendChild(tick);

    // labelAt: vaste posities (bv. start van elk boek in hfdst-modus)
    // anders: periodiek / actieve nodes
    let showLabel;
    if (labelAt) {
      showLabel = labelAt.has(i);
    } else {
      const every = dense ? Math.max(3, Math.ceil(n / 40)) : (n <= 50 ? 1 : 2);
      showLabel = activeSet.has(i) || i % every === 0 || i === 0 || i === n - 1;
    }
    if (showLabel) {
      const t = document.createElementNS(ns, 'text');
      t.setAttribute('x', x);
      t.setAttribute('y', axisY + 14);
      t.setAttribute('fill', activeSet.has(i) ? '#3d2c2e' : '#6a5a58');
      t.setAttribute('font-size', labelAt ? '8' : (dense ? '6.5' : (activeSet.has(i) ? '8.5' : '7')));
      t.setAttribute('font-weight', labelAt || activeSet.has(i) ? '600' : '400');
      t.setAttribute('font-family', 'system-ui,sans-serif');
      t.setAttribute('transform', `rotate(58 ${x} ${axisY + 14})`);
      t.setAttribute('text-anchor', 'start');
      t.textContent = lab;
      svg.appendChild(t);
    }
  });

  host.appendChild(svg);

  const isDist = colorMode === 'distance';
  const legend = el('div', 'xref-map-legend');
  if (isDist) {
    legend.innerHTML = `
      <div class="xref-leg-scale">
        <div class="xref-leg-gradient-row">
          <span class="xref-leg-end">dichtbij</span>
          <span class="xref-leg-gradient xref-leg-gradient-dist" aria-hidden="true"></span>
          <span class="xref-leg-end">ver</span>
        </div>
        <div class="xref-leg-gradient-labels">
          <span style="color:#7a2d9a">paars</span>
          <span style="color:#2d6a9a">blauw</span>
          <span style="color:#2d8a3e">groen</span>
          <span style="color:#c4a020">geel</span>
          <span style="color:#c41e1e">rood</span>
        </div>
        <p class="xref-leg-scale-hint">Regenboog op afstand: dichter bij elkaar = paars (begin regenboog), verder uit elkaar = andere kant. Zichtbaar: ${n} van ${totalAll} ${unit === 'hoofdstuk' ? 'hoofdstukken' : 'boeken'}.</p>
      </div>
    `;
  } else {
    legend.innerHTML = `
      <div class="xref-leg-scale">
        <div class="xref-leg-gradient-row">
          <span class="xref-leg-end">weinig</span>
          <span class="xref-leg-gradient xref-leg-gradient-amount" aria-hidden="true"></span>
          <span class="xref-leg-end">veel</span>
        </div>
        <div class="xref-leg-gradient-labels">
          <span style="color:#2d8a3e">groen</span>
          <span style="color:#c4a020">geel</span>
          <span style="color:#c41e1e">rood</span>
        </div>
        <p class="xref-leg-scale-hint">Hoe roder, hoe meer kruisverwijzingen (max. ${mx}). Zichtbaar: ${n} van ${totalAll} ${unit === 'hoofdstuk' ? 'hoofdstukken' : 'boeken'}.</p>
      </div>
    `;
  }
  host.appendChild(legend);
}

function exportGraphPng(host, btn) {
  const svg = host.querySelector('svg.xref-map-svg');
  if (!svg) {
    alert('Geen grafiek om op te slaan.');
    return;
  }
  const prevHtml = btn ? btn.innerHTML : '';
  if (btn) {
    btn.disabled = true;
    btn.classList.add('is-busy');
  }
  try {
    const clone = svg.cloneNode(true);
    const vb = (clone.getAttribute('viewBox') || '0 0 2000 900').split(/\s+/).map(Number);
    const w = vb[2] || 2000;
    const h = vb[3] || 900;
    clone.setAttribute('width', String(w));
    clone.setAttribute('height', String(h));
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    const ser = new XMLSerializer().serializeToString(clone);
    const blob = new Blob([ser], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      try {
        const scale = 2;
        // Extra ruimte onder de grafiek voor legende + bronvermelding
        const footerH = 110;
        const canvas = document.createElement('canvas');
        canvas.width = w * scale;
        canvas.height = (h + footerH) * scale;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#faf8f5';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.scale(scale, scale);
        ctx.drawImage(img, 0, 0, w, h);
        URL.revokeObjectURL(url);

        // Legende-info uit de DOM
        const legendEl = host.querySelector('.xref-map-legend');
        const isDist = !!(legendEl && legendEl.querySelector('.xref-leg-gradient-dist'));
        const hintEl = legendEl && legendEl.querySelector('.xref-leg-scale-hint');
        const hintText = hintEl ? hintEl.textContent.trim() : '';

        // Gradient-balk tekenen
        const barY = h + 18;
        const barW = Math.min(420, w * 0.55);
        const barX = (w - barW) / 2;
        const barH = 14;
        const grad = ctx.createLinearGradient(barX, 0, barX + barW, 0);
        if (isDist) {
          grad.addColorStop(0, 'hsl(280, 72%, 44%)');
          grad.addColorStop(0.25, 'hsl(220, 70%, 42%)');
          grad.addColorStop(0.5, 'hsl(160, 65%, 40%)');
          grad.addColorStop(0.75, 'hsl(40, 75%, 42%)');
          grad.addColorStop(1, 'hsl(0, 75%, 42%)');
        } else {
          grad.addColorStop(0, 'hsl(120, 62%, 38%)');
          grad.addColorStop(0.25, 'hsl(90, 65%, 40%)');
          grad.addColorStop(0.5, 'hsl(60, 70%, 42%)');
          grad.addColorStop(0.75, 'hsl(30, 72%, 42%)');
          grad.addColorStop(1, 'hsl(0, 78%, 42%)');
        }
        ctx.fillStyle = grad;
        ctx.beginPath();
        // afgeronde balk
        const r = 7;
        ctx.moveTo(barX + r, barY);
        ctx.arcTo(barX + barW, barY, barX + barW, barY + barH, r);
        ctx.arcTo(barX + barW, barY + barH, barX, barY + barH, r);
        ctx.arcTo(barX, barY + barH, barX, barY, r);
        ctx.arcTo(barX, barY, barX + barW, barY, r);
        ctx.closePath();
        ctx.fill();

        // Eindlabels
        ctx.font = '600 13px system-ui, sans-serif';
        ctx.fillStyle = '#5a4a4c';
        ctx.textBaseline = 'middle';
        if (isDist) {
          ctx.textAlign = 'right';
          ctx.fillText('dichtbij', barX - 10, barY + barH / 2);
          ctx.textAlign = 'left';
          ctx.fillText('ver', barX + barW + 10, barY + barH / 2);
        } else {
          ctx.textAlign = 'right';
          ctx.fillText('weinig', barX - 10, barY + barH / 2);
          ctx.textAlign = 'left';
          ctx.fillText('veel', barX + barW + 10, barY + barH / 2);
        }

        // Kleur-namen onder de balk
        ctx.font = '600 12px system-ui, sans-serif';
        ctx.textAlign = 'center';
        if (isDist) {
          const cols = [
            { t: 'paars', c: '#7a2d9a' },
            { t: 'blauw', c: '#2d6a9a' },
            { t: 'groen', c: '#2d8a3e' },
            { t: 'geel', c: '#c4a020' },
            { t: 'rood', c: '#c41e1e' },
          ];
          cols.forEach((col, i) => {
            ctx.fillStyle = col.c;
            ctx.fillText(col.t, barX + (i + 0.5) * (barW / cols.length), barY + barH + 16);
          });
        } else {
          const cols = [
            { t: 'groen', c: '#2d8a3e' },
            { t: 'geel', c: '#c4a020' },
            { t: 'rood', c: '#c41e1e' },
          ];
          cols.forEach((col, i) => {
            ctx.fillStyle = col.c;
            ctx.fillText(col.t, barX + (i + 0.5) * (barW / cols.length), barY + barH + 16);
          });
        }

        // Hint-tekst
        if (hintText) {
          ctx.font = '12px system-ui, sans-serif';
          ctx.fillStyle = '#7a6a6c';
          ctx.textAlign = 'center';
          ctx.fillText(hintText, w / 2, barY + barH + 36);
        }

        // Bronvermelding
        ctx.font = '600 13px system-ui, sans-serif';
        ctx.fillStyle = '#3d2c2e';
        ctx.textAlign = 'center';
        ctx.fillText('Afbeelding van Leo Crucis', w / 2, h + footerH - 18);

        const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
        const name = 'leo-crucis-kruisverwijzingen-' + stamp + '.png';
        canvas.toBlob((pngBlob) => {
          if (!pngBlob) {
            alert('Exporteren mislukt.');
            if (btn) { btn.disabled = false; btn.innerHTML = prevHtml; btn.classList.remove('is-busy'); }
            return;
          }
          const a = document.createElement('a');
          a.href = URL.createObjectURL(pngBlob);
          a.download = name;
          document.body.appendChild(a);
          a.click();
          setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
          if (btn) { btn.disabled = false; btn.innerHTML = prevHtml; btn.classList.remove('is-busy'); }
        }, 'image/png');
      } catch (err) {
        console.error(err);
        alert('Exporteren mislukt: ' + (err.message || err));
        if (btn) { btn.disabled = false; btn.innerHTML = prevHtml; btn.classList.remove('is-busy'); }
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      alert('Grafiek kon niet worden geladen voor export.');
      if (btn) { btn.disabled = false; btn.innerHTML = prevHtml; btn.classList.remove('is-busy'); }
    };
    img.src = url;
  } catch (err) {
    console.error(err);
    alert('Exporteren mislukt: ' + (err.message || err));
    if (btn) { btn.disabled = false; btn.innerHTML = prevHtml; btn.classList.remove('is-busy'); }
  }
}
