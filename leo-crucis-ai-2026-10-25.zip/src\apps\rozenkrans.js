/**
 * Rozenkrans oefenen — Leo Crucis mini-app.
 * Kraal voor kraal, NL/Latijn, studiemodus, intenties + streak in bestand.
 * Kleuren via design tokens (--bg, --panel, --ink, --mute, --line, --acc, --acc2).
 */

import { inTauri, readFile, writeFile } from '../core/edit.js';

/** Pad in de gebruikersmap (Tauri): apps/rozenkrans/streak.json */
const STREAK_FILE = 'rozenkrans-streak.json';
/** Oude localStorage-sleutel — eenmalig migreren naar bestand. */
const STREAK_LS_LEGACY = 'leo-crucis-rozenkrans-streak';
const STREAK_HOURS = 36;
const MAX_SESSIONS = 30;

const SETS = [
  {
    id: 'blij',
    name: 'Blijde mysteriën',
    nameLa: 'Mysteria Gaudiosa',
    adj: 'blijde',
    adjLa: 'gaudiosum',
    color: '#6b8cae',
    list: [
      'De boodschap van de engel aan Maria',
      'Maria bezoekt Elisabeth',
      'De geboorte van Jezus',
      'Jezus wordt opgedragen in de tempel',
      'Jezus wordt teruggevonden in de tempel'
    ],
    listLa: [
      'Annuntiatio',
      'Visitatio',
      'Nativitas',
      'Presentatio',
      'Inventio in Templo'
    ],
    refs: ['Lc 1,26-38', 'Lc 1,39-56', 'Lc 2,1-20', 'Lc 2,22-40', 'Lc 2,41-52'],
    study: [
      'De engel Gabriël kondigt aan Maria de geboorte van Jezus aan. Maria antwoordt met haar fiat: «Mij geschiede naar uw woord.»',
      'Maria bezoekt haar nicht Elisabeth. Het kind in Elisabeths schoot springt op van vreugde; Maria zingt het Magnificat.',
      'In Betlehem wordt Jezus geboren. Herders horen het nieuws van de engelen en gaan het Kind aanbidden.',
      'Jozef en Maria dragen Jezus op in de tempel. Simeon en Anna herkennen in Hem de Messias.',
      'De twaalfjarige Jezus wordt na drie dagen teruggevonden in de tempel, temidden van de leraren.'
    ]
  },
  {
    id: 'licht',
    name: 'Lichtende mysteriën',
    nameLa: 'Mysteria Luminosa',
    adj: 'lichtende',
    adjLa: 'luminosum',
    color: '#b8922a',
    list: [
      'De doop van Jezus in de Jordaan',
      'De bruiloft van Kana',
      'De verkondiging van het Rijk Gods',
      'De gedaanteverandering op de berg Tabor',
      'De instelling van de Eucharistie'
    ],
    listLa: [
      'Baptisma in Iordane',
      'Nuptiae in Cana',
      'Proclamatio Regni',
      'Transfiguratio',
      'Institutio Eucharistiae'
    ],
    refs: ['Mt 3,13-17', 'Joh 2,1-11', 'Mc 1,14-15', 'Lc 9,28-36', 'Mt 26,26-29'],
    study: [
      'Jezus wordt gedoopt door Johannes. De hemel opent zich; de Vader noemt Hem zijn geliefde Zoon.',
      'Op de bruiloft te Kana verandert Jezus water in wijn — zijn eerste teken, op voorspraak van Maria.',
      'Jezus verkondigt: «De tijd is vervuld, het Rijk Gods is nabij; bekeert u en gelooft in het Evangelie.»',
      'Op de berg toont Jezus zijn heerlijkheid aan Petrus, Jakobus en Johannes. Mozes en Elia verschijnen.',
      'Bij het Laatste Avondmaal stelt Jezus de Eucharistie in: «Dit is mijn Lichaam… Dit is mijn Bloed.»'
    ]
  },
  {
    id: 'pijn',
    name: 'Pijnlijke mysteriën',
    nameLa: 'Mysteria Dolorosa',
    adj: 'pijnlijke',
    adjLa: 'dolorosum',
    color: '#7a1f2b',
    list: [
      'Jezus’ doodsangst in de Hof van Olijven',
      'De geseling van Jezus',
      'De doornenkroning',
      'Jezus draagt het kruis',
      'De kruisiging en dood van Jezus'
    ],
    listLa: [
      'Agonia in Horto',
      'Flagellatio',
      'Coronatio spinis',
      'Baiulatio Crucis',
      'Crucifixio et mors'
    ],
    refs: ['Lc 22,39-46', 'Mt 27,26', 'Mt 27,27-31', 'Joh 19,16-17', 'Joh 19,18-30'],
    study: [
      'In Getsemane bidt Jezus in doodsangst: «Vader, niet mijn wil, maar de uwe geschiede.»',
      'Pilatus laat Jezus geselen. Hij draagt de straffen die ons vrede brengen.',
      'Soldaten vlechten een doornenkroon en bespotten Hem als koning der Joden.',
      'Jezus draagt zijn kruis naar Golgota. Onderweg ontmoet Hij vrouwen van Jeruzalem.',
      'Aan het kruis voltooit Jezus zijn offer: «Het is volbracht.» Hij beveelt zijn geest aan de Vader.'
    ]
  },
  {
    id: 'glorie',
    name: 'Glorievolle mysteriën',
    nameLa: 'Mysteria Gloriosa',
    adj: 'glorievolle',
    adjLa: 'gloriosum',
    color: '#c45c6a',
    list: [
      'De verrijzenis van Jezus',
      'De hemelvaart van Jezus',
      'De nederdaling van de Heilige Geest',
      'Maria’s tenhemelopneming',
      'Maria’s kroning in de hemel'
    ],
    listLa: [
      'Resurrectio',
      'Ascensio',
      'Descensus Spiritus Sancti',
      'Assumptio Mariae',
      'Coronatio Mariae'
    ],
    refs: ['Mt 28,1-10', 'Lc 24,50-53', 'Hand 2,1-11', 'Openb 12,1', 'Openb 12,1; Ps 45,10'],
    study: [
      'Op de derde dag verrijst Jezus uit de doden. De engel zegt tot de vrouwen: «Hij is niet hier; Hij is verrezen.»',
      'Jezus stijgt op ten hemel en neemt plaats aan de rechterhand van de Vader.',
      'Met Pinksteren daalt de Heilige Geest neer over de apostelen; de Kerk wordt geboren.',
      'Maria wordt met lichaam en ziel in de hemel opgenomen — teken van onze uiteindelijke hoop.',
      'Maria wordt gekroond als Koningin van hemel en aarde; zij is onze Moeder en voorspreekster.'
    ]
  }
];

const DAY = [3, 0, 2, 3, 1, 2, 0];
const ORD = ['eerste', 'tweede', 'derde', 'vierde', 'vijfde'];
const ORD_LA = ['primum', 'secundum', 'tertium', 'quartum', 'quintum'];

const T = {
  nl: {
    kruis: ['Kruisteken', 'In de naam van de Vader en de Zoon en de Heilige Geest. Amen.'],
    credo: [
      'Apostolische geloofsbelijdenis',
      'Ik geloof in God, de almachtige Vader, Schepper van hemel en aarde. En in Jezus Christus, zijn enige Zoon, onze Heer, die ontvangen is van de Heilige Geest, geboren uit de maagd Maria, die geleden heeft onder Pontius Pilatus, is gekruisigd, gestorven en begraven, neergedaald ter helle, op de derde dag verrezen uit de doden, opgevaren naar de hemel; zit aan de rechterhand van God, de almachtige Vader; vandaar zal Hij komen oordelen de levenden en de doden. Ik geloof in de Heilige Geest, de heilige katholieke Kerk, de gemeenschap van de heiligen, de vergeving van de zonden, de verrijzenis van het lichaam en het eeuwig leven. Amen.'
    ],
    ov: [
      'Onze Vader',
      'Onze Vader, die in de hemel zijt, uw naam worde geheiligd; uw rijk kome; uw wil geschiede op aarde zoals in de hemel. Geef ons heden ons dagelijks brood; en vergeef ons onze schuld, zoals ook wij aan anderen hun schuld vergeven; en leid ons niet in bekoring, maar verlos ons van het kwade. Amen.'
    ],
    wg: [
      'Weesgegroet',
      'Wees gegroet, Maria, vol van genade, de Heer is met u. Gij zijt de gezegende onder de vrouwen en gezegend is Jezus, de vrucht van uw schoot. Heilige Maria, Moeder van God, bid voor ons, zondaars, nu en in het uur van onze dood. Amen.'
    ],
    ere: [
      'Ere zij de Vader',
      'Eer aan de Vader en de Zoon en de Heilige Geest. Zoals het was in het begin, nu en altijd en in de eeuwen der eeuwen. Amen.'
    ],
    fat: [
      'Fatimagebed',
      'O mijn Jezus, vergeef ons onze zonden, behoed ons voor het vuur van de hel, leid alle zielen naar de hemel, vooral die uw barmhartigheid het meest nodig hebben. Amen.'
    ],
    salve: [
      'Wees gegroet, Koningin',
      'Wees gegroet, Koningin, Moeder van barmhartigheid, ons leven, onze vreugde en onze hoop, wees gegroet. Wij, ballingen, kinderen van Eva, roepen tot u; tot u zuchten wij, zuchtend en wenend in dit dal van tranen. Wel dan, onze Voorspreekster, sla uw barmhartige ogen op ons en toon ons na deze ballingschap Jezus, de gezegende vrucht van uw schoot, o goedertieren, o liefdevolle, o zoete Maagd Maria.'
    ]
  },
  la: {
    kruis: ['Signum Crucis', 'In nomine Patris, et Filii, et Spiritus Sancti. Amen.'],
    credo: [
      'Symbolum Apostolorum',
      'Credo in Deum, Patrem omnipotentem, Creatorem caeli et terrae. Et in Iesum Christum, Filium eius unicum, Dominum nostrum: qui conceptus est de Spiritu Sancto, natus ex Maria Virgine, passus sub Pontio Pilato, crucifixus, mortuus, et sepultus; descendit ad inferos; tertia die resurrexit a mortuis; ascendit ad caelos; sedet ad dexteram Dei Patris omnipotentis; inde venturus est iudicare vivos et mortuos. Credo in Spiritum Sanctum, sanctam Ecclesiam catholicam, sanctorum communionem, remissionem peccatorum, carnis resurrectionem, vitam aeternam. Amen.'
    ],
    ov: [
      'Pater Noster',
      'Pater noster, qui es in caelis, sanctificetur nomen tuum; adveniat regnum tuum; fiat voluntas tua, sicut in caelo et in terra. Panem nostrum cotidianum da nobis hodie; et dimitte nobis debita nostra, sicut et nos dimittimus debitoribus nostris; et ne nos inducas in tentationem; sed libera nos a malo. Amen.'
    ],
    wg: [
      'Ave Maria',
      'Ave Maria, gratia plena, Dominus tecum; benedicta tu in mulieribus, et benedictus fructus ventris tui, Iesus. Sancta Maria, Mater Dei, ora pro nobis peccatoribus, nunc et in hora mortis nostrae. Amen.'
    ],
    ere: [
      'Gloria Patri',
      'Gloria Patri, et Filio, et Spiritui Sancto. Sicut erat in principio, et nunc, et semper, et in saecula saeculorum. Amen.'
    ],
    fat: [
      'Oratio Fatimae',
      'O mi Iesu, dimitte nobis debita nostra, libera nos ab igne inferni, perduc omnes animas in caelum, praesertim illas quae maxime indigent misericordia tua. Amen.'
    ],
    salve: [
      'Salve Regina',
      'Salve, Regina, Mater misericordiae, vita, dulcedo et spes nostra, salve. Ad te clamamus, exsules filii Hevae. Ad te suspiramus, gementes et flentes in hac lacrimarum valle. Eia ergo, advocata nostra, illos tuos misericordes oculos ad nos converte. Et Iesum, benedictum fructum ventris tui, nobis post hoc exsilium ostende. O clemens, o pia, o dulcis Virgo Maria.'
    ]
  }
};

const UI = {
  nl: {
    title: 'Rozenkrans oefenen',
    subtitle: 'Kies een mysterie en bid kraal voor kraal. Pijltjestoetsen of spatie werken ook.',
    prev: 'Vorige',
    next: 'Volgende',
    again: 'Opnieuw beginnen',
    hide: 'Uit het hoofd: verberg de tekst',
    fatima: 'Fatimagebed na elke decade',
    latin: 'Latijn',
    study: 'Studiemodus',
    reveal: 'Toon tekst',
    hidePrompt: 'Bid dit gebed uit het hoofd. Kijk daarna met ‘Toon tekst’ of het klopte.',
    begin: 'Begin',
    close: 'Afsluiting',
    decade: (n) => 'Decade ' + n + ' van 5',
    mysteryTitle: (ord, adj) => 'Het ' + ord + ' ' + adj + ' mysterie',
    wgNote: (k) => 'Weesgegroet ' + k + ' van 10',
    faith: 'Voor meer geloof',
    hope: 'Voor meer hoop',
    love: 'Voor meer liefde',
    intention: 'Intentie voor deze decade',
    intentionPh: 'Voor wie of wat bid je?',
    history: 'Streak',
    noHistory: 'Nog geen voltooide rozenkransen. Bid er één om je streak te starten.',
    sessionDone: 'Sessie voltooid · streak +1',
    ref: 'Schriftplaats',
    studyLabel: 'Overweging',
    version: 'Taal',
    streakNow: 'Huidige streak',
    streakRecord: 'Record',
    streakExpires: 'Verloopt over',
    streakExpired: 'Streak verlopen — volgende rozenkrans start opnieuw bij 1',
    streakNone: 'Nog geen streak',
    streakUnit: 'rozenkransen',
    recent: 'Recente sessies',
    focus: 'Focus-modus',
    focusExit: 'Focus verlaten',
    focusTimer: 'Met studie-timer',
    focusTimerHint: 'Aftellen zoals Focus/Studie'
  },
  la: {
    title: 'Rosarium exercere',
    subtitle: 'Elige mysteria et ora granum pro grano. Sagittae vel spatium etiam valent.',
    prev: 'Prius',
    next: 'Sequens',
    again: 'Denuo incipere',
    hide: 'Memoria: textum cela',
    fatima: 'Oratio Fatimae post decadum',
    latin: 'Latine',
    study: 'Modus studii',
    reveal: 'Ostende textum',
    hidePrompt: 'Ora hoc memoriter. Deinde cum ‘Ostende textum’ verifica.',
    begin: 'Initium',
    close: 'Conclusio',
    decade: (n) => 'Decas ' + n + ' / 5',
    mysteryTitle: (ord, adj) => 'Mysterium ' + ord + ' ' + adj,
    wgNote: (k) => 'Ave Maria ' + k + ' / 10',
    faith: 'Pro fide',
    hope: 'Pro spe',
    love: 'Pro caritate',
    intention: 'Intentio huius decadæ',
    intentionPh: 'Pro quo oras?',
    history: 'Series',
    noHistory: 'Nullae rosaria completa. Ora unum ut seriem incipias.',
    sessionDone: 'Sessio completa · series +1',
    ref: 'Locus Scripturae',
    studyLabel: 'Meditatio',
    version: 'Lingua',
    streakNow: 'Series nunc',
    streakRecord: 'Recordum',
    streakExpires: 'Exspirat post',
    streakExpired: 'Series exspiravit — proximum rosarium incipit a 1',
    streakNone: 'Nulla series',
    streakUnit: 'rosaria',
    recent: 'Sessiones recentes',
    focus: 'Modus focus',
    focusExit: 'Focus relinquere',
    focusTimer: 'Cum tempore studii',
    focusTimerHint: 'Countdown sicut Focus/Studium'
  }
};

function defaultStreak() {
  return { count: 0, record: 0, lastAt: null, sessions: [] };
}

function normalizeStreak(data) {
  if (!data || typeof data !== 'object') return defaultStreak();
  return {
    count: Number(data.count) || 0,
    record: Number(data.record) || 0,
    lastAt: data.lastAt || null,
    sessions: Array.isArray(data.sessions) ? data.sessions : []
  };
}

function readLegacyLocal() {
  try {
    const raw = localStorage.getItem(STREAK_LS_LEGACY);
    if (!raw) return null;
    return normalizeStreak(JSON.parse(raw));
  } catch (_) {
    return null;
  }
}

function clearLegacyLocal() {
  try { localStorage.removeItem(STREAK_LS_LEGACY); } catch (_) {}
}

/** In-memory cache zodat sync-status (badge) meteen klopt na load. */
let _streakCache = null;

async function loadStreakAsync() {
  // 1) Bestand (Tauri)
  if (inTauri) {
    try {
      const text = await readFile(STREAK_FILE);
      if (text && String(text).trim()) {
        _streakCache = normalizeStreak(JSON.parse(text));
        return _streakCache;
      }
    } catch (_) {}
  }
  // 2) localStorage (fallback / migratie / browser)
  const legacy = readLegacyLocal();
  if (legacy && (legacy.count || legacy.record || (legacy.sessions && legacy.sessions.length))) {
    _streakCache = legacy;
    // Probeer naar bestand te schrijven als Tauri beschikbaar is
    if (inTauri) {
      try { await saveStreakAsync(legacy); } catch (_) {}
    }
    return _streakCache;
  }
  _streakCache = defaultStreak();
  return _streakCache;
}

function loadStreak() {
  return _streakCache || defaultStreak();
}

async function saveStreakAsync(data) {
  const normalized = {
    count: data.count || 0,
    record: data.record || 0,
    lastAt: data.lastAt || null,
    sessions: (data.sessions || []).slice(0, MAX_SESSIONS)
  };
  // Cache altijd meteen bijwerken (UI werkt ook als write faalt)
  _streakCache = normalized;
  const json = JSON.stringify(normalized, null, 2);
  if (inTauri) {
    try {
      await writeFile(STREAK_FILE, json);
      return { ok: true, via: 'file' };
    } catch (e) {
      console.warn('Rozenkrans streak bestand mislukt, fallback localStorage:', e);
      try {
        localStorage.setItem(STREAK_LS_LEGACY, json);
        return { ok: true, via: 'localStorage-fallback', error: String(e && e.message || e) };
      } catch (e2) {
        return { ok: false, via: 'memory', error: String(e2 && e2.message || e2) };
      }
    }
  }
  try {
    localStorage.setItem(STREAK_LS_LEGACY, json);
    return { ok: true, via: 'localStorage-fallback' };
  } catch (_) {
    return { ok: false, via: 'memory' };
  }
}

function saveStreak(data) {
  // Fire-and-forget async write; cache is meteen bijgewerkt
  return saveStreakAsync(data);
}

/** Streak-status: +1 per voltooide rozenkrans; verloopt na 36u zonder nieuwe. */
function getStreakStatus() {
  const s = loadStreak();
  const record = s.record || 0;
  if (!s.lastAt) {
    return { count: 0, record, active: false, hoursLeft: null, expiresAt: null, expired: false };
  }
  const elapsed = (Date.now() - new Date(s.lastAt).getTime()) / 3600000;
  if (elapsed > STREAK_HOURS) {
    return {
      count: 0,
      record,
      active: false,
      hoursLeft: 0,
      expiresAt: null,
      expired: true,
      lastAt: s.lastAt
    };
  }
  const hoursLeft = STREAK_HOURS - elapsed;
  return {
    count: s.count || 0,
    record: Math.max(record, s.count || 0),
    active: (s.count || 0) > 0,
    hoursLeft,
    expiresAt: new Date(new Date(s.lastAt).getTime() + STREAK_HOURS * 3600000),
    expired: false,
    lastAt: s.lastAt
  };
}

function formatHoursLeft(h) {
  if (h == null) return '';
  if (h <= 0) return '0u';
  const totalMin = Math.floor(h * 60);
  const hours = Math.floor(totalMin / 60);
  const mins = totalMin % 60;
  if (hours <= 0) return mins + 'm';
  if (mins === 0) return hours + 'u';
  return hours + 'u ' + mins + 'm';
}

function readStudyBlockMin() {
  try {
    const raw = localStorage.getItem('lc-settings');
    if (raw) {
      const s = JSON.parse(raw);
      const m = Number(s.studyBlockMin);
      if (m > 0 && m < 240) return m;
    }
  } catch (_) {}
  return 25;
}

function fmtFocusClock(ms) {
  const s = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m + ':' + String(r).padStart(2, '0');
}

const STYLE = `
/* Host-kader: full bleed */
#view:has(.rozenkrans-app),
body.browser-open:has(.rozenkrans-app) #view {
  padding: 0 !important;
  margin: 0 !important;
  border: none !important;
  border-radius: 0 !important;
  overflow: hidden !important;
  background: var(--bg) !important;
}
#view:has(.rozenkrans-app) > .in,
#view-content:has(.rozenkrans-app),
.in:has(.rozenkrans-app),
body.browser-open:has(.rozenkrans-app) #view-content,
body.browser-open:has(.rozenkrans-app) #view .in,
.split-pane:has(.rozenkrans-app),
.split-pane-single:has(.rozenkrans-app),
.split-wrap:has(.rozenkrans-app),
.mini-app-host:has(.rozenkrans-app) {
  padding: 0 !important;
  margin: 0 !important;
  max-width: none !important;
  width: 100% !important;
  height: 100% !important;
  overflow: hidden !important;
  border: none !important;
  border-radius: 0 !important;
  box-shadow: none !important;
  background: var(--bg, transparent) !important;
}
body.browser-open:has(.rozenkrans-app) .split-pane-single > .mini-app-root.rozenkrans-app,
body.browser-open #view-content > .split-pane-single > .mini-app-root.rozenkrans-app,
body.browser-open #view .in > .split-pane-single > .mini-app-root.rozenkrans-app {
  max-width: none !important;
  width: 100% !important;
  height: 100% !important;
  margin: 0 !important;
  padding: 0 !important;
  overflow: hidden !important;
}

.rozenkrans-app.app-panel,
.mini-app-root.rozenkrans-app,
.rozenkrans-app {
  --rk-accent: var(--acc, #7a1f2b);
  --rk-bead: #b9b2a0;
  display: flex !important;
  flex-direction: column !important;
  height: 100% !important;
  min-height: 0 !important;
  width: 100% !important;
  max-width: none !important;
  margin: 0 !important;
  padding: 0 !important;
  background: var(--bg);
  color: var(--ink);
  font: 17px/1.6 "Iowan Old Style", "Palatino Linotype", Palatino, Georgia, serif;
  overflow: hidden !important;
  border-radius: 0 !important;
  box-sizing: border-box !important;
}
.rozenkrans-app * { box-sizing: border-box; }
.rozenkrans-app button {
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.rozenkrans-app button:focus-visible,
.rozenkrans-app input:focus-visible {
  outline: 3px solid var(--rk-accent);
  outline-offset: 2px;
}
.rk-header {
  position: relative;
  flex-shrink: 0;
  order: 0;
  width: 100%;
  padding: 14px 20px 12px;
  border-bottom: 1px solid var(--line);
  background: var(--panel);
  display: grid;
  grid-template-columns: 1fr auto;
  grid-template-rows: auto auto;
  gap: 4px 16px;
  align-items: start;
}
.rk-header-text { grid-column: 1; grid-row: 1; min-width: 0; }
.rk-header h1 {
  margin: 0;
  font-size: 1.35rem;
  font-weight: 600;
  letter-spacing: .01em;
  line-height: 1.2;
}
.rk-header-text p {
  margin: 2px 0 0;
  color: var(--mute);
  font-size: .9rem;
}
.rk-sets {
  grid-column: 1 / -1;
  grid-row: 2;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding-right: 44px;
}
.rk-sets button {
  background: none;
  border: 1px solid var(--line);
  border-radius: 999px;
  padding: 6px 14px;
  font-size: .9rem;
  color: var(--mute);
}
.rk-sets button[aria-checked="true"] {
  border-color: var(--rk-accent);
  color: var(--ink);
  background: color-mix(in srgb, var(--rk-accent) 16%, transparent);
}
.rk-header-actions {
  grid-column: 2;
  grid-row: 1;
  display: flex;
  gap: 8px;
  align-items: center;
  justify-self: end;
}
.rk-icon-btn {
  position: relative;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  border: 1px solid var(--line);
  background: none;
  color: var(--mute);
  font: italic 600 1.05rem Georgia, serif;
  line-height: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.rk-icon-btn:hover {
  color: var(--ink);
  border-color: var(--rk-accent);
}
.rk-icon-btn .rk-badge {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 999px;
  background: var(--rk-accent, var(--acc));
  color: #fff;
  font: 600 11px/18px system-ui, sans-serif;
  text-align: center;
  pointer-events: none;
  box-shadow: 0 0 0 2px var(--panel, #faf6ef);
}
.rk-icon-btn .rk-badge[hidden] { display: none; }
.rk-icon-btn.is-urgent .rk-badge {
  background: var(--acc2, #b8922a);
}
.rk-main {
  order: 1;
  flex: 1;
  min-height: 0;
  width: 100%;
  padding: 16px 20px 24px;
  display: grid;
  gap: 24px;
  grid-template-columns: 1fr;
  overflow: auto;
  align-content: start;
}
.rk-rosary {
  display: flex;
  justify-content: center;
  align-items: flex-start;
}
.rk-rosary svg {
  width: 100%;
  max-width: 340px;
  max-height: min(52vh, 520px);
  height: auto;
}
.rk-card {
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: var(--radius, 10px);
  padding: 20px 22px 16px;
  display: grid;
  grid-template-columns: minmax(0, 1fr) 120px;
  gap: 10px 20px;
  align-content: start;
  width: 100%;
}
.rk-card > * { grid-column: 1; }
.rk-card > .rk-bar,
.rk-card > .rk-opts,
.rk-card > .rk-study,
.rk-card > .rk-intent { grid-column: 1 / -1; }
.rk-where {
  margin: 0;
  color: var(--rk-accent);
  font-size: .9rem;
}
.rk-card h2 {
  margin: 0;
  font-size: 1.4rem;
  font-weight: 600;
  line-height: 1.25;
}
.rk-note {
  margin: 0;
  color: var(--mute);
  font-size: .9rem;
}
.rk-text {
  margin: 0;
  font-size: 1.12rem;
  line-height: 1.7;
  max-width: 72ch;
  min-height: 4.8em;
}
.rk-text.is-hidden {
  color: var(--mute);
  font-style: italic;
}
.rk-study {
  margin: 0;
  padding: 12px 14px;
  background: color-mix(in srgb, var(--rk-accent) 8%, var(--bg));
  border: 1px solid var(--line);
  border-radius: var(--radius-sm, 6px);
  font-size: .95rem;
  line-height: 1.55;
  color: var(--ink);
}
.rk-study[hidden] { display: none; }
.rk-study strong {
  display: block;
  color: var(--rk-accent);
  font-size: .85rem;
  margin-bottom: 4px;
  font-weight: 600;
}
.rk-study .rk-ref {
  font-weight: 600;
  color: var(--acc2, #b8922a);
  margin-bottom: 6px;
}
.rk-intent {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
}
.rk-intent[hidden] { display: none; }
.rk-intent label {
  font-size: .9rem;
  color: var(--mute);
  flex: 0 0 auto;
}
.rk-intent input {
  flex: 1 1 200px;
  min-width: 0;
  border: 1px solid var(--line);
  border-radius: var(--radius-sm, 6px);
  padding: 8px 12px;
  background: var(--bg);
  color: var(--ink);
  font: inherit;
  font-size: .95rem;
}
.rk-bar {
  height: 4px;
  background: var(--line);
  border-radius: 2px;
  overflow: hidden;
}
.rk-bar i {
  display: block;
  height: 100%;
  width: 0;
  background: var(--rk-accent);
  transition: width .3s;
}
.rk-nav {
  grid-column: 2;
  grid-row: 1 / span 4;
  align-self: start;
  display: flex;
  flex-direction: column-reverse;
  gap: 8px;
}
.rk-nav button {
  border: 1px solid var(--line);
  background: none;
  border-radius: var(--radius-sm, 6px);
  padding: 10px 14px;
}
.rk-nav .rk-next {
  padding: 18px 14px;
  background: var(--rk-accent);
  color: #fff;
  border-color: var(--rk-accent);
  font-weight: 600;
}
:root[data-theme="light"] .rk-nav .rk-next,
:root:not([data-theme="dark"]) .rk-nav .rk-next {
  color: #faf6ef;
}
.rk-opts {
  display: flex;
  flex-wrap: wrap;
  gap: 10px 22px;
  font-size: .9rem;
  color: var(--mute);
  align-items: center;
}
.rk-switch {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  user-select: none;
  color: var(--ink);
}
.rk-switch > input {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}
.rk-switch .switch {
  width: 36px;
  height: 20px;
  border-radius: 10px;
  background: var(--line);
  position: relative;
  transition: background .15s;
  flex-shrink: 0;
  display: inline-block;
}
.rk-switch .switch::after {
  content: "";
  position: absolute;
  top: 2px;
  left: 2px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 1px 2px rgba(0,0,0,.18);
  transition: transform .15s;
}
.rk-switch > input:checked + .switch {
  background: var(--rk-accent, var(--acc));
}
.rk-switch > input:checked + .switch::after {
  transform: translateX(16px);
}
.rk-switch > input:focus-visible + .switch {
  outline: 3px solid var(--rk-accent, var(--acc));
  outline-offset: 2px;
}
.rk-switch-label {
  font-size: .9rem;
  color: var(--mute);
}
.rk-select {
  font: inherit;
  color: var(--ink);
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 6px;
  padding: 6px 10px;
  min-width: 7.5rem;
  cursor: pointer;
}
.rk-select:focus {
  outline: 2px solid var(--acc2, #b8922a);
  outline-offset: 0;
}
.rk-streak-panel {
  display: grid;
  gap: 8px;
  margin: 0 0 14px;
  padding: 12px 14px;
  background: color-mix(in srgb, var(--rk-accent) 10%, var(--bg));
  border: 1px solid var(--line);
  border-radius: var(--radius-sm, 6px);
}
.rk-streak-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  font-size: .95rem;
}
.rk-streak-row strong { color: var(--rk-accent); font-variant-numeric: tabular-nums; }
.rk-streak-warn {
  font-size: .88rem;
  color: var(--acc2, #b8922a);
}
.rk-streak-muted { color: var(--mute); font-size: .88rem; }
.rk-toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  transform: translateX(-50%) translateY(12px);
  background: var(--panel);
  color: var(--ink);
  border: 1px solid var(--rk-accent, var(--acc));
  border-radius: 10px;
  padding: 10px 18px;
  font-size: .95rem;
  box-shadow: var(--shadow, 0 4px 16px rgba(0,0,0,.12));
  opacity: 0;
  pointer-events: none;
  transition: opacity .25s, transform .25s;
  z-index: 80;
}
.rk-toast.is-on {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}
.rk-reveal {
  justify-self: start;
  background: none;
  border: 1px solid var(--line);
  border-radius: var(--radius-sm, 6px);
  padding: 6px 12px;
  font-size: .9rem;
}
.rk-reveal[hidden] { display: none; }
.rk-dialog {
  background: var(--panel);
  color: var(--ink);
  border: 1px solid var(--line);
  border-radius: var(--radius-lg, 16px);
  padding: 20px;
  max-width: 480px;
  width: calc(100% - 32px);
}
.rk-dialog::backdrop { background: rgba(0,0,0,.55); }
.rk-dialog h2 {
  margin: 0 0 6px;
  font-size: 1.2rem;
}
.rk-dialog p {
  margin: 6px 0 12px;
  color: var(--mute);
  font-size: .9rem;
}
.rk-dialog table {
  width: 100%;
  border-collapse: collapse;
}
.rk-dialog td {
  padding: 8px 10px;
  border-bottom: 1px solid var(--line);
  vertical-align: top;
}
.rk-dialog td:last-child {
  text-align: right;
  color: var(--mute);
}
.rk-dialog tr.today td {
  background: color-mix(in srgb, var(--rk-accent) 14%, transparent);
  color: var(--ink);
}
.rk-dialog .rk-close {
  margin-top: 14px;
  width: 100%;
  border: 1px solid var(--line);
  background: none;
  border-radius: var(--radius-sm, 6px);
  padding: 10px;
}
.rk-hist-list {
  list-style: none;
  margin: 0;
  padding: 0;
  max-height: 50vh;
  overflow: auto;
}
.rk-hist-list li {
  padding: 10px 0;
  border-bottom: 1px solid var(--line);
  font-size: .92rem;
}
.rk-hist-list .rk-hist-date {
  color: var(--mute);
  font-size: .82rem;
}
.rk-hist-list .rk-hist-int {
  color: var(--mute);
  font-size: .85rem;
  margin-top: 2px;
}
.rk-rosary svg .string {
  fill: none;
  stroke: var(--line);
  stroke-width: 2;
}
.rk-rosary svg .bead {
  fill: url(#rkGBead);
  stroke: rgba(0,0,0,.35);
  stroke-width: .8;
}
.rk-rosary svg .bead.done { fill: url(#rkGDone); }
.rk-rosary svg .bead.now { fill: url(#rkGNow); }
.rk-rosary svg .cross {
  fill: var(--rk-bead);
  stroke: rgba(0,0,0,.35);
  stroke-width: .8;
  transition: fill .25s;
}
.rk-rosary svg .cross.done { fill: var(--rk-accent); }
.rk-rosary svg .cross.now { fill: var(--acc2, #b8922a); }
.rk-rosary svg .halo {
  fill: none;
  stroke: var(--rk-accent);
  stroke-width: 2.5;
  transition: cx .35s, cy .35s, r .35s;
}
@media (min-width: 820px) {
  .rk-main {
    grid-template-columns: minmax(300px, 38vw) minmax(0, 1fr);
    align-items: start;
  }
  .rk-rosary svg {
    max-height: min(70vh, 580px);
    max-width: 400px;
  }
  .rk-header {
    grid-template-columns: auto 1fr auto;
    grid-template-rows: auto;
    align-items: center;
  }
  .rk-header-text { grid-column: 1; grid-row: 1; }
  .rk-sets {
    grid-column: 2;
    grid-row: 1;
    padding-right: 0;
    justify-content: flex-end;
  }
  .rk-header-actions {
    grid-column: 3;
    grid-row: 1;
  }
}
@media (max-width: 600px) {
  .rk-header { padding: 12px 14px 10px; }
  .rk-main { padding: 12px 14px 20px; }
  .rk-card { grid-template-columns: 1fr; }
  .rk-nav {
    grid-column: 1;
    grid-row: auto;
    flex-direction: row;
  }
  .rk-nav .rk-next {
    flex: 1;
    padding: 12px 14px;
  }
}

/* —— Focus-modus: alleen kraal + vooruit —— */
.rozenkrans-app.is-focus .rk-header-text,
.rozenkrans-app.is-focus .rk-sets,
.rozenkrans-app.is-focus .rk-header-actions .rk-icon-btn:not(.rk-focus-btn),
.rozenkrans-app.is-focus .rk-where,
.rozenkrans-app.is-focus .rk-card h2,
.rozenkrans-app.is-focus .rk-note,
.rozenkrans-app.is-focus .rk-text,
.rozenkrans-app.is-focus .rk-study,
.rozenkrans-app.is-focus .rk-intent,
.rozenkrans-app.is-focus .rk-reveal,
.rozenkrans-app.is-focus .rk-bar,
.rozenkrans-app.is-focus .rk-opts,
.rozenkrans-app.is-focus #rk-prev,
.rozenkrans-app.is-focus .rk-card .rk-nav button:not(.rk-next) {
  display: none !important;
}
.rozenkrans-app.is-focus .rk-header {
  padding: 8px 12px;
  grid-template-columns: 1fr auto;
  grid-template-rows: auto;
  border-bottom: none;
  background: transparent;
}
.rozenkrans-app.is-focus .rk-header-actions {
  grid-column: 1 / -1;
  grid-row: 1;
  width: 100%;
  justify-content: flex-end;
  gap: 10px;
}
.rozenkrans-app.is-focus .rk-main {
  grid-template-columns: 1fr;
  place-content: center;
  padding: 8px 12px 20px;
  gap: 16px;
}
.rozenkrans-app.is-focus .rk-rosary {
  justify-content: center;
}
.rozenkrans-app.is-focus .rk-rosary svg {
  max-width: min(420px, 88vw);
  max-height: min(72vh, 640px);
}
.rozenkrans-app.is-focus .rk-card {
  grid-template-columns: 1fr;
  border: none;
  background: transparent;
  padding: 0;
  justify-items: center;
  max-width: 320px;
  margin: 0 auto;
  width: 100%;
}
.rozenkrans-app.is-focus .rk-nav {
  grid-column: 1;
  grid-row: auto;
  flex-direction: row;
  width: 100%;
  justify-content: center;
}
.rozenkrans-app.is-focus .rk-nav .rk-next {
  flex: 1;
  max-width: 280px;
  padding: 18px 24px;
  font-size: 1.15rem;
  border-radius: 12px;
}
.rozenkrans-app.is-focus .rk-focus-timer {
  display: block;
  text-align: center;
  font-variant-numeric: tabular-nums;
  font-size: 1.1rem;
  color: var(--mute);
  letter-spacing: .04em;
}
.rk-focus-timer { display: none; }
.rozenkrans-app.is-focus .rk-focus-timer.is-on { display: block; }
.rk-focus-btn.is-active {
  border-color: var(--rk-accent, var(--acc));
  color: var(--rk-accent, var(--acc));
  background: color-mix(in srgb, var(--rk-accent, var(--acc)) 14%, transparent);
}
@media (prefers-reduced-motion: reduce) {
  .rozenkrans-app * { transition: none !important; }
}
`;

function el(tag, className, text) {
  const n = document.createElement(tag);
  if (className) n.className = className;
  if (text != null) n.textContent = text;
  return n;
}

export function createRozenkransApp() {
  const root = el('div', 'app-panel mini-app-root rozenkrans-app');
  root.setAttribute('data-kind', 'rozenkrans');
  root.setAttribute('aria-label', 'Rozenkrans oefenen');

  const style = document.createElement('style');
  style.textContent = STYLE;
  root.appendChild(style);

  let lang = 'nl';
  const ui = () => UI[lang];
  const prayers = () => T[lang];

  // Header
  const header = el('header', 'rk-header');
  const headerText = el('div', 'rk-header-text');
  const h1 = el('h1', null, ui().title);
  const sub = el('p', null, ui().subtitle);
  headerText.append(h1, sub);
  header.appendChild(headerText);

  const setsEl = el('div', 'rk-sets');
  setsEl.setAttribute('role', 'radiogroup');
  setsEl.setAttribute('aria-label', 'Mysteriën');
  header.appendChild(setsEl);

  const headerActions = el('div', 'rk-header-actions');
  const focusBtn = el('button', 'rk-icon-btn rk-focus-btn', '◎');
  focusBtn.type = 'button';
  focusBtn.setAttribute('aria-label', ui().focus);
  focusBtn.title = ui().focus;
  const histBtn = el('button', 'rk-icon-btn');
  histBtn.type = 'button';
  histBtn.textContent = '🔥';
  const streakBadge = el('span', 'rk-badge', '0');
  streakBadge.hidden = true;
  histBtn.appendChild(streakBadge);
  histBtn.setAttribute('aria-label', 'Streak');
  histBtn.title = 'Streak';
  const infoBtn = el('button', 'rk-icon-btn', 'i');
  infoBtn.type = 'button';
  infoBtn.setAttribute('aria-label', 'Welke mysteriën bid je wanneer?');
  infoBtn.title = 'Welke mysteriën bid je wanneer?';
  headerActions.append(focusBtn, histBtn, infoBtn);
  header.appendChild(headerActions);
  root.appendChild(header);

  // Main
  const main = el('main', 'rk-main');
  const rosaryWrap = el('div', 'rk-rosary');
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 400 570');
  svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label', 'Rozenkrans met de huidige kraal gemarkeerd');
  rosaryWrap.appendChild(svg);
  main.appendChild(rosaryWrap);

  const card = el('section', 'rk-card');
  card.setAttribute('aria-live', 'polite');
  const whereEl = el('p', 'rk-where');
  const titleEl = el('h2');
  const noteEl = el('p', 'rk-note');
  const textEl = el('p', 'rk-text');
  const studyBox = el('div', 'rk-study');
  studyBox.hidden = true;
  const intentBox = el('div', 'rk-intent');
  intentBox.hidden = true;
  const intentLab = el('label', null, ui().intention);
  intentLab.htmlFor = 'rk-intent-in';
  const intentIn = document.createElement('input');
  intentIn.type = 'text';
  intentIn.id = 'rk-intent-in';
  intentIn.placeholder = ui().intentionPh;
  intentIn.autocomplete = 'off';
  intentBox.append(intentLab, intentIn);
  const revealBtn = el('button', 'rk-reveal', ui().reveal);
  revealBtn.type = 'button';
  revealBtn.hidden = true;
  const bar = el('div', 'rk-bar');
  const barI = document.createElement('i');
  bar.appendChild(barI);
  const nav = el('div', 'rk-nav');
  const prevBtn = el('button', null, ui().prev);
  prevBtn.type = 'button';
  const nextBtn = el('button', 'rk-next', ui().next);
  nextBtn.type = 'button';
  nav.append(prevBtn, nextBtn);

  const opts = el('div', 'rk-opts');
  function makeSwitch(id, labelText, checked) {
    const lab = el('label', 'rk-switch');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.id = id;
    cb.checked = !!checked;
    const track = el('span', 'switch');
    track.setAttribute('aria-hidden', 'true');
    const labText = el('span', 'rk-switch-label', labelText);
    lab.append(cb, track, labText);
    return { lab, cb, labText };
  }
  const hideSw = makeSwitch('rk-hide', ui().hide, false);
  const fatSw = makeSwitch('rk-fatima', ui().fatima, true);
  const hideCb = hideSw.cb;
  const fatCb = fatSw.cb;

  const verWrap = el('label', 'rk-switch');
  verWrap.style.gap = '8px';
  const verLab = el('span', 'rk-switch-label', ui().version);
  const verSel = document.createElement('select');
  verSel.className = 'rk-select';
  verSel.setAttribute('aria-label', ui().version);
  const optNl = document.createElement('option');
  optNl.value = 'nl';
  optNl.textContent = 'Nederlands';
  const optLa = document.createElement('option');
  optLa.value = 'la';
  optLa.textContent = 'Latina';
  verSel.append(optNl, optLa);
  verSel.value = lang;
  verWrap.append(verLab, verSel);
  const focusTimerSw = makeSwitch('rk-focus-timer', ui().focusTimer, false);
  focusTimerSw.lab.title = ui().focusTimerHint;
  opts.append(hideSw.lab, fatSw.lab, verWrap, focusTimerSw.lab);

  const focusTimerEl = el('div', 'rk-focus-timer');
  focusTimerEl.setAttribute('aria-live', 'polite');

  card.append(whereEl, titleEl, noteEl, textEl, studyBox, intentBox, revealBtn, bar, focusTimerEl, nav, opts);
  main.appendChild(card);
  root.appendChild(main);

  // Info dialog
  const dialog = document.createElement('dialog');
  dialog.className = 'rk-dialog';
  dialog.setAttribute('aria-labelledby', 'rk-info-title');
  dialog.innerHTML = `
    <h2 id="rk-info-title">Welke mysteriën bid je wanneer?</h2>
    <p>Dit is de gebruikelijke indeling. Vandaag is gemarkeerd.</p>
    <table>
      <tr data-d="1"><td>Maandag</td><td>Blijde mysteriën</td></tr>
      <tr data-d="2"><td>Dinsdag</td><td>Pijnlijke mysteriën</td></tr>
      <tr data-d="3"><td>Woensdag</td><td>Glorievolle mysteriën</td></tr>
      <tr data-d="4"><td>Donderdag</td><td>Lichtende mysteriën</td></tr>
      <tr data-d="5"><td>Vrijdag</td><td>Pijnlijke mysteriën</td></tr>
      <tr data-d="6"><td>Zaterdag</td><td>Blijde mysteriën</td></tr>
      <tr data-d="0"><td>Zondag</td><td>Glorievolle mysteriën</td></tr>
    </table>
    <p>Op zondag bid je in de advent en de kersttijd de blijde mysteriën en in de vastentijd de pijnlijke. Je mag altijd een ander mysterie kiezen.</p>
    <button type="button" class="rk-close">Sluiten</button>
  `;
  root.appendChild(dialog);

  // History dialog
  const histDlg = document.createElement('dialog');
  histDlg.className = 'rk-dialog';
  histDlg.setAttribute('aria-labelledby', 'rk-hist-title');
  const histTitle = el('h2', null, ui().history);
  histTitle.id = 'rk-hist-title';
  const histList = el('ul', 'rk-hist-list');
  const histEmpty = el('p', null, ui().noHistory);
  const histClose = el('button', 'rk-close', 'Sluiten');
  histClose.type = 'button';
  histDlg.append(histTitle, histEmpty, histList, histClose);
  root.appendChild(histDlg);

  // ---- SVG beads ----
  const NS = 'http://www.w3.org/2000/svg';
  const beads = {};
  function svgEl(n, a, p) {
    const e = document.createElementNS(NS, n);
    for (const k in a) e.setAttribute(k, a[k]);
    (p || svg).appendChild(e);
    return e;
  }
  const defs = svgEl('defs', {});
  function grad(id, hi, lo) {
    const g = svgEl('radialGradient', { id, cx: '.35', cy: '.3', r: '.8' }, defs);
    svgEl('stop', { offset: '0', style: 'stop-color:' + hi }, g);
    svgEl('stop', { offset: '1', style: 'stop-color:' + lo }, g);
  }
  grad('rkGBead', '#f3eedd', '#8a8472');
  grad('rkGDone', 'color-mix(in srgb, var(--rk-accent) 55%, #fff)', 'color-mix(in srgb, var(--rk-accent) 62%, #000)');
  grad('rkGNow', '#fffcea', '#d6bd6e');

  const YB = 360, H = 340, A = 180;
  function pt(th, side) {
    const w = 0.6 + 0.4 * (1 - Math.cos(th)) / 2;
    return [200 + side * A * Math.sin(th) * w, YB - H * Math.sin(th / 2)];
  }
  const N = 1200;
  const P = [];
  const cum = [0];
  for (let i = 0; i <= N; i++) {
    const u = i / N;
    P.push(u <= 0.5 ? pt(u * 2 * Math.PI, -1) : pt((1 - u) * 2 * Math.PI, 1));
  }
  for (let i = 1; i <= N; i++) {
    cum.push(cum[i - 1] + Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]));
  }
  const L = cum[N];
  let d = 'M' + P.map(p => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).filter((_, i) => i % 4 === 0).join('L') + 'Z';
  svgEl('path', { d, class: 'string' });

  const tx = y => 200 + 9 * Math.sin((y - 360) / 40);
  let td = 'M200 360';
  for (let y = 364; y <= 474; y += 4) td += 'L' + tx(y).toFixed(1) + ' ' + y;
  svgEl('path', { d: td, class: 'string' });

  const RS = 5.6, RB = 9.5, RM = 11;
  const rad = i => (i % 11 === 0 ? RB : RS);
  let tot = RM + rad(0);
  for (let i = 1; i < 55; i++) tot += rad(i - 1) + rad(i);
  tot += rad(54) + RM;
  let acc = RM + rad(0);
  let k = 0;
  for (let i = 0; i < 55; i++) {
    if (i > 0) acc += rad(i - 1) + rad(i);
    const s = (L * acc) / tot;
    while (k < N && cum[k + 1] < s) k++;
    const f = (s - cum[k]) / ((cum[k + 1] - cum[k]) || 1);
    const x = P[k][0] + (P[k + 1][0] - P[k][0]) * f;
    const y = P[k][1] + (P[k + 1][1] - P[k][1]) * f;
    beads['L' + i] = {
      x, y, r: rad(i),
      node: svgEl('circle', { cx: x, cy: y, r: rad(i), class: 'bead' })
    };
  }
  [['gloria', 382, 6.5], ['t1', 400, RS], ['t2', 417, RS], ['t3', 434, RS], ['tbig', 457, RB]].forEach(([id, y, r]) => {
    beads[id] = {
      x: tx(y), y, r,
      node: svgEl('circle', { cx: tx(y), cy: y, r, class: 'bead' })
    };
  });
  beads.medal = {
    x: 200, y: YB, r: RM,
    node: svgEl('circle', { cx: 200, cy: YB, r: RM, class: 'bead' })
  };
  svgEl('circle', { cx: 200, cy: YB, r: 6, fill: 'none', stroke: '#0006', 'stroke-width': 1 });

  const px = tx(474);
  const cg = svgEl('g', { transform: 'translate(' + px.toFixed(1) + ' 474) rotate(-14)' });
  const c1 = svgEl('rect', { x: -6, y: 0, width: 12, height: 72, rx: 2.5, class: 'cross' }, cg);
  const c2 = svgEl('rect', { x: -23, y: 15, width: 46, height: 12, rx: 2.5, class: 'cross' }, cg);
  beads.cross = { x: px + 6.8, y: 474 + 28, r: 26, cross: [c1, c2] };
  const halo = svgEl('circle', { cx: 200, cy: YB, r: 20, class: 'halo' });

  // ---- steps ----
  function build(set) {
    const s = [];
    const P = prayers();
    const U = ui();
    const add = (key, bead, extra) =>
      s.push(Object.assign({
        title: P[key][0],
        text: P[key][1],
        bead,
        where: U.begin,
        key
      }, extra));
    add('kruis', 'cross');
    add('credo', 'cross');
    add('ov', 'tbig');
    [
      [U.faith, 't3'],
      [U.hope, 't2'],
      [U.love, 't1']
    ].forEach(([note, bead]) => add('wg', bead, { note }));
    add('ere', 'gloria');
    for (let d = 0; d < 5; d++) {
      const w = U.decade(d + 1);
      const b0 = 'L' + d * 11;
      const mystTitle = lang === 'la'
        ? U.mysteryTitle(ORD_LA[d], set.adjLa)
        : U.mysteryTitle(ORD[d], set.adj);
      const mystText = lang === 'la' ? set.listLa[d] : set.list[d];
      s.push({
        title: mystTitle,
        text: mystText,
        bead: b0,
        where: w,
        mystery: true,
        decade: d,
        ref: set.refs[d],
        study: set.study[d]
      });
      add('ov', b0, { where: w, decade: d });
      for (let j = 1; j <= 10; j++) {
        add('wg', 'L' + (d * 11 + j), { where: w, note: U.wgNote(j), decade: d });
      }
      add('ere', 'L' + (d * 11 + 10), { where: w, decade: d });
      add('fat', 'L' + (d * 11 + 10), { where: w, opt: true, decade: d });
    }
    add('salve', 'medal', { where: U.close });
    add('kruis', 'medal', { where: U.close, finish: true });
    return s;
  }

  let set = SETS[DAY[new Date().getDay()]];
  let steps = [];
  let cur = 0;
  let shown = false;
  let destroyed = false;
  /** @type {string[]} intenties per decade (0..4) */
  let intentions = ['', '', '', '', ''];
  let sessionStarted = Date.now();

  const useFat = () => fatCb.checked;
  const vis = () => steps.filter(s => !s.opt || useFat());

  function paintBead(id, state) {
    const b = beads[id];
    if (!b) return;
    const nodes = b.cross || [b.node];
    nodes.forEach(n => {
      n.classList.remove('done', 'now');
      if (state) n.classList.add(state);
    });
  }

  function currentDecade() {
    const s = steps[cur];
    return s && typeof s.decade === 'number' ? s.decade : -1;
  }

  function render() {
    const U = ui();
    const v = vis();
    if (steps[cur] && steps[cur].opt && !useFat()) cur = Math.max(0, cur - 1);
    const s = steps[cur];
    if (!s) return;
    const i = v.indexOf(s);

    Object.keys(beads).forEach(id => paintBead(id, ''));
    steps.slice(0, cur).forEach(p => {
      if (!p.opt || useFat()) paintBead(p.bead, 'done');
    });
    paintBead(s.bead, 'now');
    const b = beads[s.bead];
    if (b) {
      halo.setAttribute('cx', b.x);
      halo.setAttribute('cy', b.y);
      halo.setAttribute('r', b.r + 8);
    }

    whereEl.textContent = s.where;
    titleEl.textContent = s.title;
    noteEl.textContent = s.note || '';
    noteEl.hidden = !s.note;

    const hide = hideCb.checked && !s.mystery && !shown;
    textEl.textContent = hide ? U.hidePrompt : s.text;
    textEl.classList.toggle('is-hidden', hide);
    revealBtn.hidden = !hide;
    revealBtn.textContent = U.reveal;

    // Studiemodus: altijd bij mysteries
    if (s.mystery && s.ref) {
      studyBox.hidden = false;
      studyBox.replaceChildren();
      const lab = el('strong', null, U.studyLabel);
      const ref = el('div', 'rk-ref', U.ref + ': ' + s.ref);
      const body = el('div', null, s.study || '');
      studyBox.append(lab, ref, body);
    } else {
      studyBox.hidden = true;
    }

    // Intentie: bij start van decade (mysterie-stap) of OV van decade
    const dec = currentDecade();
    if (dec >= 0 && (s.mystery || (s.key === 'ov' && s.decade === dec))) {
      intentBox.hidden = false;
      intentLab.textContent = U.intention;
      intentIn.placeholder = U.intentionPh;
      if (intentIn.value !== intentions[dec]) {
        intentIn.value = intentions[dec] || '';
      }
    } else {
      intentBox.hidden = true;
    }

    barI.style.width = (i / Math.max(1, v.length - 1)) * 100 + '%';
    prevBtn.disabled = i === 0;
    prevBtn.style.opacity = i === 0 ? 0.4 : 1;
    prevBtn.textContent = U.prev;
    nextBtn.textContent = i === v.length - 1 ? U.again : U.next;
  }

  function persistIntent() {
    const dec = currentDecade();
    if (dec >= 0) intentions[dec] = intentIn.value.trim();
  }

  function showToast(msg) {
    let toast = root.querySelector('.rk-toast');
    if (!toast) {
      toast = el('div', 'rk-toast');
      root.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('is-on');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toast.classList.remove('is-on'), 3200);
  }

  async function completeSession() {
    const now = new Date().toISOString();
    const entry = {
      id: Date.now(),
      at: now,
      setId: set.id,
      setName: set.name,
      intentions: intentions.filter(Boolean),
      lang
    };
    if (!_streakCache) await loadStreakAsync();
    const data = loadStreak();
    const status = getStreakStatus();
    // +1 per voltooide rozenkrans; binnen 36u blijft de reeks, anders opnieuw vanaf 1
    const newCount = status.active && status.count > 0 ? status.count + 1 : 1;
    const newRecord = Math.max(data.record || 0, newCount);
    const sessions = [entry].concat(data.sessions || []).slice(0, MAX_SESSIONS);
    const res = await saveStreakAsync({
      count: newCount,
      record: newRecord,
      lastAt: now,
      sessions
    });
    return { newCount, newRecord, res };
  }

  async function go(dir) {
    persistIntent();
    const v = vis();
    let i = v.indexOf(steps[cur]);
    // Als cur op een verborgen opt-stap staat, herstel index
    if (i < 0 && steps[cur]) {
      const near = v.findIndex(s => s.bead === steps[cur].bead);
      i = near >= 0 ? near : 0;
    }
    const atEnd = i >= 0 && i === v.length - 1;
    if (dir > 0 && atEnd) {
      try {
        const result = await completeSession();
        updateStreakBadge();
        const U = ui();
        showToast(
          U.sessionDone +
          (result && result.newCount ? ' · ' + result.newCount : '')
        );
      } catch (e) {
        console.warn('Streak afronden mislukt:', e);
        updateStreakBadge();
      }
      cur = 0;
      intentions = ['', '', '', '', ''];
      sessionStarted = Date.now();
      intentIn.value = '';
    } else if (dir < 0 && i <= 0) {
      return;
    } else {
      cur = steps.indexOf(v[i + dir]);
      if (cur < 0) cur = 0;
    }
    shown = false;
    render();
  }

  function rebuildStepsKeepPos() {
    const oldBead = steps[cur] && steps[cur].bead;
    const oldTitle = steps[cur] && steps[cur].title;
    steps = build(set);
    // Probeer positie te houden
    let found = steps.findIndex(s => s.bead === oldBead && (!oldTitle || s.title === oldTitle || s.mystery === (steps[cur] && steps[cur].mystery)));
    if (found < 0) found = steps.findIndex(s => s.bead === oldBead);
    cur = found >= 0 ? found : Math.min(cur, steps.length - 1);
    shown = false;
    render();
  }

  function setMystery(sx) {
    persistIntent();
    set = sx;
    steps = build(set);
    cur = 0;
    shown = false;
    intentions = ['', '', '', '', ''];
    intentIn.value = '';
    sessionStarted = Date.now();
    root.style.setProperty('--rk-accent', set.color);
    refreshSetButtons();
    render();
  }

  function refreshSetButtons() {
    setsEl.querySelectorAll('button').forEach(b => {
      const sx = SETS.find(x => x.id === b.dataset.id);
      if (sx) b.textContent = lang === 'la' ? sx.nameLa : sx.name;
      b.setAttribute('aria-checked', b.dataset.id === set.id ? 'true' : 'false');
    });
  }

  function applyLangUI() {
    const U = ui();
    h1.textContent = U.title;
    sub.textContent = U.subtitle;
    hideSw.labText.textContent = U.hide;
    fatSw.labText.textContent = U.fatima;
    verLab.textContent = U.version;
    verSel.setAttribute('aria-label', U.version);
    histBtn.title = U.history;
    histBtn.setAttribute('aria-label', U.history);
    histTitle.textContent = U.history;
    histEmpty.textContent = U.noHistory;
    focusBtn.title = focusOn ? U.focusExit : U.focus;
    focusBtn.setAttribute('aria-label', focusBtn.title);
    focusTimerSw.labText.textContent = U.focusTimer;
    focusTimerSw.lab.title = U.focusTimerHint;
    refreshSetButtons();
    rebuildStepsKeepPos();
  }

  SETS.forEach(sx => {
    const b = el('button', null, sx.name);
    b.type = 'button';
    b.dataset.id = sx.id;
    b.setAttribute('role', 'radio');
    b.onclick = () => setMystery(sx);
    setsEl.appendChild(b);
  });

  nextBtn.onclick = () => go(1);
  prevBtn.onclick = () => go(-1);
  hideCb.onchange = () => {
    shown = false;
    render();
  };
  fatCb.onchange = () => render();
  verSel.onchange = () => {
    lang = verSel.value === 'la' ? 'la' : 'nl';
    applyLangUI();
  };
  revealBtn.onclick = () => {
    shown = true;
    render();
  };
  intentIn.onchange = persistIntent;
  intentIn.onblur = persistIntent;

  const onKey = e => {
    if (destroyed || dialog.open || histDlg.open) return;
    if (e.target.matches('input,button,textarea') && e.key === ' ') return;
    if (e.target.matches('input,textarea')) return;
    if (e.key === 'ArrowRight' || e.key === ' ') {
      e.preventDefault();
      go(1);
    }
    if (e.key === 'ArrowLeft') go(-1);
  };
  document.addEventListener('keydown', onKey);

  infoBtn.onclick = () => dialog.showModal();
  dialog.querySelector('.rk-close').onclick = () => dialog.close();
  dialog.addEventListener('click', e => {
    if (e.target === dialog) dialog.close();
  });
  dialog.querySelectorAll('tr').forEach(r => {
    if (r.dataset.d === String(new Date().getDay())) r.classList.add('today');
  });

  function renderHistory() {
    const U = ui();
    const status = getStreakStatus();
    const data = loadStreak();
    histList.replaceChildren();

    // Streak-panel bovenaan
    const panel = el('div', 'rk-streak-panel');
    const row1 = el('div', 'rk-streak-row');
    row1.append(
      el('span', null, U.streakNow),
      el('strong', null, String(status.count) + ' ' + U.streakUnit)
    );
    const row2 = el('div', 'rk-streak-row');
    row2.append(
      el('span', null, U.streakRecord),
      el('strong', null, String(status.record) + ' ' + U.streakUnit)
    );
    panel.append(row1, row2);

    if (status.active && status.hoursLeft != null) {
      const warn = el('div', 'rk-streak-warn',
        U.streakExpires + ' ' + formatHoursLeft(status.hoursLeft));
      panel.append(warn);
    } else if (status.expired) {
      panel.append(el('div', 'rk-streak-muted', U.streakExpired));
    } else if (!status.count) {
      panel.append(el('div', 'rk-streak-muted', U.streakNone));
    }

    histList.appendChild(panel);

    const list = data.sessions || [];
    if (!list.length) {
      histEmpty.hidden = false;
      histEmpty.textContent = U.noHistory;
      return;
    }
    histEmpty.hidden = true;
    histList.appendChild(el('div', 'rk-streak-muted', U.recent));
    list.forEach(entry => {
      const li = el('li');
      const date = new Date(entry.at);
      const dateStr = date.toLocaleString(lang === 'la' ? 'la' : 'nl-NL', {
        dateStyle: 'medium',
        timeStyle: 'short'
      });
      const top = el('div', null, (entry.setName || entry.setId) + (entry.lang === 'la' ? ' · LA' : ''));
      const d = el('div', 'rk-hist-date', dateStr);
      li.append(top, d);
      if (entry.intentions && entry.intentions.length) {
        li.append(el('div', 'rk-hist-int', entry.intentions.join(' · ')));
      }
      histList.appendChild(li);
    });
  }

  histBtn.onclick = () => {
    loadStreakAsync().then(() => {
      renderHistory();
      histDlg.showModal();
    }).catch(() => {
      renderHistory();
      histDlg.showModal();
    });
  };
  histClose.onclick = () => histDlg.close();
  histDlg.addEventListener('click', e => {
    if (e.target === histDlg) histDlg.close();
  });

  function updateStreakBadge() {
    const status = getStreakStatus();
    // Knop blijft alleen 🔥; cijfer in badge rechtsboven
    if (histBtn.childNodes[0] && histBtn.childNodes[0].nodeType === 3) {
      histBtn.childNodes[0].nodeValue = '🔥';
    }
    if (status.active && status.count > 0) {
      streakBadge.hidden = false;
      streakBadge.textContent = String(status.count);
      const urgent = status.hoursLeft != null && status.hoursLeft < 12;
      histBtn.classList.toggle('is-urgent', urgent);
      let title = ui().history + ' · ' + status.count;
      if (status.hoursLeft != null) {
        title += ' · ' + ui().streakExpires + ' ' + formatHoursLeft(status.hoursLeft);
      }
      histBtn.title = title;
    } else {
      streakBadge.hidden = true;
      histBtn.classList.remove('is-urgent');
      histBtn.title = ui().history;
    }
    histBtn.setAttribute('aria-label', histBtn.title);
  }

  // —— Focus-modus ——
  let focusOn = false;
  let focusTimerOn = false;
  let focusRemainMs = 0;
  let focusTimerId = null;
  let focusEndsAt = 0;

  function stopFocusTimer() {
    if (focusTimerId) {
      clearInterval(focusTimerId);
      focusTimerId = null;
    }
    focusTimerEl.classList.remove('is-on');
    focusTimerEl.textContent = '';
  }

  function tickFocusTimer() {
    focusRemainMs = Math.max(0, focusEndsAt - Date.now());
    focusTimerEl.textContent = fmtFocusClock(focusRemainMs);
    if (focusRemainMs <= 0) {
      stopFocusTimer();
      showToast(ui().focus + ' · 0:00');
    }
  }

  function startFocusTimer() {
    stopFocusTimer();
    if (!focusTimerSw.cb.checked) return;
    const min = readStudyBlockMin();
    focusRemainMs = min * 60 * 1000;
    focusEndsAt = Date.now() + focusRemainMs;
    focusTimerEl.classList.add('is-on');
    tickFocusTimer();
    focusTimerId = setInterval(tickFocusTimer, 500);
  }

  function setFocusMode(on) {
    focusOn = !!on;
    root.classList.toggle('is-focus', focusOn);
    focusBtn.classList.toggle('is-active', focusOn);
    focusBtn.title = focusOn ? ui().focusExit : ui().focus;
    focusBtn.setAttribute('aria-label', focusBtn.title);
    focusBtn.setAttribute('aria-pressed', focusOn ? 'true' : 'false');
    if (focusOn) {
      if (focusTimerSw.cb.checked) startFocusTimer();
      nextBtn.focus();
    } else {
      stopFocusTimer();
    }
  }

  focusBtn.onclick = () => setFocusMode(!focusOn);
  focusTimerSw.cb.onchange = () => {
    if (focusOn && focusTimerSw.cb.checked) startFocusTimer();
    else if (!focusTimerSw.cb.checked) stopFocusTimer();
  };

  // Escape verlaat focus-modus
  const onKeyFocus = (e) => {
    if (destroyed) return;
    if (focusOn && e.key === 'Escape') {
      e.preventDefault();
      setFocusMode(false);
    }
  };
  document.addEventListener('keydown', onKeyFocus);
  setMystery(set);
  loadStreakAsync().then(() => updateStreakBadge()).catch(() => updateStreakBadge());

  return {
    root,
    el: root,
    kind: 'rozenkrans',
    close() {
      destroyed = true;
      persistIntent();
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('keydown', onKeyFocus);
      stopFocusTimer();
      try {
        if (dialog.open) dialog.close();
        if (histDlg.open) histDlg.close();
      } catch (_) {}
    },
    focus() {
      nextBtn.focus();
    },
    getState() {
      return {
        setId: set.id,
        cur,
        hide: hideCb.checked,
        fatima: fatCb.checked,
        intentions: intentions.slice(),
        lang,
        focus: focusOn,
        focusTimer: focusTimerSw.cb.checked
      };
    },
    setState(s) {
      if (!s) return;
      if (s.setId) {
        const found = SETS.find(x => x.id === s.setId);
        if (found) {
          set = found;
          root.style.setProperty('--rk-accent', set.color);
        }
      }
      if (s.lang === 'la' || s.lang === 'nl') {
        lang = s.lang;
      } else if (typeof s.latin === 'boolean') {
        lang = s.latin ? 'la' : 'nl';
      }
      verSel.value = lang;
      if (typeof s.hide === 'boolean') hideCb.checked = s.hide;
      if (typeof s.fatima === 'boolean') fatCb.checked = s.fatima;
      if (Array.isArray(s.intentions)) {
        intentions = [0, 1, 2, 3, 4].map(i => s.intentions[i] || '');
      }
      applyLangUI();
      if (typeof s.cur === 'number' && s.cur >= 0 && s.cur < steps.length) {
        cur = s.cur;
      }
      if (typeof s.focusTimer === 'boolean') focusTimerSw.cb.checked = s.focusTimer;
      if (typeof s.focus === 'boolean') setFocusMode(s.focus);
      shown = false;
      render();
    }
  };
}
