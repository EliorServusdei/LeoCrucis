/**
 * core/dom.js — kleine DOM-helpers zonder afhankelijkheden.
 * Gebruik: import { $, el } from './core/dom.js';
 */

/** querySelector-shortcut */
export const $ = (s, root = document) => root.querySelector(s);

/** querySelectorAll → array */
export const $$ = (s, root = document) => [...root.querySelectorAll(s)];

/**
 * Maak een element.
 * @param {string} tag
 * @param {string} [cls]
 * @param {string} [text]
 */
export function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null && text !== '') e.textContent = text;
  return e;
}

/**
 * Maak een SVG-element met viewBox 0 0 24 24 en standaard stroke-stijl.
 * @param {string} innerHTML  path/rect inhoud
 * @param {object} [attrs]    extra attributen (width, height, …)
 */
export function svgIcon(innerHTML, attrs = {}) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', attrs.viewBox || '0 0 24 24');
  s.setAttribute('width', String(attrs.width ?? 24));
  s.setAttribute('height', String(attrs.height ?? 24));
  s.setAttribute('fill', attrs.fill ?? 'none');
  s.setAttribute('stroke', attrs.stroke ?? 'currentColor');
  s.setAttribute('stroke-width', String(attrs.strokeWidth ?? 1.75));
  s.setAttribute('stroke-linecap', 'round');
  s.setAttribute('stroke-linejoin', 'round');
  s.setAttribute('aria-hidden', 'true');
  s.innerHTML = innerHTML;
  return s;
}
