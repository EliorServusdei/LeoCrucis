// Fotoalbum — kies een map met foto's op je schijf en blader erdoor als in een echt album.
// Niets wordt gekopieerd of geüpload: de foto's blijven in hun map en worden alleen getoond.
// Wat je zelf instelt (favorieten, bijschriften, titel, volgorde, leesplaats, ...) wordt per map onthouden
// in de app zelf; je foto's blijven onaangeroerd.

import { bgToggle, getBackgroundMusic, onBackgroundMusic } from '../media/player.js';
import { openPdfPrintPreview, slugName } from '../editor/pdf.js';

const SETTINGS_KEY = 'lc-album-settings-v2';
const DATA_PREFIX = 'lc-album-data-v1:';
const DB_NAME = 'lc-album';
const STORE = 'handles';
const IMG_RE = /\.(jpe?g|png|gif|webp|bmp|avif)$/i;
const SKIP_RE = /\.(heic|heif|tiff?|raw|cr2|nef|arw|dng)$/i;
const FLIP_MS = 1000;
const PRINT_MAX = 100;
const DUP_BITS = 30;           // van 1024 bits mag een "mogelijke dubbel" afwijken

const h = (tag, cls, text) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
};
const mkBtn = (text, title, cls = 'alb-btn') => {
  const b = h('button', cls, text); b.type = 'button'; if (title) b.title = title; return b;
};

function loadSettings() {
  try {
    const s = JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}');
    return { secs: Number(s.secs) || 5, shuffle: !!s.shuffle, loop: !!s.loop };
  } catch { return { secs: 5, shuffle: false, loop: false }; }
}
function saveSettings(s) { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch (_) {} }

// ---- Instellingen per album (per mapnaam) ----
function defaultData() {
  return { title: '', coverColor: 'hout', paper: 'creme', density: 'normaal', cover: '', sort: 'date-asc',
    fav: new Set(), hidden: new Set(), captions: {}, order: [], pos: '' };
}
function loadData(key) {
  const d = defaultData();
  try {
    const raw = JSON.parse(localStorage.getItem(DATA_PREFIX + key) || 'null');
    if (raw && typeof raw === 'object') {
      for (const k of ['title', 'coverColor', 'paper', 'density', 'cover', 'sort', 'pos']) if (typeof raw[k] === 'string') d[k] = raw[k];
      if (Array.isArray(raw.fav)) d.fav = new Set(raw.fav);
      if (Array.isArray(raw.hidden)) d.hidden = new Set(raw.hidden);
      if (raw.captions && typeof raw.captions === 'object') d.captions = raw.captions;
      if (Array.isArray(raw.order)) d.order = raw.order;
    }
  } catch (_) {}
  return d;
}
function saveData(key, d) {
  try {
    localStorage.setItem(DATA_PREFIX + key, JSON.stringify({ ...d, fav: [...d.fav], hidden: [...d.hidden] }));
  } catch (e) { console.warn('Albuminstellingen opslaan mislukt', e); }
}

// ---- Onthouden van de laatst gekozen map (alleen waar de browser dat toelaat) ----
function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function saveHandle(handle) {
  try {
    const db = await openDb();
    await new Promise((res, rej) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(handle, 'last');
      tx.oncomplete = res; tx.onerror = () => rej(tx.error);
    });
  } catch (_) {}
}
async function loadHandle() {
  try {
    const db = await openDb();
    return await new Promise((res, rej) => {
      const req = db.transaction(STORE, 'readonly').objectStore(STORE).get('last');
      req.onsuccess = () => res(req.result || null);
      req.onerror = () => rej(req.error);
    });
  } catch (_) { return null; }
}

// ---- Map inlezen ----
async function walkHandle(dirHandle, prefix, out, depth = 0) {
  for await (const [name, handle] of dirHandle.entries()) {
    if (handle.kind === 'file') {
      if (IMG_RE.test(name)) out.files.push({ getFile: () => handle.getFile(), dir: prefix, name });
      else if (SKIP_RE.test(name)) out.skipped++;
    } else if (handle.kind === 'directory' && depth < 6 && !name.startsWith('.')) {
      await walkHandle(handle, prefix ? prefix + '/' + name : name, out, depth + 1);
    }
  }
}
function filesFromInput(fileList) {
  const out = { files: [], skipped: 0, rootName: '' };
  for (const f of fileList) {
    const rel = f.webkitRelativePath || f.name;
    const parts = rel.split('/');
    if (!out.rootName && parts.length > 1) out.rootName = parts[0];
    if (IMG_RE.test(f.name)) {
      out.files.push({ file: f, getFile: async () => f, dir: parts.slice(1, -1).join('/'), name: f.name });
    } else if (SKIP_RE.test(f.name)) out.skipped++;
  }
  return out;
}

// ---- Opnamedatum uit de foto (EXIF, alleen jpeg) ----
function exifDate(buf) {
  try {
    const v = new DataView(buf);
    if (v.byteLength < 12 || v.getUint16(0) !== 0xFFD8) return 0;
    let off = 2;
    while (off + 4 < v.byteLength) {
      if (v.getUint8(off) !== 0xFF) return 0;
      const marker = v.getUint8(off + 1);
      if (marker === 0xDA) return 0;
      const len = v.getUint16(off + 2);
      if (marker === 0xE1 && off + 10 < v.byteLength && v.getUint32(off + 4) === 0x45786966) return exifTiff(v, off + 10);
      off += 2 + len;
    }
  } catch (_) {}
  return 0;
}
function exifTiff(v, base) {
  const le = v.getUint16(base) === 0x4949;
  const u16 = o => v.getUint16(base + o, le), u32 = o => v.getUint32(base + o, le);
  if (u16(2) !== 42) return 0;
  const readIfd = (ptr, wanted) => {
    const out = {};
    if (!ptr || base + ptr + 2 > v.byteLength) return out;
    const n = u16(ptr);
    for (let i = 0; i < n; i++) {
      const e = ptr + 2 + i * 12;
      if (base + e + 12 > v.byteLength) break;
      const tag = u16(e);
      if (wanted.includes(tag)) out[tag] = { type: u16(e + 2), count: u32(e + 4), valOff: e + 8 };
    }
    return out;
  };
  const ascii = ent => {
    if (!ent || ent.type !== 2) return '';
    const o = ent.count > 4 ? u32(ent.valOff) : ent.valOff;
    let s = '';
    for (let i = 0; i < ent.count - 1 && base + o + i < v.byteLength; i++) s += String.fromCharCode(v.getUint8(base + o + i));
    return s;
  };
  const ifd0 = readIfd(u32(4), [0x0132, 0x8769]);
  let s = '';
  if (ifd0[0x8769]) {
    const ex = readIfd(u32(ifd0[0x8769].valOff), [0x9003, 0x9004]);
    s = ascii(ex[0x9003]) || ascii(ex[0x9004]);
  }
  if (!s) s = ascii(ifd0[0x0132]);
  const m = /^(\d{4}):(\d{2}):(\d{2}) (\d{2}):(\d{2}):(\d{2})/.exec(s);
  if (!m || m[1] === '0000') return 0;
  return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime();
}

// ---- Afmetingen + vingerafdruk (voor indeling en dubbels) ----
const hashCanvas = document.createElement('canvas');
hashCanvas.width = 33; hashCanvas.height = 32;
const hashCtx = hashCanvas.getContext('2d', { willReadFrequently: true });
function hashFrom(src) {
  try {
    hashCtx.imageSmoothingEnabled = true; hashCtx.imageSmoothingQuality = 'high';
    hashCtx.fillStyle = '#fff'; hashCtx.fillRect(0, 0, 33, 32);
    hashCtx.drawImage(src, 0, 0, 33, 32);
    const d = hashCtx.getImageData(0, 0, 33, 32).data;
    const out = new Uint32Array(32);
    let ones = 0;
    for (let y = 0; y < 32; y++) {
      let w = 0;
      for (let x = 0; x < 32; x++) {
        const i = (y * 33 + x) * 4, j = i + 4;
        const a = d[i] * .299 + d[i + 1] * .587 + d[i + 2] * .114;
        const b = d[j] * .299 + d[j + 1] * .587 + d[j + 2] * .114;
        if (a > b + 3) { w |= (1 << x); ones++; }
      }
      out[y] = w >>> 0;
    }
    return ones >= 24 ? out : null;     // bijna egale beelden zijn niet te onderscheiden: geen vergelijking
  } catch (_) { return null; }
}
async function measure(file) {
  try {
    const bmp = await createImageBitmap(file, { resizeWidth: 96 });
    const r = { w: bmp.width, h: bmp.height, hash: hashFrom(bmp) };
    bmp.close && bmp.close();
    return r;
  } catch (_) {
    return new Promise(resolve => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => { resolve({ w: img.naturalWidth, h: img.naturalHeight, hash: hashFrom(img) }); URL.revokeObjectURL(url); };
      img.onerror = () => { resolve(null); URL.revokeObjectURL(url); };
      img.src = url;
    });
  }
}
function pop32(x) {
  x -= (x >>> 1) & 0x55555555;
  x = (x & 0x33333333) + ((x >>> 2) & 0x33333333);
  return (((x + (x >>> 4)) & 0x0F0F0F0F) * 0x01010101) >>> 24;
}
// Mogelijke dubbels: foto's met (bijna) dezelfde verhouding én (bijna) dezelfde inhoud. Groepen via union-find.
function findDupes(list) {
  const idx = list.map((p, i) => i).filter(i => list[i].hash).sort((a, b) => list[a].r - list[b].r);
  const parent = list.map((_, i) => i);
  const find = i => { while (parent[i] !== i) { parent[i] = parent[parent[i]]; i = parent[i]; } return i; };
  for (let a = 0; a < idx.length; a++) {
    const A = list[idx[a]];
    for (let b = a + 1; b < idx.length; b++) {
      const B = list[idx[b]];
      if (B.r > A.r * 1.03) break;
      let dist = 0;
      for (let k = 0; k < 32 && dist <= DUP_BITS; k++) dist += pop32((A.hash[k] ^ B.hash[k]) >>> 0);
      if (dist <= DUP_BITS) { const ra = find(idx[a]), rb = find(idx[b]); if (ra !== rb) parent[Math.max(ra, rb)] = Math.min(ra, rb); }
    }
  }
  const size = new Map();
  list.forEach((p, i) => { const r = find(i); size.set(r, (size.get(r) || 0) + 1); });
  let groups = 0, extra = 0;
  list.forEach((p, i) => {
    const r = find(i);
    if (size.get(r) > 1) { p.dupGroup = r; } else p.dupGroup = null;
  });
  for (const [, n] of size) if (n > 1) { groups++; extra += n - 1; }
  return { groups, extra };
}


// ---- Minimale PDF-schrijver: elke pagina is één JPEG-afbeelding op een A4-blad (geen extra bibliotheek nodig) ----
function makePdf(imgs) {
  const enc = new TextEncoder();
  const chunks = []; let len = 0; const offs = [];
  const push = d => { const u = typeof d === 'string' ? enc.encode(d) : d; chunks.push(u); len += u.length; };
  const obj = (n, body) => { offs[n] = len; push(n + ' 0 obj\n' + body + '\nendobj\n'); };
  push('%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n');
  const n = imgs.length;
  const PW = 595.28, PH = 841.89, M = 22.68;           // A4 in punten, marge 8 mm
  const iw = PW - 2 * M, ih = iw * 4 / 3, y0 = (PH - ih) / 2;
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, '<< /Type /Pages /Kids [' + imgs.map((_, i) => (3 + 3 * i) + ' 0 R').join(' ') + '] /Count ' + n + ' >>');
  imgs.forEach((im, i) => {
    const pg = 3 + 3 * i, ct = pg + 1, xo = pg + 2;
    obj(pg, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + PW + ' ' + PH + '] /Resources << /XObject << /Im0 ' + xo + ' 0 R >> >> /Contents ' + ct + ' 0 R >>');
    const cs = 'q ' + iw.toFixed(2) + ' 0 0 ' + ih.toFixed(2) + ' ' + M.toFixed(2) + ' ' + y0.toFixed(2) + ' cm /Im0 Do Q';
    obj(ct, '<< /Length ' + cs.length + ' >>\nstream\n' + cs + '\nendstream');
    offs[xo] = len;
    push(xo + ' 0 obj\n<< /Type /XObject /Subtype /Image /Width ' + im.w + ' /Height ' + im.h +
      ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + im.bytes.length + ' >>\nstream\n');
    push(im.bytes);
    push('\nendstream\nendobj\n');
  });
  const total = 3 + 3 * n;
  const xref = len;
  push('xref\n0 ' + total + '\n0000000000 65535 f \n');
  for (let i = 1; i < total; i++) push(String(offs[i]).padStart(10, '0') + ' 00000 n \n');
  push('trailer\n<< /Size ' + total + ' /Root 1 0 R >>\nstartxref\n' + xref + '\n%%EOF');
  const out = new Uint8Array(len);
  let o = 0;
  for (const c of chunks) { out.set(c, o); o += c.length; }
  return out;
}
function bytesToBase64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

const natural = new Intl.Collator('nl', { numeric: true, sensitivity: 'base' });
const dateFmt = new Intl.DateTimeFormat('nl-BE', { day: 'numeric', month: 'long', year: 'numeric' });
const monthFmt = new Intl.DateTimeFormat('nl-BE', { month: 'long', year: 'numeric' });

// ---- Indeling: welke foto's samen op een pagina ----
// Elke indeling heeft vakken: L = liggend, P = staand, A = alles. Foto's worden nooit bijgesneden;
// een foto krijgt het vak waarin hij het best past en blijft op zijn eigen verhouding.
const LAYOUTS = [
  { cls: 'l1',  slots: ['A'] },
  { cls: 'l2v', slots: ['L', 'L'] },
  { cls: 'l2h', slots: ['P', 'P'] },
  { cls: 'l2m', slots: ['L', 'P'] },
  { cls: 'l2n', slots: ['P', 'L'] },
  { cls: 'l3a', slots: ['L', 'P', 'P'] },
  { cls: 'l3b', slots: ['P', 'L', 'L'] },
  { cls: 'l3c', slots: ['P', 'P', 'L'] },
  { cls: 'l3d', slots: ['L', 'L', 'P'] },
  { cls: 'l3e', slots: ['L', 'L', 'L'] },
  { cls: 'l3f', slots: ['P', 'P', 'P'] },
  { cls: 'l4',  slots: ['A', 'A', 'A', 'A'] },
  { cls: 'l4b', slots: ['L', 'P', 'P', 'P'] },
  { cls: 'l5',  slots: ['A', 'A', 'A', 'A', 'A'] }
];
// Dichtheid: ruim = 1-2 foto's per pagina, normaal = tot 4, compact = tot 5 en liefst veel
const DENSITY = {
  ruim:    { maxN: 2, bonus: 0.3, l1pen: -1, hero: 0 },
  normaal: { maxN: 4, bonus: 1.2, l1pen: 4,  hero: 9 },
  compact: { maxN: 5, bonus: 2.4, l1pen: 6,  hero: 0 }
};

function pickLayout(o, recent, k, dens) {
  const avail = o.slice(0, dens.maxN);
  let best = null, bestScore = Infinity;
  LAYOUTS.forEach((lay, idx) => {
    const n = lay.slots.length;
    if (n > avail.length) return;
    let mism = 0;
    lay.slots.forEach((sl, i) => { if (sl !== 'A' && sl !== avail[i]) mism++; });
    const jitter = ((k * 7 + idx * 13) % 6) * 0.9;
    const anyOnly = lay.slots.every(x => x === 'A');
    const repeat = recent.includes(lay.cls) ? (recent[recent.length - 1] === lay.cls ? 12 : 5) : 0;
    const score = mism * 10 + repeat - n * dens.bonus + jitter + (n === 1 ? dens.l1pen : 0) + (anyOnly && n > 1 ? 3.5 : 0);
    if (score < bestScore) { bestScore = score; best = lay; }
  });
  return { cls: best.cls, n: best.slots.length };
}

function buildPages(photos, title, dens, coverPhoto) {
  const pages = [];
  const dates = photos.map(p => p.date).filter(Boolean);
  let range = '';
  if (dates.length) {
    const lo = Math.min(...dates), hi = Math.max(...dates);
    range = new Date(lo).getFullYear() === new Date(hi).getFullYear()
      ? monthFmt.format(lo) + (monthFmt.format(lo) === monthFmt.format(hi) ? '' : ' – ' + monthFmt.format(hi))
      : dateFmt.format(lo) + ' – ' + dateFmt.format(hi);
  }
  pages.push({ kind: 'cover', title, sub: photos.length + ' foto’s', range, cover: coverPhoto || null });

  const dirs = new Set(photos.map(p => p.dir));
  const byDir = dirs.size > 1;
  const groups = [];
  for (const p of photos) {
    const key = byDir ? p.dir : (p.date ? new Date(p.date).toDateString() : '');
    const label = byDir ? (p.dir ? p.dir.split('/').pop() : title) : (p.date ? dateFmt.format(p.date) : '');
    const last = groups[groups.length - 1];
    if (last && last.key === key) last.items.push(p);
    else groups.push({ key, label, items: [p], page: 0 });
  }

  let pageNo = 0;
  const recent = [];
  for (const g of groups) {
    let i = 0, first = true;
    while (i < g.items.length) {
      const rest = g.items.slice(i, i + 5);
      let lay = pickLayout(rest.map(p => p.o), recent, pageNo, dens);
      if (dens.hero && pageNo % dens.hero === dens.hero - 1 && rest[0].o === 'L') lay = { cls: 'l1', n: 1 };
      if (first) g.page = pages.length;
      pages.push({ kind: 'photos', layout: lay.cls, items: g.items.slice(i, i + lay.n), caption: first ? g.label : '', n: ++pageNo });
      recent.push(lay.cls); if (recent.length > 3) recent.shift();
      i += lay.n; first = false;
    }
  }
  pages.push({ kind: 'end' });
  const pageOf = new Map();
  pages.forEach((pg, i) => { if (pg.kind === 'photos') pg.items.forEach(p => pageOf.set(p.key, i)); });
  return { pages, pageOf, groups };
}

const COVER_COLORS = [['hout', 'Hout'], ['bordeaux', 'Bordeaux'], ['marine', 'Marineblauw'], ['bos', 'Bosgroen'], ['zwart', 'Zwart']];
const PAPERS = [['creme', 'Crème'], ['wit', 'Wit'], ['kraft', 'Kraftpapier']];

export function createAlbumApp() {
  const settings = loadSettings();
  const root = h('div', 'app-panel album-app');
  root.tabIndex = -1;

  let all = [];             // alle gelezen foto's
  let photos = [];          // zichtbare foto's in volgorde (na filter)
  let pages = [], pageOf = new Map(), groups = [];
  let spread = 0, spreadCount = 0;
  let animating = false;
  let timer = null;
  let showQueue = [];
  let albumKey = '', defaultTitle = '';
  let data = defaultData();
  let dupInfo = { groups: 0, extra: 0 };
  const filt = { text: '', from: 0, to: 0, favOnly: false, showHidden: false, dupes: 'show' };
  const urls = new Map();           // foto -> objectURL (alleen voor wat in beeld is)
  const thumbUrls = new Map();      // foto-sleutel -> objectURL van kleine voorbeeldafbeelding

  // ---- werkbalk ----
  const bar = h('div', 'alb-bar');
  const pickBtn = mkBtn('📂 Fotomap kiezen', '', 'alb-btn alb-primary');
  const lastBtn = mkBtn('', 'Laatst gebruikte map opnieuw openen'); lastBtn.hidden = true;
  const overviewBtn = mkBtn('▦ Overzicht', 'Alle foto’s en pagina’s in één overzicht');
  const searchBtn = mkBtn('⌕ Zoeken', 'Zoeken en filteren');
  const sortSel = h('select', 'alb-sel'); sortSel.setAttribute('aria-label', 'Volgorde');
  [['date-asc', 'Datum: oud → nieuw'], ['date-desc', 'Datum: nieuw → oud'], ['name', 'Bestandsnaam'], ['manual', 'Eigen volgorde']].forEach(([v, t]) => {
    const o = h('option', '', t); o.value = v; sortSel.append(o);
  });
  const albumBtn = mkBtn('⚙ Album', 'Titel, omslag, papier en dichtheid');
  const printBtn = mkBtn('🖨 Afdrukken / PDF', 'Afdrukken of opslaan als PDF');
  const sep = h('span', 'alb-sep');
  const playBtn = mkBtn('▶ Diashow');
  const secsSel = h('select', 'alb-sel'); secsSel.setAttribute('aria-label', 'Seconden per pagina');
  [3, 5, 8, 12].forEach(s => { const o = h('option', '', s + ' s'); o.value = s; secsSel.append(o); });
  secsSel.value = String(settings.secs);
  const shuffleBtn = mkBtn('🔀', 'Willekeurige volgorde bij de diashow');
  const loopBtn = mkBtn('🔁', 'Diashow herhalen');
  const musicBtn = mkBtn('♫ Muziek', 'Achtergrondmuziek uit de audiospeler aan of uit');
  const fsBtn = mkBtn('⛶ Volledig scherm');
  const dirIn = h('input'); dirIn.type = 'file'; dirIn.multiple = true; dirIn.hidden = true;
  dirIn.setAttribute('webkitdirectory', ''); dirIn.setAttribute('directory', '');
  bar.append(pickBtn, lastBtn, overviewBtn, searchBtn, sortSel, albumBtn, printBtn, sep, playBtn, secsSel, shuffleBtn, loopBtn, musicBtn, fsBtn, dirIn);
  shuffleBtn.classList.toggle('alb-on', settings.shuffle);
  loopBtn.classList.toggle('alb-on', settings.loop);

  // ---- filterpaneel ----
  const fpanel = h('div', 'alb-filter'); fpanel.hidden = true;
  const fText = h('input', 'alb-in'); fText.type = 'search'; fText.placeholder = 'Zoek op naam, map of bijschrift';
  const fFrom = h('input', 'alb-in'); fFrom.type = 'date'; fFrom.title = 'Van';
  const fTo = h('input', 'alb-in'); fTo.type = 'date'; fTo.title = 'Tot';
  const lblDate = h('span', 'alb-lbl', 'Datum');
  const fFav = h('label', 'alb-chk'); const fFavIn = h('input'); fFavIn.type = 'checkbox'; fFav.append(fFavIn, document.createTextNode(' ★ Alleen favorieten'));
  const fHid = h('label', 'alb-chk'); const fHidIn = h('input'); fHidIn.type = 'checkbox'; fHid.append(fHidIn, document.createTextNode(' Verborgen foto’s tonen'));
  const fDup = h('select', 'alb-sel'); fDup.setAttribute('aria-label', 'Dubbels');
  const fClear = mkBtn('Wissen');
  const fCount = h('span', 'alb-fcount');
  fpanel.append(fText, lblDate, fFrom, fTo, fFav, fHid, fDup, fClear, fCount);

  const status = h('div', 'alb-status'); status.setAttribute('role', 'status');

  // ---- boek ----
  const stage = h('div', 'alb-stage');
  const empty = h('div', 'alb-empty');
  empty.append(
    h('div', 'alb-empty-icon', '📖'),
    h('p', 'alb-empty-t', 'Maak een fotoalbum van een map op je computer'),
    h('p', 'alb-empty-s', 'Kies een map (submappen worden meegenomen). De foto’s worden automatisch op pagina’s gezet, per dag of per submap, en je bladert erdoor als in een echt album. Er wordt niets gekopieerd of geüpload.')
  );
  const book = h('div', 'alb-book'); book.hidden = true;
  const slotL = h('div', 'alb-slot alb-slot-l');
  const slotR = h('div', 'alb-slot alb-slot-r');
  const spine = h('div', 'alb-spine');
  book.append(slotL, slotR, spine);
  const prevBtn = h('button', 'alb-nav alb-prev', '‹'); prevBtn.type = 'button'; prevBtn.setAttribute('aria-label', 'Vorige pagina'); prevBtn.hidden = true;
  const nextBtn = h('button', 'alb-nav alb-next', '›'); nextBtn.type = 'button'; nextBtn.setAttribute('aria-label', 'Volgende pagina'); nextBtn.hidden = true;
  stage.append(empty, book, prevBtn, nextBtn);

  const foot = h('div', 'alb-foot'); foot.hidden = true;
  const slider = h('input', 'alb-slider'); slider.type = 'range'; slider.min = 0; slider.max = 0; slider.value = 0; slider.setAttribute('aria-label', 'Naar pagina');
  const pageInfo = h('span', 'alb-pageinfo');
  foot.append(slider, pageInfo);

  root.append(bar, fpanel, status, stage, foot);

  // ---- hulpfuncties ----
  let saveT = null;
  function scheduleSave() {
    if (!albumKey) return;
    clearTimeout(saveT);
    saveT = setTimeout(() => saveData(albumKey, data), 350);
  }
  const photoByKey = key => all.find(p => p.key === key) || null;
  function urlFor(p) {
    let u = urls.get(p);
    if (!u) { u = URL.createObjectURL(p.blob); urls.set(p, u); }
    return u;
  }
  function releaseExcept(keep) {
    for (const [p, u] of urls) {
      if (!keep.has(p)) { try { URL.revokeObjectURL(u); } catch (_) {} urls.delete(p); }
    }
  }
  function spreadPhotos(s) {
    const set = new Set();
    for (const idx of [2 * s - 1, 2 * s]) {
      const pg = pages[idx];
      if (!pg) continue;
      if (pg.kind === 'photos') pg.items.forEach(p => set.add(p));
      else if (pg.kind === 'cover' && pg.cover) set.add(pg.cover);
    }
    return set;
  }
  const spreadOfPage = idx => Math.max(0, Math.ceil(idx / 2));
  function anchorKey() {
    for (const idx of [2 * spread - 1, 2 * spread]) {
      const pg = pages[idx];
      if (pg && pg.kind === 'photos') return pg.items[0].key;
    }
    return '';
  }

  // ---- pagina's tekenen ----
  function makePhotoFig(p, extraCls) {
    const fig = h('figure', 'alb-ph' + (extraCls ? ' ' + extraCls : ''));
    fig.dataset.key = p.key;
    fig.style.setProperty('--r', String(Math.round(p.r * 1000) / 1000));
    fig.classList.toggle('alb-fav', data.fav.has(p.key));
    fig.classList.toggle('alb-dim', data.hidden.has(p.key));
    const img = h('img');
    img.alt = p.name; img.decoding = 'async';
    // exacte verhouding uit de echte foto zodra die geladen is (het voorbeeld waarmee we indelen is maar een schatting)
    img.onload = () => {
      if (img.naturalWidth && img.naturalHeight) {
        p.r = img.naturalWidth / img.naturalHeight;
        fig.style.setProperty('--r', String(p.r));
      }
    };
    img.src = urlFor(p);
    fig.append(img);
    const star = h('button', 'alb-star', '★'); star.type = 'button'; star.title = 'Favoriet';
    star.onclick = e => { e.stopPropagation(); toggleFav(p); };
    fig.append(star);
    const cap = data.captions[p.key];
    if (cap) fig.append(h('div', 'alb-pcap', cap));
    fig.title = cap ? cap : p.name;
    fig.onclick = e => { e.stopPropagation(); openLightbox(p.i); };
    return fig;
  }

  function buildPage(idx) {
    const pg = pages[idx];
    const el = h('div', 'alb-page');
    if (!pg) { el.classList.add('alb-blank'); return el; }
    if (pg.kind === 'cover') {
      el.classList.add('alb-cover', 'alb-cv-' + data.coverColor);
      const frame = h('div', 'alb-cover-frame');
      frame.append(h('div', 'alb-cover-orn', '❦'));
      if (pg.cover) {
        const cell = h('div', 'alb-cover-cell');
        const fig = makePhotoFig(pg.cover, 'alb-cover-ph');
        fig.querySelector('.alb-star')?.remove();
        cell.append(fig);
        frame.append(cell);
      }
      frame.append(h('h2', 'alb-cover-title', pg.title), h('div', 'alb-cover-sub', pg.sub));
      if (pg.range) frame.append(h('div', 'alb-cover-range', pg.range));
      el.append(frame);
      return el;
    }
    if (pg.kind === 'end') {
      el.classList.add('alb-endpage');
      el.append(h('div', 'alb-end-t', 'Einde'), h('div', 'alb-cover-orn', '❦'));
      return el;
    }
    const grid = h('div', 'alb-grid ' + pg.layout);
    pg.items.forEach((p, i) => {
      const cell = h('div', 'alb-cell alb-c' + (i + 1));
      cell.append(makePhotoFig(p));
      grid.append(cell);
    });
    el.append(grid);
    if (pg.caption) el.append(h('div', 'alb-caption', pg.caption));
    el.append(h('div', 'alb-no', String(pg.n)));
    return el;
  }

  function updateChrome() {
    const l = 2 * spread - 1, r = 2 * spread;
    const lastIdx = pages.length - 1;
    const a = Math.max(l, 0), b = Math.min(r, lastIdx);
    pageInfo.textContent = (a === b ? 'Pagina ' + (a + 1) : 'Pagina ' + (a + 1) + '–' + (b + 1)) + ' van ' + pages.length;
    slider.value = spread;
    prevBtn.disabled = spread <= 0;
    nextBtn.disabled = spread >= spreadCount - 1;
  }

  function show(s) {
    spread = Math.max(0, Math.min(spreadCount - 1, s));
    slotL.replaceChildren(buildPage(2 * spread - 1));
    slotR.replaceChildren(buildPage(2 * spread));
    releaseExcept(spreadPhotos(spread));
    updateChrome();
    const k = anchorKey();
    if (k) { data.pos = k; scheduleSave(); }
  }

  // wacht tot de foto's van de nieuwe pagina's geladen zijn, zodat het blad niet leeg omdraait
  function whenReady(...els) {
    const imgs = els.flatMap(e => Array.from(e.querySelectorAll('img')));
    const allP = Promise.all(imgs.map(i => (i.decode ? i.decode().catch(() => {}) : Promise.resolve())));
    return Promise.race([allP, new Promise(r => setTimeout(r, 900))]);
  }

  async function flipTo(target) {
    if (animating || !pages.length) return;
    if (target < 0 || target >= spreadCount || target === spread) { return; }
    const dir = target > spread ? 1 : -1;
    animating = true;
    const newL = buildPage(2 * target - 1), newR = buildPage(2 * target);
    await whenReady(newL, newR);
    const leaf = h('div', 'alb-leaf ' + (dir > 0 ? 'alb-leaf-r' : 'alb-leaf-l'));
    const front = h('div', 'alb-face alb-front'), back = h('div', 'alb-face alb-back');
    const shadeF = h('div', 'alb-shade'), shadeB = h('div', 'alb-shade');
    const castUnder = h('div', 'alb-cast ' + (dir > 0 ? 'alb-cast-r' : 'alb-cast-l'));
    const castLand = h('div', 'alb-cast ' + (dir > 0 ? 'alb-cast-l alb-cast-late' : 'alb-cast-r alb-cast-late'));
    if (dir > 0) {
      front.append(slotR.firstChild, shadeF); back.append(newL, shadeB);
      slotR.replaceChildren(newR);
    } else {
      front.append(slotL.firstChild, shadeF); back.append(newR, shadeB);
      slotL.replaceChildren(newL);
    }
    leaf.append(front, back);
    book.append(castUnder, castLand, leaf);
    void leaf.offsetWidth;
    leaf.classList.add('alb-turning');
    castUnder.classList.add('alb-run'); castLand.classList.add('alb-run');
    let done = false;
    const finish = () => {
      if (done) return; done = true;
      if (dir > 0) slotL.replaceChildren(newL); else slotR.replaceChildren(newR);
      leaf.remove(); castUnder.remove(); castLand.remove();
      spread = target;
      releaseExcept(spreadPhotos(spread));
      updateChrome();
      const k = anchorKey();
      if (k) { data.pos = k; scheduleSave(); }
      animating = false;
    };
    leaf.addEventListener('transitionend', e => { if (e.target === leaf) finish(); });
    setTimeout(finish, FLIP_MS + 200);
  }
  function flip(d) {
    const t = spread + d;
    if (t < 0 || t >= spreadCount) { stopShow(); return; }
    flipTo(t);
  }

  // ---- diashow ----
  function shuffledSpreads() {
    const a = [];
    for (let i = 0; i < spreadCount; i++) if (i !== spread) a.push(i);
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }
  function tick() {
    if (!root.isConnected) return stopShow();
    if (animating) return;
    if (settings.shuffle) {
      if (!showQueue.length) { if (!settings.loop) return stopShow(); showQueue = shuffledSpreads(); }
      if (!showQueue.length) return stopShow();
      flipTo(showQueue.pop());
    } else {
      if (spread >= spreadCount - 1) { if (settings.loop && spreadCount > 1) return flipTo(0); return stopShow(); }
      flipTo(spread + 1);
    }
  }
  function startShow() {
    if (!pages.length) return;
    stopShow();
    if (!settings.shuffle && spread >= spreadCount - 1 && !settings.loop) show(0);
    showQueue = settings.shuffle ? shuffledSpreads() : [];
    playBtn.textContent = '⏸ Pauze';
    playBtn.classList.add('alb-on');
    timer = setInterval(tick, Number(secsSel.value) * 1000);
  }
  function stopShow() {
    if (timer) clearInterval(timer);
    timer = null;
    playBtn.textContent = '▶ Diashow';
    playBtn.classList.remove('alb-on');
  }

  // ---- foto's markeren: favoriet, verbergen, bijschrift ----
  function refreshMarks() {
    document.querySelectorAll('.alb-ph[data-key], .alb-th[data-key]').forEach(el => {
      el.classList.toggle('alb-fav', data.fav.has(el.dataset.key));
      el.classList.toggle('alb-dim', data.hidden.has(el.dataset.key));
    });
    if (!lb.hidden && photos[lbIndex]) lbUpdateButtons();
  }
  function toggleFav(p) {
    if (data.fav.has(p.key)) data.fav.delete(p.key); else data.fav.add(p.key);
    scheduleSave();
    if (filt.favOnly) { applyChange(); return; }
    refreshMarks();
  }
  function toggleHide(p) {
    if (data.hidden.has(p.key)) data.hidden.delete(p.key); else data.hidden.add(p.key);
    scheduleSave();
    applyChange();
  }
  function setCaption(p, text) {
    text = (text || '').trim();
    if (text) data.captions[p.key] = text; else delete data.captions[p.key];
    scheduleSave();
    if (!animating) show(spread);
    if (filt.text) applyChange();
    if (!ov.hidden) renderOverview();
  }
  function setCover(p) {
    data.cover = p ? p.key : '';
    scheduleSave();
    applyChange();
  }

  // ---- filteren en sorteren ----
  function sortedAll() {
    const mode = data.sort;
    const list = all.slice();
    if (mode === 'manual') {
      const pos = new Map(data.order.map((k, i) => [k, i]));
      const byDate = (a, b) => (a.date || 0) - (b.date || 0) || natural.compare(a.key, b.key);
      list.sort((a, b) => {
        const ia = pos.has(a.key) ? pos.get(a.key) : Infinity, ib = pos.has(b.key) ? pos.get(b.key) : Infinity;
        if (ia === ib) return byDate(a, b);
        return ia - ib;
      });
    } else if (mode === 'name') {
      list.sort((a, b) => natural.compare(a.dir, b.dir) || natural.compare(a.name, b.name));
    } else {
      list.sort((a, b) => {
        const d = (a.date || 0) - (b.date || 0);
        const r = mode === 'date-desc' ? -d : d;
        return r || natural.compare(a.key, b.key);
      });
    }
    return list;
  }
  function computeVisible() {
    let list = sortedAll();
    const q = filt.text.trim().toLowerCase();
    list = list.filter(p => {
      if (!filt.showHidden && data.hidden.has(p.key)) return false;
      if (filt.favOnly && !data.fav.has(p.key)) return false;
      if (q && !(p.key.toLowerCase().includes(q) || (data.captions[p.key] || '').toLowerCase().includes(q))) return false;
      if (filt.from && p.date < filt.from) return false;
      if (filt.to && p.date > filt.to) return false;
      return true;
    });
    if (filt.dupes === 'hide') {
      const seen = new Set();
      list = list.filter(p => {
        if (p.dupGroup == null) return true;
        if (seen.has(p.dupGroup)) return false;
        seen.add(p.dupGroup); return true;
      });
    } else if (filt.dupes === 'only') {
      list = list.filter(p => p.dupGroup != null);
      const order = [], byGroup = new Map();
      list.forEach(p => { if (!byGroup.has(p.dupGroup)) { byGroup.set(p.dupGroup, []); order.push(p.dupGroup); } byGroup.get(p.dupGroup).push(p); });
      list = order.flatMap(g => byGroup.get(g));
    }
    return list;
  }

  function rebuild(keepPos) {
    stopShow();
    const anchor = keepPos ? (anchorKey() || data.pos) : data.pos;
    photos = computeVisible();
    photos.forEach((p, i) => { p.i = i; });
    const dens = DENSITY[data.density] || DENSITY.normaal;
    const coverP = data.cover ? photoByKey(data.cover) : null;
    ({ pages, pageOf, groups } = buildPages(photos, data.title || defaultTitle || 'Mijn fotoalbum', dens, coverP));
    spreadCount = Math.ceil((pages.length + 1) / 2);
    slider.max = String(spreadCount - 1);
    book.dataset.paper = data.paper;
    const target = anchor && pageOf.has(anchor) ? spreadOfPage(pageOf.get(anchor)) : (keepPos ? Math.min(spread, spreadCount - 1) : 0);
    show(target);
    empty.hidden = true; book.hidden = false; foot.hidden = false;
    prevBtn.hidden = nextBtn.hidden = false;
    updateCount();
  }
  function applyChange() {
    rebuild(true);
    if (!ov.hidden) renderOverview();
    if (!lb.hidden) {
      if (!photos.length) closeLightbox();
      else if (lbKey) {
        const i = photos.findIndex(x => x.key === lbKey);
        if (i >= 0) { lbIndex = i; lbUpdateButtons(); } else openLightbox(Math.min(lbIndex, photos.length - 1));
      }
    }
  }
  function updateCount() {
    const hid = data.hidden.size;
    fCount.textContent = photos.length + ' van ' + all.length + ' foto’s' + (hid ? ' · ' + hid + ' verborgen' : '');
    const dupLabels = { show: 'Dubbels: gewoon tonen', hide: 'Dubbels: verbergen', only: 'Dubbels: alleen tonen' };
    [...fDup.options].forEach(o => { o.textContent = dupLabels[o.value] + (o.value !== 'show' && dupInfo.extra ? ' (' + dupInfo.extra + ')' : ''); });
    if (!photos.length) status.textContent = 'Geen foto’s die aan je filter voldoen.';
    else {
      status.textContent = photos.length + (photos.length === all.length ? ' foto’s' : ' van ' + all.length + ' foto’s')
        + (dupInfo.extra ? ' · ' + dupInfo.extra + ' mogelijke dubbels' : '')
        + (skippedNote ? ' · ' + skippedNote : '');
    }
    searchBtn.classList.toggle('alb-on', !!(filt.text || filt.from || filt.to || filt.favOnly || filt.showHidden || filt.dupes !== 'show'));
  }
  let skippedNote = '';

  // ---- lightbox met zoomen ----
  const lb = h('div', 'alb-lb'); lb.hidden = true;
  const lbTop = h('div', 'alb-lb-top');
  const lbInfo = h('div', 'alb-lb-info');
  const lbFav = mkBtn('☆', 'Favoriet (F)', 'alb-lbtn');
  const lbHide = mkBtn('🙈', 'Verbergen uit het album', 'alb-lbtn');
  const lbCover = mkBtn('🖼', 'Als omslagfoto gebruiken', 'alb-lbtn');
  const lbZoomOut = mkBtn('−', 'Uitzoomen (-)', 'alb-lbtn');
  const lbZoomIn = mkBtn('+', 'Inzoomen (+)', 'alb-lbtn');
  const lbActual = mkBtn('1:1', 'Op ware grootte (dubbelklik)', 'alb-lbtn');
  const lbFit = mkBtn('Passen', 'Volledig in beeld (0)', 'alb-lbtn');
  const lbClose = mkBtn('×', 'Sluiten (Esc)', 'alb-lbtn alb-lb-x');
  lbTop.append(lbInfo, lbFav, lbHide, lbCover, lbZoomOut, lbZoomIn, lbActual, lbFit, lbClose);
  const lbStage = h('div', 'alb-lb-stage');
  const lbImg = h('img', 'alb-lb-img'); lbImg.alt = ''; lbImg.draggable = false;
  lbStage.append(lbImg);
  const lbPrev = h('button', 'alb-lb-nav alb-lb-prev', '‹'); lbPrev.type = 'button';
  const lbNext = h('button', 'alb-lb-nav alb-lb-next', '›'); lbNext.type = 'button';
  const lbBottom = h('div', 'alb-lb-bottom');
  const lbCap = h('input', 'alb-lb-cap'); lbCap.type = 'text'; lbCap.placeholder = 'Bijschrift toevoegen…'; lbCap.setAttribute('aria-label', 'Bijschrift');
  const lbMeta = h('div', 'alb-lb-meta');
  lbBottom.append(lbCap, lbMeta);
  lb.append(lbTop, lbStage, lbPrev, lbNext, lbBottom);
  let lbIndex = -1, lbUrl = null, lbKey = '';
  const Z = { s: 1, x: 0, y: 0 };
  function applyZoom() {
    const iw = lbImg.offsetWidth, ih = lbImg.offsetHeight;
    const mx = Math.max(0, (iw * Z.s - lbStage.clientWidth) / 2), my = Math.max(0, (ih * Z.s - lbStage.clientHeight) / 2);
    Z.x = Math.max(-mx, Math.min(mx, Z.x)); Z.y = Math.max(-my, Math.min(my, Z.y));
    if (mx === 0) Z.x = 0; if (my === 0) Z.y = 0;
    lbImg.style.transform = 'translate(' + Z.x + 'px,' + Z.y + 'px) scale(' + Z.s + ')';
    lbStage.classList.toggle('alb-zoomed', Z.s > 1.001);
  }
  function zoomAt(ns, cx, cy) {   // cx, cy: punt relatief aan het midden van het podium
    ns = Math.max(1, Math.min(14, ns));
    Z.x = cx - (cx - Z.x) * (ns / Z.s);
    Z.y = cy - (cy - Z.y) * (ns / Z.s);
    Z.s = ns;
    if (ns === 1) { Z.x = 0; Z.y = 0; }
    applyZoom();
  }
  const stageCenterRel = e => {
    const r = lbStage.getBoundingClientRect();
    return [e.clientX - (r.left + r.width / 2), e.clientY - (r.top + r.height / 2)];
  };
  const resetZoom = () => { Z.s = 1; Z.x = 0; Z.y = 0; applyZoom(); };
  const actualScale = () => Math.max(1, lbImg.naturalWidth / Math.max(1, lbImg.offsetWidth));
  lbStage.addEventListener('wheel', e => {
    e.preventDefault();
    const [cx, cy] = stageCenterRel(e);
    zoomAt(Z.s * Math.exp(-e.deltaY * 0.0018), cx, cy);
  }, { passive: false });
  lbStage.addEventListener('dblclick', e => {
    const [cx, cy] = stageCenterRel(e);
    if (Z.s > 1.01) resetZoom(); else zoomAt(Math.max(actualScale(), 2.5), cx, cy);
  });
  const ptrs = new Map();
  let pinch0 = 0, pinchS = 1, swipe = null;
  lbStage.addEventListener('pointerdown', e => {
    if (e.button > 0) return;
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    lbStage.setPointerCapture(e.pointerId);
    if (ptrs.size === 2) {
      const [a, b] = [...ptrs.values()];
      pinch0 = Math.hypot(a.x - b.x, a.y - b.y); pinchS = Z.s; swipe = null;
    } else swipe = { x: e.clientX, y: e.clientY, t: Date.now() };
  });
  lbStage.addEventListener('pointermove', e => {
    const p = ptrs.get(e.pointerId);
    if (!p) return;
    if (ptrs.size === 2) {
      p.x = e.clientX; p.y = e.clientY;
      const [a, b] = [...ptrs.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      const r = lbStage.getBoundingClientRect();
      zoomAt(pinchS * (d / (pinch0 || 1)), (a.x + b.x) / 2 - (r.left + r.width / 2), (a.y + b.y) / 2 - (r.top + r.height / 2));
    } else if (Z.s > 1.001) {
      Z.x += e.clientX - p.x; Z.y += e.clientY - p.y;
      p.x = e.clientX; p.y = e.clientY;
      applyZoom();
    }
  });
  const endPtr = e => {
    const had = ptrs.delete(e.pointerId);
    if (had && swipe && Z.s <= 1.001 && e.pointerType !== 'mouse') {
      const dx = e.clientX - swipe.x, dy = e.clientY - swipe.y;
      if (Math.abs(dx) > 60 && Math.abs(dy) < 80) lbStep(dx < 0 ? 1 : -1);
    }
    swipe = null;
  };
  lbStage.addEventListener('pointerup', endPtr);
  lbStage.addEventListener('pointercancel', endPtr);
  lbStage.onclick = e => { if (e.target === lbStage && Z.s <= 1.001) closeLightbox(); };

  function lbUpdateButtons() {
    const p = photos[lbIndex];
    if (!p) return;
    lbFav.textContent = data.fav.has(p.key) ? '★' : '☆';
    lbFav.classList.toggle('alb-on', data.fav.has(p.key));
    lbHide.textContent = data.hidden.has(p.key) ? '👁' : '🙈';
    lbHide.title = data.hidden.has(p.key) ? 'Weer tonen in het album' : 'Verbergen uit het album';
    lbCover.classList.toggle('alb-on', data.cover === p.key);
    lbCover.title = data.cover === p.key ? 'Omslagfoto verwijderen' : 'Als omslagfoto gebruiken';
  }
  function openLightbox(i) {
    const p = photos[i];
    if (!p) return;
    stopShow();
    lbIndex = i; lbKey = p.key;
    if (lbUrl) URL.revokeObjectURL(lbUrl);
    lbUrl = URL.createObjectURL(p.blob);
    lbImg.onload = () => { lbMeta.textContent = p.name + '  ·  ' + lbImg.naturalWidth + ' × ' + lbImg.naturalHeight + (p.date ? '  ·  ' + dateFmt.format(p.date) : '') + '  ·  ' + (i + 1) + ' / ' + photos.length + (p.dupGroup != null ? '  ·  mogelijke dubbel' : ''); applyZoom(); };
    lbImg.src = lbUrl;
    lbInfo.textContent = p.key;
    lbCap.value = data.captions[p.key] || '';
    resetZoom();
    lbUpdateButtons();
    if (!lb.isConnected) document.body.append(lb);
    lb.hidden = false;
  }
  function closeLightbox() {
    lb.hidden = true; lbImg.removeAttribute('src'); lb.remove();
    if (lbUrl) { URL.revokeObjectURL(lbUrl); lbUrl = null; }
    lbIndex = -1; lbKey = '';
  }
  function lbStep(d) { if (lbIndex >= 0 && photos.length) openLightbox((lbIndex + d + photos.length) % photos.length); }
  lbClose.onclick = closeLightbox;
  lbPrev.onclick = () => lbStep(-1);
  lbNext.onclick = () => lbStep(1);
  lbFav.onclick = () => { const p = photos[lbIndex]; if (p) toggleFav(p); };
  lbHide.onclick = () => { const p = photos[lbIndex]; if (p) toggleHide(p); };
  lbCover.onclick = () => { const p = photos[lbIndex]; if (p) setCover(data.cover === p.key ? null : p); };
  lbZoomIn.onclick = () => zoomAt(Z.s * 1.5, 0, 0);
  lbZoomOut.onclick = () => zoomAt(Z.s / 1.5, 0, 0);
  lbActual.onclick = () => zoomAt(actualScale(), 0, 0);
  lbFit.onclick = resetZoom;
  lbCap.onchange = () => { const p = photos[lbIndex]; if (p) setCaption(p, lbCap.value); };
  lbCap.onkeydown = e => { e.stopPropagation(); if (e.key === 'Enter') { lbCap.blur(); } if (e.key === 'Escape') { lbCap.blur(); } };
  lb.onclick = e => { if (e.target === lb) closeLightbox(); };

  // ---- overzicht van alle foto's (en volgorde aanpassen) ----
  const ov = h('div', 'alb-ov'); ov.hidden = true;
  const ovHead = h('div', 'alb-ov-head');
  const ovTitle = h('div', 'alb-ov-title');
  const ovHint = h('div', 'alb-ov-hint', 'Klik op een foto om naar haar pagina te gaan. Sleep foto’s om je eigen volgorde te maken.');
  const ovClose = mkBtn('×', 'Sluiten (Esc)', 'alb-lbtn alb-lb-x');
  ovHead.append(ovTitle, ovHint, ovClose);
  const ovBody = h('div', 'alb-ov-body');
  const ovNav = h('nav', 'alb-ov-nav');
  const ovMain = h('div', 'alb-ov-main');
  ovBody.append(ovNav, ovMain);
  ov.append(ovHead, ovBody);
  let ovObserver = null;

  const thumbQueue = []; let thumbRunning = 0;
  function getThumb(p) {
    return new Promise(resolve => {
      if (thumbUrls.has(p.key)) return resolve(thumbUrls.get(p.key));
      thumbQueue.push({ p, resolve }); pumpThumbs();
    });
  }
  function pumpThumbs() {
    while (thumbRunning < 4 && thumbQueue.length) {
      const t = thumbQueue.shift(); thumbRunning++;
      makeThumb(t.p).then(u => t.resolve(u)).finally(() => { thumbRunning--; pumpThumbs(); });
    }
  }
  async function makeThumb(p) {
    try {
      const bmp = await createImageBitmap(p.blob, p.r >= 1 ? { resizeWidth: 220 } : { resizeHeight: 220 });
      const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height;
      const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(bmp, 0, 0);
      bmp.close && bmp.close();
      const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.72));
      const u = URL.createObjectURL(blob);
      thumbUrls.set(p.key, u);
      return u;
    } catch (_) { return null; }
  }

  function renderOverview() {
    const top = ovMain.scrollTop;
    if (ovObserver) ovObserver.disconnect();
    ovObserver = new IntersectionObserver(entries => {
      for (const en of entries) {
        if (!en.isIntersecting) continue;
        ovObserver.unobserve(en.target);
        const p = photos[Number(en.target.dataset.i)];
        if (!p) continue;
        getThumb(p).then(u => {
          if (!u) return;
          const img = h('img'); img.src = u; img.alt = p.name; img.draggable = false;
          en.target.querySelector('.alb-th-img').replaceChildren(img);
        });
      }
    }, { root: ovMain, rootMargin: '400px' });
    ovMain.replaceChildren(); ovNav.replaceChildren();
    ovTitle.textContent = 'Overzicht · ' + photos.length + ' foto’s · ' + (pages.length) + ' pagina’s';
    let dragKey = '';
    for (const g of groups) {
      const sec = h('section', 'alb-ov-sec');
      const head = h('h3', 'alb-ov-h', g.label || 'Zonder datum');
      head.append(h('span', 'alb-ov-n', ' · ' + g.items.length));
      sec.append(head);
      const grid = h('div', 'alb-ov-grid');
      for (const p of g.items) {
        const th = h('div', 'alb-th'); th.dataset.key = p.key; th.dataset.i = String(p.i);
        th.draggable = true;
        th.classList.toggle('alb-fav', data.fav.has(p.key));
        th.classList.toggle('alb-dim', data.hidden.has(p.key));
        th.title = p.key + (data.captions[p.key] ? ' — ' + data.captions[p.key] : '');
        th.append(h('div', 'alb-th-img'));
        const pg = pageOf.get(p.key);
        th.append(h('span', 'alb-th-pg', 'blz ' + ((pg || 0) + 1)));
        const st = h('button', 'alb-th-star', '★'); st.type = 'button'; st.title = 'Favoriet';
        st.onclick = e => { e.stopPropagation(); toggleFav(p); };
        th.append(st);
        th.onclick = () => { closeOverview(); stopShow(); show(spreadOfPage(pageOf.get(p.key) || 0)); };
        th.ondragstart = e => { dragKey = p.key; e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', p.key); } catch (_) {} th.classList.add('alb-dragging'); };
        th.ondragend = () => { th.classList.remove('alb-dragging'); ovMain.querySelectorAll('.alb-drop').forEach(x => x.classList.remove('alb-drop')); };
        th.ondragover = e => { if (dragKey && dragKey !== p.key) { e.preventDefault(); th.classList.add('alb-drop'); } };
        th.ondragleave = () => th.classList.remove('alb-drop');
        th.ondrop = e => { e.preventDefault(); const src = dragKey; dragKey = ''; if (src && src !== p.key) moveBefore(src, p.key); };
        grid.append(th);
        ovObserver.observe(th);
      }
      sec.append(grid);
      ovMain.append(sec);
      const nb = h('button', 'alb-ov-navbtn'); nb.type = 'button';
      nb.append(h('span', '', g.label || 'Zonder datum'), h('small', '', String(g.items.length)));
      nb.onclick = () => sec.scrollIntoView({ block: 'start' });
      ovNav.append(nb);
    }
    ovMain.scrollTop = top;
  }
  function moveBefore(srcKey, dstKey) {
    if (data.sort !== 'manual') { data.order = sortedAll().map(p => p.key); data.sort = 'manual'; sortSel.value = 'manual'; }
    const o = data.order;
    const si = o.indexOf(srcKey); if (si < 0) return;
    o.splice(si, 1);
    const di = o.indexOf(dstKey);
    if (di < 0) o.push(srcKey); else o.splice(di, 0, srcKey);
    scheduleSave();
    applyChange();
  }
  function openOverview() {
    if (!photos.length) return;
    stopShow();
    if (!ov.isConnected) document.body.append(ov);
    ov.hidden = false;
    renderOverview();
    const k = anchorKey();
    if (k) { const el = ovMain.querySelector('.alb-th[data-key="' + CSS.escape(k) + '"]'); if (el) el.scrollIntoView({ block: 'center' }); }
  }
  function closeOverview() {
    ov.hidden = true; ov.remove();
    if (ovObserver) ovObserver.disconnect();
  }
  ovClose.onclick = closeOverview;

  // ---- dialoog: album-instellingen ----
  function openModal(title, buildBody) {
    const back = h('div', 'alb-modal-back');
    const box = h('div', 'alb-modal');
    const head = h('div', 'alb-modal-head');
    head.append(h('div', 'alb-modal-title', title));
    const x = mkBtn('×', 'Sluiten', 'alb-lbtn alb-lb-x');
    head.append(x);
    const body = h('div', 'alb-modal-body');
    box.append(head, body);
    back.append(box);
    document.body.append(back);
    const close = () => back.remove();
    x.onclick = close;
    back.onclick = e => { if (e.target === back) close(); };
    back.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
    buildBody(body, close);
    return close;
  }
  function field(label, control) {
    const row = h('label', 'alb-field'); row.append(h('span', 'alb-field-l', label), control); return row;
  }
  function openAlbumDialog() {
    if (!all.length) { status.textContent = 'Kies eerst een fotomap.'; return; }
    openModal('Album instellen', body => {
      const title = h('input', 'alb-in alb-wide'); title.type = 'text'; title.value = data.title; title.placeholder = defaultTitle || 'Mijn fotoalbum';
      title.onchange = () => { data.title = title.value.trim(); scheduleSave(); applyChange(); };
      body.append(field('Titel', title));

      const sw = h('div', 'alb-swatches');
      COVER_COLORS.forEach(([id, label]) => {
        const b = h('button', 'alb-sw alb-cv-' + id); b.type = 'button'; b.title = label; b.setAttribute('aria-label', label);
        b.classList.toggle('alb-sel', data.coverColor === id);
        b.onclick = () => { data.coverColor = id; scheduleSave(); sw.querySelectorAll('.alb-sw').forEach(x => x.classList.remove('alb-sel')); b.classList.add('alb-sel'); applyChange(); };
        sw.append(b);
      });
      body.append(field('Omslagkleur', sw));

      const paper = h('select', 'alb-sel');
      PAPERS.forEach(([v, t]) => { const o = h('option', '', t); o.value = v; paper.append(o); });
      paper.value = data.paper;
      paper.onchange = () => { data.paper = paper.value; scheduleSave(); applyChange(); };
      body.append(field('Papier', paper));

      const dens = h('select', 'alb-sel');
      [['ruim', 'Ruim — 1 tot 2 foto’s per pagina'], ['normaal', 'Normaal — tot 4 foto’s per pagina'], ['compact', 'Compact — tot 5 foto’s per pagina']].forEach(([v, t]) => { const o = h('option', '', t); o.value = v; dens.append(o); });
      dens.value = data.density;
      dens.onchange = () => { data.density = dens.value; scheduleSave(); applyChange(); };
      body.append(field('Dichtheid', dens));

      const cov = h('div', 'alb-field-row');
      const coverP = data.cover ? photoByKey(data.cover) : null;
      cov.append(h('span', 'alb-muted', coverP ? coverP.key : 'Geen. Open een foto groot en klik op 🖼 om ze als omslag te gebruiken.'));
      if (coverP) { const rm = mkBtn('Verwijderen'); rm.onclick = () => { setCover(null); cov.firstChild.textContent = 'Geen.'; rm.remove(); }; cov.append(rm); }
      body.append(field('Omslagfoto', cov));

      const info = h('p', 'alb-muted alb-note');
      info.textContent = 'Deze keuzes, je favorieten, bijschriften, verborgen foto’s, eigen volgorde en je leesplaats worden onthouden voor de map “' + (albumKey || '') + '”. Je foto’s zelf blijven onaangeroerd.';
      body.append(info);
      const reset = mkBtn('Alles voor dit album wissen', 'Wist favorieten, bijschriften, verborgen foto’s, volgorde en instellingen van dit album');
      reset.onclick = () => {
        if (!confirm('Alle persoonlijke instellingen van dit album wissen? Je foto’s blijven onaangeroerd.')) return;
        data = defaultData(); saveData(albumKey, data); sortSel.value = data.sort; applyChange();
        document.querySelector('.alb-modal-back')?.remove();
      };
      body.append(reset);
    });
  }

  // ---- afdrukken / PDF ----
  // Elke albumpagina wordt met dezelfde indeling als op het scherm op een canvas getekend, in een PDF gezet
  // en daarna aan het eigen afdrukvenster van Leo Crucis gegeven (voorbeeld, printerkeuze, afdrukken).
  function openPrintDialog() {
    if (!pages.length) { status.textContent = 'Kies eerst een fotomap.'; return; }
    openModal('Afdrukken of opslaan als PDF', (body, close) => {
      const total = pages.length;
      body.append(h('p', 'alb-muted', 'Je album heeft ' + total + ' pagina’s. Kies welke je wilt afdrukken (maximaal ' + PRINT_MAX + ' tegelijk). Daarna opent het afdrukvenster van Leo Crucis met een voorbeeld, waar je een printer kiest of de PDF bewaart.'));
      const from = h('input', 'alb-in'); from.type = 'number'; from.min = 1; from.max = total; from.value = String(Math.max(1, 2 * spread));
      const to = h('input', 'alb-in'); to.type = 'number'; to.min = 1; to.max = total; to.value = String(Math.min(total, 2 * spread + 9));
      const row = h('div', 'alb-field-row'); row.append(from, h('span', '', ' tot '), to);
      body.append(field('Pagina’s', row));
      const go = mkBtn('🖨 Voorbeeld en afdrukken', '', 'alb-btn alb-primary');
      const note = h('p', 'alb-muted alb-note');
      go.onclick = async () => {
        let a = Math.max(1, Math.min(total, parseInt(from.value, 10) || 1)), b = Math.max(a, Math.min(total, parseInt(to.value, 10) || a));
        if (b - a + 1 > PRINT_MAX) { b = a + PRINT_MAX - 1; }
        close();
        await printPages(a - 1, b - 1);
      };
      body.append(go, note);
    });
  }

  const cssColor = (el, prop) => getComputedStyle(el)[prop];
  function wrapLines(ctx, text, maxW) {
    const words = text.split(/\s+/), lines = [];
    let cur = '';
    for (const w of words) {
      const t = cur ? cur + ' ' + w : w;
      if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t;
    }
    if (cur) lines.push(cur);
    return lines;
  }
  function drawText(ctx, el, pr, k) {
    const cs = getComputedStyle(el);
    let text = el.textContent || '';
    if (!text.trim()) return;
    if (cs.textTransform === 'capitalize') text = text.replace(/\b\p{L}/gu, c => c.toUpperCase());
    const r = el.getBoundingClientRect();
    const fs = parseFloat(cs.fontSize) * k;
    ctx.font = (cs.fontStyle !== 'normal' ? cs.fontStyle + ' ' : '') + cs.fontWeight + ' ' + fs + 'px ' + cs.fontFamily;
    ctx.fillStyle = cs.color;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const cx = (r.left - pr.left + r.width / 2) * k, cy = (r.top - pr.top + r.height / 2) * k;
    const maxW = Math.max(r.width * k, 10);
    const oneLine = cs.whiteSpace === 'nowrap';
    const lines = oneLine ? [text] : wrapLines(ctx, text, maxW);
    const lh = fs * 1.2;
    lines.forEach((ln, i) => ctx.fillText(ln, cx, cy + (i - (lines.length - 1) / 2) * lh, oneLine ? maxW * 1.04 : undefined));
  }
  async function renderPageCanvas(idx, W) {
    const H = Math.round(W * 4 / 3), k = W / 600;
    const host = h('div', 'alb-render'); host.dataset.paper = data.paper;
    host.style.cssText = 'position:fixed;left:-20000px;top:0;width:600px;height:800px;pointer-events:none';
    const el = buildPage(idx);
    host.append(el); document.body.append(host);
    host.querySelectorAll('img').forEach(i => i.removeAttribute('src'));   // alleen de indeling is nodig
    await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const ctx = c.getContext('2d');
    const pr = el.getBoundingClientRect();
    // achtergrond
    if (el.classList.contains('alb-cover') || el.classList.contains('alb-blank')) {
      const cols = (getComputedStyle(el).backgroundImage.match(/rgba?\([^)]+\)|#[0-9a-f]{3,8}/gi) || ['#5a3e2b', '#3a281c']);
      const g = ctx.createLinearGradient(0, 0, W, H);
      g.addColorStop(0, cols[0]); g.addColorStop(1, cols[cols.length - 1]);
      ctx.fillStyle = g;
    } else ctx.fillStyle = getComputedStyle(el).backgroundColor || '#f7f0e2';
    ctx.fillRect(0, 0, W, H);
    // omslagkader
    const frame = el.querySelector('.alb-cover-frame');
    if (frame) {
      const f = frame.getBoundingClientRect();
      ctx.strokeStyle = 'rgba(230,199,106,.75)'; ctx.lineWidth = 2 * k;
      ctx.strokeRect((f.left - pr.left) * k, (f.top - pr.top) * k, f.width * k, f.height * k);
      ctx.strokeStyle = 'rgba(230,199,106,.35)'; ctx.lineWidth = 1 * k;
      ctx.strokeRect((f.left - pr.left - 5) * k, (f.top - pr.top - 5) * k, (f.width + 10) * k, (f.height + 10) * k);
    }
    // foto's (met wit randje en schaduw), in hun eigen verhouding
    for (const fig of el.querySelectorAll('.alb-ph')) {
      const p = photoByKey(fig.dataset.key);
      if (!p) continue;
      const r = fig.getBoundingClientRect();
      const x = (r.left - pr.left) * k, y = (r.top - pr.top) * k, w = r.width * k, hh = r.height * k;
      const ring = 5 * k;
      ctx.save();
      ctx.shadowColor = 'rgba(40,25,10,.38)'; ctx.shadowBlur = 7 * k; ctx.shadowOffsetY = 2 * k;
      ctx.fillStyle = '#fff'; ctx.fillRect(x - ring, y - ring, w + 2 * ring, hh + 2 * ring);
      ctx.restore();
      let bmp = null;
      try { bmp = await createImageBitmap(p.blob, { resizeWidth: Math.max(8, Math.ceil(w)), resizeQuality: 'high' }); }
      catch (_) { try { bmp = await createImageBitmap(p.blob); } catch (e) { bmp = null; } }
      if (bmp) {
        const sc = Math.min(w / bmp.width, hh / bmp.height);
        const dw = bmp.width * sc, dh = bmp.height * sc;
        ctx.drawImage(bmp, x + (w - dw) / 2, y + (hh - dh) / 2, dw, dh);
        bmp.close && bmp.close();
      } else { ctx.fillStyle = '#ddd'; ctx.fillRect(x, y, w, hh); }
    }
    // teksten
    el.querySelectorAll('.alb-cover-orn,.alb-cover-title,.alb-cover-sub,.alb-cover-range,.alb-caption,.alb-pcap,.alb-no,.alb-end-t').forEach(t => drawText(ctx, t, pr, k));
    host.remove();
    return c;
  }

  async function printPages(a, b) {
    const n = b - a + 1;
    try {
      status.textContent = 'Afdruk wordt voorbereid… 0 / ' + n;
      const imgs = [];
      for (let i = a; i <= b; i++) {
        const canvas = await renderPageCanvas(i, 1100);
        const blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', 0.88));
        imgs.push({ bytes: new Uint8Array(await blob.arrayBuffer()), w: canvas.width, h: canvas.height });
        status.textContent = 'Afdruk wordt voorbereid… ' + (i - a + 1) + ' / ' + n;
        await new Promise(r => setTimeout(r, 0));
      }
      const b64 = bytesToBase64(makePdf(imgs));
      const title = (data.title || defaultTitle || 'Fotoalbum');
      status.textContent = '';
      updateCount();
      await openPdfPrintPreview(title, 'data:application/pdf;base64,' + b64, slugName(title) + '.pdf');
    } catch (e) {
      console.error(e);
      status.textContent = 'Afdrukken voorbereiden mislukt: ' + (e.message || e);
    }
  }

  // ---- album opbouwen ----
  async function loadAlbum(result, title) {
    const list = result.files;
    if (!list.length) {
      status.textContent = 'Geen foto’s gevonden in deze map.' + (result.skipped ? ' (' + result.skipped + ' HEIC/RAW-bestanden kunnen niet getoond worden.)' : '');
      return;
    }
    stopShow(); closeLightbox(); closeOverview();
    const loaded = [];
    let done = 0, next = 0;
    const total = list.length;
    status.textContent = 'Album wordt gemaakt… 0 / ' + total;
    const worker = async () => {
      while (next < total) {
        const it = list[next++];
        try {
          const f = await it.getFile();
          const dim = await measure(f);
          let date = 0;
          if (/\.jpe?g$/i.test(it.name)) { try { date = exifDate(await f.slice(0, 70000).arrayBuffer()); } catch (_) {} }
          if (dim) loaded.push({
            blob: f, name: it.name, dir: it.dir || '', key: (it.dir ? it.dir + '/' : '') + it.name,
            date: date || f.lastModified || 0, o: dim.w >= dim.h * 0.95 ? 'L' : 'P', r: dim.w / dim.h, hash: dim.hash, i: 0, dupGroup: null
          });
        } catch (e) { console.warn('Foto overgeslagen', it.name, e); }
        done++;
        if (done % 10 === 0 || done === total) status.textContent = 'Album wordt gemaakt… ' + done + ' / ' + total;
      }
    };
    await Promise.all(Array.from({ length: Math.min(6, total) }, worker));
    for (const [, u] of urls) { try { URL.revokeObjectURL(u); } catch (_) {} }
    urls.clear();
    for (const [, u] of thumbUrls) { try { URL.revokeObjectURL(u); } catch (_) {} }
    thumbUrls.clear();
    all = loaded;
    if (!all.length) { status.textContent = 'Geen leesbare foto’s gevonden.'; return; }
    status.textContent = 'Dubbels zoeken…';
    await new Promise(r => setTimeout(r, 0));
    dupInfo = findDupes(all);
    defaultTitle = title || 'Mijn fotoalbum';
    albumKey = defaultTitle;
    data = loadData(albumKey);
    sortSel.value = data.sort;
    Object.assign(filt, { text: '', from: 0, to: 0, favOnly: false, showHidden: false, dupes: 'show' });
    fText.value = ''; fFrom.value = ''; fTo.value = ''; fFavIn.checked = false; fHidIn.checked = false; fDup.value = 'show';
    const skipped = (result.skipped || 0) + (total - all.length);
    skippedNote = skipped ? skipped + ' overgeslagen (niet-ondersteund formaat)' : '';
    rebuild(false);
    root.focus({ preventScroll: true });
  }

  // ---- map kiezen ----
  async function pickFolder() {
    if (window.showDirectoryPicker) {
      try {
        const dir = await window.showDirectoryPicker({ id: 'lc-fotoalbum', mode: 'read' });
        status.textContent = 'Map wordt gelezen…';
        const out = { files: [], skipped: 0 };
        await walkHandle(dir, '', out);
        saveHandle(dir);
        showLastBtn(dir);
        await loadAlbum(out, dir.name);
        return;
      } catch (e) {
        if (e && e.name === 'AbortError') { status.textContent = ''; return; }
        console.warn('showDirectoryPicker mislukt, terugval op invoerveld', e);
      }
    }
    dirIn.click();
  }
  dirIn.onchange = async () => {
    const res = filesFromInput(Array.from(dirIn.files || []));
    dirIn.value = '';
    await loadAlbum(res, res.rootName);
  };
  async function openLast(dir) {
    try {
      let perm = await dir.queryPermission({ mode: 'read' });
      if (perm !== 'granted') perm = await dir.requestPermission({ mode: 'read' });
      if (perm !== 'granted') { status.textContent = 'Geen toegang tot de map.'; return; }
      status.textContent = 'Map wordt gelezen…';
      const out = { files: [], skipped: 0 };
      await walkHandle(dir, '', out);
      await loadAlbum(out, dir.name);
    } catch (e) {
      console.warn(e);
      status.textContent = 'Die map kon niet meer geopend worden. Kies hem opnieuw.';
    }
  }
  function showLastBtn(dir) {
    lastBtn.hidden = false;
    lastBtn.textContent = '↻ ' + dir.name;
    lastBtn.onclick = () => openLast(dir);
  }
  if (window.showDirectoryPicker) loadHandle().then(d => { if (d && d.kind === 'directory') showLastBtn(d); });

  // ---- filter-events ----
  [['show', 'Dubbels: gewoon tonen'], ['hide', 'Dubbels: verbergen'], ['only', 'Dubbels: alleen tonen']].forEach(([v, t]) => { const o = h('option', '', t); o.value = v; fDup.append(o); });
  let fT = null;
  const refilter = () => { if (all.length) applyChange(); };
  fText.oninput = () => { filt.text = fText.value; clearTimeout(fT); fT = setTimeout(refilter, 250); };
  const dayStart = v => (v ? new Date(v + 'T00:00:00').getTime() : 0);
  const dayEnd = v => (v ? new Date(v + 'T23:59:59').getTime() : 0);
  fFrom.onchange = () => { filt.from = dayStart(fFrom.value); refilter(); };
  fTo.onchange = () => { filt.to = dayEnd(fTo.value); refilter(); };
  fFavIn.onchange = () => { filt.favOnly = fFavIn.checked; refilter(); };
  fHidIn.onchange = () => { filt.showHidden = fHidIn.checked; refilter(); };
  fDup.onchange = () => { filt.dupes = fDup.value; refilter(); };
  fClear.onclick = () => {
    Object.assign(filt, { text: '', from: 0, to: 0, favOnly: false, showHidden: false, dupes: 'show' });
    fText.value = ''; fFrom.value = ''; fTo.value = ''; fFavIn.checked = false; fHidIn.checked = false; fDup.value = 'show';
    refilter();
  };
  searchBtn.onclick = () => { fpanel.hidden = !fpanel.hidden; if (!fpanel.hidden) fText.focus(); };

  // ---- overige events ----
  pickBtn.onclick = pickFolder;
  overviewBtn.onclick = openOverview;
  albumBtn.onclick = openAlbumDialog;
  printBtn.onclick = openPrintDialog;
  sortSel.onchange = () => {
    if (!all.length) return;
    if (sortSel.value === 'manual' && data.sort !== 'manual' && !data.order.length) data.order = sortedAll().map(p => p.key);
    data.sort = sortSel.value; scheduleSave(); applyChange();
  };
  secsSel.onchange = () => { settings.secs = Number(secsSel.value); saveSettings(settings); if (timer) startShow(); };
  playBtn.onclick = () => (timer ? stopShow() : startShow());
  shuffleBtn.onclick = () => { settings.shuffle = !settings.shuffle; saveSettings(settings); shuffleBtn.classList.toggle('alb-on', settings.shuffle); if (timer) startShow(); };
  loopBtn.onclick = () => { settings.loop = !settings.loop; saveSettings(settings); loopBtn.classList.toggle('alb-on', settings.loop); };
  musicBtn.onclick = () => {
    const m = getBackgroundMusic();
    if (!m.active) { status.textContent = 'Er speelt nog geen muziek. Start eerst muziek in de audiospeler (koptelefoon bovenaan) en kom dan terug naar het album: de muziek blijft doorspelen.'; return; }
    bgToggle();
  };
  const offMusic = onBackgroundMusic(m => {
    musicBtn.classList.toggle('alb-on', !!(m && m.active && m.playing));
    musicBtn.title = m && m.active ? (m.playing ? 'Muziek pauzeren: ' : 'Muziek afspelen: ') + (m.title || '') : 'Achtergrondmuziek uit de audiospeler aan of uit';
  });
  prevBtn.onclick = () => { stopShow(); flip(-1); };
  nextBtn.onclick = () => { stopShow(); flip(1); };
  slider.oninput = () => { stopShow(); if (!animating) show(Number(slider.value)); };
  slotL.onclick = e => { if (!e.target.closest('.alb-ph')) { stopShow(); flip(-1); } };
  slotR.onclick = e => { if (!e.target.closest('.alb-ph')) { stopShow(); flip(1); } };
  fsBtn.onclick = () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else if (root.requestFullscreen) root.requestFullscreen().catch(() => {});
  };
  document.addEventListener('fullscreenchange', () => root.classList.toggle('alb-fs', document.fullscreenElement === root));

  // vegen op het aanraakscherm om te bladeren
  let sw0 = null;
  book.addEventListener('pointerdown', e => { if (e.pointerType !== 'mouse') sw0 = { x: e.clientX, y: e.clientY }; });
  book.addEventListener('pointerup', e => {
    if (!sw0 || e.pointerType === 'mouse') return;
    const dx = e.clientX - sw0.x, dy = e.clientY - sw0.y; sw0 = null;
    if (Math.abs(dx) > 60 && Math.abs(dy) < 80) { stopShow(); flip(dx < 0 ? 1 : -1); }
  });

  const onKey = e => {
    if (!root.isConnected) { document.removeEventListener('keydown', onKey); stopShow(); return; }
    const tg = e.target;
    if (tg && /^(INPUT|SELECT|TEXTAREA)$/.test(tg.tagName) && tg !== slider) return;
    if (!lb.hidden) {
      if (e.key === 'Escape') closeLightbox();
      else if (e.key === 'ArrowLeft') lbStep(-1);
      else if (e.key === 'ArrowRight') lbStep(1);
      else if (e.key === '+' || e.key === '=') zoomAt(Z.s * 1.5, 0, 0);
      else if (e.key === '-') zoomAt(Z.s / 1.5, 0, 0);
      else if (e.key === '0') resetZoom();
      else if (e.key === 'f' || e.key === 'F') lbFav.onclick();
      return;
    }
    if (!ov.hidden) { if (e.key === 'Escape') closeOverview(); return; }
    if (!pages.length) return;
    if (e.key === 'ArrowRight' || e.key === 'PageDown') { e.preventDefault(); stopShow(); flip(1); }
    else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); stopShow(); flip(-1); }
    else if (e.key === 'Home') { stopShow(); show(0); }
    else if (e.key === 'End') { stopShow(); show(spreadCount - 1); }
    else if (e.key === ' ') { e.preventDefault(); timer ? stopShow() : startShow(); }
    else if (e.key === 'o' || e.key === 'O') openOverview();
  };
  document.addEventListener('keydown', onKey);

  // opruimen wanneer de app wordt weggehaald
  const cleanup = new MutationObserver(() => {
    if (!root.isConnected) {
      stopShow();
      clearTimeout(saveT); if (albumKey) saveData(albumKey, data);
      for (const [, u] of urls) { try { URL.revokeObjectURL(u); } catch (_) {} }
      urls.clear();
      for (const [, u] of thumbUrls) { try { URL.revokeObjectURL(u); } catch (_) {} }
      thumbUrls.clear();
      if (lbUrl) URL.revokeObjectURL(lbUrl);
      lb.remove(); ov.remove();
      try { offMusic(); } catch (_) {}
      cleanup.disconnect();
    }
  });
  cleanup.observe(document.body, { childList: true, subtree: true });

  return { root };
}
