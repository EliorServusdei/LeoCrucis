# Worldbuilding-projecten

Hier staan de projecten die de Worldbuilding Studio laadt en bewerkt.

| Bestand | Inhoud |
|---------|--------|
| `index.json` | Lijst van alle projecten (id, naam, status, …) |
| `{id}.json` | Volledige projectdata (boeken, hoofdstukken, personages, …) |

## Gebruik

1. **In de app** — nieuw project aanmaken, bewerken, importeren/exporteren.
2. **Handmatig** — JSON hier bewerken; herlaad de app om te zien.
3. **Tauri / desktop** — opslaan schrijft terug naar deze map (als file I/O beschikbaar is).
4. **Browser only** — wijzigingen zitten in localStorage; gebruik **Data-bestanden** of **Exporteren** om JSON hier te plaatsen.

Pad op schijf (voorbeeld):

`…/leo-crucis/src/apps/worldbuilding/projecten/`
