// Kunstgalerij — eigen afbeeldingen (IndexedDB + metadata in localStorage).

const META_KEY = 'lc-gallery-meta-v1';
const DB_NAME = 'lc-gallery';
const STORE = 'images';

function loadMeta() {
  try {
    const raw = JSON.parse(localStorage.getItem(META_KEY) || '[]');
    return Array.isArray(raw) ? raw : [];
  } catch { return []; }
}
function saveMeta(list) {
  try { localStorage.setItem(META_KEY, JSON.stringify(list)); } catch (e) { console.warn(e); }
}
function uid() { return 'g-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function idbPut(id, blob) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(blob, id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function idbGet(id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}
async function idbDel(id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export function createGalleryApp() {
  const root = document.createElement('div');
  root.className = 'app-panel gallery-app';

  let items = loadMeta();
  const urlCache = new Map();

  const toolbar = document.createElement('div');
  toolbar.className = 'gal-toolbar';
  const addBtn = document.createElement('button');
  addBtn.type = 'button'; addBtn.className = 'gal-add'; addBtn.textContent = '+ Kunstwerk toevoegen';
  const fileIn = document.createElement('input');
  fileIn.type = 'file'; fileIn.accept = 'image/*'; fileIn.multiple = true; fileIn.hidden = true;
  toolbar.append(addBtn, fileIn);

  const grid = document.createElement('div');
  grid.className = 'gal-grid';
  const empty = document.createElement('p');
  empty.className = 'gal-empty';
  empty.textContent = 'Nog geen kunstwerken. Voeg afbeeldingen toe uit je bestanden.';

  const lightbox = document.createElement('div');
  lightbox.className = 'gal-lightbox';
  lightbox.hidden = true;
  const lbImg = document.createElement('img');
  lbImg.alt = '';
  const lbCap = document.createElement('div');
  lbCap.className = 'gal-lb-cap';
  const lbClose = document.createElement('button');
  lbClose.type = 'button'; lbClose.className = 'gal-lb-close'; lbClose.textContent = '×';
  lightbox.append(lbClose, lbImg, lbCap);

  root.append(toolbar, empty, grid, lightbox);

  async function objectUrl(id) {
    if (urlCache.has(id)) return urlCache.get(id);
    const blob = await idbGet(id);
    if (!blob) return null;
    const url = URL.createObjectURL(blob);
    urlCache.set(id, url);
    return url;
  }

  async function render() {
    items = loadMeta();
    grid.replaceChildren();
    empty.hidden = items.length > 0;
    for (const it of items) {
      const card = document.createElement('article');
      card.className = 'gal-card';
      const img = document.createElement('img');
      img.alt = it.title || 'Kunstwerk';
      img.loading = 'lazy';
      const url = await objectUrl(it.id);
      if (url) img.src = url;
      const cap = document.createElement('div');
      cap.className = 'gal-cap';
      const title = document.createElement('input');
      title.type = 'text'; title.className = 'gal-title'; title.value = it.title || '';
      title.placeholder = 'Titel';
      title.onclick = e => e.stopPropagation();
      title.onchange = () => {
        it.title = title.value.trim();
        saveMeta(items);
      };
      const del = document.createElement('button');
      del.type = 'button'; del.className = 'gal-del'; del.textContent = 'Verwijderen';
      del.onclick = async e => {
        e.stopPropagation();
        if (!confirm('Dit kunstwerk verwijderen?')) return;
        items = items.filter(x => x.id !== it.id);
        saveMeta(items);
        await idbDel(it.id);
        if (urlCache.has(it.id)) {
          try { URL.revokeObjectURL(urlCache.get(it.id)); } catch (_) {}
          urlCache.delete(it.id);
        }
        render();
      };
      cap.append(title, del);
      card.append(img, cap);
      card.onclick = () => {
        if (!url) return;
        lbImg.src = url;
        lbCap.textContent = it.title || it.fileName || '';
        lightbox.hidden = false;
      };
      grid.append(card);
    }
  }

  addBtn.onclick = () => fileIn.click();
  fileIn.onchange = async () => {
    const files = Array.from(fileIn.files || []);
    fileIn.value = '';
    for (const f of files) {
      if (!f.type.startsWith('image/')) continue;
      const id = uid();
      try {
        await idbPut(id, f);
        items.unshift({
          id,
          title: f.name.replace(/\.[^.]+$/, '').replace(/[_]+/g, ' '),
          fileName: f.name,
          added: Date.now()
        });
      } catch (e) {
        console.warn('Afbeelding opslaan mislukt', e);
        alert('Kon “' + f.name + '” niet opslaan (mogelijk te groot).');
      }
    }
    saveMeta(items);
    await render();
  };
  lbClose.onclick = () => { lightbox.hidden = true; lbImg.removeAttribute('src'); };
  lightbox.onclick = e => { if (e.target === lightbox) lbClose.onclick(); };

  render();
  return { root };
}
