// apps-verse-study.js — Verdieping bij een Bijbelvers (splitscreen)
// UI volgt bewust de bestaande Bijbel-stijl: bb-head, bb-chip, bb-hit, .box

import { lookupOrigineel } from './woordenboek-origineel.js';

const META_BASE = 'data/bijbel-meta/';

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

const metaCache = new Map();

async function loadChapterMeta(bookOsis, chapter) {
  const key = `${bookOsis}.${chapter}`;
  if (metaCache.has(key)) return metaCache.get(key);
  try {
    const res = await fetch(`${META_BASE}${bookOsis}.${chapter}.json`);
    if (!res.ok) {
      const empty = { verses: {} };
      metaCache.set(key, empty);
      return empty;
    }
    const data = await res.json();
    metaCache.set(key, data);
    return data;
  } catch {
    const empty = { verses: {} };
    metaCache.set(key, empty);
    return empty;
  }
}

export function createVerseStudyApp(startPos) {
  const root = el('div', 'app-panel verse-study-app bijbel-app mini-app-root');
  const pos = startPos && typeof startPos === 'object' ? startPos : {};
  const book = pos.osis || pos.book || 'John';
  const chapter = pos.chapter || 1;
  const verse = pos.verse || pos.from || 1;
  const bookNl = pos.bookNl || book;

  // Zelfde kop als de Bijbellezer
  const head = el('div', 'bb-head');
  head.append(el('h2', 'bb-title', `${bookNl} ${chapter}:${verse}`));
  head.append(el('span', 'bb-sub', 'Verdieping'));
  root.append(head);

  // Tabs als bb-chips (zoals hoofdstukkeuze)
  const chips = el('div', 'bb-chips vs-tabs');
  const tabDefs = [
    { id: 'xref',  label: 'Kruisverwijzingen' },
    { id: 'mss',   label: 'Manuscripten' },
    { id: 'hist',  label: 'Context' },
    { id: 'words', label: 'Woordstudie' },
  ];
  const tabBtns = {};
  const panels = {};
  tabDefs.forEach((t, i) => {
    const btn = el('button', 'bb-chip' + (i === 0 ? ' on' : ''), t.label);
    btn.type = 'button';
    btn.dataset.tab = t.id;
    tabBtns[t.id] = btn;
    chips.append(btn);
  });
  root.append(chips);

  const body = el('div', 'vs-body');
  tabDefs.forEach((t, i) => {
    const sec = el('div', 'vs-panel');
    sec.dataset.panel = t.id;
    if (i > 0) sec.hidden = true;
    panels[t.id] = sec;
    body.append(sec);
  });
  root.append(body);

  let activeTab = 'xref';
  function setTab(id) {
    activeTab = id;
    for (const [k, btn] of Object.entries(tabBtns)) {
      btn.classList.toggle('on', k === id);
    }
    for (const [k, sec] of Object.entries(panels)) {
      sec.hidden = k !== id;
    }
  }
  chips.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-tab]');
    if (btn) setTab(btn.dataset.tab);
  });

  function box(titleText) {
    const b = el('div', 'box');
    if (titleText) b.append(el('h3', '', titleText));
    return b;
  }

  function renderXref(data) {
    const sec = panels.xref;
    sec.replaceChildren();
    if (!data || !data.cross_references) {
      sec.append(el('p', 'bb-note', 'Geen kruisverwijzingen beschikbaar voor dit vers.'));
      return;
    }
    const cr = data.cross_references;
    const groups = [
      { key: 'quotations', title: 'Directe citaten / vervulling' },
      { key: 'parallels',  title: 'Parallelle teksten' },
      { key: 'thematic',   title: 'Thematische verbanden' },
    ];
    let any = false;
    for (const g of groups) {
      const list = cr[g.key];
      if (!list || !list.length) continue;
      any = true;
      const b = box(g.title);
      const ul = el('ul', 'bb-hits');
      for (const item of list) {
        const li = el('li', 'bb-hit vs-hit');
        const refBtn = el('button', 'bb-hit-ref', item.label || item.ref);
        refBtn.type = 'button';
        refBtn.title = 'Open in de Bijbel';
        refBtn.onclick = () => {
          window.dispatchEvent(new CustomEvent('lc-bible-navigate', {
            detail: { osis: item.ref },
          }));
        };
        const text = el('span', 'bb-hit-text');
        if (item.note) {
          text.append(el('span', 'vs-hit-note', item.note));
        }
        if (item.preview) {
          if (item.note) text.append(document.createTextNode(' '));
          text.append(el('span', 'vs-hit-preview', item.preview));
        }
        if (!item.note && !item.preview) {
          text.textContent = 'Open in de Bijbel →';
        }
        li.append(refBtn, text);
        ul.append(li);
      }
      b.append(ul);
      sec.append(b);
    }
    if (!any) {
      sec.append(el('p', 'bb-note', 'Geen kruisverwijzingen beschikbaar voor dit vers.'));
    } else {
      sec.append(el('p', 'bb-note', 'Klik op een verwijzing om die links in de Bijbel te openen.'));
    }
  }

  function renderMss(data) {
    const sec = panels.mss;
    sec.replaceChildren();
    if (!data || !data.manuscripts) {
      sec.append(el('p', 'bb-note', 'Nog geen manuscriptinformatie voor dit vers.'));
      return;
    }
    const m = data.manuscripts;
    if (m.primary_witnesses && m.primary_witnesses.length) {
      const b = box('Belangrijkste getuigen');
      const ul = el('ul', 'vs-plain-list');
      for (const w of m.primary_witnesses) {
        const li = el('li');
        let line = w.name || w.id;
        if (w.date) line += ` · ${w.date}`;
        if (w.type) line += ` (${w.type})`;
        li.append(el('strong', '', line));
        if (w.contains) {
          li.append(document.createElement('br'));
          li.append(el('span', 'bb-note', w.contains));
        }
        ul.append(li);
      }
      b.append(ul);
      sec.append(b);
    }
    if (m.variants && m.variants.length) {
      const b = box('Tekstvarianten');
      for (const v of m.variants) {
        if (v.reading) b.append(el('p', 'vs-reading', v.reading));
        if (v.translation_note) b.append(el('p', '', v.translation_note));
        if (v.academic_consensus) {
          const p = el('p', 'bb-note', v.academic_consensus);
          if (v.confidence) p.prepend(document.createTextNode(`[${v.confidence}] `));
          b.append(p);
        }
      }
      sec.append(b);
    }
    if (m.reliability_note) {
      const b = box(null);
      b.append(el('p', 'bb-note', m.reliability_note));
      // disclaimer-stijl zoals voetnoten
      b.style.borderLeft = '3px solid var(--acc2)';
      sec.append(b);
    }
  }

  function renderHist(data) {
    const sec = panels.hist;
    sec.replaceChildren();
    if (!data || !data.historical_context) {
      sec.append(el('p', 'bb-note', 'Nog geen historische context voor dit vers.'));
      return;
    }
    const h = data.historical_context;
    if (h.composition) {
      const b = box('Tijd & auteur');
      const parts = [];
      if (h.composition.estimated_date) parts.push(h.composition.estimated_date);
      if (h.composition.traditional_author) parts.push(h.composition.traditional_author);
      if (h.composition.location) parts.push(h.composition.location);
      if (parts.length) b.append(el('p', '', parts.join(' · ')));
      if (h.composition.situation) b.append(el('p', 'bb-note', h.composition.situation));
      sec.append(b);
    }
    if (h.cultural_background) {
      const b = box('Historische & culturele achtergrond');
      b.append(el('p', '', h.cultural_background));
      sec.append(b);
    }
    if (data.geography && data.geography.places && data.geography.places.length) {
      const b = box('Geografie');
      const ul = el('ul', 'vs-plain-list');
      for (const p of data.geography.places) {
        const li = el('li');
        let line = p.name;
        if (p.modern && p.modern !== p.name) line += ` (${p.modern})`;
        li.append(el('strong', '', line));
        if (p.note) {
          li.append(document.createElement('br'));
          li.append(el('span', 'bb-note', p.note));
        }
        ul.append(li);
      }
      b.append(ul);
      if (data.geography.timeline_anchor) {
        b.append(el('p', 'bb-note', 'Tijdlijn: ' + data.geography.timeline_anchor));
      }
      sec.append(b);
    }
  }

  function renderWords(data) {
    const sec = panels.words;
    sec.replaceChildren();
    const words = data && data.word_study;
    if (!words || !words.length) {
      sec.append(el('p', 'bb-note', 'Nog geen woordstudie voor dit vers.'));
      return;
    }
    sec.append(el('p', 'bb-note', 'Elk blok toont een woord uit het vers en de grondtekst. Klik op Strong’s of lemma voor het woordenboek (NL).'));
    for (const w of words) {
      const b = box(null);

      const fromVerse = w.in_verse || w.gloss || '';
      if (fromVerse) {
        const h = el('h3', 'vs-word-from', fromVerse);
        b.append(h);
      }

      if (w.verse_phrase) {
        b.append(el('p', 'vs-verse-phrase', w.verse_phrase));
      }

      const bridge = el('p', 'vs-word-bridge');
      const bits = [];
      if (w.greek || w.hebrew) bits.push(w.greek || w.hebrew);
      if (w.lemma && w.lemma !== (w.greek || w.hebrew)) bits.push(w.lemma);
      if (w.strong) bits.push(w.strong);
      bridge.textContent = bits.join(' · ');
      b.append(bridge);

      if (w.gloss) b.append(el('p', '', w.gloss));
      if (w.brief) b.append(el('p', 'bb-note', w.brief));

      // Woordenboek-referentie (Strong’s → NL)
      const dictSlot = el('div', 'vs-dict-slot');
      dictSlot.append(el('p', 'bb-note', 'Woordenboek laden…'));
      b.append(dictSlot);

      const query = w.strong || w.lemma || w.greek || w.hebrew || '';
      if (query) {
        lookupOrigineel(query).then(hits => {
          dictSlot.replaceChildren();
          if (!hits.length) {
            dictSlot.append(el('p', 'bb-note', 'Geen woordenboek-item voor ' + query + '.'));
            return;
          }
          const e = hits[0];
          const row = el('div', 'vs-dict-row');
          const lab = el('span', 'vs-dict-lab', 'Woordenboek');
          row.append(lab);
          const lemma = el('strong', '', e.l);
          row.append(lemma);
          if (e.s) row.append(el('span', 'vs-dict-strong', e.s));
          dictSlot.append(row);
          if (e.n) dictSlot.append(el('p', 'vs-dict-gloss', e.n));
          const openBtn = el('button', 'bb-chip', 'Open in woordenboek');
          openBtn.type = 'button';
          openBtn.title = 'Open dit lemma in het woordenboek oorspronkelijke talen';
          openBtn.onclick = () => {
            window.dispatchEvent(new CustomEvent('lc-open-woordenboek-origineel', {
              detail: { query: e.s || e.l }
            }));
          };
          dictSlot.append(openBtn);
        }).catch(() => {
          dictSlot.replaceChildren(el('p', 'bb-note', 'Woordenboek niet beschikbaar.'));
        });
      } else {
        dictSlot.replaceChildren();
      }

      sec.append(b);
    }
  }

  body.append(el('p', 'bb-status', 'Laden…'));

  (async () => {
    const chapterData = await loadChapterMeta(book, chapter);
    const verseData = (chapterData.verses && chapterData.verses[String(verse)]) || {};
    // status weg
    const status = body.querySelector('.bb-status');
    if (status) status.remove();
    renderXref(verseData);
    renderMss(verseData);
    renderHist(verseData);
    renderWords(verseData);
    setTab(activeTab);
  })();

  return { root };
}
