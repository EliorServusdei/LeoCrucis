// Atlas-app — kaarten als atlas: inhoudsopgave per regio, platen bladeren, zoom/pan.
// Opslag: IndexedDB + metadata in localStorage. Meegeleverde kaarten + eigen uploads.

const META_KEY = 'lc-maps-meta-v1';
const SEEDED_KEY = 'lc-maps-seeded-v5'; // v5 = Vlaamse steden (Wikimedia Commons)
const DB_NAME = 'lc-maps';
const STORE = 'images';

/**
 * Meegeleverde open-source kaarten.
 * Wikimedia Commons: CC BY-SA / Public domain (zie attribution).
 * Schematische SVG's: eigen werk, CC0.
 */
const BUNDLED_MAPS = [
  { id: 'wm-real-blankmap-world', title: 'Wereldkaart (blanco)', fileName: 'real-blankmap-world.png', src: 'assets/maps/real-blankmap-world.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Wereldkaart (blanco)' },
  { id: 'wm-real-world-map-blank-without-borders', title: 'Wereldkaart zonder grenzen', fileName: 'real-world-map-blank-without-borders.png', src: 'assets/maps/real-world-map-blank-without-borders.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Wereldkaart zonder grenzen' },
  { id: 'wm-real-central-europe-location-map', title: 'Central Europe Location Map', fileName: 'real-central-europe-location-map.png', src: 'assets/maps/real-central-europe-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Central Europe Location Map' },
  { id: 'wm-real-eastern-europe-location-map', title: 'Eastern Europe Location Map', fileName: 'real-eastern-europe-location-map.png', src: 'assets/maps/real-eastern-europe-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Eastern Europe Location Map' },
  { id: 'wm-real-blank-map-of-europe-cropped-blue', title: 'Europa – blanco (blauw)', fileName: 'real-blank-map-of-europe-cropped-blue.png', src: 'assets/maps/real-blank-map-of-europe-cropped-blue.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Europa – blanco (blauw)' },
  { id: 'wm-real-europe-blank-laea-location-map', title: 'Europa – blanco locatiekaart', fileName: 'real-europe-blank-laea-location-map.png', src: 'assets/maps/real-europe-blank-laea-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Europa – blanco locatiekaart' },
  { id: 'wm-real-europe-laea-location-map', title: 'Europa – locatiekaart', fileName: 'real-europe-laea-location-map.png', src: 'assets/maps/real-europe-laea-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Europa – locatiekaart' },
  { id: 'wm-real-europe-outline-map', title: 'Europa – omtrek', fileName: 'real-europe-outline-map.png', src: 'assets/maps/real-europe-outline-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Europa – omtrek' },
  { id: 'wm-real-europe-map', title: 'Europa – overzicht', fileName: 'real-europe-map.png', src: 'assets/maps/real-europe-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Europa – overzicht' },
  { id: 'wm-europa-politiek-wm', title: 'Europa – politieke kaart', fileName: 'europa-politiek-wm.png', src: 'assets/maps/europa-politiek-wm.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Europa – politieke kaart' },
  { id: 'wm-real-europe-topographic-map-2024', title: 'Europa – topografisch (2024)', fileName: 'real-europe-topographic-map-2024.png', src: 'assets/maps/real-europe-topographic-map-2024.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Europa – topografisch (2024)' },
  { id: 'wm-real-european-union-on-the-globe-europe-centered', title: 'European Union On The Globe Europe Centered', fileName: 'real-european-union-on-the-globe-europe-centered.png', src: 'assets/maps/real-european-union-on-the-globe-europe-centered.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – European Union On The Globe Europe Centered' },
  { id: 'wm-real-map-of-europe', title: 'Kaart van Europa', fileName: 'real-map-of-europe.png', src: 'assets/maps/real-map-of-europe.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Kaart van Europa' },
  { id: 'wm-real-northern-europe-location-map', title: 'Northern Europe Location Map', fileName: 'real-northern-europe-location-map.png', src: 'assets/maps/real-northern-europe-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Northern Europe Location Map' },
  { id: 'wm-real-southern-europe-location-map', title: 'Southern Europe Location Map', fileName: 'real-southern-europe-location-map.png', src: 'assets/maps/real-southern-europe-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Southern Europe Location Map' },
  { id: 'wm-vlaanderen-in-europa-wm', title: 'Vlaanderen in Europa', fileName: 'vlaanderen-in-europa-wm.png', src: 'assets/maps/vlaanderen-in-europa-wm.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Vlaanderen in Europa' },
  { id: 'wm-real-flanders-in-europe', title: 'Vlaanderen in Europa (detail)', fileName: 'real-flanders-in-europe.png', src: 'assets/maps/real-flanders-in-europe.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Vlaanderen in Europa (detail)' },
  { id: 'wm-real-western-europe-location-map', title: 'Western Europe Location Map', fileName: 'real-western-europe-location-map.png', src: 'assets/maps/real-western-europe-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Western Europe Location Map' },
  { id: 'wm-real-belgium-location-map', title: 'België', fileName: 'real-belgium-location-map.png', src: 'assets/maps/real-belgium-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – België' },
  { id: 'wm-real-belgium-provinces-blank', title: 'België – provincies (blanco)', fileName: 'real-belgium-provinces-blank.png', src: 'assets/maps/real-belgium-provinces-blank.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – België – provincies (blanco)' },
  { id: 'wm-vlaanderen-blanco-wm', title: 'Vlaanderen – blanco', fileName: 'vlaanderen-blanco-wm.png', src: 'assets/maps/vlaanderen-blanco-wm.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Vlaanderen – blanco' },
  { id: 'wm-vlaanderen-provincies-wm', title: 'Vlaanderen – provincies', fileName: 'vlaanderen-provincies-wm.png', src: 'assets/maps/vlaanderen-provincies-wm.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Vlaanderen – provincies' },
  { id: 'wm-real-provinces-of-flanders', title: 'Vlaanderen – provincies (detail)', fileName: 'real-provinces-of-flanders.png', src: 'assets/maps/real-provinces-of-flanders.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Vlaanderen – provincies (detail)' },
  { id: 'wm-real-albania-location-map', title: 'Albania Location Map', fileName: 'real-albania-location-map.png', src: 'assets/maps/real-albania-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Albania Location Map' },
  { id: 'wm-real-andorra-location-map', title: 'Andorra Location Map', fileName: 'real-andorra-location-map.png', src: 'assets/maps/real-andorra-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Andorra Location Map' },
  { id: 'wm-real-austria-location-map', title: 'Austria Location Map', fileName: 'real-austria-location-map.png', src: 'assets/maps/real-austria-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Austria Location Map' },
  { id: 'wm-real-baltic-states-location-map', title: 'Baltic States Location Map', fileName: 'real-baltic-states-location-map.png', src: 'assets/maps/real-baltic-states-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Baltic States Location Map' },
  { id: 'wm-real-belarus-location-map', title: 'Belarus Location Map', fileName: 'real-belarus-location-map.png', src: 'assets/maps/real-belarus-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Belarus Location Map' },
  { id: 'wm-real-benelux-location-map', title: 'Benelux Location Map', fileName: 'real-benelux-location-map.png', src: 'assets/maps/real-benelux-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Benelux Location Map' },
  { id: 'wm-real-bosnia-and-herzegovina-location-map', title: 'Bosnia And Herzegovina Location Map', fileName: 'real-bosnia-and-herzegovina-location-map.png', src: 'assets/maps/real-bosnia-and-herzegovina-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Bosnia And Herzegovina Location Map' },
  { id: 'wm-real-british-isles-location-map', title: 'British Isles Location Map', fileName: 'real-british-isles-location-map.png', src: 'assets/maps/real-british-isles-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – British Isles Location Map' },
  { id: 'wm-real-bulgaria-location-map', title: 'Bulgaria Location Map', fileName: 'real-bulgaria-location-map.png', src: 'assets/maps/real-bulgaria-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Bulgaria Location Map' },
  { id: 'wm-real-croatia-location-map', title: 'Croatia Location Map', fileName: 'real-croatia-location-map.png', src: 'assets/maps/real-croatia-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Croatia Location Map' },
  { id: 'wm-real-cyprus-location-map', title: 'Cyprus Location Map', fileName: 'real-cyprus-location-map.png', src: 'assets/maps/real-cyprus-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Cyprus Location Map' },
  { id: 'wm-real-czech-republic-location-map', title: 'Czech Republic Location Map', fileName: 'real-czech-republic-location-map.png', src: 'assets/maps/real-czech-republic-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Czech Republic Location Map' },
  { id: 'wm-real-denmark-location-map', title: 'Denmark Location Map', fileName: 'real-denmark-location-map.png', src: 'assets/maps/real-denmark-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Denmark Location Map' },
  { id: 'wm-real-estonia-location-map', title: 'Estonia Location Map', fileName: 'real-estonia-location-map.png', src: 'assets/maps/real-estonia-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Estonia Location Map' },
  { id: 'wm-real-finland-location-map', title: 'Finland Location Map', fileName: 'real-finland-location-map.png', src: 'assets/maps/real-finland-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Finland Location Map' },
  { id: 'wm-real-france-location-map', title: 'France Location Map', fileName: 'real-france-location-map.png', src: 'assets/maps/real-france-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – France Location Map' },
  { id: 'wm-real-germany-location-map', title: 'Germany Location Map', fileName: 'real-germany-location-map.png', src: 'assets/maps/real-germany-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Germany Location Map' },
  { id: 'wm-real-greece-location-map', title: 'Greece Location Map', fileName: 'real-greece-location-map.png', src: 'assets/maps/real-greece-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Greece Location Map' },
  { id: 'wm-real-hungary-location-map', title: 'Hungary Location Map', fileName: 'real-hungary-location-map.png', src: 'assets/maps/real-hungary-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Hungary Location Map' },
  { id: 'wm-real-iberian-peninsula-location-map', title: 'Iberian Peninsula Location Map', fileName: 'real-iberian-peninsula-location-map.png', src: 'assets/maps/real-iberian-peninsula-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Iberian Peninsula Location Map' },
  { id: 'wm-real-iceland-location-map', title: 'Iceland Location Map', fileName: 'real-iceland-location-map.png', src: 'assets/maps/real-iceland-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Iceland Location Map' },
  { id: 'wm-real-ireland-location-map', title: 'Ireland Location Map', fileName: 'real-ireland-location-map.png', src: 'assets/maps/real-ireland-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Ireland Location Map' },
  { id: 'wm-real-italy-location-map', title: 'Italy Location Map', fileName: 'real-italy-location-map.png', src: 'assets/maps/real-italy-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Italy Location Map' },
  { id: 'wm-real-kosovo-location-map', title: 'Kosovo Location Map', fileName: 'real-kosovo-location-map.png', src: 'assets/maps/real-kosovo-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Kosovo Location Map' },
  { id: 'wm-real-latvia-location-map', title: 'Latvia Location Map', fileName: 'real-latvia-location-map.png', src: 'assets/maps/real-latvia-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Latvia Location Map' },
  { id: 'wm-real-liechtenstein-location-map', title: 'Liechtenstein Location Map', fileName: 'real-liechtenstein-location-map.png', src: 'assets/maps/real-liechtenstein-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Liechtenstein Location Map' },
  { id: 'wm-real-lithuania-location-map', title: 'Lithuania Location Map', fileName: 'real-lithuania-location-map.png', src: 'assets/maps/real-lithuania-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Lithuania Location Map' },
  { id: 'wm-real-luxembourg-location-map', title: 'Luxembourg Location Map', fileName: 'real-luxembourg-location-map.png', src: 'assets/maps/real-luxembourg-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Luxembourg Location Map' },
  { id: 'wm-real-malta-location-map', title: 'Malta Location Map', fileName: 'real-malta-location-map.png', src: 'assets/maps/real-malta-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Malta Location Map' },
  { id: 'wm-real-moldova-location-map', title: 'Moldova Location Map', fileName: 'real-moldova-location-map.png', src: 'assets/maps/real-moldova-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Moldova Location Map' },
  { id: 'wm-real-monaco-location-map', title: 'Monaco Location Map', fileName: 'real-monaco-location-map.png', src: 'assets/maps/real-monaco-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Monaco Location Map' },
  { id: 'wm-real-montenegro-location-map', title: 'Montenegro Location Map', fileName: 'real-montenegro-location-map.png', src: 'assets/maps/real-montenegro-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Montenegro Location Map' },
  { id: 'wm-real-netherlands-location-map', title: 'Netherlands Location Map', fileName: 'real-netherlands-location-map.png', src: 'assets/maps/real-netherlands-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Netherlands Location Map' },
  { id: 'wm-real-north-macedonia-location-map', title: 'North Macedonia Location Map', fileName: 'real-north-macedonia-location-map.png', src: 'assets/maps/real-north-macedonia-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – North Macedonia Location Map' },
  { id: 'wm-real-norway-location-map', title: 'Norway Location Map', fileName: 'real-norway-location-map.png', src: 'assets/maps/real-norway-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Norway Location Map' },
  { id: 'wm-real-poland-location-map', title: 'Poland Location Map', fileName: 'real-poland-location-map.png', src: 'assets/maps/real-poland-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Poland Location Map' },
  { id: 'wm-real-portugal-location-map', title: 'Portugal Location Map', fileName: 'real-portugal-location-map.png', src: 'assets/maps/real-portugal-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Portugal Location Map' },
  { id: 'wm-real-romania-location-map', title: 'Romania Location Map', fileName: 'real-romania-location-map.png', src: 'assets/maps/real-romania-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Romania Location Map' },
  { id: 'wm-real-russia-location-map', title: 'Russia Location Map', fileName: 'real-russia-location-map.png', src: 'assets/maps/real-russia-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Russia Location Map' },
  { id: 'wm-real-san-marino-location-map', title: 'San Marino Location Map', fileName: 'real-san-marino-location-map.png', src: 'assets/maps/real-san-marino-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – San Marino Location Map' },
  { id: 'wm-real-scandinavia-location-map', title: 'Scandinavia Location Map', fileName: 'real-scandinavia-location-map.png', src: 'assets/maps/real-scandinavia-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Scandinavia Location Map' },
  { id: 'wm-real-serbia-location-map', title: 'Serbia Location Map', fileName: 'real-serbia-location-map.png', src: 'assets/maps/real-serbia-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Serbia Location Map' },
  { id: 'wm-real-slovakia-location-map', title: 'Slovakia Location Map', fileName: 'real-slovakia-location-map.png', src: 'assets/maps/real-slovakia-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Slovakia Location Map' },
  { id: 'wm-real-slovenia-location-map', title: 'Slovenia Location Map', fileName: 'real-slovenia-location-map.png', src: 'assets/maps/real-slovenia-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Slovenia Location Map' },
  { id: 'wm-real-spain-location-map', title: 'Spain Location Map', fileName: 'real-spain-location-map.png', src: 'assets/maps/real-spain-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Spain Location Map' },
  { id: 'wm-real-sweden-location-map', title: 'Sweden Location Map', fileName: 'real-sweden-location-map.png', src: 'assets/maps/real-sweden-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Sweden Location Map' },
  { id: 'wm-real-switzerland-location-map', title: 'Switzerland Location Map', fileName: 'real-switzerland-location-map.png', src: 'assets/maps/real-switzerland-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Switzerland Location Map' },
  { id: 'wm-real-turkey-location-map', title: 'Turkey Location Map', fileName: 'real-turkey-location-map.png', src: 'assets/maps/real-turkey-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Turkey Location Map' },
  { id: 'wm-real-ukraine-location-map', title: 'Ukraine Location Map', fileName: 'real-ukraine-location-map.png', src: 'assets/maps/real-ukraine-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Ukraine Location Map' },
  { id: 'wm-real-united-kingdom-location-map', title: 'United Kingdom Location Map', fileName: 'real-united-kingdom-location-map.png', src: 'assets/maps/real-united-kingdom-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – United Kingdom Location Map' },
  { id: 'wm-real-vatican-city-location-map', title: 'Vatican City Location Map', fileName: 'real-vatican-city-location-map.png', src: 'assets/maps/real-vatican-city-location-map.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Vatican City Location Map' },
  { id: 'wm-real-flemish-region-blank', title: 'Vlaams Gewest – blanco', fileName: 'real-flemish-region-blank.png', src: 'assets/maps/real-flemish-region-blank.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – Vlaams Gewest – blanco' },
  // Vlaamse steden – Wikimedia Commons (locatie + OSM)
  { id: 'wm-brugge-locatie', title: 'Brugge – locatie', fileName: 'brugge-locatie.png', src: 'assets/maps/brugge-locatie.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – BruggeLocatie.png (publiek domein)' },
  { id: 'wm-brugge-osm', title: 'Brugge – stratenkaart (OSM)', fileName: 'brugge-osm.png', src: 'assets/maps/brugge-osm.png', license: 'Wikimedia Commons / ODbL', attribution: 'Wikimedia Commons – Bruges OSM (OpenStreetMap, ODbL)' },
  { id: 'wm-gent-locatie', title: 'Gent – locatie', fileName: 'gent-locatie.png', src: 'assets/maps/gent-locatie.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – GentLocation.svg (eigen werk / Commons)' },
  { id: 'wm-antwerpen-locatie', title: 'Antwerpen – locatie', fileName: 'antwerpen-locatie.png', src: 'assets/maps/antwerpen-locatie.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – AntwerpenLocatie.png (publiek domein)' },
  { id: 'wm-antwerpen-osm', title: 'Antwerpen – stratenkaart (OSM)', fileName: 'antwerpen-osm.png', src: 'assets/maps/antwerpen-osm.png', license: 'Wikimedia Commons / ODbL', attribution: 'Wikimedia Commons – Anvers OSM (OpenStreetMap, ODbL)' },
  { id: 'wm-leuven-locatie', title: 'Leuven – locatie', fileName: 'leuven-locatie.png', src: 'assets/maps/leuven-locatie.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – LeuvenLocatie.png (publiek domein)' },
  { id: 'wm-leuven-osm', title: 'Leuven – stratenkaart (OSM)', fileName: 'leuven-osm.png', src: 'assets/maps/leuven-osm.png', license: 'Wikimedia Commons / ODbL', attribution: 'Wikimedia Commons – Louvain OSM (OpenStreetMap, ODbL)' },
  { id: 'wm-mechelen-locatie', title: 'Mechelen – locatie', fileName: 'mechelen-locatie.png', src: 'assets/maps/mechelen-locatie.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – MechelenLocatie.png (publiek domein)' },
  { id: 'wm-hasselt-locatie', title: 'Hasselt – locatie', fileName: 'hasselt-locatie.png', src: 'assets/maps/hasselt-locatie.png', license: 'Wikimedia Commons', attribution: 'Wikimedia Commons – HasseltLocatie.png (publiek domein)' },
];

function loadMeta() {
  try {
    const raw = JSON.parse(localStorage.getItem(META_KEY) || '[]');
    return Array.isArray(raw) ? raw : [];
  } catch { return []; }
}
function saveMeta(list) {
  try { localStorage.setItem(META_KEY, JSON.stringify(list)); } catch (e) { console.warn(e); }
}
function uid() { return 'm-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

async function seedBundledMaps() {
  // Altijd ontbrekende meegeleverde kaarten bijladen (ook na eerdere seed),
  // zodat updates van BUNDLED_MAPS zichtbaar worden zonder localStorage te wissen.
  const items = loadMeta();
  const existing = new Set(items.map(i => i.id));
  let added = 0;
  for (const m of BUNDLED_MAPS) {
    if (existing.has(m.id)) continue;
    try {
      const res = await fetch(m.src);
      if (!res.ok) {
        console.warn('Meegeleverde kaart niet gevonden:', m.src, res.status);
        continue;
      }
      const blob = await res.blob();
      if (!blob || blob.size < 100) {
        console.warn('Meegeleverde kaart leeg/ongeldig:', m.title);
        continue;
      }
      await idbPut(m.id, blob);
      items.unshift({
        id: m.id,
        title: m.title,
        fileName: m.fileName,
        added: Date.now(),
        license: m.license || '',
        attribution: m.attribution || '',
        bundled: true
      });
      existing.add(m.id);
      added++;
    } catch (e) {
      console.warn('Meegeleverde kaart laden mislukt:', m.title, e);
    }
  }
  if (added > 0) saveMeta(items);
  try { localStorage.setItem(SEEDED_KEY, '1'); } catch (_) {}
}

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function idbPut(id, blob) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(blob, id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function idbGet(id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).get(id);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}
async function idbDel(id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/** Bepaal atlas-hoofdstuk voor een kaart. */
function atlasChapter(it) {
  const t = ((it.title || '') + ' ' + (it.id || '') + ' ' + (it.fileName || '')).toLowerCase();
  if (/world|wereld|globe|earth|aarde/.test(t)) return 'wereld';
  if (/belgi|vlaander|nederland|benelux|lage.?landen|brussels|antwerp|brugge|gent|leuven|mechelen|kortrijk|oostende|hasselt|aalst|sint.?niklaas|louvain|anvers/.test(t)) return 'lage-landen';
  if (/europe|europa|european|eu\b/.test(t)) return 'europa';
  if (it.bundled) return 'overig';
  return 'eigen';
}

const ATLAS_CHAPTERS = [
  { id: 'wereld', label: 'Wereld', blurb: 'Wereldkaarten en globes' },
  { id: 'europa', label: 'Europa', blurb: 'Europa – politiek, topografisch, omtrek' },
  { id: 'lage-landen', label: 'Lage Landen', blurb: 'België, Vlaanderen, Nederland' },
  { id: 'overig', label: 'Overige kaarten', blurb: 'Andere meegeleverde kaarten' },
  { id: 'eigen', label: 'Eigen kaarten', blurb: 'Kaarten die je zelf hebt toegevoegd' }
];

/** Snelle sprongen op de interactieve OSM-kaart (Vlaanderen). */
const OSM_PLACES = [
  { id: 'vlaanderen', name: 'Vlaanderen', lat: 51.05, lon: 4.15, zoom: 8 },
  { id: 'belgie', name: 'België', lat: 50.5, lon: 4.5, zoom: 7 },
  { id: 'brugge', name: 'Brugge', lat: 51.2093, lon: 3.2247, zoom: 14 },
  { id: 'gent', name: 'Gent', lat: 51.0543, lon: 3.7174, zoom: 13 },
  { id: 'antwerpen', name: 'Antwerpen', lat: 51.2194, lon: 4.4025, zoom: 13 },
  { id: 'leuven', name: 'Leuven', lat: 50.8798, lon: 4.7005, zoom: 14 },
  { id: 'mechelen', name: 'Mechelen', lat: 51.0259, lon: 4.4776, zoom: 14 },
  { id: 'kortrijk', name: 'Kortrijk', lat: 50.8279, lon: 3.2647, zoom: 14 },
  { id: 'oostende', name: 'Oostende', lat: 51.2154, lon: 2.9286, zoom: 14 },
  { id: 'hasselt', name: 'Hasselt', lat: 50.9307, lon: 5.3378, zoom: 14 },
  { id: 'aalst', name: 'Aalst', lat: 50.9378, lon: 4.0409, zoom: 14 },
  { id: 'sint-niklaas', name: 'Sint-Niklaas', lat: 51.1659, lon: 4.1437, zoom: 14 },
  { id: 'brussel', name: 'Brussel', lat: 50.8503, lon: 4.3517, zoom: 12 }
];

const OSM_LAYERS = [
  {
    id: 'carto',
    label: 'Straatkaart (OSM)',
    url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png',
    attr: '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> © CARTO',
    maxZoom: 20,
    subdomains: 'abcd',
    cachePrefix: 'carto'
  },
  {
    id: 'osm',
    label: 'OpenStreetMap',
    url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    attr: '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>',
    maxZoom: 19,
    cachePrefix: 'osm'
  },
  {
    id: 'topo',
    label: 'Terrein (OpenTopo)',
    url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
    attr: '© OSM © OpenTopoMap (CC-BY-SA)',
    maxZoom: 17,
    subdomains: 'abc',
    cachePrefix: 'topo'
  }
];

/** Regio’s die je één keer kunt downloaden voor offline gebruik. */
const OFFLINE_REGIONS = {
  vlaanderen: {
    id: 'vlaanderen',
    name: 'Vlaanderen',
    west: 2.53, south: 50.67, east: 5.92, north: 51.51,
    minZ: 7, maxZ: 13
  },
  belgie: {
    id: 'belgie',
    name: 'België',
    west: 2.5, south: 49.45, east: 6.4, north: 51.55,
    minZ: 7, maxZ: 12
  }
};

const TILE_DB_NAME = 'lc-map-tiles-v1';
const TILE_STORE = 'tiles';
const TILE_META_KEY = 'lc-map-tiles-meta-v1';

function lon2tile(lon, z) {
  return Math.floor((lon + 180) / 360 * Math.pow(2, z));
}
function lat2tile(lat, z) {
  const r = lat * Math.PI / 180;
  return Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * Math.pow(2, z));
}

function openTileDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(TILE_DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(TILE_STORE)) db.createObjectStore(TILE_STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function tileGet(key) {
  const db = await openTileDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(TILE_STORE, 'readonly');
    const r = tx.objectStore(TILE_STORE).get(key);
    r.onsuccess = () => resolve(r.result || null);
    r.onerror = () => reject(r.error);
  });
}
async function tilePut(key, blob) {
  const db = await openTileDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(TILE_STORE, 'readwrite');
    tx.objectStore(TILE_STORE).put(blob, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function tileCount() {
  const db = await openTileDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(TILE_STORE, 'readonly');
    const r = tx.objectStore(TILE_STORE).count();
    r.onsuccess = () => resolve(r.result || 0);
    r.onerror = () => reject(r.error);
  });
}
async function tileClear() {
  const db = await openTileDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(TILE_STORE, 'readwrite');
    tx.objectStore(TILE_STORE).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
function loadTileMeta() {
  try { return JSON.parse(localStorage.getItem(TILE_META_KEY) || '{}') || {}; }
  catch { return {}; }
}
function saveTileMeta(m) {
  try { localStorage.setItem(TILE_META_KEY, JSON.stringify(m)); } catch (_) {}
}
function tileKey(prefix, z, x, y) {
  return prefix + '/' + z + '/' + x + '/' + y;
}
function expandTileUrl(template, z, x, y, subdomains) {
  let url = template.replace('{z}', z).replace('{x}', x).replace('{y}', y);
  if (subdomains && url.indexOf('{s}') >= 0) {
    const s = subdomains[Math.abs(x + y) % subdomains.length];
    url = url.replace('{s}', s);
  }
  return url;
}

/** Lokaal gebundeld tegelpad (standaard offline Vlaanderen). */
function bundledTileUrl(prefix, z, x, y) {
  return 'assets/maps/tiles/' + prefix + '/' + z + '/' + x + '/' + y + '.png';
}

function tryLoadImage(url) {
  return new Promise((resolve) => {
    const test = new Image();
    test.onload = () => resolve(true);
    test.onerror = () => resolve(false);
    test.src = url;
  });
}

/** Leaflet-laag: 1) gebundelde assets 2) IndexedDB 3) netwerk + cache. */
function createCachingTileLayer(L, layerDef) {
  const prefix = layerDef.cachePrefix || layerDef.id;
  const Layer = L.TileLayer.extend({
    createTile(coords, done) {
      const img = document.createElement('img');
      img.alt = '';
      img.setAttribute('role', 'presentation');
      const z = coords.z, x = coords.x, y = coords.y;
      const key = tileKey(prefix, z, x, y);
      const remote = this.getTileUrl(coords);
      const bundled = bundledTileUrl(prefix, z, x, y);

      const finish = (blobOrUrl) => {
        const src = typeof blobOrUrl === 'string' ? blobOrUrl : URL.createObjectURL(blobOrUrl);
        img.onload = () => {
          if (typeof blobOrUrl !== 'string') {
            try { URL.revokeObjectURL(src); } catch (_) {}
          }
          done(null, img);
        };
        img.onerror = () => done(new Error('tile load failed'), img);
        img.src = src;
      };

      tryLoadImage(bundled).then((ok) => {
        if (ok) { finish(bundled); return; }
        return tileGet(key).then((blob) => {
          if (blob) { finish(blob); return; }
          return fetch(remote, { mode: 'cors', credentials: 'omit' })
            .then((res) => {
              if (!res.ok) throw new Error('HTTP ' + res.status);
              return res.blob();
            })
            .then(async (blob) => {
              try { await tilePut(key, blob); } catch (_) {}
              finish(blob);
            })
            .catch(() => finish(remote));
        });
      }).catch(() => finish(remote));

      return img;
    }
  });
  const opts = {
    maxZoom: layerDef.maxZoom || 19,
    attribution: layerDef.attr,
    crossOrigin: true
  };
  if (layerDef.subdomains) opts.subdomains = layerDef.subdomains;
  return new Layer(layerDef.url, opts);
}

/** Download tegels voor een regio (één keer online → daarna offline). */
async function downloadRegionTiles(region, layerDef, onProgress) {
  const prefix = layerDef.cachePrefix || layerDef.id;
  const subs = layerDef.subdomains || 'a';
  let done = 0, errors = 0;
  const jobs = [];
  for (let z = region.minZ; z <= region.maxZ; z++) {
    const x0 = lon2tile(region.west, z);
    const x1 = lon2tile(region.east, z);
    const y0 = lat2tile(region.north, z);
    const y1 = lat2tile(region.south, z);
    for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) {
      for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) {
        jobs.push({ z, x, y });
      }
    }
  }
  const total = jobs.length;
  const concurrency = 6;
  let idx = 0;
  async function worker() {
    while (idx < jobs.length) {
      const i = idx++;
      const { z, x, y } = jobs[i];
      const key = tileKey(prefix, z, x, y);
      try {
        const existing = await tileGet(key);
        if (!existing) {
          const url = expandTileUrl(layerDef.url, z, x, y, subs);
          const res = await fetch(url, { mode: 'cors', credentials: 'omit' });
          if (!res.ok) throw new Error(String(res.status));
          const blob = await res.blob();
          if (blob && blob.size > 50) await tilePut(key, blob);
          else errors++;
        }
      } catch (_) { errors++; }
      done++;
      if (onProgress && (done % 10 === 0 || done === total)) onProgress({ total, done, errors });
    }
  }
  await Promise.all(Array.from({ length: concurrency }, () => worker()));
  if (onProgress) onProgress({ total, done, errors });
  const meta = loadTileMeta();
  meta[region.id] = {
    layer: layerDef.id,
    at: Date.now(),
    tiles: done - errors,
    minZ: region.minZ,
    maxZ: region.maxZ
  };
  saveTileMeta(meta);
  return { total, done, errors };
}

function loadLeaflet() {
  if (window.L) return Promise.resolve(window.L);
  return new Promise((resolve, reject) => {
    if (!document.querySelector('link[data-lc-leaflet]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'assets/vendor/leaflet/leaflet.css';
      link.setAttribute('data-lc-leaflet', '1');
      document.head.appendChild(link);
    }
    const s = document.createElement('script');
    s.src = 'assets/vendor/leaflet/leaflet.js';
    s.async = true;
    s.onload = () => {
      if (window.L) {
        try { window.L.Icon.Default.imagePath = 'assets/vendor/leaflet/images/'; } catch (_) {}
        resolve(window.L);
      } else reject(new Error('Leaflet niet geladen'));
    };
    s.onerror = () => reject(new Error('Leaflet script mislukt'));
    document.head.appendChild(s);
  });
}

export function createMapsApp() {
  const root = document.createElement('div');
  root.className = 'app-panel maps-app atlas-app';

  let items = loadMeta();
  const urlCache = new Map();
  let activeId = null;
  let scale = 1, panX = 0, panY = 0;
  let dragging = false, lastX = 0, lastY = 0;
  /** @type {'plates'|'map'} */
  let viewMode = 'map';
  let leafletMap = null;
  let leafletLayer = null;
  let activeLayerId = 'carto';
  let activePlaceId = 'vlaanderen';

  seedBundledMaps().then(() => {
    items = loadMeta();
    renderShell();
    if (viewMode === 'plates') showPlate(activeId);
    else ensureMap();
  });

  // —— Shell: inhoudsopgave + plaat / interactieve kaart ——
  const shell = document.createElement('div');
  shell.className = 'atlas-shell';

  const toc = document.createElement('aside');
  toc.className = 'atlas-toc';
  const tocHead = document.createElement('div');
  tocHead.className = 'atlas-toc-head';
  tocHead.innerHTML = '<h2>Atlas</h2>';
  const modeSwitch = document.createElement('div');
  modeSwitch.className = 'atlas-mode-switch';
  modeSwitch.setAttribute('role', 'tablist');
  const modePlatesBtn = document.createElement('button');
  modePlatesBtn.type = 'button';
  modePlatesBtn.className = 'atlas-mode-btn';
  modePlatesBtn.textContent = 'Platen';
  modePlatesBtn.title = 'Klassieke atlasplaten (afbeeldingen)';
  const modeMapBtn = document.createElement('button');
  modeMapBtn.type = 'button';
  modeMapBtn.className = 'atlas-mode-btn';
  modeMapBtn.textContent = 'Kaart';
  modeMapBtn.title = 'Interactieve OpenStreetMap-kaart';
  modeSwitch.append(modePlatesBtn, modeMapBtn);
  tocHead.appendChild(modeSwitch);
  const tocList = document.createElement('div');
  tocList.className = 'atlas-toc-list';
  const tocActions = document.createElement('div');
  tocActions.className = 'atlas-toc-actions';
  const addBtn = document.createElement('button');
  addBtn.type = 'button';
  addBtn.className = 'atlas-add-btn';
  addBtn.textContent = '+ Kaart toevoegen';
  const fileIn = document.createElement('input');
  fileIn.type = 'file';
  fileIn.accept = 'image/*,.svg,image/svg+xml';
  fileIn.multiple = true;
  fileIn.hidden = true;
  tocActions.append(addBtn, fileIn);
  toc.append(tocHead, tocList, tocActions);

  const stage = document.createElement('section');
  stage.className = 'atlas-stage';

  const plateBar = document.createElement('div');
  plateBar.className = 'atlas-plate-bar';
  const prevBtn = document.createElement('button');
  prevBtn.type = 'button';
  prevBtn.className = 'atlas-nav-btn';
  prevBtn.textContent = '‹';
  prevBtn.title = 'Vorige plaat';
  const plateMeta = document.createElement('div');
  plateMeta.className = 'atlas-plate-meta';
  const plateTitle = document.createElement('h3');
  plateTitle.className = 'atlas-plate-title';
  plateTitle.textContent = 'Kies een kaart';
  const plateInfo = document.createElement('p');
  plateInfo.className = 'atlas-plate-info';
  plateMeta.append(plateTitle, plateInfo);
  const nextBtn = document.createElement('button');
  nextBtn.type = 'button';
  nextBtn.className = 'atlas-nav-btn';
  nextBtn.textContent = '›';
  nextBtn.title = 'Volgende plaat';
  const zoomGroup = document.createElement('div');
  zoomGroup.className = 'atlas-zoom';
  const zoomOutBtn = document.createElement('button');
  zoomOutBtn.type = 'button';
  zoomOutBtn.className = 'atlas-zoom-btn';
  zoomOutBtn.textContent = '−';
  const zoomLabel = document.createElement('span');
  zoomLabel.className = 'atlas-zoom-label';
  zoomLabel.textContent = '100%';
  const zoomInBtn = document.createElement('button');
  zoomInBtn.type = 'button';
  zoomInBtn.className = 'atlas-zoom-btn';
  zoomInBtn.textContent = '+';
  const zoomReset = document.createElement('button');
  zoomReset.type = 'button';
  zoomReset.className = 'atlas-zoom-btn atlas-zoom-reset';
  zoomReset.textContent = 'Passend';
  zoomGroup.append(zoomOutBtn, zoomLabel, zoomInBtn, zoomReset);
  plateBar.append(prevBtn, plateMeta, nextBtn, zoomGroup);

  const plateFrame = document.createElement('div');
  plateFrame.className = 'atlas-plate-frame';
  const plateInner = document.createElement('div');
  plateInner.className = 'atlas-plate-inner';
  const plateImg = document.createElement('img');
  plateImg.className = 'atlas-plate-img';
  plateImg.alt = '';
  plateImg.draggable = false;
  const plateEmpty = document.createElement('div');
  plateEmpty.className = 'atlas-plate-empty';
  plateEmpty.innerHTML = '<p>Open een plaat via de inhoudsopgave.</p><p class="atlas-hint">Of voeg zelf een landkaart of plattegrond toe.</p>';
  plateInner.append(plateImg, plateEmpty);
  plateFrame.append(plateInner);

  const plateFoot = document.createElement('div');
  plateFoot.className = 'atlas-plate-foot';
  const attrEl = document.createElement('span');
  attrEl.className = 'atlas-attr';
  const delBtn = document.createElement('button');
  delBtn.type = 'button';
  delBtn.className = 'atlas-del-btn';
  delBtn.textContent = 'Verwijderen';
  delBtn.hidden = true;
  plateFoot.append(attrEl, delBtn);

  // Interactieve OSM-kaart (Leaflet)
  const mapPanel = document.createElement('div');
  mapPanel.className = 'atlas-map-panel';
  mapPanel.hidden = true;
  const mapToolbar = document.createElement('div');
  mapToolbar.className = 'atlas-map-toolbar';
  const layerSelect = document.createElement('select');
  layerSelect.className = 'atlas-map-layer';
  layerSelect.title = 'Kaartstijl';
  for (const ly of OSM_LAYERS) {
    const opt = document.createElement('option');
    opt.value = ly.id;
    opt.textContent = ly.label;
    layerSelect.appendChild(opt);
  }
  const mapStatus = document.createElement('span');
  mapStatus.className = 'atlas-map-status';
  mapStatus.textContent = 'OpenStreetMap · online tegels';
  mapToolbar.append(layerSelect, mapStatus);
  const mapEl = document.createElement('div');
  mapEl.className = 'atlas-map-el';
  mapEl.setAttribute('role', 'application');
  mapEl.setAttribute('aria-label', 'Interactieve kaart');
  mapPanel.append(mapToolbar, mapEl);

  stage.append(plateBar, plateFrame, plateFoot, mapPanel);
  shell.append(toc, stage);
  root.append(shell);

  function setViewMode(mode) {
    viewMode = mode === 'plates' ? 'plates' : 'map';
    const isMap = viewMode === 'map';
    modeMapBtn.classList.toggle('is-active', isMap);
    modePlatesBtn.classList.toggle('is-active', !isMap);
    root.classList.toggle('atlas-mode-map', isMap);
    root.classList.toggle('atlas-mode-plates', !isMap);
    plateBar.hidden = isMap;
    plateFrame.hidden = isMap;
    plateFoot.hidden = isMap;
    mapPanel.hidden = !isMap;
    // display:flex in CSS overschrijft anders [hidden] — forceer visibility
    mapPanel.style.display = isMap ? '' : 'none';
    plateBar.style.display = isMap ? 'none' : '';
    plateFrame.style.display = isMap ? 'none' : '';
    plateFoot.style.display = isMap ? 'none' : '';
    addBtn.hidden = isMap;
    renderShell();
    if (isMap) ensureMap();
    else if (activeId) showPlate(activeId);
  }
  modeMapBtn.onclick = () => setViewMode('map');
  modePlatesBtn.onclick = () => setViewMode('plates');

  function setBaseLayer(id) {
    const L = window.L;
    if (!L || !leafletMap) return;
    const def = OSM_LAYERS.find(l => l.id === id) || OSM_LAYERS[0];
    activeLayerId = def.id;
    layerSelect.value = def.id;
    if (leafletLayer) leafletMap.removeLayer(leafletLayer);
    leafletLayer = createCachingTileLayer(L, def);
    leafletLayer.addTo(leafletMap);
    updateMapStatus();
  }

  async function updateMapStatus() {
    const def = OSM_LAYERS.find(l => l.id === activeLayerId) || OSM_LAYERS[0];
    let n = 0;
    try { n = await tileCount(); } catch (_) {}
    const online = typeof navigator !== 'undefined' ? navigator.onLine : true;
    // Gebundelde Vlaanderen-tegels (z7–12) zitten in de app-assets
    if (!online) {
      mapStatus.textContent = def.label + ' · offline · Vlaanderen meegeleverd' + (n ? ' + ' + n + ' extra' : '');
    } else {
      mapStatus.textContent = def.label + ' · Vlaanderen standaard offline · online voor updates';
    }
  }

  function flyToPlace(place) {
    if (!leafletMap || !place) return;
    activePlaceId = place.id;
    leafletMap.flyTo([place.lat, place.lon], place.zoom, { duration: 0.8 });
    renderShell();
  }

  async function ensureMap() {
    try {
      mapStatus.textContent = 'Kaart laden…';
      const L = await loadLeaflet();
      if (!leafletMap) {
        // eigen zoomControl: false + handmatige knoppen (betrouwbaarder in Tauri/webview)
        leafletMap = L.map(mapEl, {
          center: [51.05, 4.15],
          zoom: 8,
          zoomControl: false,
          attributionControl: true,
          scrollWheelZoom: true,
          doubleClickZoom: true,
          touchZoom: true,
          boxZoom: true,
          keyboard: true
        });
        L.control.zoom({
          position: 'topleft',
          zoomInTitle: 'Inzoomen',
          zoomOutTitle: 'Uitzoomen'
        }).addTo(leafletMap);
        setBaseLayer(activeLayerId);
        // Klik op +/- forceren (sommige webviews blokkeren <a href="#">)
        mapEl.addEventListener('click', (ev) => {
          const t = ev.target.closest && ev.target.closest('.leaflet-control-zoom-in, .leaflet-control-zoom-out');
          if (!t || !leafletMap) return;
          ev.preventDefault();
          ev.stopPropagation();
          if (t.classList.contains('leaflet-control-zoom-in')) leafletMap.zoomIn();
          else leafletMap.zoomOut();
        }, true);
        const resize = () => { try { leafletMap.invalidateSize({ animate: false }); } catch (_) {} };
        setTimeout(resize, 50);
        setTimeout(resize, 200);
        setTimeout(resize, 500);
        if (typeof ResizeObserver !== 'undefined') {
          const ro = new ResizeObserver(() => resize());
          ro.observe(mapEl);
        }
      } else {
        setTimeout(() => { try { leafletMap.invalidateSize({ animate: false }); } catch (_) {} }, 50);
      }
      await updateMapStatus();
    } catch (e) {
      console.warn(e);
      mapStatus.textContent = 'Kaart kon niet laden — controleer internetverbinding.';
    }
  }

  layerSelect.onchange = () => setBaseLayer(layerSelect.value);

  // Extra zoomknoppen in de toolbar (altijd klikbaar)
  const zoomInTb = document.createElement('button');
  zoomInTb.type = 'button';
  zoomInTb.className = 'atlas-map-zoom-btn';
  zoomInTb.textContent = '+';
  zoomInTb.title = 'Inzoomen';
  zoomInTb.onclick = (e) => { e.preventDefault(); if (leafletMap) leafletMap.zoomIn(); };
  const zoomOutTb = document.createElement('button');
  zoomOutTb.type = 'button';
  zoomOutTb.className = 'atlas-map-zoom-btn';
  zoomOutTb.textContent = '−';
  zoomOutTb.title = 'Uitzoomen';
  zoomOutTb.onclick = (e) => { e.preventDefault(); if (leafletMap) leafletMap.zoomOut(); };
  mapToolbar.append(zoomInTb, zoomOutTb);

  const offlineBtn = document.createElement('button');
  offlineBtn.type = 'button';
  offlineBtn.className = 'atlas-map-offline-btn';
  offlineBtn.textContent = 'Update Vlaanderen';
  offlineBtn.title = 'Optioneel: tegels vernieuwen (internet nodig)';
  const offlineBeBtn = document.createElement('button');
  offlineBeBtn.type = 'button';
  offlineBeBtn.className = 'atlas-map-offline-btn';
  offlineBeBtn.textContent = 'België offline';
  offlineBeBtn.title = 'Download België voor offline gebruik';
  const clearTilesBtn = document.createElement('button');
  clearTilesBtn.type = 'button';
  clearTilesBtn.className = 'atlas-map-offline-btn atlas-map-offline-clear';
  clearTilesBtn.textContent = 'Cache legen';
  clearTilesBtn.title = 'Verwijder opgeslagen tegels';
  mapToolbar.append(offlineBtn, offlineBeBtn, clearTilesBtn);

  let downloading = false;
  async function runOfflineDownload(regionId) {
    if (downloading) return;
    const region = OFFLINE_REGIONS[regionId];
    const def = OSM_LAYERS.find(l => l.id === activeLayerId) || OSM_LAYERS[0];
    if (!region) return;
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      mapStatus.textContent = 'Geen internet — offline-download niet mogelijk.';
      return;
    }
    downloading = true;
    offlineBtn.disabled = true;
    offlineBeBtn.disabled = true;
    mapStatus.textContent = 'Downloaden: 0%…';
    try {
      const result = await downloadRegionTiles(region, def, ({ total, done, errors }) => {
        const pct = total ? Math.round(100 * done / total) : 0;
        mapStatus.textContent = 'Downloaden ' + region.name + ': ' + pct + '% (' + done + '/' + total + ')' +
          (errors ? ' · fouten: ' + errors : '');
      });
      mapStatus.textContent = region.name + ' offline klaar: ' + (result.done - result.errors) +
        ' tegels' + (result.errors ? ' (' + result.errors + ' mislukt)' : '') + '. Werkt nu zonder internet.';
      // Herlaad laag zodat cache gebruikt wordt
      if (leafletMap) setBaseLayer(activeLayerId);
    } catch (e) {
      console.warn(e);
      mapStatus.textContent = 'Download mislukt. Controleer internet en probeer opnieuw.';
    }
    downloading = false;
    offlineBtn.disabled = false;
    offlineBeBtn.disabled = false;
  }
  offlineBtn.onclick = () => runOfflineDownload('vlaanderen');
  offlineBeBtn.onclick = () => runOfflineDownload('belgie');
  clearTilesBtn.onclick = async () => {
    if (!confirm('Alle opgeslagen kaarttegels wissen?')) return;
    try {
      await tileClear();
      saveTileMeta({});
      mapStatus.textContent = 'Tegel-cache geleegd.';
      updateMapStatus();
    } catch (e) {
      mapStatus.textContent = 'Cache legen mislukt.';
    }
  };

  // Online/offline indicator
  window.addEventListener('online', () => updateMapStatus());
  window.addEventListener('offline', () => updateMapStatus());

  function orderedItems() {
    const by = Object.fromEntries(ATLAS_CHAPTERS.map(c => [c.id, []]));
    for (const it of items) {
      const ch = atlasChapter(it);
      (by[ch] || by.eigen).push(it);
    }
    const out = [];
    for (const c of ATLAS_CHAPTERS) out.push(...(by[c.id] || []));
    return out;
  }

  function renderShell() {
    tocList.replaceChildren();
    if (viewMode === 'map') {
      const sec = document.createElement('section');
      sec.className = 'atlas-toc-chapter';
      const h = document.createElement('h4');
      h.textContent = 'Plaatsen';
      const bl = document.createElement('p');
      bl.className = 'atlas-toc-blurb';
      bl.textContent = 'Spring naar een stad of regio';
      sec.append(h, bl);
      const ul = document.createElement('ul');
      ul.className = 'atlas-toc-plates';
      for (const p of OSM_PLACES) {
        const li = document.createElement('li');
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'atlas-toc-item' + (p.id === activePlaceId ? ' is-active' : '');
        btn.innerHTML = `<span class="atlas-page-num">◉</span><span class="atlas-page-title"></span>`;
        btn.querySelector('.atlas-page-title').textContent = p.name;
        btn.onclick = () => flyToPlace(p);
        li.append(btn);
        ul.append(li);
      }
      sec.append(ul);
      tocList.append(sec);
      const note = document.createElement('p');
      note.className = 'atlas-toc-blurb atlas-map-note';
      note.innerHTML = 'OpenStreetMap (ODbL). <strong>Vlaanderen is standaard offline</strong> (zoom 7–12). Optioneel: updates of België downloaden.';
      tocList.append(note);
      return;
    }
    const by = Object.fromEntries(ATLAS_CHAPTERS.map(c => [c.id, []]));
    for (const it of items) {
      const ch = atlasChapter(it);
      (by[ch] || by.eigen).push(it);
    }
    let page = 0;
    for (const ch of ATLAS_CHAPTERS) {
      const list = by[ch.id] || [];
      if (!list.length && ch.id !== 'eigen') continue;
      const sec = document.createElement('section');
      sec.className = 'atlas-toc-chapter';
      const h = document.createElement('h4');
      h.textContent = ch.label;
      const bl = document.createElement('p');
      bl.className = 'atlas-toc-blurb';
      bl.textContent = list.length ? `${list.length} plaat${list.length === 1 ? '' : 'en'}` : 'Nog geen kaarten';
      sec.append(h, bl);
      const ul = document.createElement('ul');
      ul.className = 'atlas-toc-plates';
      for (const it of list) {
        page++;
        const li = document.createElement('li');
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'atlas-toc-item' + (it.id === activeId ? ' is-active' : '');
        btn.innerHTML = `<span class="atlas-page-num">${String(page).padStart(2, '0')}</span><span class="atlas-page-title"></span>`;
        btn.querySelector('.atlas-page-title').textContent = it.title || 'Naamloos';
        btn.onclick = () => { setViewMode('plates'); showPlate(it.id); };
        li.append(btn);
        ul.append(li);
      }
      sec.append(ul);
      tocList.append(sec);
    }
  }

  async function resolveUrl(it) {
    if (urlCache.has(it.id)) return urlCache.get(it.id);
    try {
      const blob = await idbGet(it.id);
      if (blob) {
        const url = URL.createObjectURL(blob);
        urlCache.set(it.id, url);
        return url;
      }
    } catch (_) {}
    const bundled = BUNDLED_MAPS.find(m => m.id === it.id);
    if (bundled) return bundled.src;
    return null;
  }

  function applyTransform() {
    plateImg.style.transform = `translate(${panX}px, ${panY}px) scale(${scale})`;
    zoomLabel.textContent = Math.round(scale * 100) + '%';
  }

  function fitPlate() {
    scale = 1;
    panX = 0;
    panY = 0;
    applyTransform();
  }

  async function showPlate(id) {
    activeId = id;
    renderShell();
    const order = orderedItems();
    const idx = order.findIndex(x => x.id === id);
    const it = idx >= 0 ? order[idx] : null;
    prevBtn.disabled = idx <= 0;
    nextBtn.disabled = idx < 0 || idx >= order.length - 1;

    if (!it) {
      plateImg.removeAttribute('src');
      plateImg.hidden = true;
      plateEmpty.hidden = false;
      plateTitle.textContent = 'Atlas';
      plateInfo.textContent = items.length ? 'Kies een plaat links' : 'Nog geen kaarten in de atlas';
      attrEl.textContent = '';
      delBtn.hidden = true;
      return;
    }

    plateTitle.textContent = it.title || 'Kaart';
    plateInfo.textContent = `Plaat ${idx + 1} van ${order.length}` + (it.bundled ? ' · Meegeleverd' : ' · Eigen');
    attrEl.textContent = [it.license, it.attribution].filter(Boolean).join(' · ');
    delBtn.hidden = false;

    const url = await resolveUrl(it);
    fitPlate();
    if (url) {
      plateEmpty.hidden = true;
      plateImg.hidden = false;
      plateImg.alt = it.title || '';
      plateImg.src = url;
    } else {
      plateImg.hidden = true;
      plateEmpty.hidden = false;
      plateEmpty.innerHTML = '<p>Kaartbestand niet gevonden.</p>';
    }
  }

  prevBtn.onclick = () => {
    const order = orderedItems();
    const idx = order.findIndex(x => x.id === activeId);
    if (idx > 0) showPlate(order[idx - 1].id);
  };
  nextBtn.onclick = () => {
    const order = orderedItems();
    const idx = order.findIndex(x => x.id === activeId);
    if (idx >= 0 && idx < order.length - 1) showPlate(order[idx + 1].id);
  };
  zoomInBtn.onclick = () => { scale = Math.min(5, scale * 1.25); applyTransform(); };
  zoomOutBtn.onclick = () => { scale = Math.max(0.25, scale / 1.25); applyTransform(); };
  zoomReset.onclick = () => fitPlate();

  plateFrame.addEventListener('wheel', e => {
    if (plateImg.hidden) return;
    e.preventDefault();
    const f = e.deltaY < 0 ? 1.1 : 1 / 1.1;
    scale = Math.min(5, Math.max(0.25, scale * f));
    applyTransform();
  }, { passive: false });

  plateFrame.addEventListener('pointerdown', e => {
    if (plateImg.hidden || e.button !== 0) return;
    dragging = true;
    lastX = e.clientX;
    lastY = e.clientY;
    plateFrame.setPointerCapture(e.pointerId);
    plateFrame.classList.add('is-dragging');
  });
  plateFrame.addEventListener('pointermove', e => {
    if (!dragging) return;
    panX += e.clientX - lastX;
    panY += e.clientY - lastY;
    lastX = e.clientX;
    lastY = e.clientY;
    applyTransform();
  });
  const endDrag = e => {
    if (!dragging) return;
    dragging = false;
    plateFrame.classList.remove('is-dragging');
    try { plateFrame.releasePointerCapture(e.pointerId); } catch (_) {}
  };
  plateFrame.addEventListener('pointerup', endDrag);
  plateFrame.addEventListener('pointercancel', endDrag);

  delBtn.onclick = async () => {
    if (!activeId || !confirm('Deze kaart uit de atlas verwijderen?')) return;
    const id = activeId;
    items = items.filter(x => x.id !== id);
    saveMeta(items);
    await idbDel(id);
    if (urlCache.has(id)) {
      try { URL.revokeObjectURL(urlCache.get(id)); } catch (_) {}
      urlCache.delete(id);
    }
    const order = orderedItems();
    activeId = order[0] ? order[0].id : null;
    renderShell();
    showPlate(activeId);
  };

  addBtn.onclick = () => fileIn.click();
  fileIn.onchange = async () => {
    const files = Array.from(fileIn.files || []);
    fileIn.value = '';
    let lastId = null;
    for (const f of files) {
      const isImg = f.type.startsWith('image/') || f.type === 'image/svg+xml' || /\.svg$/i.test(f.name);
      if (!isImg) continue;
      const id = uid();
      try {
        await idbPut(id, f);
        items.unshift({
          id,
          title: f.name.replace(/\.[^.]+$/, '').replace(/[_]+/g, ' '),
          fileName: f.name,
          added: Date.now()
        });
        lastId = id;
      } catch (e) {
        console.warn('Kaart opslaan mislukt', e);
        alert('Kon “' + f.name + '” niet opslaan (mogelijk te groot).');
      }
    }
    saveMeta(items);
    renderShell();
    if (lastId) showPlate(lastId);
  };

  // Eerste weergave: interactieve kaart (Google Maps-gevoel)
  setViewMode('map');

  return { root };
}
