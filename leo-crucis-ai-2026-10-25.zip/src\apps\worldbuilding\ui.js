/**
 * Worldbuilding Studio — UI helpers
 */
import { el, svgIcon } from '../../core/dom.js';
import { ICONS } from './constants.js';

export function icon(name, size = 18) {
  return svgIcon(ICONS[name] || ICONS.box, { width: size, height: size });
}
export function btn(label, opts = {}) {
  const b = el('button', `wb-btn ${opts.cls || ''}`.trim());
  if (opts.icon) b.appendChild(icon(opts.icon, opts.iconSize || 16));
  if (label) b.appendChild(el('span', '', label));
  if (opts.title) b.title = opts.title;
  b.setAttribute('aria-label', opts.aria || opts.title || label || 'knop');
  b.type = opts.type || 'button';
  if (opts.onClick) b.addEventListener('click', opts.onClick);
  if (opts.disabled) b.disabled = true;
  return b;
}
export function iconBtn(iconName, opts = {}) {
  return btn('', { ...opts, icon: iconName, cls: `wb-btn-icon ${opts.cls || ''}`.trim(), aria: opts.aria || opts.title || iconName });
}
export function input(opts = {}) {
  const i = el('input', `wb-input ${opts.cls || ''}`.trim());
  i.type = opts.type || 'text';
  if (opts.placeholder) i.placeholder = opts.placeholder;
  if (opts.value != null) i.value = opts.value;
  if (opts.aria) i.setAttribute('aria-label', opts.aria);
  if (opts.onInput) i.addEventListener('input', opts.onInput);
  if (opts.onChange) i.addEventListener('change', opts.onChange);
  return i;
}
export function textarea(opts = {}) {
  const t = el('textarea', `wb-textarea ${opts.cls || ''}`.trim());
  if (opts.placeholder) t.placeholder = opts.placeholder;
  if (opts.value != null) t.value = opts.value;
  if (opts.rows) t.rows = opts.rows;
  if (opts.aria) t.setAttribute('aria-label', opts.aria);
  if (opts.onInput) t.addEventListener('input', opts.onInput);
  return t;
}
export function select(options, opts = {}) {
  const s = el('select', `wb-select ${opts.cls || ''}`.trim());
  if (opts.aria) s.setAttribute('aria-label', opts.aria);
  for (const o of options) {
    const opt = el('option', '', o.label);
    opt.value = o.id;
    if (o.id === opts.value) opt.selected = true;
    s.appendChild(opt);
  }
  if (opts.onChange) s.addEventListener('change', opts.onChange);
  return s;
}
export function field(labelText, control) {
  const wrap = el('div', 'wb-field');
  wrap.appendChild(el('label', 'wb-label', labelText));
  wrap.appendChild(control);
  return wrap;
}
export function modal({ title, body, actions = [], onClose }) {
  const overlay = el('div', 'wb-modal-overlay');
  const dialog = el('div', 'wb-modal');
  dialog.setAttribute('role', 'dialog');
  dialog.setAttribute('aria-modal', 'true');
  const head = el('div', 'wb-modal-head');
  head.appendChild(el('h2', 'wb-modal-title', title));
  head.appendChild(iconBtn('x', { title: 'Sluiten', onClick: () => { overlay.remove(); onClose?.(); } }));
  const content = el('div', 'wb-modal-body');
  if (typeof body === 'string') content.textContent = body;
  else if (body) content.appendChild(body);
  const foot = el('div', 'wb-modal-foot');
  for (const a of actions) {
    foot.appendChild(btn(a.label, {
      cls: a.primary ? 'wb-btn-primary' : a.danger ? 'wb-btn-danger' : '',
      onClick: async () => {
        if (a.onClick) { const r = await a.onClick(); if (r === false) return; }
        overlay.remove(); onClose?.();
      },
    }));
  }
  dialog.append(head, content, foot);
  overlay.appendChild(dialog);
  overlay.addEventListener('click', e => { if (e.target === overlay) { overlay.remove(); onClose?.(); } });
  return overlay;
}
export async function confirmDialog(message, { yes = 'Bevestigen', no = 'Annuleren', danger = false } = {}) {
  return new Promise(resolve => {
    const overlay = modal({
      title: 'Bevestigen', body: message,
      actions: [
        { label: no, onClick: () => resolve(false) },
        { label: yes, primary: !danger, danger, onClick: () => resolve(true) },
      ],
      onClose: () => resolve(false),
    });
    document.body.appendChild(overlay);
  });
}
export function toast(message, type = 'info') {
  let host = document.querySelector('.wb-toast-host');
  if (!host) { host = el('div', 'wb-toast-host'); document.body.appendChild(host); }
  const t = el('div', `wb-toast wb-toast-${type}`, message);
  host.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 2800);
}
export function emptyState({ icon: ic = 'box', title, text, action }) {
  const wrap = el('div', 'wb-empty');
  wrap.appendChild(icon(ic, 40));
  if (title) wrap.appendChild(el('h3', '', title));
  if (text) wrap.appendChild(el('p', '', text));
  if (action) wrap.appendChild(action);
  return wrap;
}
export function formatRelative(iso) {
  if (!iso) return '';
  try {
    const d = new Date(iso);
    const diff = Date.now() - d.getTime();
    const m = Math.floor(diff / 60000);
    if (m < 1) return 'zojuist';
    if (m < 60) return `${m} min. geleden`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h} u. geleden`;
    const days = Math.floor(h / 24);
    if (days < 7) return `${days} d. geleden`;
    return d.toLocaleDateString('nl-NL', { year: 'numeric', month: 'short', day: 'numeric' });
  } catch { return ''; }
}
export function debounce(fn, ms = 300) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}
export function statusBadge(status) {
  const map = { concept: 'Concept', development: 'In ontwikkeling', complete: 'Voltooid', archived: 'Gearchiveerd' };
  return el('span', `wb-badge wb-badge-${status}`, map[status] || status);
}
export function typeBadge(worldType) {
  const map = {
    'high-fantasy': 'High fantasy', 'dark-fantasy': 'Dark fantasy', 'low-fantasy': 'Low fantasy',
    'sci-fi': 'Sciencefiction', 'alt-history': 'Alt. geschiedenis', mythic: 'Mythologisch',
    steampunk: 'Steampunk', other: 'Anders',
  };
  return el('span', 'wb-badge wb-badge-type', map[worldType] || worldType);
}
