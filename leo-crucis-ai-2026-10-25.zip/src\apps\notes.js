// Notities-app — offline, localStorage.

const KEY = 'lc-notes-v1';

function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '[]');
    return Array.isArray(raw) ? raw : [];
  } catch { return []; }
}
function save(list) {
  try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) { console.warn(e); }
}
function uid() { return 'n-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

export function createNotesApp() {
  const root = document.createElement('div');
  root.className = 'app-panel notes-app';

  let notes = load();
  let activeId = notes[0]?.id || null;

  const sidebar = document.createElement('aside');
  sidebar.className = 'notes-side';
  const sideHead = document.createElement('div');
  sideHead.className = 'notes-side-head';
  const newBtn = document.createElement('button');
  newBtn.type = 'button'; newBtn.className = 'notes-new'; newBtn.textContent = '+ Nieuwe notitie';
  sideHead.append(newBtn);
  const list = document.createElement('ul');
  list.className = 'notes-list';
  sidebar.append(sideHead, list);

  const editor = document.createElement('div');
  editor.className = 'notes-editor';
  const titleIn = document.createElement('input');
  titleIn.type = 'text'; titleIn.className = 'notes-title'; titleIn.placeholder = 'Titel';
  titleIn.setAttribute('aria-label', 'Titel');
  const bodyIn = document.createElement('textarea');
  bodyIn.className = 'notes-body'; bodyIn.placeholder = 'Schrijf hier…';
  bodyIn.setAttribute('aria-label', 'Inhoud');
  const meta = document.createElement('div');
  meta.className = 'notes-meta';
  const delBtn = document.createElement('button');
  delBtn.type = 'button'; delBtn.className = 'notes-del'; delBtn.textContent = 'Verwijderen';
  meta.append(delBtn);
  editor.append(titleIn, bodyIn, meta);

  root.append(sidebar, editor);

  let saveTimer = null;
  function persistSoon() {
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(() => save(notes), 250);
  }

  function current() { return notes.find(n => n.id === activeId) || null; }

  function renderList() {
    list.replaceChildren();
    if (!notes.length) {
      const li = document.createElement('li');
      li.className = 'notes-empty';
      li.textContent = 'Nog geen notities';
      list.append(li);
      return;
    }
    notes
      .slice()
      .sort((a, b) => (b.updated || 0) - (a.updated || 0))
      .forEach(n => {
        const li = document.createElement('li');
        li.className = 'notes-item' + (n.id === activeId ? ' is-active' : '');
        const t = document.createElement('div');
        t.className = 'notes-item-title';
        t.textContent = n.title || 'Naamloos';
        const p = document.createElement('div');
        p.className = 'notes-item-preview';
        p.textContent = (n.body || '').slice(0, 80) || 'Leeg';
        li.append(t, p);
        li.onclick = () => { activeId = n.id; render(); };
        list.append(li);
      });
  }

  function renderEditor() {
    const n = current();
    if (!n) {
      titleIn.value = '';
      bodyIn.value = '';
      titleIn.disabled = true;
      bodyIn.disabled = true;
      delBtn.disabled = true;
      return;
    }
    titleIn.disabled = false;
    bodyIn.disabled = false;
    delBtn.disabled = false;
    if (document.activeElement !== titleIn) titleIn.value = n.title || '';
    if (document.activeElement !== bodyIn) bodyIn.value = n.body || '';
  }

  function render() {
    renderList();
    renderEditor();
  }

  newBtn.onclick = () => {
    const n = { id: uid(), title: '', body: '', updated: Date.now(), created: Date.now() };
    notes.unshift(n);
    activeId = n.id;
    save(notes);
    render();
    titleIn.focus();
  };

  titleIn.oninput = () => {
    const n = current();
    if (!n) return;
    n.title = titleIn.value;
    n.updated = Date.now();
    persistSoon();
    renderList();
  };
  bodyIn.oninput = () => {
    const n = current();
    if (!n) return;
    n.body = bodyIn.value;
    n.updated = Date.now();
    persistSoon();
    renderList();
  };
  delBtn.onclick = () => {
    const n = current();
    if (!n) return;
    if (!confirm('Notitie verwijderen?')) return;
    notes = notes.filter(x => x.id !== n.id);
    activeId = notes[0]?.id || null;
    save(notes);
    render();
  };

  if (!notes.length) {
    notes.push({ id: uid(), title: 'Welkom', body: 'Dit is je notitieblok in Leo Crucis.\n\nAlles blijft lokaal op dit apparaat.', updated: Date.now(), created: Date.now() });
    activeId = notes[0].id;
    save(notes);
  }
  render();
  return { root };
}
