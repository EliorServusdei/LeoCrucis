/**
 * Timer / stopwatch — Leo Crucis mini-app.
 * Presets: 5 / 15 / 25 (pomodoro) / 45 min + vrij.
 */

function el(tag, className, text) {
  const n = document.createElement(tag);
  if (className) n.className = className;
  if (text != null) n.textContent = text;
  return n;
}

function pad(n) {
  return String(n).padStart(2, '0');
}

function formatMs(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}:${pad(m)}:${pad(sec)}`;
  return `${pad(m)}:${pad(sec)}`;
}

export function createTimerApp() {
  const root = el('div', 'app-panel mini-app-root timer-app');
  root.setAttribute('data-kind', 'timer');
  root.setAttribute('aria-label', 'Timer');

  let mode = 'timer'; // timer | stopwatch
  let durationMs = 25 * 60 * 1000;
  let remainingMs = durationMs;
  let elapsedMs = 0;
  let running = false;
  let endsAt = 0;
  let startedAt = 0;
  let tickId = null;
  let destroyed = false;

  const title = el('h1', 'timer-title', 'Timer');
  root.append(title);

  const modeBar = el('div', 'timer-modes');
  const btnTimer = el('button', 'timer-mode is-active', 'Aftellen');
  btnTimer.type = 'button';
  const btnSw = el('button', 'timer-mode', 'Stopwatch');
  btnSw.type = 'button';
  modeBar.append(btnTimer, btnSw);
  root.append(modeBar);

  const display = el('div', 'timer-display', formatMs(remainingMs));
  display.setAttribute('aria-live', 'polite');
  root.append(display);

  const presets = el('div', 'timer-presets');
  const presetVals = [
    [5, '5 min'],
    [15, '15 min'],
    [25, '25 min'],
    [45, '45 min']
  ];
  for (const [min, lab] of presetVals) {
    const b = el('button', 'timer-preset', lab);
    b.type = 'button';
    b.dataset.min = String(min);
    presets.append(b);
  }
  root.append(presets);

  const custom = el('div', 'timer-custom');
  const minIn = el('input', 'timer-min-in');
  minIn.type = 'number';
  minIn.min = '0';
  minIn.max = '180';
  minIn.value = '25';
  minIn.setAttribute('aria-label', 'Minuten');
  const setBtn = el('button', 'timer-btn', 'Instellen');
  setBtn.type = 'button';
  custom.append(el('span', 'timer-custom-lab', 'Minuten'), minIn, setBtn);
  root.append(custom);

  const actions = el('div', 'timer-actions');
  const startBtn = el('button', 'timer-btn timer-btn-primary', 'Start');
  startBtn.type = 'button';
  const resetBtn = el('button', 'timer-btn', 'Reset');
  resetBtn.type = 'button';
  actions.append(startBtn, resetBtn);
  root.append(actions);

  const status = el('div', 'timer-status', '');
  root.append(status);

  function stopTick() {
    if (tickId) {
      clearInterval(tickId);
      tickId = null;
    }
  }

  function paint() {
    if (mode === 'timer') {
      display.textContent = formatMs(remainingMs);
      display.classList.toggle('is-done', remainingMs <= 0 && !running);
    } else {
      display.textContent = formatMs(elapsedMs);
      display.classList.remove('is-done');
    }
    startBtn.textContent = running ? 'Pauze' : remainingMs <= 0 && mode === 'timer' ? 'Opnieuw' : 'Start';
    presets.hidden = mode === 'stopwatch';
    custom.hidden = mode === 'stopwatch';
    title.textContent = mode === 'timer' ? 'Timer' : 'Stopwatch';
  }

  function onDone() {
    running = false;
    stopTick();
    remainingMs = 0;
    paint();
    status.textContent = 'Klaar!';
    try {
      if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
        new Notification('Leo Crucis Timer', { body: 'De timer is afgelopen.' });
      }
    } catch (_) {}
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.connect(g);
      g.connect(ctx.destination);
      o.frequency.value = 880;
      g.gain.value = 0.08;
      o.start();
      setTimeout(() => {
        o.stop();
        ctx.close();
      }, 400);
    } catch (_) {}
  }

  function tick() {
    if (!running || destroyed) return;
    if (mode === 'timer') {
      remainingMs = Math.max(0, endsAt - Date.now());
      if (remainingMs <= 0) onDone();
      else paint();
    } else {
      elapsedMs = Date.now() - startedAt;
      paint();
    }
  }

  function start() {
    if (mode === 'timer' && remainingMs <= 0) {
      remainingMs = durationMs;
    }
    if (mode === 'timer' && remainingMs <= 0) return;
    running = true;
    status.textContent = '';
    if (mode === 'timer') endsAt = Date.now() + remainingMs;
    else startedAt = Date.now() - elapsedMs;
    stopTick();
    tickId = setInterval(tick, 200);
    paint();
  }

  function pause() {
    if (!running) return;
    tick();
    running = false;
    stopTick();
    paint();
  }

  function reset() {
    running = false;
    stopTick();
    status.textContent = '';
    if (mode === 'timer') remainingMs = durationMs;
    else elapsedMs = 0;
    paint();
  }

  startBtn.onclick = () => {
    if (running) pause();
    else start();
  };
  resetBtn.onclick = reset;

  btnTimer.onclick = () => {
    if (mode === 'timer') return;
    pause();
    mode = 'timer';
    btnTimer.classList.add('is-active');
    btnSw.classList.remove('is-active');
    remainingMs = durationMs;
    paint();
  };
  btnSw.onclick = () => {
    if (mode === 'stopwatch') return;
    pause();
    mode = 'stopwatch';
    btnSw.classList.add('is-active');
    btnTimer.classList.remove('is-active');
    elapsedMs = 0;
    paint();
  };

  presets.onclick = (e) => {
    const b = e.target.closest('[data-min]');
    if (!b) return;
    const min = parseInt(b.dataset.min, 10);
    pause();
    durationMs = min * 60 * 1000;
    remainingMs = durationMs;
    minIn.value = String(min);
    status.textContent = '';
    paint();
  };

  setBtn.onclick = () => {
    const min = Math.max(0, Math.min(180, parseInt(minIn.value, 10) || 0));
    pause();
    durationMs = min * 60 * 1000;
    remainingMs = durationMs;
    status.textContent = '';
    paint();
  };

  paint();

  return {
    root,
    el: root,
    kind: 'timer',
    close() {
      destroyed = true;
      stopTick();
    },
    getState() {
      return { mode, durationMs, remainingMs, elapsedMs, running };
    },
    setState(s) {
      if (!s) return;
      pause();
      if (s.mode) mode = s.mode;
      if (s.durationMs) durationMs = s.durationMs;
      if (s.remainingMs != null) remainingMs = s.remainingMs;
      if (s.elapsedMs != null) elapsedMs = s.elapsedMs;
      paint();
    }
  };
}
