/**
 * ui/shortcuts.js — globale sneltoetsen (fase 4)
 *
 * Actief buiten invoervelden (input/textarea/contenteditable),
 * behalve Ctrl/Cmd+K en Escape.
 */

const SHORTCUTS = [
  { keys: 'Ctrl+K  of  /', action: 'Zoeken openen' },
  { keys: 'Alt+←', action: 'Terug' },
  { keys: 'Alt+→', action: 'Vooruit' },
  { keys: 'Alt+Home', action: 'Startscherm' },
  { keys: 'Ctrl+,', action: 'Instellingen' },
  { keys: '?', action: 'Dit overzicht' },
  { keys: 'Escape', action: 'Menu / overlay sluiten' },
];

/**
 * @param {object} deps
 * @param {() => void} deps.showSearch
 * @param {() => void} deps.showHome
 * @param {() => void} deps.showSettings
 * @param {() => void} [deps.goBack]
 * @param {() => void} [deps.goForward]
 * @param {() => void} [deps.closeOverlays]
 */
export function installShortcuts(deps) {
  const {
    showSearch,
    showHome,
    showSettings,
    goBack = () => { try { history.back(); } catch (_) {} },
    goForward = () => { try { history.forward(); } catch (_) {} },
    closeOverlays = () => {},
  } = deps;

  function isTypingTarget(el) {
    if (!el || el === document.body) return false;
    const tag = (el.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
    if (el.isContentEditable) return true;
    if (el.closest && el.closest('[contenteditable="true"]')) return true;
    return false;
  }

  function onKey(e) {
    const typing = isTypingTarget(e.target);
    const mod = e.ctrlKey || e.metaKey;
    const key = e.key;

    // Alt+← / Alt+→ / Alt+Home
    if (e.altKey && !mod && !e.shiftKey) {
      if (key === 'ArrowLeft') {
        e.preventDefault();
        goBack();
        return;
      }
      if (key === 'ArrowRight') {
        e.preventDefault();
        goForward();
        return;
      }
      if (key === 'Home') {
        e.preventDefault();
        showHome();
        return;
      }
    }

    // Ctrl/Cmd+K — zoeken (ook vanuit invoerveld)
    if (mod && !e.altKey && (key === 'k' || key === 'K')) {
      e.preventDefault();
      showSearch();
      return;
    }

    // Ctrl/Cmd+, — instellingen
    if (mod && !e.altKey && key === ',') {
      e.preventDefault();
      showSettings();
      return;
    }

    if (typing) return;

    // / — zoeken
    if (key === '/' && !mod && !e.altKey) {
      e.preventDefault();
      showSearch();
      return;
    }

    // ? — sneltoetsenkaart
    if (key === '?' || (e.shiftKey && key === '/')) {
      e.preventDefault();
      showShortcutsHelp();
      return;
    }

    // Escape — overlays
    if (key === 'Escape') {
      closeOverlays();
    }
  }

  document.addEventListener('keydown', onKey, true);

  return {
    list: SHORTCUTS,
    showHelp: showShortcutsHelp,
    uninstall() {
      document.removeEventListener('keydown', onKey, true);
    },
  };
}

export function showShortcutsHelp() {
  const existing = document.getElementById('lc-shortcuts-help');
  if (existing) {
    existing.remove();
    return;
  }

  const back = document.createElement('div');
  back.id = 'lc-shortcuts-help';
  back.className = 'lc-help-back';
  back.setAttribute('role', 'dialog');
  back.setAttribute('aria-label', 'Sneltoetsen');

  const box = document.createElement('div');
  box.className = 'lc-help-box';

  const h = document.createElement('h2');
  h.textContent = 'Sneltoetsen';
  box.appendChild(h);

  const table = document.createElement('div');
  table.className = 'lc-help-table';
  for (const row of SHORTCUTS) {
    const r = document.createElement('div');
    r.className = 'lc-help-row';
    const k = document.createElement('kbd');
    k.textContent = row.keys;
    const a = document.createElement('span');
    a.textContent = row.action;
    r.append(k, a);
    table.appendChild(r);
  }
  box.appendChild(table);

  const hint = document.createElement('p');
  hint.className = 'lc-help-hint';
  hint.textContent = 'Druk op ? of Escape om te sluiten.';
  box.appendChild(hint);

  const close = document.createElement('button');
  close.type = 'button';
  close.className = 'dlg-ok';
  close.textContent = 'Sluiten';
  close.onclick = () => back.remove();
  box.appendChild(close);

  back.appendChild(box);
  back.addEventListener('click', e => { if (e.target === back) back.remove(); });
  document.body.appendChild(back);
  close.focus();
}
