#!/usr/bin/env python3
"""Verplaats stad/<gebouw>/<id>.html -> stad/<gebouw>/<sectie>/<id>.html
   op basis van src/data/book-paths.json (nieuwe paden: gebouw/sectie/id).
   Draai vanuit de projectroot:  python3 tools/migrate-stad-sections.py
"""
import json, os, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STAD = ROOT / 'src' / 'stad'
PATHS = json.loads((ROOT / 'src' / 'data' / 'book-paths.json').read_text(encoding='utf-8'))

moved = skipped = missing = 0
for id_lower, rel in PATHS.items():
    parts = rel.split('/')
    if len(parts) < 3:
        print('skip (pad heeft geen sectie):', rel)
        skipped += 1
        continue
    gebouw, sectie, fname = parts[0], parts[1], parts[2]
    src = STAD / gebouw / f'{fname}.html'
    # ook oude locatie met id_lower als bestandsnaam
    if not src.exists():
        alt = STAD / gebouw / f'{id_lower}.html'
        if alt.exists():
            src = alt
    dst = STAD / gebouw / sectie / f'{fname}.html'
    if not src.exists():
        # misschien al verplaatst
        if dst.exists():
            skipped += 1
            continue
        print('MISSING', src)
        missing += 1
        continue
    if src.resolve() == dst.resolve():
        skipped += 1
        continue
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        print('exists, skip', dst)
        skipped += 1
        continue
    shutil.move(str(src), str(dst))
    moved += 1

print(f'Klaar: {moved} verplaatst, {skipped} overgeslagen, {missing} ontbrekend')
print('Draai daarna: node tools/build-search-index.mjs')
