/**
 * ui/recent-apps.js — Android-achtige recente-apps stack
 *
 * Houdt de lijst recentApps bij. UI-dialogen en overzicht blijven in app.js
 * of later in ui/mini-apps-view.js; hier alleen de data-API + limiet-dialog.
 *
 * Factory: createRecentAppsApi(deps)
 */

import { el } from '../core/dom.js';

/**
 * @param {object} deps
 * @param {() => object} deps.loadSettings
 * @param {(force?: boolean) => void} [deps.showSettings]
 * @param {() => string|null} [deps.getCurrentSection]
 * @param {() => {kind?: string}|null} [deps.getSplitLeft]
 * @param {() => {kind?: string}|null} [deps.getSplitRight]
 */
export function createRecentAppsApi(deps) {
  const {
    loadSettings,
    showSettings,
    getCurrentSection = () => null,
    getSplitLeft = () => null,
    getSplitRight = () => null
  } = deps;

  /** @type {{ id: string, kind: string, iconKind: string, title: string, hint: string, activate: Function, close: Function }[]} */
  let recentApps = [];

  function getList() {
    return recentApps;
  }

  function setList(arr) {
    const next = Array.isArray(arr) ? arr : [];
    recentApps.length = 0;
    for (const e of next) recentApps.push(e);
  }

  function getRecentAppsMax() {
    try {
      const n = Number(loadSettings().recentAppsMax);
      if (Number.isFinite(n) && n >= 1 && n <= 8) return Math.floor(n);
    } catch (_) {}
    return 3;
  }

  /** Popup bij bereikt app-limiet, met instellingen-knop. */
  function showRecentAppsLimitDialog(lim) {
    document.querySelectorAll('.dlg-back.lc-recent-limit-dlg').forEach(n => n.remove());
    const back = el('div', 'dlg-back lc-recent-limit-dlg');
    const box = el('div', 'dlg');
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-label', 'App-limiet bereikt');

    const msgRow = el('div', 'lc-limit-msg-row');
    const p = el('p', '', `Er staan al ${lim} apps open. Sluit 1 app of verhoog je limiet in Instellingen.`);
    const gear = el('button', 'lc-limit-gear');
    gear.type = 'button';
    gear.title = 'Instellingen openen';
    gear.setAttribute('aria-label', 'Instellingen — max. open apps');
    gear.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
    msgRow.append(p, gear);

    const row = el('div', 'dlg-row');
    const ok = el('button', 'primary', 'OK');
    ok.type = 'button';
    ok.onclick = () => back.remove();
    row.append(ok);
    box.append(msgRow, row);
    back.append(box);
    back.addEventListener('click', e => { if (e.target === back) back.remove(); });
    document.body.append(back);

    gear.onclick = () => {
      back.remove();
      if (typeof showSettings === 'function') {
        try { showSettings(true); } catch (_) {}
      }
    };
    ok.focus();
  }

  /** True als deze id al in de stack zit of er nog ruimte is; anders popup en false. */
  function canOpenNewRecent(id) {
    if (!id) return true;
    if (recentApps.some(e => e.id === id)) return true;
    const max = getRecentAppsMax();
    if (recentApps.length < max) return true;
    showRecentAppsLimitDialog(max);
    return false;
  }

  /**
   * Voegt een app toe aan recente apps (alleen als er ruimte is of hij al open stond).
   * @returns {boolean}
   */
  function pushRecentApp(entry) {
    if (!entry || !entry.id) return false;
    const existing = recentApps.find(e => e.id === entry.id);
    if (existing) {
      const kept = recentApps.filter(e => e.id !== entry.id);
      recentApps.length = 0;
      recentApps.push({
        id: entry.id,
        kind: entry.kind || existing.kind || 'app',
        iconKind: entry.iconKind || existing.iconKind || entry.kind || 'app',
        title: entry.title || existing.title || entry.id,
        hint: entry.hint || existing.hint || 'App',
        activate: entry.activate || existing.activate || (() => {}),
        close: entry.close || existing.close || (() => {})
      }, ...kept);
      return true;
    }
    if (!canOpenNewRecent(entry.id)) return false;
    if (recentApps.length >= getRecentAppsMax()) return false;
    recentApps.unshift({
      id: entry.id,
      kind: entry.kind || 'app',
      iconKind: entry.iconKind || entry.kind || 'app',
      title: entry.title || entry.id,
      hint: entry.hint || 'App',
      activate: entry.activate || (() => {}),
      close: entry.close || (() => {})
    });
    return true;
  }

  function removeRecentApp(id) {
    const i = recentApps.findIndex(e => e.id === id);
    if (i < 0) return null;
    const [e] = recentApps.splice(i, 1);
    return e;
  }

  function isRecentActive(id) {
    if (!id) return false;
    if (id === 'app-search' && document.body.classList.contains('search-open')) return true;
    const currentSection = getCurrentSection();
    if (currentSection && id === 'section-' + currentSection) return true;
    try {
      const splitLeft = getSplitLeft();
      const splitRight = getSplitRight();
      if (splitLeft && splitLeft.kind && id === 'app-' + splitLeft.kind) return true;
      if (splitRight && splitRight.kind && id === 'app-' + splitRight.kind) return true;
    } catch (_) {}
    const h = (location.hash || '').replace(/^#/, '').split('?')[0].split('+')[0];
    if (h === 'zoek' && id === 'app-search') return true;
    if (h && id === 'app-' + h) return true;
    if (h === 'bijbel' && id === 'app-bible') return true;
    if ((h === 'settings' || h === 'instellingen') && id === 'app-settings') return true;
    if ((h === 'focus' || h === 'studie') && id === 'app-focus') return true;
    return false;
  }

  /** Trim de stack tot max (houdt settings-entry als die er is). */
  function trimToMax(preferKeepId) {
    const max = getRecentAppsMax();
    while (recentApps.length > max) {
      let dropped = null;
      for (let j = recentApps.length - 1; j >= 0; j--) {
        if (preferKeepId && recentApps[j].id === preferKeepId) continue;
        dropped = recentApps.splice(j, 1)[0];
        break;
      }
      if (!dropped) break;
      try { if (typeof dropped.close === 'function') dropped.close(); } catch (_) {}
    }
  }

  return {
    getList,
    setList,
    getRecentAppsMax,
    canOpenNewRecent,
    pushRecentApp,
    removeRecentApp,
    isRecentActive,
    showRecentAppsLimitDialog,
    trimToMax,
    /** Live reference (zelfde array) — handig voor bestaande code die `recentApps` muteert. */
    get recentApps() { return recentApps; }
  };
}
