/**
 * core/books.js — laden/opslaan/indexeren van boeken.
 *
 * Gebruik:
 *   import { createBookApi } from './core/books.js';
 *   const books = createBookApi({ ...deps });
 */

import { textOf, detectType, whereOf, allItems } from './world-model.js';

/**
 * @param {object} deps
 * @param {() => object} deps.getWorld
 * @param {() => object} deps.getDetails          // browser localStorage-details
 * @param {() => object} deps.getBookCache
 * @param {(id, val) => void} deps.setBookCache
 * @param {() => object} deps.getExtra            // zoek-overlay
 * @param {(extra) => void} deps.setExtra
 * @param {() => object} deps.getRefsOverlay
 * @param {(refs) => void} deps.saveRefs
 * @param {boolean} deps.inTauri
 * @param {(path) => Promise<string>} deps.readFile
 * @param {(path, content) => Promise<void>} deps.writeFile
 * @param {(path) => Promise<void>} deps.deleteFile
 * @param {(extra) => void} deps.persistExtra     // saveExtra + setOverlay
 * @param {(refDoc) => object} deps.parseRef
 * @param {(ref) => string} deps.refScript
 * @param {() => object} deps.emptyRef
 * @param {(id) => string|null} deps.userPath
 * @param {(id) => string|null} deps.bundledUrl
 */
export function createBookApi(deps) {
  const {
    getWorld, getDetails, getBookCache, setBookCache,
    getExtra, setExtra, getRefsOverlay, saveRefs,
    inTauri, readFile, writeFile, deleteFile, persistExtra,
    parseRef, refScript, emptyRef, userPath, bundledUrl
  } = deps;

  function parseBook(text) {
    const doc = new DOMParser().parseFromString(text, 'text/html');
    return {
      title: (doc.title || '').trim(),
      html: (doc.querySelector('main') || doc.body).innerHTML.trim(),
      ref: parseRef(doc)
    };
  }

  function bookDocument(title, html, ref) {
    const safeTitle = String(title || '').replace(/&/g, '&amp;').replace(/</g, '&lt;');
    return `<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="utf-8">
<title>${safeTitle}</title>
<link rel="stylesheet" href="../../styles.css">
${refScript(ref)}
</head>
<body>
<main class="book">
${(html || '').trim()}
</main>
</body>
</html>
`;
  }

  function getRef(id, d) {
    if (!inTauri && getRefsOverlay()[id]) return getRefsOverlay()[id];
    return (d && d.ref) || emptyRef();
  }

  async function writeBookFile(id, doc) {
    const rel = userPath(id);
    if (!rel) throw new Error(`Geen gebouwmap gevonden voor boek "${id}"`);
    await writeFile(rel, doc);
    deleteFile(`books/${id}.html`).catch(() => {});
  }

  async function loadBook(id) {
    if (inTauri) {
      for (const rel of [userPath(id), `books/${id}.html`]) {
        if (!rel) continue;
        try {
          const t = await readFile(rel);
          if (t) return parseBook(t);
        } catch (_) {}
      }
    }
    const details = getDetails();
    if (details[id]) return details[id];
    const cache = getBookCache();
    if (!(id in cache)) {
      try {
        const url = bundledUrl(id);
        if (!url) throw new Error('onbekend boek');
        const res = await fetch(url);
        if (!res.ok) throw new Error(String(res.status));
        setBookCache(id, parseBook(await res.text()));
      } catch (_) {
        setBookCache(id, null);
      }
    }
    return getBookCache()[id];
  }

  function reindex(id, html, save = true) {
    const world = getWorld();
    const it = allItems(world).find(i => i.id === id);
    if (!it) return;
    const extra = { ...getExtra() };
    extra[id] = [{
      id,
      title: it.title,
      where: whereOf(world, id),
      heading: it.title,
      text: `${it.desc || ''} ${textOf(html)}`.slice(0, 6000),
      type: it.type || detectType(html)
    }];
    setExtra(extra);
    if (save) persistExtra(extra);
  }

  async function saveBookInner(id, title, html) {
    if (inTauri) {
      await writeBookFile(id, bookDocument(title, html, getRef(id, await loadBook(id))));
    } else {
      getDetails()[id] = { title, html };
    }
    setBookCache(id, undefined);
    const cache = getBookCache();
    delete cache[id];
    reindex(id, html);
  }

  function dropItem(it) {
    if (!it) return;
    delete getDetails()[it.id];
    const extra = { ...getExtra() };
    extra[it.id] = [];
    setExtra(extra);
    const refs = getRefsOverlay();
    delete refs[it.id];
    saveRefs(refs);
    if (inTauri) {
      const rel = userPath(it.id);
      if (rel) deleteFile(rel).catch(() => {});
      deleteFile(`books/${it.id}.html`).catch(() => {});
    }
    persistExtra(extra);
  }

  async function saveRef(id, ref) {
    if (inTauri) {
      const d = await loadBook(id);
      await writeBookFile(id, bookDocument(d.title, d.html, ref));
    } else {
      const refs = getRefsOverlay();
      refs[id] = ref;
      saveRefs(refs);
    }
  }

  return {
    parseBook,
    bookDocument,
    getRef,
    writeBookFile,
    loadBook,
    reindex,
    saveBookInner,
    dropItem,
    saveRef,
    detectType,
    textOf
  };
}
