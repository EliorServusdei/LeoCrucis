// Verberg het consolevenster op Windows in release-builds.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    leo_crucis_lib::run()
}
