/**
 * ui/breadcrumbs.js — navigatiecontext in de header (fase 4)
 *
 * Toont bijv. Stad › Kerk › Kamer of App › Bijbel
 */

import { el } from '../core/dom.js';

/**
 * @param {object} deps
 * @param {HTMLElement|null} [deps.host] — container; default #header-crumbs
 * @param {() => { b: *, r: * }} deps.getNav
 * @param {() => object} deps.getWorld
 * @param {() => string|null} deps.getCurrentSection
 * @param {() => string|null} [deps.getMiniAppKind]
 * @param {() => string|null} [deps.getMiniAppTitle]
 * @param {(b: *, r: *) => void} deps.go
 * @param {() => void} deps.showHome
 * @param {(id: string) => void} [deps.showSection]
 * @param {(itemId: string) => string} [deps.whereOf]
 */
export function createBreadcrumbsApi(deps) {
  const {
    host: hostOpt = null,
    getNav,
    getWorld,
    getCurrentSection,
    getMiniAppKind = () => null,
    getMiniAppTitle = () => null,
    go,
    showHome,
    showSection = () => {},
    whereOf = () => '',
  } = deps;

  function getHost() {
    if (hostOpt) return hostOpt;
    let h = document.getElementById('header-crumbs');
    if (!h) {
      h = document.createElement('nav');
      h.id = 'header-crumbs';
      h.className = 'header-crumbs';
      h.setAttribute('aria-label', 'Locatie');
      const header = document.querySelector('header');
      const sep = header && header.querySelector('.header-sep');
      // Na de navigatieknoppen plaatsen
      const nav = header && header.querySelector('.header-nav');
      if (nav && nav.nextSibling) {
        header.insertBefore(h, nav.nextSibling);
      } else if (header) {
        header.appendChild(h);
      }
    }
    return h;
  }

  function crumb(label, onClick, current) {
    if (current || !onClick) {
      const span = el('span', 'header-crumb is-current', label);
      span.setAttribute('aria-current', 'page');
      return span;
    }
    const btn = el('button', 'header-crumb', label);
    btn.type = 'button';
    btn.onclick = onClick;
    return btn;
  }

  function sep() {
    return el('span', 'header-crumb-sep', '›');
  }

  function render() {
    const host = getHost();
    if (!host) return;
    // Breadcrumbs uitgeschakeld — open apps staan in de header-taakbalk
    host.replaceChildren();
    host.hidden = true;
    host.setAttribute('aria-hidden', 'true');
    host.style.display = 'none';
    return;

    const parts = [];
    parts.push(crumb('Start', () => showHome(), false));

    const appKind = getMiniAppKind();
    const appTitle = getMiniAppTitle();
    const sectionId = getCurrentSection();
    const nav = getNav() || { b: null, r: null };
    const world = getWorld() || { buildings: [] };

    if (appKind) {
      parts.push(sep());
      parts.push(crumb(appTitle || appKind, null, true));
    } else if (sectionId) {
      const loc = whereOf(sectionId) || '';
      // whereOf: "Gebouw › Kamer"
      const bits = loc.split('›').map(s => s.trim()).filter(Boolean);
      if (bits[0]) {
        parts.push(sep());
        const b = (world.buildings || []).find(x => x.label === bits[0]);
        parts.push(crumb(bits[0], b ? () => go(b, null) : null, !bits[1]));
      }
      if (bits[1]) {
        parts.push(sep());
        const b = (world.buildings || []).find(x => x.label === bits[0]);
        const r = b && (b.rooms || []).find(x => x.label === bits[1]);
        parts.push(crumb(bits[1], b && r ? () => go(b, r) : null, true));
      }
      // Boektitel als we die kunnen vinden
      try {
        const items = (world.buildings || []).flatMap(b =>
          (b.rooms || []).flatMap(r => {
            if (r.shelves) return r.shelves.flatMap(s => s.items || []);
            return r.items || [];
          })
        );
        const it = items.find(i => i.id === sectionId);
        if (it && it.title) {
          parts.push(sep());
          parts.push(crumb(it.title, null, true));
        }
      } catch (_) {}
    } else if (nav.b) {
      parts.push(sep());
      parts.push(crumb(nav.b.label || 'Gebouw', () => go(nav.b, null), !nav.r));
      if (nav.r) {
        parts.push(sep());
        parts.push(crumb(nav.r.label || 'Kamer', null, true));
      }
    }

    // Alleen tonen als er meer is dan "Start"
    if (parts.length <= 1) {
      host.hidden = true;
      host.replaceChildren();
      return;
    }
    host.hidden = false;
    for (const p of parts) host.appendChild(p);
  }

  return { render, getHost };
}
