// Bouwt uit world.json en src/stad/<gebouw>/<sectie>/*.html twee bestanden:
//   data/search-index.json   de zoekindex
//   data/book-paths.json     waar elk meegeleverd boek staat (id -> "gebouw/sectie/bestandsnaam"), zodat de app het snel vindt
// Draaien met:  node tools/build-search-index.mjs   (ook automatisch via "npm run index")
// Indexeert: titel, beschrijving, koppen, tekst én auteurs (uit #lc-ref of info-panel).
import fs from 'node:fs';
import path from 'node:path';

const SRC = path.resolve('src');
const read = p => fs.readFileSync(path.join(SRC, p), 'utf8');
const world = JSON.parse(read('data/world.json'));

// Alle meegeleverde boeken: src/stad/<gebouw>/<sectie>/<id>.html (of plat src/stad/<gebouw>/<id>.html).
// Sleutel = id in kleine letters; waarde = relatief pad zonder .html (gebouw/sectie/id of gebouw/id).
const STAD = path.join(SRC, 'stad');
const paths = {};
function addBook(relNoExt, id) {
  const key = id.toLowerCase();
  if (paths[key]) console.warn(`Dubbel boek-id "${id}": ${paths[key]} en ${relNoExt}`);
  else paths[key] = relNoExt;
}
if (fs.existsSync(STAD)) {
  for (const gebouw of fs.readdirSync(STAD, { withFileTypes: true }).filter(d => d.isDirectory()).map(d => d.name).sort()) {
    const gdir = path.join(STAD, gebouw);
    for (const entry of fs.readdirSync(gdir, { withFileTypes: true })) {
      if (entry.isFile() && entry.name.toLowerCase().endsWith('.html')) {
        const id = entry.name.slice(0, -5);
        addBook(`${gebouw}/${id}`, id);
      } else if (entry.isDirectory()) {
        const sectie = entry.name;
        const sdir = path.join(gdir, sectie);
        for (const f of fs.readdirSync(sdir).filter(f => f.toLowerCase().endsWith('.html')).sort()) {
          const id = f.slice(0, -5);
          addBook(`${gebouw}/${sectie}/${id}`, id);
        }
      }
    }
  }
}
fs.writeFileSync(path.join(SRC, 'data/book-paths.json'), JSON.stringify(paths));

const ent = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&nbsp;': ' ', '&quot;': '"', '&#39;': "'" };
const clean = h => h
  .replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ')
  .replace(/<[^>]+>/g, ' ')
  .replace(/&[a-z#0-9]+;/gi, m => ent[m] ?? ' ')
  .replace(/\$\{[^}]*\}/g, ' ')
  .replace(/\s+/g, ' ').trim();

// Splitst een HTML-fragment in stukken per kop (h1-h4).
function byHeading(html, fallback) {
  const parts = html.split(/(?=<h[1-4][\b>])/i);
  return parts.map(p => {
    const m = p.match(/<h[1-4][^>]*>([\s\S]*?)<\/h[1-4]>/i);
    return { heading: m ? clean(m[1]) : fallback, text: clean(p) };
  }).filter(c => c.text.length > 20);
}

/** Lees volledig HTML-bestand; geef inhoud + auteurs terug. */
function readBook(id) {
  const rel = paths[id.toLowerCase()];
  if (!rel) return null;
  const f = path.join(STAD, rel + '.html');
  if (!fs.existsSync(f)) return null;
  const raw = fs.readFileSync(f, 'utf8');

  // Auteurs: eerst gestructureerde #lc-ref, anders info-panel "Schrijver"
  let authors = [];
  const refM = raw.match(/<script[^>]*\bid=["']lc-ref["'][^>]*>([\s\S]*?)<\/script>/i);
  if (refM) {
    try {
      const ref = JSON.parse(refM[1].trim());
      if (Array.isArray(ref.authors)) authors = ref.authors.filter(a => typeof a === 'string' && a.trim());
    } catch { /* negeer kapotte JSON */ }
  }
  if (!authors.length) {
    const writerM = raw.match(/<dt[^>]*>\s*Schrijver\s*<\/dt>\s*<dd[^>]*>([\s\S]*?)<\/dd>/i);
    if (writerM) {
      const name = clean(writerM[1]);
      if (name) authors = [name];
    }
  }

  // Inhoud: <main> heeft voorrang; anders body (zonder scripts/styles)
  let body = null;
  const mainM = raw.match(/<main[^>]*>([\s\S]*)<\/main>/i);
  if (mainM) {
    body = mainM[1];
  } else {
    const bodyM = raw.match(/<body[^>]*>([\s\S]*)<\/body>/i);
    if (bodyM) {
      body = bodyM[1]
        .replace(/<script[\s\S]*?<\/script>/gi, ' ')
        .replace(/<style[\s\S]*?<\/style>/gi, ' ');
    }
  }

  // Bestandstype (zelfde herkenning als de app): pdf, pptx, xlsx of gewoon document
  const type = /class=["']pdf-book["']/.test(raw) ? 'pdf' : raw.includes('data-slides') ? 'pptx' : raw.includes('data-sheet') ? 'xlsx' : 'doc';
  return { body, authors, type };
}

const docs = [];
const roomItems = r => r.shelves ? r.shelves.flatMap(x => x.items || []) : (r.items || []);
for (const b of world.buildings) for (const r of b.rooms) for (const it of roomItems(r)) {
  const where = `${b.label} › ${r.label}`;
  const book = readBook(it.id);
  const authorStr = book?.authors?.length ? book.authors.join(', ') : '';

  // Metadata-fragment (titel + beschrijving + auteurs) — altijd aanwezig
  docs.push({
    id: it.id,
    title: it.title,
    where,
    heading: it.title,
    text: [it.desc || '', authorStr, r.label, b.label].filter(Boolean).join(' '),
    ...(book?.type && book.type !== 'doc' ? { type: book.type } : {}),
  });

  if (book?.body) {
    for (const c of byHeading(book.body, it.title)) {
      // Auteurs ook in elk tekstfragment, zodat zoeken op auteur altijd treft
      const text = authorStr ? `${c.text} ${authorStr}` : c.text;
      docs.push({ id: it.id, title: it.title, where, heading: c.heading, text, ...(book.type !== 'doc' ? { type: book.type } : {}) });
    }
  }
}

const out = path.join(SRC, process.env.INDEX_OUT || 'data/search-index.json');
fs.writeFileSync(out, JSON.stringify(docs));
const kb = Math.round(fs.statSync(out).size / 1024);
console.log(`${Object.keys(paths).length} boeken in ${new Set(Object.values(paths).map(p => p.split('/')[0])).size} gebouwmappen; ${docs.length} fragmenten, ${kb} KB`);
