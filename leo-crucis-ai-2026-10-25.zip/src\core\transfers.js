// Achtergrond-overdrachten (zoals Chrome-downloads): voortgang in de header,
// app blijft bruikbaar terwijl films/muziek naar de bibliotheek worden geschreven.

const listeners = new Set();
/** @type {Array<{
 *   id: string,
 *   label: string,
 *   detail: string,
 *   done: number,
 *   total: number,
 *   rate: number,
 *   startedAt: number,
 *   lastT: number,
 *   lastDone: number,
 *   status: 'running'|'done'|'error',
 *   error?: string
 * }>} */
let items = [];
let seq = 0;

function notify() {
  const snap = getTransfers();
  listeners.forEach(fn => { try { fn(snap); } catch (e) { /* niets */ } });
}

function etaText(t, frac) {
  if (!(t.rate > 0) || frac >= 0.999) return frac >= 0.999 ? 'klaar' : 'berekenen…';
  const left = Math.max(0, (t.total - t.done) / t.rate);
  const s = Math.round(left);
  if (s < 10) return 'nog enkele seconden';
  if (s < 60) return 'nog ongeveer ' + s + ' seconden';
  const m = Math.round(s / 60);
  if (m < 60) return 'nog ongeveer ' + m + ' minuten';
  return 'nog ongeveer ' + Math.floor(m / 60) + ' u ' + (m % 60) + ' min';
}

export function getTransfers() {
  const active = items.filter(x => x.status === 'running');
  const recent = items.filter(x => x.status !== 'running').slice(-8);
  let overallDone = 0, overallTotal = 0;
  active.forEach(t => { overallDone += t.done; overallTotal += (t.total || 0); });
  const pct = overallTotal > 0 ? Math.round(Math.min(1, overallDone / overallTotal) * 100) : (active.length ? 0 : 100);
  return {
    active,
    recent,
    all: items.slice(),
    count: active.length,
    busy: active.length > 0,
    percent: pct
  };
}

export function onTransfers(fn) {
  if (typeof fn !== 'function') return () => {};
  listeners.add(fn);
  try { fn(getTransfers()); } catch (e) { /* niets */ }
  return () => listeners.delete(fn);
}

export function clearFinishedTransfers() {
  items = items.filter(x => x.status === 'running');
  notify();
}

/**
 * Start een achtergrondtaak met voortgang.
 * @param {string} label
 * @returns {{ id: string, update: Function, done: Function, fail: Function }}
 */
export function startTransfer(label = 'Bezig…') {
  const id = 'tr-' + (++seq) + '-' + Date.now().toString(36);
  const task = {
    id,
    label,
    detail: '',
    done: 0,
    total: 0,
    rate: 0,
    startedAt: Date.now(),
    lastT: Date.now(),
    lastDone: 0,
    status: 'running'
  };
  items.push(task);
  notify();

  const update = (p = {}) => {
    if (task.status !== 'running') return;
    if (p.label != null) task.label = p.label;
    if (p.detail != null) task.detail = p.detail;
    if (p.total != null && p.total !== task.total) {
      task.total = p.total;
      task.startedAt = Date.now();
      task.lastT = task.startedAt;
      task.lastDone = p.done || 0;
      task.rate = 0;
    }
    if (p.done != null) {
      const now = Date.now();
      const dt = (now - task.lastT) / 1000;
      if (dt >= 0.4) {
        const inst = (p.done - task.lastDone) / dt;
        if (inst > 0) task.rate = task.rate ? task.rate * 0.7 + inst * 0.3 : inst;
        task.lastT = now;
        task.lastDone = p.done;
      }
      task.done = p.done;
    }
    notify();
  };

  const done = (detail) => {
    if (task.status !== 'running') return;
    task.status = 'done';
    if (detail != null) task.detail = detail;
    if (task.total > 0) task.done = task.total;
    notify();
    // klaar-items na een tijd opruimen
    setTimeout(() => {
      const i = items.findIndex(x => x.id === id && x.status === 'done');
      if (i >= 0 && items.filter(x => x.status === 'running').length === 0) {
        // laat recente klaar-items staan tot gebruiker panel sluit / clear
      }
      notify();
    }, 400);
  };

  const fail = (err) => {
    if (task.status !== 'running') return;
    task.status = 'error';
    task.error = err && err.message ? err.message : String(err || 'Mislukt');
    task.detail = task.error;
    notify();
  };

  return { id, update, done, fail, get eta() {
    const frac = task.total > 0 ? task.done / task.total : 0;
    return etaText(task, frac);
  } };
}

/** Zelfde API-vorm als withLoading, maar blokkeert de UI niet. */
export async function withTransfer(work, label) {
  const tr = startTransfer(label);
  try {
    const result = await (typeof work === 'function' ? work(tr.update) : work);
    tr.done();
    return result;
  } catch (e) {
    tr.fail(e);
    throw e;
  }
}

export function transferEta(task) {
  if (!task) return '';
  if (task.status === 'done') return 'klaar';
  if (task.status === 'error') return task.error || 'mislukt';
  const frac = task.total > 0 ? task.done / task.total : 0;
  const pct = Math.round(frac * 100);
  return pct + '% · ' + etaText(task, frac);
}
