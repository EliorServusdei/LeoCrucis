/**
 * core/boot-diagnostics.js — foutcodes bij opstarten / modularisatie
 *
 * Doel: als een module of init-stap faalt, zie je meteen:
 *   - een code (bijv. E-INIT-03)
 *   - welke stap/module
 *   - de echte foutmelding
 * in de console én optioneel op het scherm.
 *
 * Gebruik:
 *   import { boot, bootStep, bootModule, bootReport } from './core/boot-diagnostics.js';
 *
 *   // Bij dynamische import van een nieuwe module:
 *   const mod = await bootModule('E-MOD-SEARCH', './ui/search-ui.js', () => import('./ui/search-ui.js'));
 *
 *   // Rond een init-stap:
 *   await bootStep('E-INIT-WORLD', 'Wereld tekenen', () => { renderWorld(); });
 */

const LOG_PREFIX = '[LeoCrucis]';

/** @type {{ code: string, step: string, message: string, at: string, stack?: string }[]} */
const errors = [];
/** @type {{ code: string, step: string, ms: number }[]} */
const steps = [];

let bannerEl = null;

function nowIso() {
  try { return new Date().toISOString(); } catch (_) { return String(Date.now()); }
}

/**
 * Registreer een fout met code.
 * @param {string} code  bijv. 'E-INIT-03' of 'E-MOD-SEARCH-UI'
 * @param {string} step  korte beschrijving
 * @param {unknown} err  Error of string
 */
export function bootFail(code, step, err) {
  const message = err && typeof err === 'object' && 'message' in err
    ? String(err.message)
    : String(err || 'onbekende fout');
  const stack = err && typeof err === 'object' && err.stack ? String(err.stack) : undefined;
  const entry = { code, step, message, at: nowIso(), stack };
  errors.push(entry);
  console.error(`${LOG_PREFIX} ${code} — ${step}:`, message);
  if (stack) console.error(stack);
  showBanner(entry);
  return entry;
}

/**
 * Log een geslaagde stap (handig bij fase-2 om te zien hoe ver je kwam).
 */
export function bootOk(code, step, ms) {
  steps.push({ code, step, ms: ms || 0 });
  if (typeof console !== 'undefined' && console.debug) {
    console.debug(`${LOG_PREFIX} ${code} OK — ${step}${ms != null ? ` (${Math.round(ms)}ms)` : ''}`);
  }
}

/**
 * Voer een init-stap uit; bij fout: code + banner, gooit door of slikt in.
 * @param {string} code
 * @param {string} step
 * @param {() => (void|Promise<void>)} fn
 * @param {{ optional?: boolean }} [opts]  optional=true → fout loggen, niet gooien
 */
export async function bootStep(code, step, fn, opts = {}) {
  const t0 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  try {
    await fn();
    const t1 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    bootOk(code, step, t1 - t0);
  } catch (err) {
    bootFail(code, step, err);
    if (!opts.optional) throw err;
  }
}

/**
 * Laad/evalueer een module-factory; vangt syntax/runtime bij import.
 * @param {string} code
 * @param {string} label  pad of naam
 * @param {() => Promise<any>} importer  () => import('./ui/search-ui.js')
 */
export async function bootModule(code, label, importer) {
  const t0 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  try {
    const mod = await importer();
    const t1 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    bootOk(code, `module ${label}`, t1 - t0);
    return mod;
  } catch (err) {
    bootFail(code, `module laden: ${label}`, err);
    throw err;
  }
}

/**
 * Globale handlers: onvang ongecatchte fouten met codes.
 * Eenmalig aanroepen vroeg in app.js.
 */
export function installGlobalHandlers() {
  if (typeof window === 'undefined') return;
  if (window.__lcBootHandlers) return;
  window.__lcBootHandlers = true;

  window.addEventListener('error', (ev) => {
    const msg = ev && (ev.message || (ev.error && ev.error.message)) || 'script error';
    const file = ev && ev.filename ? ` @ ${ev.filename}:${ev.lineno || 0}` : '';
    bootFail('E-GLOBAL', `Ongecatchte fout${file}`, ev.error || msg);
  });

  window.addEventListener('unhandledrejection', (ev) => {
    const reason = ev && ev.reason;
    bootFail('E-PROMISE', 'Unhandled promise rejection', reason);
  });
}

/** Alle geregistreerde fouten (kopie). */
export function bootErrors() {
  return errors.slice();
}

/** Samenvatting voor console of UI. */
export function bootReport() {
  const report = {
    ok: errors.length === 0,
    errorCount: errors.length,
    errors: errors.slice(),
    steps: steps.slice()
  };
  if (errors.length) {
    console.warn(`${LOG_PREFIX} Boot-rapport: ${errors.length} fout(en)`);
    errors.forEach(e => console.warn(`  ${e.code}  ${e.step} — ${e.message}`));
  } else {
    console.info(`${LOG_PREFIX} Boot-rapport: OK (${steps.length} stappen)`);
  }
  return report;
}

/**
 * Zichtbare banner bovenaan het scherm (geen dependency op styles.css).
 * Klik = sluiten. Blijft tot de gebruiker wegklikt.
 */
function showBanner(entry) {
  if (typeof document === 'undefined') return;
  try {
    if (!bannerEl) {
      bannerEl = document.createElement('div');
      bannerEl.id = 'lc-boot-banner';
      bannerEl.setAttribute('role', 'alert');
      Object.assign(bannerEl.style, {
        position: 'fixed',
        top: '0',
        left: '0',
        right: '0',
        zIndex: '99999',
        padding: '12px 16px',
        background: '#7f1d1d',
        color: '#fff',
        fontFamily: 'system-ui, sans-serif',
        fontSize: '14px',
        lineHeight: '1.4',
        boxShadow: '0 2px 12px rgba(0,0,0,.35)',
        cursor: 'pointer'
      });
      bannerEl.title = 'Klik om te sluiten';
      bannerEl.onclick = () => { try { bannerEl.remove(); bannerEl = null; } catch (_) {} };
      document.body.appendChild(bannerEl);
    }
    bannerEl.innerHTML =
      '<strong style="margin-right:8px">' + escapeHtml(entry.code) + '</strong>' +
      '<span>' + escapeHtml(entry.step) + '</span>' +
      '<div style="opacity:.9;margin-top:4px;font-size:12px">' + escapeHtml(entry.message) + '</div>' +
      '<div style="opacity:.7;margin-top:4px;font-size:11px">Klik om te sluiten · zie ook de browserconsole (F12)</div>';
  } catch (_) { /* geen DOM */ }
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** Code-conventie (documentatie). */
export const BOOT_CODES = {
  GLOBAL: 'E-GLOBAL',
  PROMISE: 'E-PROMISE',
  INIT: 'E-INIT',
  INIT_WORLD: 'E-INIT-WORLD',
  INIT_SEARCH: 'E-INIT-SEARCH',
  INIT_SETTINGS: 'E-INIT-SETTINGS',
  INIT_FOCUS: 'E-INIT-FOCUS',
  MOD_CORE: 'E-MOD-CORE',
  MOD_SEARCH_UI: 'E-MOD-SEARCH-UI',
  MOD_MINI_APPS: 'E-MOD-MINI-APPS',
  MOD_FOCUS: 'E-MOD-FOCUS',
  MOD_RECENT: 'E-MOD-RECENT',
  MOD_HISTORY: 'E-MOD-HISTORY'
};
