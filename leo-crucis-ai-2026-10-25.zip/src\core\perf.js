// Prestatiebewaking: framerate meten, max-FPS respecteren en zwaar werk
// (downloads/parsing) vertragen zodat de app soepel blijft en andere apps
// naast Leo Crucis kunnen draaien.
//
// Gebruik:
//   import { yieldForUi, startFpsMonitor, getFps, isThrottling } from './perf.js';
//   await yieldForUi();

import { loadSettings } from './edit.js';

let fps = 60;
let lastT = 0;
let frames = 0;
let acc = 0;
let monitoring = false;
let rafId = 0;
let lastPaint = 0;

const POWER_FACTOR = {
  low: 0.35,      // zachte laadkracht → langere pauzes
  normal: 1,
  high: 1.8,
  max: 3.5,       // harde laadkracht → korte pauzes
};

function opts() {
  try {
    const s = loadSettings();
    const power = ['low', 'normal', 'high', 'max'].includes(s.loadPower) ? s.loadPower : 'normal';
    return {
      enabled: s.loadThrottle !== false,
      minFps: Math.max(10, Math.min(60, Number(s.loadMinFps) || 30)),
      maxDelayMs: Math.max(16, Math.min(500, Number(s.loadThrottleMs) || 120)),
      maxFps: Math.max(0, Math.min(240, Number(s.maxFps) || 0)), // 0 = onbeperkt
      power,
      powerFactor: POWER_FACTOR[power] || 1,
      concurrency: Math.max(1, Math.min(4, Number(s.loadConcurrency) || 2)),
    };
  } catch {
    return { enabled: true, minFps: 30, maxDelayMs: 120, maxFps: 0, power: 'normal', powerFactor: 1, concurrency: 2 };
  }
}

// —— Parallelle download-slots ——
let activeLoads = 0;
const loadWaiters = [];

export function getLoadConcurrency() {
  return opts().concurrency;
}

function pumpLoadQueue() {
  const max = opts().concurrency;
  while (activeLoads < max && loadWaiters.length) {
    const next = loadWaiters.shift();
    activeLoads++;
    next();
  }
}

/** Wacht op een vrij download-slot, voer fn uit, geef slot vrij. */
export async function withLoadSlot(fn) {
  await new Promise(resolve => {
    loadWaiters.push(resolve);
    pumpLoadQueue();
  });
  try {
    return await fn();
  } finally {
    activeLoads = Math.max(0, activeLoads - 1);
    pumpLoadQueue();
  }
}


function tick(now) {
  const o = opts();
  // Max-FPS: sla meting/frame over als we sneller gaan dan het plafond
  if (o.maxFps > 0) {
    const minDt = 1000 / o.maxFps;
    if (lastPaint && now - lastPaint < minDt - 0.5) {
      rafId = requestAnimationFrame(tick);
      return;
    }
    lastPaint = now;
  } else {
    lastPaint = now;
  }

  if (!lastT) lastT = now;
  frames++;
  acc += now - lastT;
  lastT = now;
  if (acc >= 100) {
    fps = Math.round((frames * 1000) / acc);
    frames = 0;
    acc = 0;
  }
  rafId = requestAnimationFrame(tick);
}

export function startFpsMonitor() {
  if (monitoring) return;
  monitoring = true;
  lastT = 0;
  frames = 0;
  acc = 0;
  lastPaint = 0;
  rafId = requestAnimationFrame(tick);
}

export function stopFpsMonitor() {
  monitoring = false;
  if (rafId) cancelAnimationFrame(rafId);
  rafId = 0;
}

export function getFps() {
  return fps;
}

export function isThrottling() {
  const o = opts();
  if (!o.enabled) return false;
  if (fps > 0 && fps < o.minFps) return true;
  if (o.maxFps > 0 && fps > o.maxFps) return true;
  if (o.power === 'low') return true; // structureel zachter
  return false;
}

/**
 * Laat de UI / andere apps ademhalen.
 * - lagere laadkracht → langere pauzes
 * - FPS onder drempel → extra pauze
 * - FPS boven max-FPS → pauze om CPU vrij te geven
 */
export function yieldForUi(options = {}) {
  const o = opts();
  startFpsMonitor();

  if (!o.enabled && !options.force && o.power !== 'low' && !(o.maxFps > 0)) {
    return Promise.resolve();
  }

  const low = fps > 0 && fps < o.minFps;
  const overCap = o.maxFps > 0 && fps > o.maxFps;
  const soft = o.power === 'low';

  let delay = 0;

  if (low) {
    const ratio = Math.min(1, (o.minFps - fps) / o.minFps);
    delay = Math.max(delay, 16 + ratio * o.maxDelayMs);
  }
  if (overCap) {
    // Mik op het plafond: wacht ongeveer één frame van maxFps
    delay = Math.max(delay, Math.round(1000 / o.maxFps));
  }
  if (soft && !low && !overCap) {
    delay = Math.max(delay, 12);
  }
  if (options.force && delay < 8) delay = 8;

  // Laadkracht: hoger = kortere pauze
  if (delay > 0) {
    delay = Math.max(4, Math.round(delay / o.powerFactor));
  }

  if (delay <= 0 && !options.force) {
    return new Promise(r => {
      if (typeof requestIdleCallback === 'function') {
        requestIdleCallback(() => r(), { timeout: 24 });
      } else {
        setTimeout(r, 0);
      }
    });
  }

  return new Promise(r => setTimeout(r, delay));
}

export async function mapWithYield(items, fn, cfg = {}) {
  const every = Math.max(1, cfg.every || 1);
  const list = Array.isArray(items) ? items : [...items];
  const out = [];
  for (let i = 0; i < list.length; i++) {
    out.push(await fn(list[i], i));
    if ((i + 1) % every === 0) await yieldForUi();
  }
  return out;
}
