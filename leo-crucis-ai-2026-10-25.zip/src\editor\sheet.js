// Eenvoudige Excel-achtige rekenblad-editor.
const h = (tag, cls, text) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
};

const COLS = 10; // A–J
const ROWS = 20;
const colName = i => String.fromCharCode(65 + i);

const emptyGrid = () => {
  const g = [];
  for (let r = 0; r < ROWS; r++) {
    const row = [];
    for (let c = 0; c < COLS; c++) row.push('');
    g.push(row);
  }
  return g;
};

export function parseSheetHtml(html) {
  try {
    const d = document.createElement('div');
    d.innerHTML = html || '';
    const el = d.querySelector('script[type="application/json"][data-sheet]');
    if (el) {
      const data = JSON.parse(el.textContent);
      if (Array.isArray(data.cells)) return data;
    }
  } catch (e) {}
  return { cells: emptyGrid(), colWidths: [] };
};

export function buildSheetHtml(data) {
  const json = JSON.stringify(data);
  return `<div class="sheet-book"><script type="application/json" data-sheet>${json.replace(/</g, '\\u003c')}</script></div>`;
}

function evalCell(raw, get) {
  if (raw == null || raw === '') return '';
  const s = String(raw).trim();
  if (!s.startsWith('=')) return s;
  try {
    let expr = s.slice(1);
    // Replace cell refs like A1, B2
    expr = expr.replace(/\b([A-J])([1-9]|1\d|20)\b/gi, (_, col, row) => {
      const c = col.toUpperCase().charCodeAt(0) - 65;
      const r = parseInt(row, 10) - 1;
      const v = get(r, c);
      const n = parseFloat(String(v).replace(',', '.'));
      return Number.isFinite(n) ? String(n) : '0';
    });
    // Only allow safe math
    if (!/^[\d\s+\-*/().,%]+$/.test(expr)) return '#ERR';
    expr = expr.replace(/,/g, '.');
    // eslint-disable-next-line no-new-func
    const val = Function('"use strict"; return (' + expr + ')')();
    return Number.isFinite(val) ? String(Math.round(val * 1000) / 1000) : String(val);
  } catch (e) {
    return '#ERR';
  }
}

export function renderSheetView(html, { title, onBack, onEdit, dev }) {
  const data = parseSheetHtml(html);
  const cells = data.cells || emptyGrid();
  const wrap = h('div', 'sheet-view');
  const head = h('div', 'view-head');
  const back = h('button', 'back', '← Terug');
  back.type = 'button';
  back.onclick = onBack;
  head.append(back, h('h1', '', title || 'Rekenblad'));
  if (dev && onEdit) {
    const edit = h('button', 'dev-btn pencil', '✎');
    edit.type = 'button';
    edit.title = 'Rekenblad bewerken';
    edit.onclick = onEdit;
    head.append(edit);
  }
  wrap.append(head);

  const table = h('table', 'sheet-table sheet-readonly');
  const thead = h('thead');
  const hr = h('tr');
  hr.append(h('th', '', ''));
  for (let c = 0; c < COLS; c++) hr.append(h('th', '', colName(c)));
  thead.append(hr);
  table.append(thead);
  const tbody = h('tbody');
  const get = (r, c) => {
    const raw = (cells[r] && cells[r][c]) || '';
    return evalCell(raw, get);
  };
  for (let r = 0; r < ROWS; r++) {
    const tr = h('tr');
    tr.append(h('th', '', String(r + 1)));
    for (let c = 0; c < COLS; c++) {
      const td = h('td', '', get(r, c));
      tr.append(td);
    }
    tbody.append(tr);
  }
  table.append(tbody);
  const scroller = h('div', 'sheet-scroll');
  scroller.append(table);
  wrap.append(scroller);
  return wrap;
}

export function createSheetEditor(initialHtml, { ask }) {
  let data = parseSheetHtml(initialHtml);
  let cells = data.cells || emptyGrid();
  // Ensure size
  while (cells.length < ROWS) cells.push(Array(COLS).fill(''));
  cells = cells.map(row => {
    const r = row.slice(0, COLS);
    while (r.length < COLS) r.push('');
    return r;
  });

  const bar = h('div', 'editor-bar sheet-bar');
  const note = h('span', 'editor-note');
  const flash = t => { note.textContent = t; setTimeout(() => { if (note.textContent === t) note.textContent = ''; }, 3000); };

  const formulaBar = h('input', 'sheet-formula');
  formulaBar.placeholder = 'Formule of waarde (bijv. =A1+B1)';
  formulaBar.setAttribute('aria-label', 'Formulebalk');

  let active = { r: 0, c: 0 };
  const inputs = [];

  const getVal = (r, c) => evalCell((cells[r] && cells[r][c]) || '', (rr, cc) => getVal(rr, cc));

  const table = h('table', 'sheet-table');
  const thead = h('thead');
  const hr = h('tr');
  hr.append(h('th', '', ''));
  for (let c = 0; c < COLS; c++) hr.append(h('th', '', colName(c)));
  thead.append(hr);
  table.append(thead);
  const tbody = h('tbody');

  const setActive = (r, c) => {
    active = { r, c };
    inputs.forEach(row => row.forEach(inp => inp.classList.remove('cell-active')));
    if (inputs[r] && inputs[r][c]) {
      inputs[r][c].classList.add('cell-active');
      formulaBar.value = cells[r][c] || '';
    }
  };

  for (let r = 0; r < ROWS; r++) {
    const tr = h('tr');
    tr.append(h('th', '', String(r + 1)));
    inputs[r] = [];
    for (let c = 0; c < COLS; c++) {
      const td = h('td');
      const inp = h('input', 'sheet-cell');
      inp.value = cells[r][c] || '';
      inp.setAttribute('aria-label', colName(c) + (r + 1));
      inp.onfocus = () => setActive(r, c);
      inp.oninput = () => {
        cells[r][c] = inp.value;
        formulaBar.value = inp.value;
      };
      inp.onblur = () => {
        // Refresh computed display hints via title
        inp.title = cells[r][c] && String(cells[r][c]).startsWith('=')
          ? '→ ' + getVal(r, c)
          : '';
      };
      inputs[r][c] = inp;
      td.append(inp);
      tr.append(td);
    }
    tbody.append(tr);
  }
  table.append(tbody);

  formulaBar.onchange = formulaBar.onkeydown = e => {
    if (e.type === 'keydown' && e.key !== 'Enter') return;
    const { r, c } = active;
    cells[r][c] = formulaBar.value;
    if (inputs[r] && inputs[r][c]) {
      inputs[r][c].value = formulaBar.value;
      inputs[r][c].title = formulaBar.value.startsWith('=') ? '→ ' + getVal(r, c) : '';
    }
  };

  const tool = (label, title, fn) => {
    const b = h('button', '', label);
    b.type = 'button';
    b.title = title;
    b.onclick = fn;
    bar.append(b);
  };

  tool('Σ Som', 'Som van selectie (kolom A)', () => {
    // Insert SUM of A1:A10 in active cell as example
    const { r, c } = active;
    cells[r][c] = '=A1+A2+A3';
    if (inputs[r][c]) inputs[r][c].value = cells[r][c];
    formulaBar.value = cells[r][c];
    flash('Voorbeeldformule gezet — pas aan naar wens');
  });
  tool('Wissen', 'Cel legen', () => {
    const { r, c } = active;
    cells[r][c] = '';
    if (inputs[r][c]) { inputs[r][c].value = ''; inputs[r][c].title = ''; }
    formulaBar.value = '';
  });
  tool('📊', 'Voorbeeld: rekenblad vullen', () => {
    cells[0][0] = 'Item'; cells[0][1] = 'Aantal'; cells[0][2] = 'Prijs'; cells[0][3] = 'Totaal';
    cells[1][0] = 'Appels'; cells[1][1] = '5'; cells[1][2] = '1.2'; cells[1][3] = '=B2*C2';
    cells[2][0] = 'Brood'; cells[2][1] = '2'; cells[2][2] = '2.5'; cells[2][3] = '=B3*C3';
    cells[3][0] = 'Totaal'; cells[3][3] = '=D2+D3';
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
      if (inputs[r][c]) inputs[r][c].value = cells[r][c] || '';
    }
    flash('Voorbeeld geladen');
  });
  bar.append(h('span', '', 'fx'), formulaBar, note);

  const area = h('div', 'sheet-editor');
  const scroller = h('div', 'sheet-scroll');
  scroller.append(table);
  area.append(scroller);
  setActive(0, 0);

  return {
    bar,
    area,
    getHtml: () => buildSheetHtml({ cells }),
    setHtml: html => {
      data = parseSheetHtml(html);
      cells = data.cells || emptyGrid();
      for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
        if (inputs[r] && inputs[r][c]) inputs[r][c].value = (cells[r] && cells[r][c]) || '';
      }
    },
    flash,
    focus: () => { if (inputs[0] && inputs[0][0]) inputs[0][0].focus(); }
  };
}
