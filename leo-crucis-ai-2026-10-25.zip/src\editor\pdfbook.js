// PDF-boeken: inlezen + eigen viewer (pdf.js), alle pagina's onder elkaar, scrollen in het vlak.
const h = (tag, cls, text) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
};

const DEFAULT_MAX_MB = 500;

function pdfQualityScale() {
  try {
    const q = document.documentElement.getAttribute('data-pdf-quality') || 'normal';
    if (q === 'fast') return Math.min(1, window.devicePixelRatio || 1) * 0.75;
    if (q === 'sharp') return Math.min(2.5, (window.devicePixelRatio || 1) * 1.25);
    return window.devicePixelRatio || 1;
  } catch { return window.devicePixelRatio || 1; }
}

let pdfjsLib = null;

/** Huidige limiet ophalen uit instellingen (valt terug op 500 MB). */
function currentMaxMb() {
  try {
    const raw = localStorage.getItem('lc-settings');
    if (raw) {
      const s = JSON.parse(raw);
      const n = Number(s && s.pdfMaxMb);
      if (Number.isFinite(n) && n > 0) return Math.min(2000, Math.max(1, Math.round(n)));
    }
  } catch (e) {}
  return DEFAULT_MAX_MB;
}

async function loadPdfJs() {
  if (pdfjsLib) return pdfjsLib;
  pdfjsLib = await import(new URL('vendor/pdf.min.mjs', import.meta.url).href);
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('vendor/pdf.worker.min.mjs', import.meta.url).href;
  return pdfjsLib;
}

function dataUrlToUint8(dataUrl) {
  const m = /^data:([^;]+);base64,(.+)$/i.exec(dataUrl || '');
  if (!m) throw new Error('Ongeldige PDF-data');
  const bin = atob(m[2]);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return arr;
}

export function parsePdfHtml(html) {
  const d = document.createElement('div');
  d.innerHTML = html || '';
  const el = d.querySelector('.pdf-book');
  if (!el) return { dataUrl: '', name: '' };
  return {
    dataUrl: el.getAttribute('data-pdf') || '',
    name: el.getAttribute('data-name') || 'document.pdf'
  };
}

export function buildPdfHtml(dataUrl, name) {
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  return `<div class="pdf-book" data-name="${esc(name)}" data-pdf="${esc(dataUrl)}"></div>`;
}

export async function fileToPdfDataUrl(file) {
  if (!file || (file.type !== 'application/pdf' && !/\.pdf$/i.test(file.name || ''))) {
    throw new Error('Kies een PDF-bestand');
  }
  const maxMb = currentMaxMb();
  if (file.size > maxMb * 1024 * 1024) throw new Error(`PDF mag max. ${maxMb} MB zijn`);
  return new Promise((ok, no) => {
    const r = new FileReader();
    r.onload = () => ok(r.result);
    r.onerror = () => no(new Error('Kon PDF niet lezen'));
    r.readAsDataURL(file);
  });
}

/**
 * Eigen PDF-viewer: alle pagina's onder elkaar, scrollen in het grijze vlak.
 */
export function renderPdfView(html, { title, onBack, onEdit, dev, infoBtn }) {
  const { dataUrl, name } = parsePdfHtml(html);
  const wrap = h('div', 'pdf-view');
  const head = h('div', 'view-head');
  const back = h('button', 'back', '← Terug');
  back.type = 'button';
  back.onclick = onBack;
  head.append(back, h('h1', '', title || name || 'PDF'));
  if (dev && onEdit) {
    const edit = h('button', 'dev-btn pencil', '✎');
    edit.type = 'button';
    edit.title = 'PDF vervangen';
    edit.onclick = () => { document.body.classList.remove('pdf-open'); onEdit(); };
    head.append(edit);
  }
  if (infoBtn) head.append(infoBtn);
  wrap.append(head);

  document.body.classList.add('pdf-open');
  const headerEl = document.querySelector('header');
  const syncHeaderH = () => {
    const hh = headerEl ? headerEl.getBoundingClientRect().height : 64;
    document.documentElement.style.setProperty('--header-h', hh + 'px');
  };
  syncHeaderH();
  const onResizeWin = () => { syncHeaderH(); };
  window.addEventListener('resize', onResizeWin);
  const unlock = () => {
    document.body.classList.remove('pdf-open');
    window.removeEventListener('resize', onResizeWin);
  };
  const _onBack = onBack;
  onBack = () => { unlock(); if (_onBack) _onBack(); };
  back.onclick = onBack;

  if (!dataUrl) {
    wrap.append(h('p', 'pdf-empty', 'Nog geen PDF geladen. Klik op bewerken om een bestand te kiezen.'));
    return wrap;
  }

  // Toolbar: geen vorige/volgende — wel zoom, passend, download, print
  const toolbar = h('div', 'lc-pdf-toolbar');
  const pageLabel = h('span', 'lc-pdf-page', '…');
  const btnZoomOut = h('button', 'back', '−');
  const btnZoomIn = h('button', 'back', '+');
  const zoomInput = h('input', 'lc-pdf-zoom-input');
  zoomInput.type = 'number';
  zoomInput.min = '35';
  zoomInput.max = '300';
  zoomInput.step = '5';
  zoomInput.value = '100';
  zoomInput.title = 'Zoompercentage (35–300)';
  zoomInput.setAttribute('aria-label', 'Zoompercentage');
  const zoomUnit = h('span', 'lc-pdf-zoom-unit', '%');
  const btnFit = h('button', 'back', 'Passend');
  const btnDl = h('button', 'back', '⬇ Downloaden');
  const btnPrint = h('button', 'back', '🖨 Afdrukken');
  [btnZoomOut, btnZoomIn, btnFit, btnDl, btnPrint].forEach(b => { b.type = 'button'; });
  btnZoomOut.title = 'Uitzoomen';
  btnZoomIn.title = 'Inzoomen';
  btnFit.title = 'Breedte passend';
  btnDl.title = 'PDF downloaden';
  btnPrint.title = 'Afdrukken via Leo Crucis';
  toolbar.append(pageLabel, h('span', 'lc-pdf-sep', '|'), btnZoomOut, zoomInput, zoomUnit, btnZoomIn, btnFit, h('span', 'lc-pdf-sep', '|'), btnDl, btnPrint);

  const frame = h('div', 'lc-pdf-frame');
  const stage = h('div', 'lc-pdf-stage');
  const pagesHost = h('div', 'lc-pdf-pages');
  stage.append(pagesHost);
  frame.append(toolbar, stage);
  wrap.append(frame);

  // Laadcirkel + statusbericht (zichtbaar tijdens laden / renderen / fouten)
  const status = h('div', 'pdf-status');
  status.style.display = 'none';
  const spinner = h('div', 'pdf-spinner');
  spinner.setAttribute('aria-hidden', 'true');
  const statusText = h('p', 'pdf-status-text', '');
  status.append(spinner, statusText);
  wrap.append(status);

  const showStatus = (msg, { spin = false } = {}) => {
    statusText.textContent = msg || '';
    status.classList.toggle('spinning', !!spin);
    status.style.display = msg ? 'flex' : 'none';
  };

  let pdfDoc = null;
  let scale = 1;
  let rendering = false;

  const updateZoomLabel = () => {
    zoomInput.value = String(Math.round(scale * 100));
  };

  const applyZoomPercent = (pct) => {
    let n = parseInt(pct, 10);
    if (!Number.isFinite(n)) n = 100;
    n = Math.max(35, Math.min(300, n));
    scale = n / 100;
    updateZoomLabel();
    renderAll();
  };

  zoomInput.addEventListener('change', () => applyZoomPercent(zoomInput.value));
  zoomInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      applyZoomPercent(zoomInput.value);
      zoomInput.blur();
    }
  });

  /** Alle pagina's onder elkaar tekenen */
  const renderAll = async () => {
    if (!pdfDoc || rendering) return;
    rendering = true;
    showStatus('Pagina\'s weergeven…', { spin: true });
    try {
      const n = pdfDoc.numPages;
      pageLabel.textContent = n === 1 ? '1 pagina' : n + ' pagina\'s';
      updateZoomLabel();
      pagesHost.replaceChildren();
      const outputScale = pdfQualityScale();

      for (let num = 1; num <= n; num++) {
        const page = await pdfDoc.getPage(num);
        const viewport = page.getViewport({ scale });
        const canvas = h('canvas', 'lc-pdf-canvas');
        canvas.width = Math.floor(viewport.width * outputScale);
        canvas.height = Math.floor(viewport.height * outputScale);
        canvas.style.width = Math.floor(viewport.width) + 'px';
        canvas.style.height = Math.floor(viewport.height) + 'px';
        const wrapPage = h('div', 'lc-pdf-page-wrap');
        const label = h('div', 'lc-pdf-page-num', String(num));
        wrapPage.append(label, canvas);
        pagesHost.append(wrapPage);
        const ctx = canvas.getContext('2d');
        const transform = outputScale !== 1 ? [outputScale, 0, 0, outputScale, 0, 0] : null;
        await page.render({ canvasContext: ctx, viewport, transform }).promise;
      }
      showStatus('');
    } catch (e) {
      showStatus('Kon pagina\'s niet tonen: ' + (e.message || e));
    }
    rendering = false;
  };

  btnZoomIn.onclick = () => {
    scale = Math.min(3, scale + 0.15);
    renderAll();
  };
  btnZoomOut.onclick = () => {
    scale = Math.max(0.35, scale - 0.15);
    renderAll();
  };
  btnFit.onclick = async () => {
    if (!pdfDoc) return;
    const page = await pdfDoc.getPage(1);
    const base = page.getViewport({ scale: 1 });
    const availW = Math.max(100, stage.clientWidth - 32);
    scale = Math.max(0.35, Math.min(2.5, availW / base.width));
    await renderAll();
  };
  btnDl.onclick = () => {
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = name || 'document.pdf';
    a.click();
  };
  btnPrint.onclick = async () => {
    try {
      showStatus('Afdrukvoorbeeld voorbereiden…', { spin: true });
      const { openPdfPrintPreview } = await import('./pdf.js');
      if (typeof openPdfPrintPreview === 'function') {
        await openPdfPrintPreview(title || name, dataUrl, name);
      } else {
        btnDl.click();
      }
      showStatus('');
    } catch (e) {
      showStatus(e.message || String(e));
    }
  };

  stage.tabIndex = 0;
  stage.addEventListener('keydown', e => {
    if (e.key === '+' || e.key === '=') btnZoomIn.click();
    if (e.key === '-') btnZoomOut.click();
  });

  (async () => {
    try {
      showStatus('PDF laden…', { spin: true });
      const lib = await loadPdfJs();
      const data = dataUrlToUint8(dataUrl);
      pdfDoc = await lib.getDocument({ data }).promise;
      showStatus('Pagina\'s weergeven…', { spin: true });
      // Altijd starten op 100%
      scale = 1;
      await renderAll();
      showStatus('');
    } catch (e) {
      showStatus('PDF kon niet geladen worden: ' + (e.message || e));
      console.error(e);
    }
  })();

  return wrap;
}

/** Editor: PDF kiezen / vervangen. */
export function createPdfEditor(initialHtml, { ask }) {
  let { dataUrl, name } = parsePdfHtml(initialHtml);
  const area = h('div', 'pdf-editor');
  const note = h('p', 'editor-note', name ? `Huidig bestand: ${name}` : 'Nog geen PDF gekozen.');
  const preview = h('div', 'pdf-preview');

  const file = h('input');
  file.type = 'file';
  file.accept = 'application/pdf,.pdf';
  file.hidden = true;
  file.onchange = async () => {
    const f = file.files[0];
    if (!f) return;
    try {
      dataUrl = await fileToPdfDataUrl(f);
      name = f.name || 'document.pdf';
      note.textContent = `Gekozen: ${name} (${(f.size / 1024).toFixed(0)} KB) — klik Opslaan`;
      preview.replaceChildren();
      preview.append(h('p', '', `PDF geladen: ${name}. Na opslaan zie je alle pagina's onder elkaar.`));
    } catch (e) {
      note.textContent = e.message || String(e);
    }
    file.value = '';
  };

  const pick = h('button', 'dlg-ok', '📄 PDF kiezen…');
  pick.type = 'button';
  pick.onclick = () => file.click();

  const clear = h('button', 'back', 'Wissen');
  clear.type = 'button';
  clear.onclick = () => {
    dataUrl = '';
    name = '';
    note.textContent = 'Nog geen PDF gekozen.';
    preview.replaceChildren();
  };

  const row = h('div', 'pdf-editor-actions');
  row.append(pick, clear);
  area.append(note, row, preview, file);

  return {
    area,
    getHtml: () => buildPdfHtml(dataUrl, name),
    setHtml: html => {
      const p = parsePdfHtml(html);
      dataUrl = p.dataUrl;
      name = p.name;
      note.textContent = name ? `Huidig bestand: ${name}` : 'Nog geen PDF gekozen.';
      preview.replaceChildren();
    },
    flash: t => { note.textContent = t; },
    focus: () => pick.focus()
  };
}
