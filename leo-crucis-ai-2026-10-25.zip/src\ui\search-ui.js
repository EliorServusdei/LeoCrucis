/**
 * ui/search-ui.js — zoekscherm, tabs, resultaten, geschiedenis-panel
 */
import { el } from '../core/dom.js';
import {
  loadSearchRecent,
  getSearchHistory,
  saveSearchRecent,
  clearSearchHistory,
  removeSearchHistoryEntry,
  formatSearchHistoryTime,
  formatSearchHistoryRelative,
  historyDayKey,
  HISTORY_DAY_LABELS
} from './search-history.js';

/**
 * @param {object} deps
 */
export function createSearchUiApi(deps) {
  const {
    loadIndex,
    searchAll,
    suggest = async () => [],
    snippet: searchSnippet,
    allItems,
    canOpenNewRecent,
    pushRecentApp,
    removeRecentApp,
    showHome,
    showSection,
    showMiniApp,
    showFocus,
    showMediaPlayer,
    startCreate = () => {},
    ask = async () => true,
    miniAppIconSvg,
    viewContent,
    home,
    view,
    setHash = (h) => { try { location.hash = h; } catch (_) {} },
    setCurrentSection = () => {},
    listLeoApps = () => [],
    openExternalUrl = async () => {},
    openBrowser = async () => {},
  } = deps;

  const searchTabs = { list: [], active: 0, seq: 0 };
  let searchUI = null;
  const SEARCH_KINDS = [['all', 'Alles'], ['app', 'Apps'], ['library', 'Bibliotheek'], ['woordenboek', 'Woordenboek'], ['bijbel', 'Bijbel']];
  const SEARCH_TYPES = [
    ['all', 'Alles', '🗂️'], ['doc', 'Documenten', '📝'], ['pdf', "PDF's", '📄'],
    ['pptx', 'Presentaties', '📊'], ['xlsx', 'Excel', '📈'], ['foto', "Foto's", '🖼️']
  ];
  // Bestandstype van een resultaat (alleen bibliotheek en foto's zijn bestanden; woordenboek en bijbel niet).
  function gsTypeOf(g) {
    if (g.kind === 'foto') return 'foto';
    if (g.kind !== 'library') return null;
    const it = allItems().find(i => i.id === g.id);
    const t = (it && it.type) || g.type || 'doc';
    return ['doc', 'pdf', 'pptx', 'xlsx'].includes(t) ? t : 'doc';
  }
  const SEARCH_STEP = 10;
  const SEARCH_MAX_TABS = 20;

  // Herkent een website-adres (https://…, www.…, of domein met bekende extensie) in de zoekbalk.
  const GS_TLDS = 'com|org|net|be|nl|eu|edu|gov|info|io|co|de|fr|uk|us|es|it|pl|ch|at|lu|ie|va|app|dev|ai|tv|me|xyz|online|site|wiki|vlaanderen|brussels|church|catholic|bible|news|blog|shop|ca|au|nz|jp|ru|se|no|dk|fi|pt|gr|cz|ro|hu|int|mil|ac|ly|fm|gg|sh|cc|ws|to';
  function gsAsUrl(raw) {
    const s = String(raw || '').trim().replace(/^['"]+|['"]+$/g, '');
    if (!s || /\s/.test(s)) return null;
    if (/^https?:\/\/[^\s/]+/i.test(s)) return s;
    const m = s.match(/^((?:[a-z0-9-]+\.)+([a-z]{2,24})|localhost|(?:\d{1,3}\.){3}\d{1,3})(?::\d+)?([/?#].*)?$/i);
    if (!m) return null;
    const host = m[1].toLowerCase();
    if (host === 'localhost' || /^\d/.test(host)) return 'http://' + s;
    if (/^www\./.test(host) || new RegExp('^(' + GS_TLDS + ')$').test(m[2].toLowerCase())) return 'https://' + s;
    return null;
  }
  const gsHost = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (_) { return u; } };
  const gsNorm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const gsTerms = q => {
    const t = gsNorm(q).split(/\s+/).filter(x => x.length > 1);
    // Spellingsvarianten die de bijbelzoeker ook vindt (Jezus/Jesus)
    for (const x of [...t]) { if (x === 'jezus') t.push('jesus'); else if (x === 'jesus') t.push('jezus'); }
    return t;
  };
  // Per teken normaliseren, zodat posities in de genormaliseerde tekst terug te rekenen zijn naar de originele tekst.
  function gsRanges(text, terms) {
    let n = ''; const map = [];
    for (let i = 0; i < text.length; i++) {
      const c = gsNorm(text[i]);
      for (let k = 0; k < c.length; k++) { n += c[k]; map.push(i); }
    }
    const r = [];
    for (const t of terms) {
      let p = n.indexOf(t);
      while (p >= 0 && r.length < 80) { r.push([map[p], map[p + t.length - 1] + 1]); p = n.indexOf(t, p + t.length); }
    }
    r.sort((a, b) => a[0] - b[0]);
    const out = [];
    for (const x of r) {
      const last = out[out.length - 1];
      if (last && x[0] <= last[1]) last[1] = Math.max(last[1], x[1]); else out.push([x[0], x[1]]);
    }
    return out;
  }
  function gsSnippet(text, terms, len = 230) {
    text = String(text || '').replace(/\s+/g, ' ').trim();
    if (text.length <= len) return text;
    const r = gsRanges(text, terms);
    let start = r.length ? Math.max(0, r[0][0] - 70) : 0;
    if (start > 0) { const sp = text.indexOf(' ', start); if (sp >= 0 && sp < start + 20) start = sp + 1; }
    let end = Math.min(text.length, start + len);
    if (end < text.length) { const sp = text.lastIndexOf(' ', end); if (sp > start + len * 0.6) end = sp; }
    return (start ? '… ' : '') + text.slice(start, end) + (end < text.length ? ' …' : '');
  }
  // Zoektermen vet markeren (alleen tekstnodes, nooit innerHTML met zoektekst).
  function gsHighlight(node, text, terms) {
    let pos = 0;
    for (const [s, e] of gsRanges(text, terms)) {
      if (s > pos) node.append(text.slice(pos, s));
      const m = document.createElement('mark'); m.textContent = text.slice(s, e); node.append(m);
      pos = e;
    }
    if (pos < text.length) node.append(text.slice(pos));
    return node;
  }

  const activeSearchTab = () => searchTabs.list.find(t => t.id === searchTabs.active) || searchTabs.list[0];
  function newSearchTab() {
    const t = { id: ++searchTabs.seq, q: '', draft: null, found: null, filter: 'all', ftype: 'all', btest: 'all', bbook: 'all', url: '', frame: null, shown: SEARCH_STEP, scroll: 0, state: 'empty', error: '', token: 0, progress: '', ms: 0 };
    searchTabs.list.push(t);
    return t;
  }
  function saveSearchScroll() {
    const t = activeSearchTab();
    if (t && searchUI && searchUI.page.isConnected) t.scroll = window.scrollY || 0;
  }

  function showSearchHistoryPanel(opts) {
    const ui = searchUI;
    if (!ui || !ui.page.isConnected) return;
    const filterQ = (opts && opts.filter != null) ? String(opts.filter) : '';
    const all = getSearchHistory();
    const fq = filterQ.trim().toLowerCase();
    const list = fq
      ? all.filter(e => e.q.toLowerCase().includes(fq))
      : all;

    const panel = el('div', 'gs-history');

    // Kop
    const head = el('div', 'gs-history-head');
    const headLeft = el('div', 'gs-history-head-left');
    const icon = el('span', 'gs-history-icon');
    icon.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
    headLeft.append(icon, el('h2', 'gs-history-title', 'Zoekgeschiedenis'));
    const close = el('button', 'gs-history-close', '×');
    close.type = 'button';
    close.title = 'Sluiten';
    close.setAttribute('aria-label', 'Geschiedenis sluiten');
    close.onclick = () => { try { renderSearchBody(true); } catch (_) {} };
    head.append(headLeft, close);
    panel.append(head);

    // Meta + acties
    const metaRow = el('div', 'gs-history-meta-row');
    const meta = el('p', 'gs-history-meta');
    if (!all.length) {
      meta.textContent = 'Nog geen zoekopdrachten opgeslagen.';
    } else if (fq) {
      meta.textContent = list.length + ' van ' + all.length + ' zoekopdracht' + (all.length === 1 ? '' : 'en');
    } else {
      meta.textContent = all.length + ' zoekopdracht' + (all.length === 1 ? '' : 'en') + ' · lokaal opgeslagen';
    }
    metaRow.append(meta);
    if (all.length) {
      const actions = el('div', 'gs-history-actions');
      const clearBtn = el('button', 'gs-history-clear');
      clearBtn.type = 'button';
      clearBtn.title = 'Hele geschiedenis wissen';
      clearBtn.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/></svg><span>Wissen</span>';
      clearBtn.onclick = async () => {
        if (!await ask('Hele zoekgeschiedenis wissen?', { yes: 'Wissen', no: 'Annuleren' })) return;
        clearSearchHistory();
        showSearchHistoryPanel();
      };
      actions.append(clearBtn);
      metaRow.append(actions);
    }
    panel.append(metaRow);

    // Zoeken in geschiedenis
    if (all.length) {
      const filterWrap = el('div', 'gs-history-filter');
      const filterInput = document.createElement('input');
      filterInput.type = 'search';
      filterInput.className = 'gs-history-filter-input';
      filterInput.placeholder = 'Zoek in geschiedenis…';
      filterInput.setAttribute('aria-label', 'Filter zoekgeschiedenis');
      filterInput.autocomplete = 'off';
      filterInput.value = filterQ;
      let filterTimer = null;
      filterInput.addEventListener('input', () => {
        clearTimeout(filterTimer);
        filterTimer = setTimeout(() => {
          showSearchHistoryPanel({ filter: filterInput.value });
          const again = ui.panel.querySelector('.gs-history-filter-input');
          if (again) {
            again.focus();
            const len = again.value.length;
            try { again.setSelectionRange(len, len); } catch (_) {}
          }
        }, 120);
      });
      filterInput.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
          e.preventDefault();
          if (filterInput.value) {
            filterInput.value = '';
            showSearchHistoryPanel();
          } else {
            close.click();
          }
        }
      });
      filterWrap.append(filterInput);
      panel.append(filterWrap);
    }

    // Lijst of lege staat
    if (!all.length) {
      const empty = el('div', 'gs-history-empty');
      empty.innerHTML =
        '<div class="gs-history-empty-icon" aria-hidden="true">' +
        '<svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>' +
        '</div>' +
        '<p class="gs-history-empty-title">Nog geen zoekgeschiedenis</p>' +
        '<p class="gs-history-empty-sub">Zoekopdrachten verschijnen hier automatisch. Klik later op een item om opnieuw te zoeken.</p>';
      panel.append(empty);
    } else if (!list.length) {
      const empty = el('div', 'gs-history-empty');
      empty.innerHTML =
        '<p class="gs-history-empty-title">Geen resultaten</p>' +
        '<p class="gs-history-empty-sub">Geen zoekopdrachten gevonden voor “' + filterQ.replace(/[<>&"]/g, '') + '”.</p>';
      panel.append(empty);
    } else {
      // Groeperen per dag
      const groups = [];
      const seen = new Set();
      for (const e of list) {
        const key = historyDayKey(e.at);
        if (!seen.has(key)) {
          seen.add(key);
          groups.push({ key, label: HISTORY_DAY_LABELS[key] || key, items: [] });
        }
        groups.find(g => g.key === key).items.push(e);
      }

      const listWrap = el('div', 'gs-history-groups');
      for (const g of groups) {
        const section = el('section', 'gs-history-group');
        section.append(el('h3', 'gs-history-group-title', g.label));
        const ul = el('ul', 'gs-history-list');
        for (const e of g.items) {
          const li = el('li', 'gs-history-item');

          const main = el('button', 'gs-history-q');
          main.type = 'button';
          main.title = 'Opnieuw zoeken: ' + e.q;
          const qText = el('span', 'gs-history-q-text', e.q);
          const time = el('span', 'gs-history-time', formatSearchHistoryRelative(e.at));
          time.title = formatSearchHistoryTime(e.at);
          main.append(qText, time);
          main.onclick = () => {
            try { runTabSearch(activeSearchTab(), e.q); } catch (_) {}
          };

          const tools = el('div', 'gs-history-item-tools');

          const btnNew = el('button', 'gs-history-tool');
          btnNew.type = 'button';
          btnNew.title = 'Openen in nieuw tabblad';
          btnNew.setAttribute('aria-label', 'Openen in nieuw tabblad: ' + e.q);
          btnNew.innerHTML = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14"/><path d="M5 12h14"/></svg>';
          btnNew.onclick = ev => {
            ev.stopPropagation();
            try { addSearchTab(e.q); } catch (_) {}
          };

          const btnCopy = el('button', 'gs-history-tool');
          btnCopy.type = 'button';
          btnCopy.title = 'Kopiëren';
          btnCopy.setAttribute('aria-label', 'Kopiëren: ' + e.q);
          btnCopy.innerHTML = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>';
          btnCopy.onclick = async ev => {
            ev.stopPropagation();
            try {
              await navigator.clipboard.writeText(e.q);
              btnCopy.classList.add('is-done');
              btnCopy.title = 'Gekopieerd';
              setTimeout(() => { btnCopy.classList.remove('is-done'); btnCopy.title = 'Kopiëren'; }, 1200);
            } catch (_) {}
          };

          const btnDel = el('button', 'gs-history-tool gs-history-tool-del');
          btnDel.type = 'button';
          btnDel.title = 'Verwijderen';
          btnDel.setAttribute('aria-label', 'Verwijderen: ' + e.q);
          btnDel.innerHTML = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 6l12 12"/><path d="M18 6L6 18"/></svg>';
          btnDel.onclick = ev => {
            ev.stopPropagation();
            removeSearchHistoryEntry(e);
            showSearchHistoryPanel({ filter: filterQ });
          };

          tools.append(btnNew, btnCopy, btnDel);
          li.append(main, tools);
          ul.append(li);
        }
        section.append(ul);
        listWrap.append(section);
      }
      panel.append(listWrap);
    }

    ui.panel.replaceChildren(panel);
    ui.barSlot.hidden = true;
    ui.panel.classList.remove('is-compact');
  }
  function showResults(q = '') {
    if (!canOpenNewRecent('app-search')) return;
    setCurrentSection(null);
    document.body.classList.remove('pdf-open');
    // Zelfde scherm-indeling als andere full-views: body scrollt niet, header blijft vast
    document.body.classList.add('browser-open');
    document.body.classList.add('search-open');
    if (!searchTabs.list.length) searchTabs.active = newSearchTab().id;
    viewContent.replaceChildren();

    const page = el('div', 'search-page gs');
    const top = el('div', 'gs-top');                 // blijft bovenaan staan bij scrollen
    const strip = el('div', 'gs-tabs');
    strip.setAttribute('role', 'tablist');
    strip.setAttribute('aria-label', 'Zoektabbladen');
    const barSlot = el('div', 'gs-barslot');
    top.append(strip, barSlot);
    const panel = el('div', 'gs-panel');
    panel.setAttribute('role', 'tabpanel');
    const webhost = el('div', 'gs-webhost');            // hier staan de webpagina's van web-tabbladen (blijven bewaard bij wisselen)
    page.append(top, panel, webhost);
    viewContent.append(page);
    searchUI = { page, strip, barSlot, panel, webhost, out: null, input: null };
    for (const t of searchTabs.list) if (t.frame) webhost.append(t.frame);
    // De vaste zoekbalk moet onder de (vaste) hoofdbalk blijven staan.
    const setHeadH = () => { const h = document.querySelector('header'); page.style.setProperty('--gs-head', (h ? Math.round(h.getBoundingClientRect().height) : 56) + 'px'); };
    setHeadH();
    window.addEventListener('resize', () => { if (page.isConnected) setHeadH(); });

    home.style.display = 'none';
    view.style.display = 'block';
    setHash('#zoek');
    renderSearchTabs();
    renderSearchBody(true);
    if (q) runTabSearch(activeSearchTab(), q);

    // Zoeken = één app in recente apps (niet elk tabblad apart)
    pushRecentApp({
      id: 'app-search',
      kind: 'search',
      iconKind: 'search',
      title: 'Zoeken',
      hint: 'App',
      activate: () => showResults(''),
      close: () => {
        try {
          // Alle zoektabs weg, terug naar home als zoeken actief was
          if (typeof searchTabs !== 'undefined' && Array.isArray(searchTabs.list)) {
            const ids = searchTabs.list.map(t => t.id);
            for (const id of ids) {
              try { if (typeof closeSearchTab === 'function') closeSearchTab(id); } catch (_) {}
            }
          }
          if (document.body.classList.contains('search-open')) showHome();
        } catch (_) {}
      }
    });
  }

  function gsTabLabel(t) {
    if (!t) return 'Startscherm';
    if (t.state === 'web') return gsHost(t.url) || t.url || 'Web';
    const q = String(t.q || '').trim();
    if (!q || t.state === 'empty') return 'Startscherm';
    return q;
  }

  /** Actieve tab terug naar leeg startscherm (zoekbalk leeg, voorbeelden zichtbaar). */
  function goSearchHome() {
    const t = activeSearchTab();
    if (!t) return;
    t.token++;
    t.q = '';
    t.draft = null;
    t.found = null;
    t.filter = 'all';
    t.ftype = 'all';
    t.btest = 'all';
    t.bbook = 'all';
    t.shown = SEARCH_STEP;
    t.progress = '';
    t.error = '';
    t.ms = 0;
    t.scroll = 0;
    t.state = 'empty';
    t.url = '';
    if (t.frame) { try { t.frame.remove(); } catch (_) {} t.frame = null; }
    try {
      const box = document.getElementById('gs-suggest');
      if (box) { box.hidden = true; box.replaceChildren(); }
    } catch (_) {}
    renderSearchTabs();
    renderSearchBody(false);
    window.scrollTo(0, 0);
    try {
      if (searchUI && searchUI.input) {
        searchUI.input.value = '';
        searchUI.input.focus();
      }
    } catch (_) {}
  }

  function renderSearchTabs() {
    const ui = searchUI; if (!ui || !ui.page.isConnected) return;
    ui.strip.replaceChildren();

    // Home-icoon: altijd zichtbaar, terug naar startscherm van zoeken
    const homeBtn = el('button', 'gs-tab-home');
    homeBtn.type = 'button';
    homeBtn.title = 'Startscherm';
    homeBtn.setAttribute('aria-label', 'Terug naar startscherm');
    homeBtn.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 11.5 12 4l8 7.5"/><path d="M6.5 10.5V20h11V10.5"/></svg>';
    homeBtn.onclick = () => goSearchHome();
    ui.strip.append(homeBtn);

    for (const t of searchTabs.list) {
      const sel = t.id === searchTabs.active;
      const tab = el('div', 'gs-tab' + (sel ? ' is-active' : '') + ((t.state === 'empty' || !String(t.q || '').trim()) && t.state !== 'web' ? ' is-home' : ''));
      const b = el('button', 'gs-tab-btn');
      b.type = 'button';
      b.id = 'gs-tab-' + t.id;
      b.setAttribute('role', 'tab');
      b.setAttribute('aria-selected', sel ? 'true' : 'false');
      const web = t.state === 'web';
      const label = gsTabLabel(t);
      b.title = label;
      if (t.state === 'loading') b.append(el('span', 'gs-spin'));
      if (web) b.append(el('span', 'gs-tab-ic', '🌐'));
      else if (t.state === 'empty' || !String(t.q || '').trim()) b.append(el('span', 'gs-tab-ic gs-tab-ic-home', '⌂'));
      b.append(el('span', 'gs-tab-title', label));
      b.onclick = () => switchSearchTab(t.id);
      const x = el('button', 'gs-tab-x', '×');
      x.type = 'button';
      x.title = 'Tabblad sluiten';
      x.setAttribute('aria-label', 'Tabblad sluiten: ' + label);
      x.onclick = e => { e.stopPropagation(); closeSearchTab(t.id); };
      tab.addEventListener('auxclick', e => { if (e.button === 1) { e.preventDefault(); closeSearchTab(t.id); } });
      tab.append(b, x);
      ui.strip.append(tab);
    }
    const plus = el('button', 'gs-new', '+');
    plus.type = 'button';
    plus.title = 'Nieuw tabblad';
    plus.setAttribute('aria-label', 'Nieuw zoektabblad');
    plus.onclick = () => addSearchTab('');
    ui.strip.append(plus);
    const act = ui.strip.querySelector('.is-active');
    if (act && act.scrollIntoView) { try { act.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (_) {} }
  }

  function switchSearchTab(id) {
    if (id === searchTabs.active) return;
    saveSearchScroll();
    searchTabs.active = id;
    renderSearchTabs();
    renderSearchBody(true);
  }
  function addSearchTab(q) {
    if (searchTabs.list.length >= SEARCH_MAX_TABS) {
      const last = searchTabs.list[searchTabs.list.length - 1];
      switchSearchTab(last.id);
      if (q) runTabSearch(last, q);
      return;
    }
    saveSearchScroll();
    const t = newSearchTab();
    searchTabs.active = t.id;
    renderSearchTabs();
    renderSearchBody(false);
    window.scrollTo(0, 0);
    if (q) runTabSearch(t, q);
  }
  function closeSearchTab(id) {
    const i = searchTabs.list.findIndex(t => t.id === id);
    if (i < 0) return;
    const wasActive = id === searchTabs.active;
    searchTabs.list[i].token++;                 // lopende zoekopdracht negeren
    if (searchTabs.list[i].frame) { searchTabs.list[i].frame.remove(); searchTabs.list[i].frame = null; }
    searchTabs.list.splice(i, 1);
    // Laatste tabblad dicht → terug naar startscherm
    if (!searchTabs.list.length) {
      searchTabs.active = 0;
      try { showHome(); } catch (_) {}
      return;
    }
    if (wasActive) {
      searchTabs.active = searchTabs.list[Math.min(i, searchTabs.list.length - 1)].id;
      renderSearchTabs();
      renderSearchBody(true);
    } else {
      renderSearchTabs();
    }
  }

  // Linkerdeel van het tabblad: zoekbalk. Rechterdeel (resultaten) wordt apart ververst zodat typen niet gestoord wordt.
  function renderSearchBody(restore) {
    const ui = searchUI; if (!ui || !ui.page.isConnected) return;
    // Vorige suggest-listeners + paneel opruimen (voorkomt zweven rechtsboven)
    try {
      if (ui._suggestAbort) { ui._suggestAbort.abort(); ui._suggestAbort = null; }
      const box = document.getElementById('gs-suggest');
      if (box) { box.hidden = true; box.replaceChildren(); box.style.cssText = ''; }
    } catch (_) {}
    const t = activeSearchTab();
    const p = ui.panel;
    p.replaceChildren();
    ui.barSlot.replaceChildren();
    p.setAttribute('aria-labelledby', 'gs-tab-' + t.id);
    const compact = t.state !== 'empty';
    ui.barSlot.hidden = !compact;
    ui.panel.classList.toggle('is-compact', compact);

    let heroEl = null;
    if (!compact) {
      heroEl = el('div', 'search-hero');
      const iconWrap = el('div', 'search-hero-icon');
      const logo = document.createElement('img');
      logo.src = 'assets/logo.png'; logo.alt = 'Leo Crucis'; logo.width = 48; logo.height = 48;
      iconWrap.append(logo);
      heroEl.append(iconWrap, el('h1', '', 'Zoeken in de bibliotheek'));
      heroEl.append(el('p', 'search-hero-sub', 'Zoek in apps, bibliotheek, woordenboek en bijbel'));
      p.append(heroEl);
    }

    function syncTypingLayout() {
      const typing = !compact && !!(input.value || '').trim();
      if (heroEl) heroEl.hidden = typing;
      p.classList.toggle('is-typing', typing);
      if (ui.types && t.state === 'web') ui.types.hidden = true;
    }

    const barWrap = el('div', 'gs-barwrap');
    const bar = el('div', 'searchbar searchbar-lg' + (compact ? ' gs-bar' : ''));
    const input = document.createElement('input');
    input.type = 'search';
    input.placeholder = 'Bijv. Augustinus, Atlas, startscherm…';
    input.setAttribute('aria-label', 'Zoeken in de bibliotheek');
    input.setAttribute('autocomplete', 'off');
    input.setAttribute('aria-autocomplete', 'list');
    input.setAttribute('aria-controls', 'gs-suggest');
    input.setAttribute('aria-expanded', 'false');
    input.value = t.draft != null ? t.draft : t.q;
    const btn = el('button', 'gs-go');
    btn.type = 'button';
    btn.title = 'Zoeken';
    btn.setAttribute('aria-label', 'Zoeken');
    btn.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>';

    // Suggesties: fixed op body, alleen zichtbaar tijdens typen in déze zoekbalk
    let suggestBox = document.getElementById('gs-suggest');
    if (!suggestBox) {
      suggestBox = el('div', 'gs-suggest');
      suggestBox.id = 'gs-suggest';
      suggestBox.setAttribute('role', 'listbox');
      document.body.appendChild(suggestBox);
    }
    // Altijd dicht bij (her)opbouw van de zoek-UI — voorkomt zweven in de hoek
    suggestBox.hidden = true;
    suggestBox.replaceChildren();
    let suggestItems = [];
    let suggestIdx = -1;
    let suggestTimer = 0;
    let suggestToken = 0;
    let suggestOpenFor = ''; // query waarvoor de lijst open staat
    const suggestAbort = new AbortController();

    const KIND_LABEL = { library: 'Bibliotheek', woordenboek: 'Woordenboek', bijbel: 'Bijbel', app: 'Apps', recent: 'Recent', foto: "Foto's" };

    function placeSuggest() {
      if (!input.isConnected) { hideSuggest(); return false; }
      const r = input.getBoundingClientRect();
      // Ongeldige meting (nog niet layout, of input verborgen) → niet tonen in de hoek
      if (!r.width || r.bottom < 8 || r.top > window.innerHeight - 8) {
        hideSuggest();
        return false;
      }
      const gap = 6;
      let w = Math.max(r.width, 240);
      w = Math.min(w, window.innerWidth - 16);
      let left = r.left;
      if (left + w > window.innerWidth - 8) left = Math.max(8, window.innerWidth - w - 8);
      if (left < 8) left = 8;
      let top = r.bottom + gap;
      const maxH = Math.min(380, window.innerHeight * 0.55);
      // Als er onder te weinig ruimte is: boven de balk
      if (top + 120 > window.innerHeight && r.top > maxH + gap) {
        top = Math.max(8, r.top - gap - Math.min(maxH, 280));
      }
      suggestBox.style.cssText = [
        'position:fixed',
        'left:' + left + 'px',
        'top:' + top + 'px',
        'width:' + w + 'px',
        'right:auto',
        'bottom:auto',
        'z-index:9999',
        'max-height:' + maxH + 'px'
      ].join(';');
      return true;
    }

    function hideSuggest() {
      clearTimeout(suggestTimer);
      suggestToken++; // annuleer in-flight refresh
      suggestBox.hidden = true;
      suggestBox.replaceChildren();
      suggestItems = [];
      suggestIdx = -1;
      suggestOpenFor = '';
      try { input.setAttribute('aria-expanded', 'false'); } catch (_) {}
    }

    function renderSuggestList(items) {
      // Alleen tonen als de gebruiker nog in dit veld typt
      if (document.activeElement !== input) { hideSuggest(); return; }
      const qNow = (input.value || '').trim();
      if (qNow.length < 2) { hideSuggest(); return; }

      suggestItems = items || [];
      suggestIdx = -1;
      suggestBox.replaceChildren();
      if (!suggestItems.length) { hideSuggest(); return; }
      for (let i = 0; i < suggestItems.length; i++) {
        const it = suggestItems[i];
        const row = el('button', 'gs-suggest-item');
        row.type = 'button';
        row.setAttribute('role', 'option');
        row.dataset.i = String(i);
        row.textContent = it.text;
        row.onmousedown = e => { e.preventDefault(); }; // blur niet laten winnen vóór click
        row.onclick = () => {
          input.value = it.text;
          t.draft = it.text;
          hideSuggest();

          runTabSearch(t, it.text);
        };
        suggestBox.append(row);
      }
      if (!placeSuggest()) return;
      suggestBox.hidden = false;
      suggestOpenFor = qNow;
      input.setAttribute('aria-expanded', 'true');
    }

    function highlightSuggest(i) {
      const rows = suggestBox.querySelectorAll('.gs-suggest-item');
      rows.forEach((r, j) => r.classList.toggle('is-active', j === i));
      suggestIdx = i;
      if (i >= 0 && suggestItems[i]) {
        input.value = suggestItems[i].text;
        t.draft = suggestItems[i].text;
      }
    }

    async function refreshSuggest() {
      const q = (input.value || '').trim();
      // Alleen tijdens typen, met minstens 2 tekens, en focus in dit veld
      if (document.activeElement !== input || q.length < 2) {
        hideSuggest();
        return;
      }
      const token = ++suggestToken;
      const nq = gsNorm(q);
      const items = [];
      const seen = new Set();
      const push = (text, kind, where, score) => {
        const key = gsNorm(text);
        if (!key || seen.has(key)) return;
        seen.add(key);
        items.push({ text, kind, where, score: score || 0 });
      };

      // Recente zoekopdrachten die matchen
      try {
        for (const h of (typeof loadSearchRecent === 'function' ? loadSearchRecent() : [])) {
          const text = typeof h === 'string' ? h : (h && h.q);
          if (!text) continue;
          const nt = gsNorm(text);
          if (nt.startsWith(nq) || (nq.length >= 2 && nt.includes(nq))) {
            push(text, 'recent', 'Recent', nt.startsWith(nq) ? 60 : 40);
          }
        }
      } catch (_) {}

      try {
        for (const it of allItems()) {
          const title = (it.title || '').trim();
          if (!title) continue;
          const nt = gsNorm(title);
          if (nt.startsWith(nq) || (nq.length >= 2 && nt.includes(nq))) {
            push(title, 'library', 'Bibliotheek', nt.startsWith(nq) ? 55 : 35);
          }
        }
      } catch (_) {}

      try {
        const extra = await suggest(q, 7);
        if (token !== suggestToken) return;
        for (const x of extra) {
          push(x.text, x.kind || 'library', x.where || '', x.score || 30);
        }
      } catch (_) {}

      if (token !== suggestToken) return;
      items.sort((a, b) => b.score - a.score || a.text.localeCompare(b.text, 'nl'));
      if (items.length < 7) {
        try {
          const more = await suggest(q, 14);
          if (token !== suggestToken) return;
          for (const x of more) {
            push(x.text, x.kind || 'library', x.where || '', (x.score || 30) - 5);
          }
        } catch (_) {}
        items.sort((a, b) => b.score - a.score || a.text.localeCompare(b.text, 'nl'));
      }
      if (token !== suggestToken) return;
      // Query kan intussen veranderd of leeggemaakt zijn
      if ((input.value || '').trim().length < 2 || document.activeElement !== input) {
        hideSuggest();
        return;
      }
      renderSuggestList(items.slice(0, 7));
    }

    btn.onclick = () => { hideSuggest(); runTabSearch(t, input.value); };

    input.addEventListener('input', () => {
      t.draft = input.value;
      syncTypingLayout();
      clearTimeout(suggestTimer);
      const q = (input.value || '').trim();
      if (q.length < 2) {
        hideSuggest();
        return;
      }
      // Alleen na echte toetsaanslagen (niet bij programmatisch zetten zonder input-event)
      suggestTimer = setTimeout(refreshSuggest, 140);
    }, { signal: suggestAbort.signal });

    // Geen suggesties bij pure focus/click — alleen tijdens typen
    input.addEventListener('blur', () => {
      setTimeout(() => {
        if (document.activeElement === input) return;
        if (suggestBox.contains(document.activeElement)) return;
        hideSuggest();
      }, 150);
    }, { signal: suggestAbort.signal });

    const onScrollOrResize = () => {
      if (suggestBox.hidden) return;
      if (document.activeElement !== input) { hideSuggest(); return; }
      if (!placeSuggest()) hideSuggest();
    };
    window.addEventListener('scroll', onScrollOrResize, { capture: true, signal: suggestAbort.signal });
    window.addEventListener('resize', onScrollOrResize, { signal: suggestAbort.signal });
    // Klik buiten: dicht
    document.addEventListener('pointerdown', (e) => {
      if (suggestBox.hidden) return;
      if (e.target === input || input.contains(e.target)) return;
      if (suggestBox.contains(e.target)) return;
      hideSuggest();
    }, { signal: suggestAbort.signal });

    input.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') {
        if (suggestBox.hidden || !suggestItems.length) return; // niet openen zonder typen
        e.preventDefault();
        highlightSuggest(Math.min(suggestItems.length - 1, suggestIdx + 1));
        return;
      }
      if (e.key === 'ArrowUp') {
        if (suggestBox.hidden || !suggestItems.length) return;
        e.preventDefault();
        highlightSuggest(Math.max(-1, suggestIdx - 1));
        if (suggestIdx < 0) input.value = t.draft != null ? t.draft : t.q;
        return;
      }
      if (e.key === 'Escape') {
        if (!suggestBox.hidden) { e.preventDefault(); hideSuggest(); return; }
        return;
      }
      if (e.key !== 'Enter') return;
      e.preventDefault();
      hideSuggest();
      const v = (input.value || '').trim();
      if ((e.ctrlKey || e.metaKey) && v) { t.draft = null; input.value = t.q; addSearchTab(v); return; }
      runTabSearch(t, input.value);
    }, { signal: suggestAbort.signal });

    // Bij tab-wissel / hertekenen: listeners van vorige body stoppen via abort in volgende render
    // Bewaar abort op ui zodat een nieuwe render de vorige kan annuleren
    if (ui._suggestAbort) { try { ui._suggestAbort.abort(); } catch (_) {} }
    ui._suggestAbort = suggestAbort;

    bar.append(input, btn);
    barWrap.append(bar);
    const barRow = el('div', 'gs-barrow');
    const types = el('div', 'gs-types');
    types.setAttribute('role', 'group');
    types.setAttribute('aria-label', 'Filter op soort bestand');
    for (const [k, label, icon] of SEARCH_TYPES) {
      const c = el('button', 'gs-type');
      c.type = 'button';
      c.dataset.k = k;
      c.title = label;
      c.append(el('span', 'gs-type-ic', icon), el('span', 'gs-type-l', label), el('span', 'gs-type-n'));
      c.onclick = () => { t.ftype = k; t.filter = 'all'; t.btest = 'all'; t.bbook = 'all'; t.shown = SEARCH_STEP; renderSearchOut(t); };
      types.append(c);
    }
    const tools = el('div', 'gs-webtools');
    tools.hidden = t.state !== 'web';
    const mkTool = (title, svg, fn) => {
      const b = el('button', 'gs-tool');
      b.type = 'button'; b.title = title; b.setAttribute('aria-label', title);
      b.innerHTML = svg; b.onclick = fn; return b;
    };
    const svgA = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
    tools.append(
      mkTool('Vernieuwen', svgA + '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>', () => { if (t.frame) t.frame.src = t.url; }),
      mkTool('Extern openen in je gewone browser (als de pagina hier niet laadt)', svgA + '<path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>', () => openInSystemBrowser(t.url))
    );
    // Geschiedenis-icoon helemaal rechts op dezelfde rij als de filters
    const hist = el('button', 'gs-history-btn');
    hist.type = 'button';
    hist.title = 'Zoekgeschiedenis';
    hist.setAttribute('aria-label', 'Zoekgeschiedenis bekijken');
    hist.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
    hist.onclick = () => showSearchHistoryPanel();
    barRow.append(barWrap, types, tools, hist);
    (compact ? ui.barSlot : p).append(barRow);
    ui.input = input;
    ui.types = types;
    syncTypingLayout();

    const out = el('div', 'gs-out');
    p.append(out);
    ui.out = out;
    renderSearchOut(t);
    syncWebFrames();

    requestAnimationFrame(() => {
      if (restore) window.scrollTo(0, t.scroll || 0);
      if (t.state === 'empty' || !t.q) { try { input.focus(); } catch (_) {} }
      syncTypingLayout();
    });
  }

  async function runTabSearch(t, raw) {
    const q = String(raw || '').trim();
    t.draft = null;
    const token = ++t.token;
    // "startscherm" / "home" / "start" → leeg startscherm (geen echte zoekopdracht)
    const qn = q.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    if (qn === 'startscherm' || qn === 'start screen' || qn === 'home' || qn === 'start') {
      goSearchHome();
      return;
    }
    t.q = q;
    // Suggesties altijd dicht bij echte zoekactie
    try {
      const box = document.getElementById('gs-suggest');
      if (box) { box.hidden = true; box.replaceChildren(); }
    } catch (_) {}
    if (q) saveSearchRecent(q);
    t.filter = 'all';
    t.btest = 'all';
    t.bbook = 'all';
    t.shown = SEARCH_STEP;
    t.progress = '';
    t.error = '';
    t.found = null;
    t.scroll = 0;
    const url = gsAsUrl(q);
    if (url) {                                    // website: tonen in een web-tabblad
      t.url = url;
      t.state = 'web';
      if (!t.frame) {
        const f = document.createElement('iframe');
        f.className = 'gs-frame';
        f.title = 'Webpagina';
        f.setAttribute('referrerpolicy', 'no-referrer-when-downgrade');
        f.setAttribute('allow', 'fullscreen; clipboard-read; clipboard-write');
        t.frame = f;
        if (searchUI && searchUI.webhost) searchUI.webhost.append(f);
      }
      t.frame.src = url;
      renderSearchTabs();
      if (searchTabs.active === t.id && searchUI && searchUI.page.isConnected) renderSearchBody(false);
      return;
    }
    if (t.frame) { t.frame.remove(); t.frame = null; }
    t.url = '';
    if (!q) { t.state = 'empty'; }
    else t.state = 'loading';
    const isActive = () => searchTabs.active === t.id && searchUI && searchUI.page.isConnected;
    renderSearchTabs();
    if (isActive()) { renderSearchBody(false); }
    if (!q) return;

    const t0 = performance.now();
    try {
      await loadIndex();
      const found = await searchAll(q, {
        onBijbelProgress: (d, n) => {
          if (t.token !== token) return;
          t.progress = `Bijbel doorzoeken… ${d}/${n}`;
          if (isActive() && searchUI.out) {
            const c = searchUI.out.querySelector('.gs-progress');
            if (c) c.textContent = t.progress;
          }
        }
      });
      if (t.token !== token) return;
      t.found = found;
      t.ms = performance.now() - t0;
      t.state = 'done';
    } catch (err) {
      if (t.token !== token) return;
      t.state = 'error';
      t.error = (err && err.message) || 'Zoeken mislukt';
    }
    renderSearchTabs();
    if (isActive()) renderSearchOut(t);
  }

  function syncWebFrames() {
    const ui = searchUI; if (!ui || !ui.webhost) return;
    let any = false;
    for (const t of searchTabs.list) {
      if (!t.frame) continue;
      const show = t.id === searchTabs.active && t.state === 'web';
      t.frame.hidden = !show;
      if (show) any = true;
    }
    ui.webhost.hidden = !any;
  }

  function updateTypeChips(t) {
    const ui = searchUI; if (!ui || !ui.types) return;
    const found = t.found || [];
    const cnt = { all: found.length };
    for (const g of found) { const k = gsTypeOf(g); if (k) cnt[k] = (cnt[k] || 0) + 1; }
    ui.types.querySelectorAll('.gs-type').forEach(c => {
      const k = c.dataset.k, on = t.ftype === k;
      c.classList.toggle('is-on', on);
      c.setAttribute('aria-pressed', on ? 'true' : 'false');
      c.querySelector('.gs-type-n').textContent = t.state === 'done' && k !== 'all' ? String(cnt[k] || 0) : '';
      c.classList.toggle('is-zero', t.state === 'done' && k !== 'all' && !cnt[k]);
    });
  }

  function renderSearchOut(t) {
    const ui = searchUI; if (!ui || !ui.out) return;
    const out = ui.out;
    out.replaceChildren();
    updateTypeChips(t);
    if (ui.types) ui.types.hidden = t.state === 'web';
    if (ui.types && ui.types.nextElementSibling) ui.types.nextElementSibling.hidden = t.state !== 'web';
    ui.panel.classList.toggle('is-web', t.state === 'web');
    if (t.state === 'web') return;       // de pagina zelf staat in de webhost; de knoppen staan naast de zoekbalk

    if (t.state === 'empty') {
      const empty = el('div', 'gs-start');
      empty.append(el('p', 'gs-start-label', 'Probeer bijvoorbeeld'));
      const row = el('div', 'gs-start-ex');
      for (const w of ['Augustinus', 'gebed', 'wiskunde', 'Jezus', 'Latijn', 'catechismus', 'Matteüs']) {
        const c = el('button', 'gs-ex', w);
        c.type = 'button';
        c.onclick = () => runTabSearch(t, w);
        row.append(c);
      }
      empty.append(row);
      empty.append(el('p', 'gs-start-tip', 'Tip: met Ctrl+Enter opent een zoekopdracht in een nieuw tabblad. Met + houd je meerdere zoekopdrachten naast elkaar.'));
      out.append(empty);
      return;
    }
    if (t.state === 'loading') {
      const row = el('div', 'gs-loading');
      row.append(el('span', 'gs-spin gs-spin-lg'), el('span', 'gs-progress', t.progress || 'Zoeken in bibliotheek, woordenboek en bijbel…'));
      out.append(row);
      return;
    }
    if (t.state === 'error') {
      out.append(el('p', 'search-empty-hint gs-error', t.error));
      return;
    }

    const allFound = t.found || [];
    const found = t.ftype === 'all' ? allFound : allFound.filter(g => gsTypeOf(g) === t.ftype);
    const terms = gsTerms(t.q);
    if (allFound.length && !found.length) {
      const lab = (SEARCH_TYPES.find(x => x[0] === t.ftype) || [])[1] || 'dit type';
      const box = el('div', 'gs-none');
      const p1 = el('p', 'gs-none-title');
      p1.append('Geen ' + lab.toLowerCase() + ' gevonden voor ');
      p1.append(el('strong', '', t.q));
      box.append(p1, el('p', 'gs-none-sub', 'Kies "Alles" om alle ' + allFound.length + ' resultaten te zien.'));
      out.append(box);
      return;
    }
    if (!found.length) {
      const box = el('div', 'gs-none');
      const p1 = el('p', 'gs-none-title');
      p1.append('Geen resultaten voor ');
      const strong = el('strong', '', t.q);
      p1.append(strong);
      box.append(p1, el('p', 'gs-none-sub', 'Suggesties:'));
      const ul = el('ul', 'gs-none-list');
      ['Controleer de spelling van de woorden.', 'Probeer andere of meer algemene woorden.', 'Probeer minder woorden: alle zoekwoorden moeten voorkomen.']
        .forEach(s => ul.append(el('li', '', s)));
      box.append(ul);
      out.append(box);
      return;
    }

    // Filters (Alles / Bibliotheek / Woordenboek / Bijbel) met aantallen
    const counts = { all: found.length };
    for (const g of found) counts[g.kind] = (counts[g.kind] || 0) + 1;
    const filters = el('div', 'gs-filters');
    filters.setAttribute('role', 'group');
    filters.setAttribute('aria-label', 'Filter op bron');
    for (const [k, label] of SEARCH_KINDS) {
      if (k !== 'all' && !counts[k]) continue;
      const c = el('button', 'gs-chip' + (t.filter === k ? ' is-on' : ''));
      c.type = 'button';
      c.setAttribute('aria-pressed', t.filter === k ? 'true' : 'false');
      c.append(label + ' ', el('span', 'gs-chip-n', String(counts[k])));
      c.onclick = () => {
        t.filter = k;
        if (k !== 'bijbel') { t.btest = 'all'; t.bbook = 'all'; }
        t.shown = SEARCH_STEP;
        renderSearchOut(t);
      };
      filters.append(c);
    }
    out.append(filters);

    let list = t.filter === 'all' ? found : found.filter(g => g.kind === t.filter);

    // Bijbel-subfilters: testament + boek (alleen tonen als er bijbelresultaten zijn)
    const bibleAll = found.filter(g => g.kind === 'bijbel');
    const showBibleFilters = (t.filter === 'bijbel' || t.filter === 'all') && bibleAll.length > 0;
    if (showBibleFilters && t.filter === 'bijbel') {
      const pool = bibleAll;
      // Testament-tellingen
      const testCounts = { all: pool.length, OT: 0, NT: 0 };
      for (const g of pool) {
        const tt = g.testament || (g.hits && g.hits[0] && g.hits[0].testament) || '';
        if (tt === 'OT') testCounts.OT++;
        else if (tt === 'NT') testCounts.NT++;
      }
      let afterTest = pool;
      if (t.btest === 'OT' || t.btest === 'NT') {
        afterTest = pool.filter(g => (g.testament || '') === t.btest);
      }
      const bookCounts = new Map(); // osis -> { name, n }
      for (const g of afterTest) {
        const osis = g.osis || (g.hits && g.hits[0] && g.hits[0].osis) || '';
        const name = g.book || (g.title || '').split(/\s+\d/)[0] || osis;
        if (!osis) continue;
        const cur = bookCounts.get(osis) || { name, n: 0 };
        cur.n++;
        bookCounts.set(osis, cur);
      }

      // Testament + boek op één compacte rij
      const subRow = el('div', 'gs-filters gs-filters-sub gs-bible-refine');
      subRow.setAttribute('role', 'group');
      subRow.setAttribute('aria-label', 'Bijbel verfijnen');
      for (const [k, label] of [['all', 'Alle'], ['OT', 'OT'], ['NT', 'NT']]) {
        if (k !== 'all' && !testCounts[k]) continue;
        const full = k === 'all' ? 'Alle bijbel' : k === 'OT' ? 'Oude Testament' : 'Nieuwe Testament';
        const c = el('button', 'gs-chip gs-chip-sub' + (t.btest === k ? ' is-on' : ''));
        c.type = 'button';
        c.title = full;
        c.setAttribute('aria-label', full);
        c.setAttribute('aria-pressed', t.btest === k ? 'true' : 'false');
        c.append(label + ' ', el('span', 'gs-chip-n', String(testCounts[k])));
        c.onclick = () => {
          t.btest = k;
          t.bbook = 'all';
          t.shown = SEARCH_STEP;
          renderSearchOut(t);
        };
        subRow.append(c);
      }
      if (bookCounts.size > 0) {
        const sel = document.createElement('select');
        sel.id = 'gs-book-select';
        sel.className = 'gs-book-select';
        sel.setAttribute('aria-label', 'Filter op bijbelboek');
        const optAll = document.createElement('option');
        optAll.value = 'all';
        optAll.textContent = 'Alle boeken (' + afterTest.length + ')';
        if (t.bbook === 'all') optAll.selected = true;
        sel.append(optAll);
        const books = [...bookCounts.entries()].sort((a, b) => b[1].n - a[1].n || a[1].name.localeCompare(b[1].name, 'nl'));
        for (const [osis, info] of books) {
          const o = document.createElement('option');
          o.value = osis;
          o.textContent = info.name + ' (' + info.n + ')';
          if (t.bbook === osis) o.selected = true;
          sel.append(o);
        }
        sel.onchange = () => {
          t.bbook = sel.value || 'all';
          t.shown = SEARCH_STEP;
          renderSearchOut(t);
        };
        subRow.append(sel);
      }
      out.append(subRow);

      // Pas filters toe op list
      list = afterTest;
      if (t.bbook && t.bbook !== 'all') {
        list = list.filter(g => (g.osis || (g.hits && g.hits[0] && g.hits[0].osis) || '') === t.bbook);
      }
    } else if (t.filter !== 'bijbel') {
      // bij wissel weg van bijbel: subfilters resetten niet nodig (al bij chip-click)
    }

    const secs = (t.ms / 1000).toFixed(2).replace('.', ',');
    out.append(el('p', 'gs-stats', `${list.length} resultaat${list.length === 1 ? '' : 'en'} (${secs} seconden)`));

    const wrap = el('div', 'gs-results');
    for (const g of list.slice(0, t.shown)) wrap.append(gsResultEl(t, g, terms));
    out.append(wrap);

    if (list.length > t.shown) {
      const more = el('button', 'gs-more', `Meer resultaten (${list.length - t.shown})`);
      more.type = 'button';
      more.onclick = () => { t.shown += SEARCH_STEP; renderSearchOut(t); };
      out.append(more);
    }
  }

  // Groot symbool vooraan per soort resultaat (bespaart hoogte: bron staat naast de titel).
  const GS_ICONS = { woordenboek: null, bijbel: '✝︎', foto: '🖼️', doc: '📝', pdf: '📄', pptx: '📊', xlsx: '📈' };
  const WB_ICON_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><path d="M9 8h7"/><path d="M9 12h7"/><path d="M9 16h4"/></svg>';
  function gsResultEl(t, g, terms) {
    const a = document.createElement('a');
    a.href = 'javascript:void(0)';
    a.setAttribute('role', 'link');
    a.dataset.kind = g.kind || '';
    a.dataset.id = g.id || '';
    a.onclick = e => {
      e.preventDefault();
      e.stopPropagation();
      openSearchResult(g, t.q);
    };

    const gid = String(g.id || '');
    const gkind = g.kind || (gid.startsWith('app:') ? 'app' : gid.startsWith('wb:') ? 'woordenboek' : gid.startsWith('bijbel') ? 'bijbel' : gid.startsWith('foto:') ? 'foto' : 'library');

    // ——— App- of spel-resultaat: groot icoon + label "App" / "Spel" ———
    if (gkind === 'app' || gkind === 'game' || gid.startsWith('game:')) {
      const isGame = gkind === 'game' || gid.startsWith('game:') || g.type === 'game';
      a.className = 'gs-result gs-result-app' + (isGame ? ' gs-result-game' : '');
      a.setAttribute('aria-label', (isGame ? 'Open spel ' : 'Open app ') + (g.title || ''));
      const appKind = g.appKind || (gid.startsWith('app:') || gid.startsWith('game:') ? gid.slice(gid.indexOf(':') + 1) : '');

      const iconBtn = el('span', 'gs-app-icon');
      iconBtn.setAttribute('aria-hidden', 'true');
      let iconSvg = null;
      try { iconSvg = typeof miniAppIconSvg === 'function' ? miniAppIconSvg(appKind) : null; } catch (_) {}
      if (iconSvg) {
        iconSvg.setAttribute('width', '28');
        iconSvg.setAttribute('height', '28');
        iconBtn.append(iconSvg);
      } else {
        iconBtn.innerHTML = '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="6" height="6" rx="1.2"/><rect x="14" y="4" width="6" height="6" rx="1.2"/><rect x="4" y="14" width="6" height="6" rx="1.2"/><rect x="14" y="14" width="6" height="6" rx="1.2"/></svg>';
      }

      const body = el('div', 'gs-body');
      const src = el('div', 'gs-src');
      const badge = el('span', isGame ? 'gs-app-badge gs-game-badge' : 'gs-app-badge', isGame ? 'Spel' : 'App');
      let whereTxt = g.where ? String(g.where) : (isGame ? 'Spel' : 'Leo Crucis');
      whereTxt = whereTxt.replace(/^(App|Spel|Game)\s*[·•]\s*/i, '');
      if (isGame && (!whereTxt || /^spel$/i.test(whereTxt))) whereTxt = '';
      const where = el('span', 'gs-src-name', whereTxt);
      src.append(badge);
      if (whereTxt) src.append(where);

      const title = el('h3', 'gs-title');
      gsHighlight(title, g.title || appKind || (isGame ? 'Spel' : 'App'), terms);

      const cta = el('p', 'gs-app-cta');
      cta.textContent = isGame ? 'Tik om dit spel te openen' : 'Tik om deze app te openen';

      body.append(src, title, cta);
      a.append(iconBtn, body);
      return a;
    }

    // ——— Overige resultaten (bibliotheek, woordenboek, bijbel, foto) ———
    a.className = 'gs-result gs-result-wb';
    const body = el('div', 'gs-body');

    const src = el('div', 'gs-src');
    const ic = el('span', 'gs-favicon');
    ic.setAttribute('aria-hidden', 'true');
    if (gkind === 'woordenboek') {
      ic.innerHTML = WB_ICON_SVG;
    } else if (gkind === 'bijbel') {
      ic.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><path d="M12 6v10"/><path d="M9 8.5h6"/></svg>';
    } else if (gkind === 'foto') {
      ic.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M3 16l5-4 4 3 3-2 6 4"/></svg>';
    } else {
      ic.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h4"/></svg>';
    }
    const srcName = gkind === 'woordenboek' ? (g.where || 'Woordenboek')
      : gkind === 'bijbel' ? (g.where || 'Bijbel')
      : gkind === 'foto' ? (g.where || 'Kunstgalerij')
      : (g.where || 'Bibliotheek');
    src.append(ic, el('span', 'gs-src-name', srcName));
    body.append(src);

    const title = el('h3', 'gs-title');
    gsHighlight(title, g.title || '', terms);
    body.append(title);

    const hits = (g.hits || []).slice(0, g.kind === 'library' ? 2 : 1);
    for (const h of hits) {
      const txt = String(h.text || '').replace(/\s+/g, ' ').trim();
      if (!txt || txt === g.title) continue;
      const p = el('p', 'gs-snip');
      if (g.kind === 'library' && h.heading && h.heading !== g.title) {
        p.append(el('strong', 'gs-snip-h', h.heading + ' — '));
      }
      gsHighlight(p, gsSnippet(txt, terms), terms);
      body.append(p);
    }
    a.append(body);
    return a;
  }


  function openSearchResult(g, q) {
    saveSearchScroll();
    const id = String(g.id || '');
    const kind = String(g.kind || '');
    const hit = (g.hits && g.hits[0]) || {};
    const parts = id.split(':');

    // Mini-apps (Atlas, Canoniek Recht, Bijbelgrafieken, …)
    if (kind === 'app' || kind === 'game' || id.startsWith('app:') || id.startsWith('game:')) {
      const appKind = g.appKind || parts[1] || '';
      if (!appKind) return;
      if (appKind === 'focus') { try { showFocus(); } catch (_) {} return; }
      if (appKind === 'doc' || appKind === 'pptx' || appKind === 'xlsx') {
        try { startCreate(appKind); } catch (_) {}
        return;
      }
      if (appKind === 'audio' || appKind === 'video') {
        try { showMediaPlayer(appKind); } catch (_) { try { showMiniApp(appKind); } catch (__) {} }
        return;
      }
      try { showMiniApp(appKind); } catch (_) {}
      return;
    }

    // Foto's
    if (kind === 'foto' || id.startsWith('foto:')) {
      showMiniApp('gallery');
      return;
    }

    // Woordenboek
    if (kind === 'woordenboek' || id.startsWith('wb:')) {
      try {
        localStorage.setItem('lc-woordenboek-pos-v1', JSON.stringify({ q: g.query || g.title || q }));
      } catch (_) {}
      showMiniApp('woordenboek');
      return;
    }

    // Bijbel — kind, id-prefix of osis in hit
    const isBijbel = kind === 'bijbel'
      || id.startsWith('bijbel:')
      || id.startsWith('bijbel-book:')
      || !!(hit.osis);
    if (isBijbel) {
      let osis = hit.osis || null;
      let chapter = hit.chapter != null ? Number(hit.chapter) : null;
      let verse = hit.verse != null ? Number(hit.verse) : null;
      if (!osis && (id.startsWith('bijbel:') || id.startsWith('bijbel-book:'))) {
        osis = parts[1] || 'Gen';
        if (parts[2]) chapter = parseInt(parts[2], 10);
        if (parts[3]) verse = parseInt(parts[3], 10);
      }
      const pos = {
        osis: osis || 'Gen',
        chapter: chapter && !isNaN(chapter) ? chapter : 1,
        q: String(g.query || q || '').trim()
      };
      if (verse != null && !isNaN(verse) && verse > 0) {
        pos.from = verse;
        pos.to = verse;
      }
      try { localStorage.setItem('lc-bijbel-pos-v1', JSON.stringify(pos)); } catch (_) {}
      showMiniApp('bible', pos);
      return;
    }

    // Bibliotheek
    if (id && !id.includes(':')) {
      showSection(id);
      return;
    }
    if (id) showSection(id);
  }

  return {
    showResults,
    showSearchHistoryPanel,
    openSearchResult,
    get searchUI() { return searchUI; },
    get searchTabs() { return searchTabs; },
  };
}
