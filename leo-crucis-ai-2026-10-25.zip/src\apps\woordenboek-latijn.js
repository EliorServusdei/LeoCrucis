// Woordenboek Nederlands → Latijn — als opengeslagen boek
// Data: data/woordenboek-latijn/nl-la.json (gebouwd met tools/build-woordenboek-latijn.mjs)
//
// Bron: FreeDict (GNU GPL v2+), via een tussenstap in het Engels en Duits, aangevuld met een
// handmatig nagekeken basislijst. Entry = [nederlands, [[latijn, score, grammatica?, woordsoort?], …]]
// Score: 4 = handmatig nagekeken, 3/2 = via meerdere routes bevestigd, 1 = één route (minder zeker).
//
// Opbouw: linkerpagina = register (zoeken, A–Z, woordenlijst met eerste vertaling);
//         rechterpagina = het opgeslagen woord met grote Latijnse woorden en hun vormen.

const DATA_URL = 'data/woordenboek-latijn/nl-la.json';
const RESULTS_MAX = 80;
const EXAMPLES = ['vriend', 'schrijven', 'kerk', 'liefde', 'goed', 'bidden'];

let dataPromise = null;
function loadData() {
  if (!dataPromise) {
    dataPromise = fetch(DATA_URL)
      .then(r => { if (!r.ok) throw new Error('nl-la'); return r.json(); })
      .then(d => {
        const entries = d.entries.map(e => ({ w: e[0], n: norm(e[0]), l: e[1] }));
        const byNorm = new Map();
        const byLetter = new Map();
        for (const e of entries) {
          (byNorm.get(e.n) || byNorm.set(e.n, []).get(e.n)).push(e);
          const L = letterOf(e.n);
          (byLetter.get(L) || byLetter.set(L, []).get(L)).push(e);
        }
        return { meta: d, entries, byNorm, byLetter };
      })
      .catch(err => { dataPromise = null; throw err; });
  }
  return dataPromise;
}

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function norm(s) {
  return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
}

function letterOf(n) {
  const c = (n[0] || '#');
  return c >= 'a' && c <= 'z' ? c : '#';
}

const SCORE_LABEL = {
  4: 'Handmatig nagekeken',
  3: 'Betrouwbaar: bevestigd via drie routes',
  2: 'Bevestigd via twee routes',
  1: 'Minder zeker: slechts één route'
};
// [css-klasse, uitleg, korte letter (Nederlands: m, v, o)]
const GENDER = {
  'm.': ['m', 'mannelijk', 'm'], 'f.': ['f', 'vrouwelijk', 'v'], 'n.': ['n', 'onzijdig', 'o'], 'm./f.': ['mf', 'mannelijk of vrouwelijk', 'm/v']
};
const BOX_LABELS = {
  'zn.': ['nominatief', 'genitief'],
  'ww.': ['ik-vorm', 'infinitief', 'perfectum', 'supinum'],
  'bn.': ['mannelijk', 'vrouwelijk', 'onzijdig']
};

/** Splitst "domus, domus (f.)" of "scribo, scribere, scripsi, scriptum" in vormen met labels. */
function formParts(row) {
  const gram = row[2] || '', pos = row[3] || '';
  let g = gram, gender = null;
  const m = g.match(/\s*\((m\.\/f\.|m\.|f\.|n\.)\)\s*$/);
  if (m) { gender = m[1]; g = g.slice(0, m.index); }
  const segs = g.split(',').map(x => x.trim()).filter(Boolean);
  let labels = BOX_LABELS[pos];
  if (labels && pos === 'ww.' && segs.some(x => / sum$/.test(x))) labels = ['ik-vorm', 'infinitief', 'perfectum'];
  if (labels && pos === 'bn.' && segs.length === 2) labels = ['nominatief', 'genitief'];
  if (!labels || segs.length < 2) return { boxes: [], gender, raw: gram && segs.length < 2 && g !== row[0] ? g : '' };
  return { boxes: segs.slice(0, labels.length).map((v, i) => [labels[i], v]), gender, raw: '' };
}

export function injectLatijnStyles() {
  if (document.getElementById('wbl-styles')) return;
  const s = document.createElement('style');
  s.id = 'wbl-styles';
  s.textContent = `
/* —— Woordenboek: keuze tussen de twee woordenboeken —— */
.wb-modes{flex:0 0 auto;display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.wb-mode{height:30px;padding:0 14px;border-radius:999px;border:1px solid var(--line);background:transparent;
  color:var(--ink);font:inherit;font-size:.86em;font-weight:600;cursor:pointer}
.wb-mode:hover{border-color:var(--acc)}
.wb-mode[aria-pressed="true"]{background:var(--acc);border-color:var(--acc);color:#fff8ea;text-shadow:0 1px 1px rgba(0,0,0,.25)}
.wb-app.wb-lat-mode > :not(.wb-modes):not(.wb-lat){display:none !important}
.wb-lat{flex:1 1 auto;min-height:0;display:none;flex-direction:column;container-type:inline-size}
.wb-app.wb-lat-mode .wb-lat{display:flex}

/* —— Nederlands → Latijn: opengeslagen boek —— */
.wbl-stage{flex:1 1 auto;min-height:0;display:flex;justify-content:center;padding:2px 0 4px}
.wbl-book{--wbl-red:#7a1f2b;--wbl-gold:#a67c3a;--wbl-gutter:38px;grid-template-columns:1fr 1fr}
/* Twee even brede pagina's; de rug ligt exact op de scheiding en niets loopt eronder door */
.wbl-book .wb-book-spine{width:var(--wbl-gutter)}
.wbl-book .wb-page-inner{padding:14px 18px 10px;overflow:hidden}
.wbl-book .wb-page-l .wb-page-inner{padding-right:calc(var(--wbl-gutter) / 2 + 14px)}
.wbl-book .wb-page-r .wb-page-inner{padding-left:calc(var(--wbl-gutter) / 2 + 14px)}

/* linkerpagina: register */
.wbl-search{display:flex;gap:6px;margin:0 0 8px;flex:0 0 auto}
.wbl-input{flex:1 1 auto;min-width:0;height:32px;box-sizing:border-box;padding:4px 10px;border-radius:6px;
  border:1px solid rgba(90,70,40,.35);background:#fffaf0;color:#2c241c;font:inherit;font-size:.92em}
.wbl-input:focus{outline:2px solid var(--wbl-gold);outline-offset:0}
.wbl-letters{flex:0 0 auto;display:flex;flex-wrap:wrap;gap:3px;margin:0 0 8px}
.wbl-letter{min-width:24px;height:24px;padding:0 5px;border-radius:5px;border:1px solid rgba(90,70,40,.22);
  background:transparent;color:#4a3b2a;font:inherit;font-size:.8em;font-weight:700;text-transform:uppercase;cursor:pointer}
.wbl-letter:hover{border-color:var(--wbl-gold);color:var(--wbl-red)}
.wbl-letter.on{background:var(--wbl-red);border-color:var(--wbl-red);color:#fff8ea}
.wbl-head{flex:0 0 auto;font-size:.74em;letter-spacing:.12em;text-transform:uppercase;color:#8a7a68;margin:0 0 4px;
  display:flex;justify-content:space-between;gap:8px}
.wbl-words{flex:1 1 auto;min-height:0;overflow-y:auto;margin:0 -6px 0 -2px;padding:0 6px 0 2px}
.wbl-word{display:flex;align-items:baseline;gap:8px;width:100%;box-sizing:border-box;text-align:left;padding:5px 6px;
  border:0;border-bottom:1px solid rgba(90,70,40,.1);background:transparent;color:#2c241c;font:inherit;cursor:pointer;border-radius:4px}
.wbl-word:hover{background:rgba(166,124,58,.12)}
.wbl-word.on{background:rgba(122,31,43,.1);box-shadow:inset 3px 0 0 var(--wbl-red)}
.wbl-w{font-family:Georgia,'Times New Roman',serif;font-weight:700;flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.wbl-fw{margin-left:auto;font-family:Georgia,'Times New Roman',serif;font-style:italic;font-size:.88em;color:var(--wbl-red);
  flex:0 1 45%;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:right}
.wbl-fw.low{opacity:.5}
.wbl-none{margin:14px 2px;font-size:.9em;color:#6a5a48;line-height:1.45}

/* rechterpagina: het woord */
.wbl-entry{flex:1 1 auto;min-height:0;overflow-y:auto;margin:0 -8px 0 0;padding:0 8px 8px 0}
.wbl-top{display:flex;align-items:center;gap:6px;margin:0 0 2px}
.wbl-kicker{font-size:.72em;letter-spacing:.16em;text-transform:uppercase;color:#8a7a68;margin-right:auto}
.wbl-step{width:28px;height:28px;border-radius:6px;border:1px solid rgba(90,70,40,.25);background:transparent;color:#4a3b2a;
  font-size:1.1em;line-height:1;cursor:pointer}
.wbl-step:hover:not(:disabled){border-color:var(--wbl-gold);color:var(--wbl-red)}
.wbl-step:disabled{opacity:.3;cursor:default}
.wbl-back{display:none;height:28px;padding:0 10px;border-radius:6px;border:1px solid rgba(90,70,40,.25);background:transparent;
  color:#4a3b2a;font:inherit;font-size:.82em;cursor:pointer}
.wbl-nl{margin:0;font-family:Georgia,'Times New Roman',serif;font-size:2.1em;line-height:1.1;font-weight:700;font-style:italic;color:#2c241c;word-break:break-word}
.wbl-rule{display:flex;align-items:center;gap:10px;margin:10px 0 14px;color:var(--wbl-gold)}
.wbl-rule::before,.wbl-rule::after{content:"";flex:1;height:1px;background:linear-gradient(90deg,transparent,var(--wbl-gold),transparent)}
.wbl-rule span{font-size:.8em}
.wbl-tr{padding:2px 0 14px;margin:0 0 14px;border-bottom:1px solid rgba(90,70,40,.14)}
.wbl-tr:last-child{border-bottom:0}
.wbl-trhead{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.wbl-la{margin:0;font-family:Georgia,'Times New Roman',serif;font-size:1.75em;line-height:1.15;font-weight:700;color:var(--wbl-red)}
.wbl-pos{font-size:.74em;font-style:italic;color:#6a5a48;border:1px solid rgba(90,70,40,.25);border-radius:999px;padding:1px 8px}
.wbl-g{display:inline-flex;align-items:center;justify-content:center;min-width:22px;height:22px;padding:0 6px;border-radius:999px;
  font-size:.74em;font-weight:700;color:#fff;cursor:help}
.wbl-g.m{background:#2f5d8a}.wbl-g.f{background:#a23b4a}.wbl-g.n{background:#4d7a4a}.wbl-g.mf{background:linear-gradient(90deg,#2f5d8a 50%,#a23b4a 50%)}
.wbl-conf{margin-left:auto;font-size:.74em;letter-spacing:1px;color:var(--wbl-gold);cursor:help;white-space:nowrap}
.wbl-conf.ok{color:#fff;background:var(--wbl-gold);border-radius:999px;padding:1px 9px;letter-spacing:0}
.wbl-conf.s1{opacity:.6}
.wbl-boxes{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 0}
.wbl-box{min-width:88px;border:1px solid rgba(90,70,40,.22);border-radius:8px;background:rgba(255,250,240,.7);padding:4px 10px 6px}
.wbl-box small{display:block;font-size:.66em;letter-spacing:.1em;text-transform:uppercase;color:#8a7a68}
.wbl-box b{font-family:Georgia,'Times New Roman',serif;font-size:1.05em;color:#2c241c}
.wbl-raw{margin:6px 0 0;font-style:italic;color:#6a5a48;font-size:.92em}
.wbl-more{margin-top:2px}
.wbl-more > summary{cursor:pointer;font-size:.84em;color:#6a5a48;padding:4px 0 10px}
.wbl-more .wbl-la{font-size:1.4em}
.wbl-legend{margin:6px 0 0;font-size:.74em;line-height:1.45;color:#8a7a68}

/* welkomstpagina */
.wbl-welcome{flex:1 1 auto;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:8px;padding:8px}
.wbl-orn{font-size:3.2em;line-height:1;color:var(--wbl-gold);font-family:Georgia,serif}
.wbl-wt{margin:0;font-family:Georgia,'Times New Roman',serif;font-size:1.7em;font-weight:700;color:#2c241c;letter-spacing:.03em}
.wbl-ws{margin:0;font-style:italic;color:#6a5a48}
.wbl-wp{margin:4px 0 6px;max-width:34ch;font-size:.9em;line-height:1.5;color:#4a3b2a}
.wbl-chips{display:flex;flex-wrap:wrap;gap:6px;justify-content:center}
.wbl-chip{height:30px;padding:0 14px;border-radius:999px;border:1px solid var(--wbl-gold);background:transparent;color:var(--wbl-red);
  font-family:Georgia,'Times New Roman',serif;font-size:.95em;font-weight:700;cursor:pointer}
.wbl-chip:hover{background:var(--wbl-red);border-color:var(--wbl-red);color:#fff8ea}

/* smalle ruimte (of splitscreen): één pagina tegelijk */
@container (max-width:720px){
  .wbl-book{grid-template-columns:1fr}
  .wbl-book .wb-book-spine{display:none}
  .wbl-book .wb-page-l,.wbl-book .wb-page-r{border-radius:8px}
  .wbl-book.wb-book:not(.wb-closed)[data-view="list"] .wb-page-l{display:flex}
  .wbl-book.wb-book:not(.wb-closed)[data-view="list"] .wb-page-r{display:none}
  .wbl-book.wb-book:not(.wb-closed)[data-view="entry"] .wb-page-l{display:none}
  .wbl-book.wb-book:not(.wb-closed)[data-view="entry"] .wb-page-r{display:flex}
  .wbl-book.wb-book:not(.wb-closed) .wb-page-l::after,
  .wbl-book.wb-book:not(.wb-closed) .wb-page-r::after{display:none}
  .wbl-book[data-view="entry"] .wbl-back{display:inline-block}
  .wbl-book .wb-page-l .wb-page-inner,
  .wbl-book .wb-page-r .wb-page-inner{padding:12px 14px 8px}
}
`;
  document.head.append(s);
}

function displayWord(e) {
  const w = e.w;
  return e.l.length && e.l.every(r => /^[A-Z]/.test(r[0])) ? w.charAt(0).toUpperCase() + w.slice(1) : w;
}

function searchEntries(data, q) {
  const nq = norm(q);
  if (!nq) return null;
  const exact = data.byNorm.get(nq) || [];
  const prefix = [], contains = [];
  for (const e of data.entries) {
    if (e.n === nq) continue;
    if (e.n.startsWith(nq)) prefix.push(e);
    else if (nq.length >= 3 && e.n.includes(nq)) contains.push(e);
  }
  return [...exact, ...prefix, ...contains].slice(0, RESULTS_MAX);
}

/** Het paneel zelf. Geeft { root, focus, setQuery } terug. */
export function createLatijnPanel() {
  injectLatijnStyles();
  const root = el('div', 'wb-lat');

  const stage = el('div', 'wbl-stage');
  const book = el('div', 'wb-book wbl-book');
  book.dataset.view = 'list';
  book.setAttribute('aria-label', 'Woordenboek Nederlands naar Latijn');

  // —— Linkerpagina: register ——
  const pageL = el('div', 'wb-page wb-page-l');
  const innerL = el('div', 'wb-page-inner');
  const form = el('form', 'wbl-search');
  form.setAttribute('role', 'search');
  const input = el('input', 'wbl-input');
  input.type = 'search';
  input.placeholder = 'Zoek een Nederlands woord…';
  input.setAttribute('aria-label', 'Zoek een Nederlands woord om het Latijnse woord te vinden');
  input.autocomplete = 'off';
  input.spellcheck = false;
  form.append(input);
  const letters = el('div', 'wbl-letters');
  letters.setAttribute('role', 'navigation');
  letters.setAttribute('aria-label', 'Letters');
  const headL = el('div', 'wbl-head');
  const headTitle = el('span', '', 'Nederlands');
  const headCount = el('span', '', '');
  headL.append(headTitle, headCount);
  const words = el('div', 'wbl-words');
  words.setAttribute('role', 'listbox');
  innerL.append(form, letters, headL, words);
  pageL.append(innerL);

  const spine = el('div', 'wb-book-spine');

  // —— Rechterpagina: woord ——
  const pageR = el('div', 'wb-page wb-page-r');
  const innerR = el('div', 'wb-page-inner');
  pageR.append(innerR);

  book.append(pageL, spine, pageR);
  stage.append(book);
  root.append(stage);

  // —— State ——
  let data = null;
  let list = [];          // huidige lijst (letter of zoekresultaten)
  let listIdx = -1;       // geselecteerd woord in list
  let curLetter = null;
  let searching = false;
  const wordBtns = [];

  function setView(v) { book.dataset.view = v; }

  function buildLetters() {
    letters.replaceChildren();
    const all = 'abcdefghijklmnopqrstuvwxyz#'.split('');
    for (const L of all) {
      if (!data.byLetter.has(L)) continue;
      const b = el('button', 'wbl-letter', L);
      b.type = 'button';
      b.dataset.l = L;
      b.title = data.byLetter.get(L).length.toLocaleString('nl-NL') + ' woorden';
      b.onclick = () => { input.value = ''; showLetter(L); };
      letters.append(b);
    }
  }

  function markLetter(L) {
    for (const b of letters.children) b.classList.toggle('on', b.dataset.l === L);
  }

  // Virtuele lijst: alleen zichtbare rijen in de DOM (~30–50 nodes i.p.v. duizenden)
  const ROW_H = 30;
  const ROW_BUF = 8;
  let listSpacer = null;
  let listWindow = null;
  let listRaf = 0;

  function makeWordBtn(e, i) {
    const b = el('button', 'wbl-word');
    b.type = 'button';
    b.setAttribute('role', 'option');
    b.dataset.i = String(i);
    b.style.height = ROW_H + 'px';
    b.style.boxSizing = 'border-box';
    const fw = el('span', 'wbl-fw' + (e.l[0] && e.l[0][1] < 2 ? ' low' : ''), e.l[0] ? e.l[0][0] : '');
    if (fw.classList.contains('low')) fw.title = 'Minder zeker';
    b.append(el('span', 'wbl-w', displayWord(e)), fw);
    b.onclick = () => select(i, true);
    if (i === listIdx) {
      b.classList.add('on');
      b.setAttribute('aria-selected', 'true');
    } else {
      b.setAttribute('aria-selected', 'false');
    }
    return b;
  }

  function paintListWindow() {
    if (!listWindow || !list.length) return;
    const vh = words.clientHeight || 360;
    const st = words.scrollTop;
    let start = Math.max(0, Math.floor(st / ROW_H) - ROW_BUF);
    let end = Math.min(list.length, Math.ceil((st + vh) / ROW_H) + ROW_BUF);
    if (end <= start) end = Math.min(list.length, start + 1);
    listSpacer.style.height = (list.length * ROW_H) + 'px';
    listWindow.style.transform = 'translateY(' + (start * ROW_H) + 'px';
    listWindow.replaceChildren();
    wordBtns.length = 0;
    const frag = document.createDocumentFragment();
    for (let i = start; i < end; i++) {
      const b = makeWordBtn(list[i], i);
      frag.append(b);
      wordBtns.push(b);
    }
    listWindow.append(frag);
  }

  function onListScroll() {
    if (listRaf) return;
    listRaf = requestAnimationFrame(() => {
      listRaf = 0;
      paintListWindow();
    });
  }

  function renderList(entries, title) {
    list = entries;
    listIdx = -1;
    headTitle.textContent = title;
    headCount.textContent = entries.length.toLocaleString('nl-NL');
    words.replaceChildren();
    wordBtns.length = 0;
    words.removeEventListener('scroll', onListScroll);
    listSpacer = null;
    listWindow = null;
    if (!entries.length) {
      words.append(el('p', 'wbl-none', 'Geen woorden gevonden. Probeer de stam van het woord (\u201cschrijf\u201d), de onbepaalde wijs (\u201cschrijven\u201d) of een synoniem.'));
      return;
    }
    listSpacer = el('div', 'wbl-v-spacer');
    listSpacer.style.position = 'relative';
    listSpacer.style.width = '100%';
    listSpacer.style.height = (entries.length * ROW_H) + 'px';
    listWindow = el('div', 'wbl-v-window');
    listWindow.style.position = 'absolute';
    listWindow.style.left = '0';
    listWindow.style.right = '0';
    listWindow.style.top = '0';
    listSpacer.append(listWindow);
    words.style.position = 'relative';
    words.append(listSpacer);
    words.scrollTop = 0;
    words.addEventListener('scroll', onListScroll, { passive: true });
    paintListWindow();
  }

  function showLetter(L) {
    searching = false;
    curLetter = L;
    markLetter(L);
    renderList(data.byLetter.get(L) || [], L === '#' ? '#' : L.toUpperCase());
    setView('list');
    showWelcome();
  }

  function runSearch(q) {
    const res = searchEntries(data, q);
    if (!res) { // leeg veld: terug naar de letterlijst
      searching = false;
      showLetter(curLetter || 'a');
      return;
    }
    searching = true;
    markLetter(null);
    renderList(res, 'Zoekresultaten');
    if (res.length) select(0, false);
    else showWelcome(true);
  }

  function select(i, openEntryView) {
    if (i < 0 || i >= list.length) return;
    listIdx = i;
    // Scroll zodat de rij in beeld komt, daarna venster hertekenen
    const top = i * ROW_H;
    const vh = words.clientHeight || 360;
    if (top < words.scrollTop) words.scrollTop = top;
    else if (top + ROW_H > words.scrollTop + vh) words.scrollTop = top - vh + ROW_H * 2;
    paintListWindow();
    wordBtns.forEach(b => {
      const bi = Number(b.dataset.i);
      const on = bi === i;
      b.classList.toggle('on', on);
      b.setAttribute('aria-selected', String(on));
    });
    renderEntry(list[i]);
    if (openEntryView) setView('entry');
  }

  function openWord(w) {
    input.value = w;
    runSearch(w);
    setView('entry');
  }

  // —— Rechterpagina inhoud ——
  function showWelcome(noResult) {
    innerR.replaceChildren();
    const box = el('div', 'wbl-welcome');
    box.append(
      el('div', 'wbl-orn', '\u2720'),
      el('h2', 'wbl-wt', 'Lingua Latina'),
      el('p', 'wbl-ws', 'Nederlands \u2192 Latijn')
    );
    if (noResult) {
      box.append(el('p', 'wbl-wp', 'Dat woord staat er (nog) niet in. Probeer een ander woord of kies er een uit de lijst.'));
    } else {
      box.append(el('p', 'wbl-wp', 'Kies links een woord, een letter, of zoek er een. Hier verschijnt dan het Latijn, met verbuiging of vervoeging.'));
    }
    const chips = el('div', 'wbl-chips');
    for (const w of EXAMPLES) {
      if (!data || !data.byNorm.has(norm(w))) continue;
      const c = el('button', 'wbl-chip', w);
      c.type = 'button';
      c.onclick = () => openWord(w);
      chips.append(c);
    }
    box.append(chips);
    innerR.append(box);
  }

  function renderTranslation(row, isMore) {
    const [la, score, , pos] = row;
    const fp = formParts(row);
    const tr = el('article', 'wbl-tr');
    const head = el('div', 'wbl-trhead');
    head.append(el('h3', 'wbl-la', la));
    if (pos) head.append(el('span', 'wbl-pos', pos));
    if (fp.gender && GENDER[fp.gender]) {
      const g = el('span', 'wbl-g ' + GENDER[fp.gender][0], GENDER[fp.gender][2]);
      g.title = GENDER[fp.gender][1];
      head.append(g);
    }
    const conf = el('span', 'wbl-conf' + (score >= 4 ? ' ok' : ' s' + Math.min(score, 3)), score >= 4 ? '\u2713 nagekeken' : '\u25CF'.repeat(Math.min(score, 3)));
    conf.title = SCORE_LABEL[Math.min(score, 4)] || '';
    head.append(conf);
    tr.append(head);
    if (fp.boxes.length) {
      const boxes = el('div', 'wbl-boxes');
      for (const [label, val] of fp.boxes) {
        const bx = el('div', 'wbl-box');
        bx.append(el('small', '', label), el('b', '', val));
        boxes.append(bx);
      }
      tr.append(boxes);
    } else if (fp.raw) {
      tr.append(el('p', 'wbl-raw', fp.raw));
    }
    return tr;
  }

  function renderEntry(entry) {
    innerR.replaceChildren();
    const top = el('div', 'wbl-top');
    const back = el('button', 'wbl-back', '\u2190 Lijst');
    back.type = 'button';
    back.onclick = () => setView('list');
    const prev = el('button', 'wbl-step', '\u2039');
    prev.type = 'button';
    prev.title = 'Vorig woord';
    prev.setAttribute('aria-label', 'Vorig woord');
    prev.disabled = listIdx <= 0;
    prev.onclick = () => select(listIdx - 1, false);
    const next = el('button', 'wbl-step', '\u203A');
    next.type = 'button';
    next.title = 'Volgend woord';
    next.setAttribute('aria-label', 'Volgend woord');
    next.disabled = listIdx >= list.length - 1;
    next.onclick = () => select(listIdx + 1, false);
    top.append(back, el('span', 'wbl-kicker', 'Nederlands'), prev, next);

    const wrap = el('div', 'wbl-entry');
    wrap.append(el('h2', 'wbl-nl', displayWord(entry)));
    const rule = el('div', 'wbl-rule');
    rule.append(el('span', '', '\u25C6'));
    wrap.append(rule);

    // Is er een handmatig nagekeken vertaling (✓), dan staan alleen die vooraan; de rest is 'minder zeker'.
    const hasChecked = entry.l.some(r => r[1] >= 4);
    const minScore = hasChecked ? 4 : 2;
    const sure = entry.l.filter(r => r[1] >= minScore);
    const unsure = entry.l.filter(r => r[1] < minScore);
    for (const r of (sure.length ? sure : unsure)) wrap.append(renderTranslation(r));
    if (sure.length && unsure.length) {
      const more = el('details', 'wbl-more');
      more.append(el('summary', '', 'Minder zekere vertalingen (' + unsure.length + ')'));
      for (const r of unsure) more.append(renderTranslation(r, true));
      wrap.append(more);
    }
    wrap.append(el('p', 'wbl-legend',
      'Geslacht: m = mannelijk, v = vrouwelijk, o = onzijdig. \u2713 = nagekeken, \u25CF\u25CF\u25CF = drie bronnen, \u25CF = één bron (minder zeker). ' +
      'Bron: FreeDict (GNU GPL), via Engels en Duits. Controleer altijd even in een Latijns woordenboek.'));
    innerR.append(top, wrap);
    wrap.scrollTop = 0;
  }

  // —— Events ——
  let t = null;
  input.addEventListener('input', () => {
    if (!data) return;
    clearTimeout(t);
    t = setTimeout(() => runSearch(input.value), 120);
  });
  form.addEventListener('submit', e => {
    e.preventDefault();
    if (!data) return;
    clearTimeout(t);
    runSearch(input.value);
    if (list.length) setView('entry');
  });
  root.addEventListener('keydown', e => {
    if (!data || !list.length) return;
    if (e.key === 'ArrowDown' && document.activeElement === input) {
      e.preventDefault();
      select(Math.min(listIdx + 1, list.length - 1), false);
    } else if (e.key === 'ArrowUp' && document.activeElement === input) {
      e.preventDefault();
      select(Math.max(listIdx - 1, 0), false);
    }
  });

  // —— Laden ——
  headCount.textContent = '';
  words.append(el('p', 'wbl-none', 'Laden\u2026'));
  innerR.append(el('div', 'wbl-welcome', ''));

  loadData().then(d => {
    data = d;
    buildLetters();
    if (input.value.trim()) runSearch(input.value);
    else showLetter(data.byLetter.has('a') ? 'a' : [...data.byLetter.keys()][0]);
  }).catch(() => {
    words.replaceChildren(el('p', 'wbl-none', 'Kon het Nederlands\u2013Latijn woordenboek niet laden.'));
  });

  return {
    root,
    focus() { input.focus(); },
    setQuery(q) { input.value = q || ''; if (data) runSearch(q); }
  };
}
