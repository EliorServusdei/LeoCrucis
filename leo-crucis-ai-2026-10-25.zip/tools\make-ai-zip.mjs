/**
 * Maakt een compacte zip met alleen de bestanden die AI nodig heeft om
 * aan de code te werken. Grote data, assets, node_modules e.d. blijven buiten.
 *
 * Gebruik (vanuit de projectroot):
 *   node tools/make-ai-zip.mjs
 *   npm run ai-zip
 *
 * Opties:
 *   --out <pad>        waar de zip moet komen (standaard: projectroot)
 *   --name <naam>      bestandsnaam zonder .zip (standaard: leo-crucis-ai-YYYY-MM-DD)
 *   --dry              toon alleen wat meegaat, maak geen zip
 *   --include-large    neem ook bestanden > 400 KB mee (zware HTML-inhoud e.d.)
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import os from 'node:os';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');

const args = process.argv.slice(2);
const dry = args.includes('--dry');
const includeLarge = args.includes('--include-large');
const outIdx = args.indexOf('--out');
const nameIdx = args.indexOf('--name');
const outDir = outIdx >= 0 && args[outIdx + 1] ? path.resolve(args[outIdx + 1]) : root;
const stamp = new Date().toISOString().slice(0, 10);
const baseName =
  nameIdx >= 0 && args[nameIdx + 1]
    ? args[nameIdx + 1].replace(/\.zip$/i, '')
    : `leo-crucis-ai-${stamp}`;
const zipPath = path.join(outDir, `${baseName}.zip`);

// Bestanden groter dan dit (bytes) worden overgeslagen, tenzij --include-large.
// Zo blijven zware inhouds-HTML's (techniek, taal, …) buiten de AI-zip.
const MAX_FILE_BYTES = 400 * 1024;

// Mappen die helemaal overgeslagen worden (naam van de map zelf).
const EXCLUDE_DIR_NAMES = new Set([
  'node_modules',
  '.git',
  'target',
  'dist',
  'gen',
  'icons',
  'assets',
  'vendor',
  'media',
  'woordenboek',
  'bijbel',
  'audio',
  'video',
]);

// Bestandsnamen / extensies die we niet meenemen.
const EXCLUDE_FILE_RE =
  /\.(png|jpe?g|gif|webp|ico|icns|mp4|webm|mp3|wav|ogg|pdf|node|lock)$/i;

// Relatieve paden (posix-stijl) die we expliciet overslaan.
const EXCLUDE_REL_PREFIXES = [
  'src/data/woordenboek/',
  'src/data/bijbel/',
  'src/assets/',
  'src/vendor/',
  'media/',
  'src-tauri/icons/',
  'src-tauri/gen/',
  'src-tauri/target/',
  'node_modules/',
];

function shouldSkipDir(name) {
  return EXCLUDE_DIR_NAMES.has(name) || name.startsWith('.');
}

function shouldSkipFile(relPosix, name) {
  if (EXCLUDE_FILE_RE.test(name)) return true;
  // package-lock is nuttig voor AI; Cargo.lock ook. Die houden we.
  if (name === 'package-lock.json' || name === 'Cargo.lock') return false;
  return EXCLUDE_REL_PREFIXES.some((p) => relPosix === p.slice(0, -1) || relPosix.startsWith(p));
}

/** Verzamel alle bestanden die meegaan (relatieve posix-paden). */
function collect(dir, relBase = '') {
  const out = [];
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const ent of entries) {
    const name = ent.name;
    const rel = relBase ? `${relBase}/${name}` : name;
    const full = path.join(dir, name);
    if (ent.isDirectory()) {
      if (shouldSkipDir(name)) continue;
      // Hele data-submappen woordenboek/bijbel al via EXCLUDE_DIR_NAMES
      out.push(...collect(full, rel));
    } else if (ent.isFile()) {
      if (shouldSkipFile(rel.replace(/\\/g, '/'), name)) continue;
      if (!includeLarge) {
        try {
          if (fs.statSync(full).size > MAX_FILE_BYTES) continue;
        } catch {
          continue;
        }
      }
      out.push({ full, rel: rel.replace(/\\/g, '/') });
    }
  }
  return out;
}

function formatSize(n) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

const files = collect(root);
let totalBytes = 0;
for (const f of files) {
  try {
    totalBytes += fs.statSync(f.full).size;
  } catch {
    /* negeer */
  }
}

console.log(`AI-zip: ${files.length} bestanden, ca. ${formatSize(totalBytes)}`);
if (dry) {
  for (const f of files.sort((a, b) => a.rel.localeCompare(b.rel))) {
    console.log('  ' + f.rel);
  }
  console.log('(dry-run — geen zip gemaakt)');
  process.exit(0);
}

if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}
if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

/**
 * Strategie:
 * 1. Kopieer geselecteerde bestanden naar een tijdelijke map (behoud structuur).
 * 2. Zip die map met het systeem-commando (zip / PowerShell).
 * Zo werken we cross-platform zonder extra npm-dependencies.
 */
const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'leo-ai-zip-'));
const stageDir = path.join(tmpRoot, 'leo-crucis');

try {
  for (const f of files) {
    const dest = path.join(stageDir, f.rel);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(f.full, dest);
  }

  // Korte leesmij in de zip, zodat AI weet wat er ontbreekt.
  const readme = `Leo Crucis — AI-werkzip
========================
Gegenereerd: ${new Date().toISOString()}
Bestanden:   ${files.length}
Grootte:     ca. ${formatSize(totalBytes)}

Bewust weggelaten (te groot / niet nodig voor codewerk):
  - node_modules/
  - src/data/woordenboek/   (volledige woordenboek-JSON's)
  - src/data/bijbel/        (volledige bijbelvertalingen)
  - src/assets/             (afbeeldingen, tilesets, video)
  - src/vendor/             (minified third-party bundles)
  - media/
  - src-tauri/icons/, gen/, target/
  - .png .jpg .mp4 .pdf .icns .node
  - bestanden > 400 KB (zware inhouds-HTML), tenzij --include-large

Bij een bug in laden/parsen van woordenboek of bijbel: stuur
apart een klein sample (1 letter-JSON of 1 bijbelboek) mee.
`;
  fs.writeFileSync(path.join(stageDir, 'AI-README.txt'), readme, 'utf8');

  const isWin = process.platform === 'win32';
  let ok = false;

  if (!isWin) {
    // macOS / Linux: zip
    const r = spawnSync(
      'zip',
      ['-r', '-q', zipPath, '.'],
      { cwd: stageDir, stdio: 'inherit', shell: false }
    );
    ok = r.status === 0;
    if (!ok) {
      console.error('zip-commando mislukt. Installeer "zip" of gebruik een andere tool.');
    }
  } else {
    // Windows: PowerShell Compress-Archive
    const ps = `
      $ErrorActionPreference = 'Stop'
      Compress-Archive -Path (Join-Path '${stageDir.replace(/'/g, "''")}' '*') -DestinationPath '${zipPath.replace(/'/g, "''")}' -Force
    `;
    const r = spawnSync(
      'powershell.exe',
      ['-NoProfile', '-Command', ps],
      { stdio: 'inherit', shell: false }
    );
    ok = r.status === 0;
  }

  if (!ok || !fs.existsSync(zipPath)) {
    console.error('Kon geen zip maken.');
    process.exit(1);
  }

  const finalSize = fs.statSync(zipPath).size;
  console.log(`Klaar: ${zipPath}`);
  console.log(`Zip-grootte: ${formatSize(finalSize)}`);
} finally {
  fs.rmSync(tmpRoot, { recursive: true, force: true });
}
