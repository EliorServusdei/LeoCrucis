# Codex 1917 – correcties v14

Plaats deze bestanden in: `src/data/codex-1917/`

## Hersteld
- **Can. 1099** – volledige tekst (vorm van het huwelijk), typo *schismate* gecorrigeerd
- **Can. 256** – OCR *Universitatibus*
- **Can. 395, 401** – OCR *Ecclesiae*
- **Can. 215–254** – De suprema potestate herschreven/uitgelijnd
- **Huwelijk** – o.a. 1094–1100, 1108–1110, 1118, 1120, 1126–1127, 1130–1131, 1138, 1141
- **Processen** – o.a. 1552–1554, 1556–1557, 1572–1574

Daarna hard herladen.

