// Eenvoudige PowerPoint-achtige presentatie-editor.
const h = (tag, cls, text) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
};

const defaultSlides = () => ([
  { title: 'Titel van de presentatie', bullets: ['Ondertitel of eerste punt', 'Tweede punt'], notes: '' },
  { title: 'Inhoud', bullets: ['Onderwerp 1', 'Onderwerp 2', 'Onderwerp 3'], notes: '' }
]);

export function parseSlidesHtml(html) {
  try {
    const d = document.createElement('div');
    d.innerHTML = html || '';
    const el = d.querySelector('script[type="application/json"][data-slides]');
    if (el) return JSON.parse(el.textContent);
  } catch (e) {}
  return defaultSlides();
}

export function buildSlidesHtml(slides) {
  const json = JSON.stringify(slides);
  return `<div class="slides-book"><script type="application/json" data-slides>${json.replace(/</g, '\\u003c')}</script></div>`;
}

export function renderSlidesView(html, { title, onBack, onEdit, dev }) {
  const slides = parseSlidesHtml(html);
  let idx = 0;
  const wrap = h('div', 'slides-view');
  const head = h('div', 'view-head');
  const back = h('button', 'back', '← Terug');
  back.type = 'button';
  back.onclick = onBack;
  head.append(back, h('h1', '', title || 'Presentatie'));
  if (dev && onEdit) {
    const edit = h('button', 'dev-btn pencil', '✎');
    edit.type = 'button';
    edit.title = 'Presentatie bewerken';
    edit.onclick = onEdit;
    head.append(edit);
  }
  wrap.append(head);

  const stage = h('div', 'slide-stage');
  const counter = h('span', 'slide-counter');
  const nav = h('div', 'slide-nav');
  const prev = h('button', 'back', '← Vorige');
  const next = h('button', 'back', 'Volgende →');
  prev.type = next.type = 'button';
  nav.append(prev, counter, next);

  const paint = () => {
    const s = slides[idx] || { title: '', bullets: [] };
    stage.replaceChildren();
    stage.append(h('h2', 'slide-title', s.title || 'Dia ' + (idx + 1)));
    const ul = h('ul', 'slide-bullets');
    (s.bullets || []).forEach(b => ul.append(h('li', '', b)));
    stage.append(ul);
    if (s.notes) stage.append(h('p', 'slide-notes', s.notes));
    counter.textContent = `${idx + 1} / ${slides.length}`;
    prev.disabled = idx === 0;
    next.disabled = idx >= slides.length - 1;
  };
  prev.onclick = () => { if (idx > 0) { idx--; paint(); } };
  next.onclick = () => { if (idx < slides.length - 1) { idx++; paint(); } };

  wrap.append(stage, nav);
  paint();
  return wrap;
}

export function createSlidesEditor(initialHtml, { ask }) {
  let slides = parseSlidesHtml(initialHtml);
  let idx = 0;
  const bar = h('div', 'editor-bar slides-bar');
  const area = h('div', 'slides-editor');
  const note = h('span', 'editor-note');
  const flash = t => { note.textContent = t; setTimeout(() => { if (note.textContent === t) note.textContent = ''; }, 3000); };

  const list = h('div', 'slide-thumbnails');
  const editor = h('div', 'slide-edit-panel');

  const titleIn = h('input', 'slide-field');
  titleIn.placeholder = 'Titel van de dia';
  titleIn.setAttribute('aria-label', 'Diatitel');
  const bulletsIn = h('textarea', 'slide-field slide-bullets-in');
  bulletsIn.placeholder = 'Opsomming — één punt per regel';
  bulletsIn.rows = 8;
  bulletsIn.setAttribute('aria-label', 'Opsommingstekens');
  const notesIn = h('textarea', 'slide-field');
  notesIn.placeholder = 'Notities (optioneel)';
  notesIn.rows = 2;

  const syncFromSlide = () => {
    const s = slides[idx] || { title: '', bullets: [], notes: '' };
    titleIn.value = s.title || '';
    bulletsIn.value = (s.bullets || []).join('\n');
    notesIn.value = s.notes || '';
  };
  const syncToSlide = () => {
    if (!slides[idx]) return;
    slides[idx].title = titleIn.value;
    slides[idx].bullets = bulletsIn.value.split('\n').map(x => x.trim()).filter(Boolean);
    slides[idx].notes = notesIn.value;
  };

  const renderThumbs = () => {
    list.replaceChildren();
    slides.forEach((s, i) => {
      const th = h('button', 'slide-thumb' + (i === idx ? ' active' : ''));
      th.type = 'button';
      th.textContent = `${i + 1}. ${(s.title || 'Dia').slice(0, 28)}`;
      th.onclick = () => { syncToSlide(); idx = i; renderThumbs(); syncFromSlide(); };
      list.append(th);
    });
  };

  titleIn.oninput = bulletsIn.oninput = notesIn.oninput = () => {
    syncToSlide();
    renderThumbs();
  };

  const tool = (label, title, fn) => {
    const b = h('button', '', label);
    b.type = 'button';
    b.title = title;
    b.onclick = fn;
    bar.append(b);
    return b;
  };

  tool('+ Dia', 'Nieuwe dia toevoegen', () => {
    syncToSlide();
    slides.splice(idx + 1, 0, { title: 'Nieuwe dia', bullets: ['Punt 1'], notes: '' });
    idx++;
    renderThumbs();
    syncFromSlide();
    flash('Dia toegevoegd');
  });
  tool('🗑 Dia', 'Huidige dia verwijderen', () => {
    if (slides.length <= 1) { flash('Minstens één dia nodig'); return; }
    slides.splice(idx, 1);
    if (idx >= slides.length) idx = slides.length - 1;
    renderThumbs();
    syncFromSlide();
    flash('Dia verwijderd');
  });
  tool('↑', 'Dia omhoog', () => {
    if (idx === 0) return;
    syncToSlide();
    [slides[idx - 1], slides[idx]] = [slides[idx], slides[idx - 1]];
    idx--;
    renderThumbs();
    syncFromSlide();
  });
  tool('↓', 'Dia omlaag', () => {
    if (idx >= slides.length - 1) return;
    syncToSlide();
    [slides[idx + 1], slides[idx]] = [slides[idx], slides[idx + 1]];
    idx++;
    renderThumbs();
    syncFromSlide();
  });
  bar.append(note);

  editor.append(
    h('label', '', 'Titel'),
    titleIn,
    h('label', '', 'Opsomming (één per regel)'),
    bulletsIn,
    h('label', '', 'Notities'),
    notesIn
  );

  const body = h('div', 'slides-editor-body');
  body.append(list, editor);
  area.append(body);

  renderThumbs();
  syncFromSlide();

  return {
    bar,
    area,
    getHtml: () => { syncToSlide(); return buildSlidesHtml(slides); },
    setHtml: html => { slides = parseSlidesHtml(html); idx = 0; renderThumbs(); syncFromSlide(); },
    flash,
    focus: () => titleIn.focus()
  };
}
