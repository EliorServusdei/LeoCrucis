// Bibliotheek Leo Crucis — opstart en navigatie.
// Inhoud: wereld in src/data/world.json, elk boek als eigen bestand in src/stad/<gebouw>/<sectie>/<id>.html (map per gebouw en per sectie).

import { loadIndex, search, searchAll, snippet, setOverlay, preloadIndexQuiet, isIndexLoaded, getSearchCacheStats } from './core/search.js';
import * as SearchMod from './core/search.js';
const suggest = typeof SearchMod.suggest === 'function' ? SearchMod.suggest : (async () => []);
import { createEditor } from './editor/editor.js';
import { openInfo, infoButton, parseRef, refScript, emptyRef, hasRef } from './core/refs.js';
import { isDev, setDev, loadSaved, saveWorld, saveDetails, loadExtra, saveExtra, loadRefs, saveRefs, resetAll, slug, uniqueId, ask, inTauri, readFile, writeFile, deleteFile, openFolder, openMediaFolder, resetFiles, listStad, readUserPdfB64, exportUserImage, listUserCovers, readUserImageB64, loadSettings, saveSettings, applySettings, clearAppCache, getTauriWindow, loadStudy, recordStudyBlock, weekStudySummary, periodStudySummary, ACHIEVEMENTS, evaluateAchievements, saveStudy, loadSessions, upsertSession, clearSessions, todayKey, clampSessionMax, trimSessions, initFocusStorage, flushFocusStorage, FOCUS_FILES } from './core/edit.js';
import { chooseBookType, chooseDocDesign, initialDocHtml, typeMeta } from './editor/choose.js';
import { APP_VERSION, APP_NAME } from './version.js';
import { createPdfEditor, renderPdfView, buildPdfHtml } from './editor/pdfbook.js';
import { createSlidesEditor, renderSlidesView, buildSlidesHtml } from './editor/slides.js';
import { createSheetEditor, renderSheetView, buildSheetHtml } from './editor/sheet.js';
import { createMediaPlayer, onBackgroundMusic, bgToggle, bgPrev, bgNext, bgStop, getBackgroundMusic } from './media/player.js';
import { withLoading, hideSplash, setSplashProgress } from './core/loading.js';
import { startFpsMonitor, getFps, isThrottling, yieldForUi } from './core/perf.js';
import { onTransfers, clearFinishedTransfers, transferEta } from './core/transfers.js';

// --- core modules (fase 1 architectuur) ---
import { $, el, svgIcon } from './core/dom.js';
import {
  roomItems as roomItemsOf,
  allItems as allItemsOf,
  itemOf as itemOfWorld,
  findItemLoc as findItemLocOf,
  whereOf as whereOfWorld,
  ensureShelves as ensureShelvesOf,
  colorOf as colorOfItem,
  defaultColorForId,
  textOf as textOfHtml,
  detectType as detectTypeOf
} from './core/world-model.js';
import { createPathApi } from './core/paths.js';
import { createBookApi } from './core/books.js';
import { loadJSON } from './core/json.js';
import {
  installGlobalHandlers,
  bootStep,
  bootFail,
  bootReport,
  bootErrors
} from './core/boot-diagnostics.js';

// --- ui modules (fase 2) ---
import {
  configureSearchHistory,
  loadSearchRecent,
  getSearchHistory,
  saveSearchRecent,
  initSearchHistoryFromFile,
  clearSearchHistory,
  removeSearchHistoryEntry,
  formatSearchHistoryTime,
  formatSearchHistoryRelative,
  historyDayKey,
  HISTORY_DAY_LABELS
} from './ui/search-history.js';
import { createRecentAppsApi } from './ui/recent-apps.js';
import { createFocusStudyApi, fmtDuration, fmtClock } from './ui/focus-study.js';
import { createSearchUiApi } from './ui/search-ui.js';
import { createMiniAppsViewApi, MINI_APP_TITLES as MINI_APP_TITLES_MOD } from './ui/mini-apps-view.js';
import { createWorldViewApi } from './ui/world-view.js';
import { createSettingsViewApi } from './ui/settings-view.js';
import { createBookDndApi } from './ui/book-dnd.js';
import { createHeaderApi } from './ui/header.js';
import { installShortcuts, showShortcutsHelp } from './ui/shortcuts.js';
import { maybeStartOnboarding, startOnboarding, resetOnboarding } from './ui/onboarding.js';
import { createBreadcrumbsApi } from './ui/breadcrumbs.js';
import {
  setNav as storeSetNav,
  setCurrentSection as storeSetCurrentSection,
  setWorld as storeSetWorld,
} from './core/store.js';

import {
  MINI_APP_ICONS,
  miniAppIconSvg,
  APP_CATALOG,
  createMiniAppInstance as createMiniAppFromRegistry,
  preloadMiniApps
} from './apps/registry.js';

const home = $('#home');
try { installGlobalHandlers(); } catch (_) {}
try { window.bootReport = bootReport; window.bootErrors = bootErrors; } catch (_) {}
const view = $('#view');
const viewContent = $('#view-content');

// Geen standaard browser-contextmenu (rechtermuisklik) in de app
document.addEventListener('contextmenu', e => { e.preventDefault(); }, true);

// Editor is altijd actief: boeken, secties en stad bewerken zonder schakelaar.
const dev = true;
try { document.body.classList.add('dev-on'); } catch (_) {}
let extra = loadExtra();
let refsOverlay = loadRefs();                  // browser: eigen referentiegegevens (id -> ref); in de app staan ze in het boekbestand
let currentSection = null;
// Wereld (secties/boeken) bewaren. In de browser staan ook de boekteksten in localStorage; in de app zijn dat losse bestanden.
const persist = () => withLoading(async () => {
  try { await saveWorld(world); if (!inTauri) saveDetails(details); }
  catch (e) { ask('Opslaan mislukt: ' + e, { yes: 'OK' }); }
}, 'Opslaan…');
// Eén boek bewaren (bestand in de gebruikersmap, of localStorage in de browser) en zoekbaar maken.
async function saveBook(id, title, html) {
  return withLoading(() => saveBookInner(id, title, html), 'Opslaan…');
}

const takenIds = () => new Set([...allItems().map(i => i.id), ...Object.keys(details)]);
const devBtn = (label, title, fn, cls = '') => { const b = el('button', 'dev-btn ' + cls, label); b.type = 'button'; b.title = title; b.setAttribute('aria-label', title); b.onclick = fn; return b; };
const xBtn = (title, fn) => {
  const x = el('span', 'dev-x', ''); // kruisje via CSS ::before voor nette centrering
  x.title = title;
  x.setAttribute('role', 'button');
  x.setAttribute('aria-label', title);
  x.onclick = e => { e.stopPropagation(); fn(); };
  return x;
};

let details = {};        // alleen EIGEN wijzigingen (id -> {title, html}); de boeken zelf staan in src/stad/<gebouw>/<sectie>/<id>.html
const bookCache = {};

let bookPaths = {};             // meegeleverde boeken: id (kleine letters) -> "gebouw/sectie/bestandsnaam" of "gebouw/bestandsnaam"

let world = { buildings: [] };
const nav = { b: null, r: null };
/** Index van het actieve gebouw in de start-carrousel (interactieve weergave). */
let carouselIndex = 0;


// --- Paths & books via core-modules ---
const paths = createPathApi({
  getWorld: () => world,
  getBookPaths: () => bookPaths,
  findItemLoc: findItemLocOf,
  itemOf: itemOfWorld
});
const { relBookPath, dirOf, userPath, bundledUrl } = paths;

const books = createBookApi({
  getWorld: () => world,
  getDetails: () => details,
  getBookCache: () => bookCache,
  setBookCache: (id, val) => {
    if (val === undefined) delete bookCache[id];
    else bookCache[id] = val;
  },
  getExtra: () => extra,
  setExtra: (x) => { extra = x; },
  getRefsOverlay: () => refsOverlay,
  saveRefs,
  inTauri,
  readFile,
  writeFile,
  deleteFile,
  persistExtra: (x) => { saveExtra(x); setOverlay(x); },
  parseRef,
  refScript,
  emptyRef,
  userPath,
  bundledUrl
});

const {
  loadBook,
  saveBookInner,
  reindex,
  dropItem,
  saveRef,
  bookDocument,
  getRef,
  writeBookFile,
  parseBook,
  detectType,
  textOf
} = books;

function roomItems(r) { return roomItemsOf(r); }
function allItems() { return allItemsOf(world); }
function itemOf(id) { return itemOfWorld(world, id); }
function findItemLoc(id) { return findItemLocOf(world, id); }
function whereOf(id) { return whereOfWorld(world, id); }
function ensureShelves(room) { return ensureShelvesOf(room); }
function colorOf(item, fallbackIdx) { return colorOfItem(item, fallbackIdx); }

function createMiniAppInstance(kind, startPos) {
  return createMiniAppFromRegistry(kind, startPos);
}

function listLeoApps() {
  return APP_CATALOG.map(entry => {
    if (entry.create) {
      return { kind: entry.kind, run: () => startCreate(entry.kind) };
    }
    if (entry.kind === 'focus') {
      return { kind: entry.kind, run: () => showFocus() };
    }
    if (entry.kind === 'audio' || entry.kind === 'video') {
      return {
        kind: entry.kind,
        run: () => {
          try { showMediaPlayer(entry.kind); }
          catch (_) { showMiniApp(entry.kind); }
        }
      };
    }
    return { kind: entry.kind, run: () => showMiniApp(entry.kind) };
  });
}

function openItem(item) { showSection(item.id); }
function go(b, r) {
  nav.b = b;
  nav.r = r;
  try { storeSetNav(b, r); } catch (_) {}
  renderWorld();
  try { refreshBreadcrumbs(); } catch (_) {}
}

// ===== Boek-DnD via ui/book-dnd.js (fase 1) =====
let dndApi = null;
function wireDnd() {
  if (dndApi) return dndApi;
  dndApi = createBookDndApi({
    getDev: () => !!dev,
    colorOf,
    findItemLoc,
    ensureShelves,
    persist,
    renderWorld: () => renderWorld(),
  });
  dndApi.installGlobalListeners();
  return dndApi;
}
function openSpineColorPicker(item, anchor, fallbackIdx) {
  return wireDnd().openSpineColorPicker(item, anchor, fallbackIdx);
}
function moveBook(itemId, targetRoom, targetShelf, targetIndex) {
  return wireDnd().moveBook(itemId, targetRoom, targetShelf, targetIndex);
}
function wireBookDrag(el, item) {
  return wireDnd().wireBookDrag(el, item);
}
function wireDropTarget(el, opts) {
  return wireDnd().wireDropTarget(el, opts);
}

// ===== Wereld / startscherm via ui/world-view.js (fase 3) =====
function currentViewMode() {
  wireUiModules();
  return worldApi.currentViewMode();
}
function renderWorld() {
  wireUiModules();
  return worldApi.renderWorld();
}
function ensureLayers() {
  wireUiModules();
  return worldApi.ensureLayers();
}
function ensurePieces() {
  wireUiModules();
  return worldApi.ensurePieces();
}

function refreshCovers() {
  wireUiModules();
  return worldApi.refreshCovers();
}
function exportBuildingImages() {
  wireUiModules();
  return worldApi.exportBuildingImages();
}
function openBuildMenu(focusSec) {
  wireUiModules();
  return worldApi.openBuildMenu(focusSec);
}
function openBuildingMenu() {
  wireUiModules();
  return worldApi.openBuildingMenu();
}

function setHash(h) {
  try { history.replaceState(null, '', h); } catch (e) {}
}

function showHome() {
  try { currentSection = null; storeSetCurrentSection(null); } catch (_) {}
  try { wireUiModules(); if (miniApi && miniApi.clearSplitState) miniApi.clearSplitState(); } catch (_) {}
  document.body.classList.remove('pdf-open');
  document.body.classList.remove('browser-open');
  document.body.classList.remove('search-open');
  document.body.classList.remove('split-open');
  try { if (miniApi && typeof miniApi.syncHeaderNavState === 'function') miniApi.syncHeaderNavState(); } catch (_) {}
  try { renderHeaderOpenApps(); } catch (_) {}
  if (viewContent && viewContent.children.length) {
    viewContent.replaceChildren();
  }
  if (home) home.style.display = 'block';
  if (view) view.style.display = 'none';
  setHash('#');
  renderWorld();
  try { refreshBreadcrumbs(); } catch (_) {}
}

async function showSection(id, edit = false) {
  // Bijbel/woordenboek hebben eigen limietcheck; boeken/docs via section-id
  const specialEarly = (() => { try { return allItems().find(i => i.id === id); } catch (_) { return null; } })();
  if (!(specialEarly && (specialEarly.type === 'bible' || specialEarly.type === 'dictionary'))) {
    if (!canOpenNewRecent('section-' + id)) return;
  }
  currentSection = id;
  try { storeSetCurrentSection(id); } catch (_) {}
  try { refreshBreadcrumbs(); } catch (_) {}
  // PDF-viewer zet body.pdf-open; die mag niet blijven hangen bij andere boeken/editors
  clearSplitState();
  document.body.classList.remove('pdf-open');
  document.body.classList.remove('browser-open');
  document.body.classList.remove('search-open');
  if (edit && dev) return startEdit(id);
  const special = allItems().find(i => i.id === id);
  if (special && special.type === 'bible') { showBible(special); return; }
  if (special && special.type === 'dictionary') { showMiniApp('woordenboek'); return; }
  const d = await withLoading(() => loadBook(id), 'Boek openen…');
  if (currentSection !== id) return;
  const it = allItems().find(i => i.id === id);
  const type = (it && it.type) || detectType(d && d.html) || 'doc';
  viewContent.replaceChildren();

  const title = (it && it.title) || (d && d.title) || id;
  if (it) rememberOfficeRecent(id);
  const goEdit = () => startEdit(id);

  if (type === 'pdf') {
    const ref = getRef(id, d);
    const ib = infoButton(hasRef(ref), () => openInfo({
      title,
      ref: JSON.parse(JSON.stringify(ref)),
      dev,
      save: async r => {
        await saveRef(id, r);
        ib.classList.toggle('has', hasRef(r));
        Object.assign(ref, r);
      }
    }));
    const view = renderPdfView(d ? d.html : '', {
      title,
      onBack: showHome,
      onEdit: goEdit,
      dev,
      infoBtn: ib
    });
    viewContent.append(view);
  } else if (type === 'pptx') {
    const view = renderSlidesView(d ? d.html : '', {
      title,
      onBack: showHome,
      onEdit: goEdit,
      dev
    });
    viewContent.append(view);
  } else if (type === 'xlsx') {
    const view = renderSheetView(d ? d.html : '', {
      title,
      onBack: showHome,
      onEdit: goEdit,
      dev
    });
    viewContent.append(view);
  } else {
    const head = document.createElement('div');
    head.className = 'view-head';
    const back = document.createElement('button');
    back.className = 'back';
    back.id = 'btn-back';
    back.textContent = '← Terug';
    back.onclick = showHome;
    const h1 = document.createElement('h1');
    h1.textContent = title;
    head.append(back, h1);
    if (dev) head.append(devBtn('✎', 'Boek bewerken', goEdit, 'pencil'));

    const ref = getRef(id, d);
    const ib = infoButton(hasRef(ref), () => openInfo({ title: h1.textContent, ref: JSON.parse(JSON.stringify(ref)), dev, save: async r => { await saveRef(id, r); ib.classList.toggle('has', hasRef(r)); Object.assign(ref, r); } }));
    head.append(ib);

    const body = document.createElement('div');
    body.className = 'book';
    body.innerHTML = d ? d.html : '<div class="box"><p>Deze sectie is nog in opbouw.</p></div>';
    wireBookLinks(body);
    viewContent.append(head, body);
  }

  home.style.display = 'none';
  view.style.display = 'block';
  setHash('#' + id);
  window.scrollTo(0, 0);

  pushRecentApp({
    id: 'section-' + id,
    kind: 'section',
    iconKind: type === 'pdf' ? 'doc' : (type === 'pptx' ? 'pptx' : (type === 'xlsx' ? 'xlsx' : 'doc')),
    title,
    hint: type === 'pdf' ? 'PDF' : (type === 'pptx' ? 'Presentatie' : (type === 'xlsx' ? 'Rekenblad' : 'Boek')),
    activate: () => { try { showSection(id); } catch (_) {} },
    close: () => {
      if (currentSection === id) {
        try { showHome(); } catch (_) {}
      }
    }
  });
}

/** Bijbellezer (src/apps-bijbel.js): item met type "bible" in world.json. */
function showBible(item) {
  if (!canOpenNewRecent('app-bible')) return;
  viewContent.replaceChildren();
  const head = el('div', 'view-head');
  const back = el('button', 'back', '← Terug');
  back.type = 'button';
  back.id = 'btn-back';
  back.onclick = showHome;
  head.append(back, el('h1', '', item.title || 'Bijbel'));
  const app = createMiniAppFromRegistry('bible');
  viewContent.append(head, app.root);
  home.style.display = 'none';
  view.style.display = 'block';
  pushRecentApp({
    id: 'app-bible',
    kind: 'app',
    iconKind: 'bible',
    title: item.title || 'Bijbel',
    hint: 'App',
    activate: () => { try { showBible(item); } catch (_) { showMiniApp('bible'); } },
    close: () => { try { if (currentSection === (item && item.id)) showHome(); else showHome(); } catch (_) {} }
  });

  setHash('#' + item.id);
  window.scrollTo(0, 0);
}

/** Open URL in systeembrowser (buiten de app). */
async function openInSystemBrowser(href) {
  const url = (href || '').trim();
  if (!url) return;
  try {
    if (inTauri && window.__TAURI__?.core?.invoke) {
      // Eigen Rust-commando (werkt zonder shell-plugin)
      try {
        await window.__TAURI__.core.invoke('open_url', { url });
        return;
      } catch (e0) { /* probeer andere methodes */ }
      // Tauri shell-plugin (als die ooit wordt toegevoegd)
      try {
        const shell = window.__TAURI__?.shell;
        if (shell?.open) {
          await shell.open(url);
          return;
        }
      } catch (e1) { /* ignore */ }
      try {
        await window.__TAURI__.core.invoke('plugin:shell|open', { path: url });
        return;
      } catch (e2) { /* ignore */ }
    }
  } catch (e) { /* fall through */ }
  // Fallback (browserversie of als invoke faalt)
  window.open(url, '_blank', 'noopener,noreferrer');
}

/** Externe URL: standaard in-app browser; { system: true } → systeembrowser. */
async function openExternalUrl(href, { system = false } = {}) {
  if (system) {
    await openInSystemBrowser(href);
    return;
  }
  showInAppBrowser(href);
}

/**
 * Ingebouwde browser (URL-balk + iframe).
 * Sites zoals grok.com blokkeren vaak iframes → knop “Extern”.
 */

/** Kies waar een nieuw document wordt opgeslagen (gebouw › kamer › plank). */
function chooseSaveLocation() {
  return new Promise(resolve => {
    const back = el('div', 'dlg-back');
    const box = el('div', 'dlg dlg-wide dlg-save-loc');
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-label', 'Opslaan locatie');
    box.append(el('p', 'dlg-title', 'Waar wil je dit opslaan?'));
    box.append(el('p', 'dlg-hint', 'Kies een sectie (plank) in de bibliotheek.'));

    const list = el('div', 'save-loc-list');
    let selected = null;
    const options = [];

    for (const b of (world.buildings || [])) {
      for (const r of (b.rooms || [])) {
        ensureShelves(r);
        (r.shelves || []).forEach((sh, si) => {
          const label = sh.label || ('Plank ' + (si + 1));
          const path = b.label + ' › ' + r.label + (sh.label ? ' › ' + sh.label : '');
          const btn = el('button', 'save-loc-item');
          btn.type = 'button';
          btn.innerHTML = '<strong>' + label.replace(/</g, '&lt;') + '</strong><span class="save-loc-path">' + path.replace(/</g, '&lt;') + '</span>';
          btn.onclick = () => {
            list.querySelectorAll('.save-loc-item').forEach(x => x.classList.remove('active'));
            btn.classList.add('active');
            selected = { building: b, room: r, shelf: sh };
          };
          list.append(btn);
          options.push({ btn, building: b, room: r, shelf: sh });
        });
      }
    }

    if (!options.length) {
      box.append(el('p', 'dlg-hint', 'Er is nog geen sectie. Maak eerst een gebouw en kamer aan op de startpagina.'));
    } else {
      box.append(list);
      // select first by default
      options[0].btn.classList.add('active');
      selected = { building: options[0].building, room: options[0].room, shelf: options[0].shelf };
    }

    const row = el('div', 'dlg-row');
    const cancel = el('button', 'back', 'Annuleren');
    cancel.type = 'button';
    cancel.onclick = () => { back.remove(); resolve(null); };
    const ok = el('button', 'save', 'Opslaan hier');
    ok.type = 'button';
    ok.onclick = () => {
      if (!selected) return;
      back.remove();
      resolve(selected);
    };
    if (!options.length) ok.disabled = true;
    row.append(cancel, ok);
    box.append(row);
    back.append(box);
    document.body.append(back);
    back.addEventListener('keydown', e => { if (e.key === 'Escape') cancel.onclick(); });
    ok.focus();
  });
}

/**
 * Nieuw document/presentatie/rekenblad vanuit de header.
 * Opent de editor met lege inhoud; bij Opslaan wordt gevraagd waar het komt.
 */
async function startCreate(type) {
  document.body.classList.remove('pdf-open');
  document.body.classList.remove('browser-open');
  currentSection = null;
  viewContent.replaceChildren();

  let title = type === 'pptx' ? 'Nieuwe presentatie' : type === 'xlsx' ? 'Nieuw rekenblad' : 'Nieuw document';
  let html = '';
  if (type === 'doc') {
    const design = await chooseDocDesign();
    if (design === null) { showHome(); return; }
    html = initialDocHtml(design);
  } else if (type === 'pptx') {
    html = buildSlidesHtml([
      { title: 'Titel', bullets: ['Eerste punt', 'Tweede punt'], notes: '' },
      { title: 'Inhoud', bullets: ['Onderwerp 1', 'Onderwerp 2'], notes: '' }
    ]);
  } else if (type === 'xlsx') {
    html = buildSheetHtml({ cells: Array.from({ length: 20 }, () => Array(10).fill('')) });
  } else {
    showHome();
    return;
  }

  const head = el('div', 'view-head');
  const cancel = el('button', 'back', '← Annuleren');
  cancel.onclick = () => showHome();
  const ti = el('input', 'title-edit');
  ti.value = title;
  ti.setAttribute('aria-label', 'Titel');
  head.append(cancel, ti);

  const saveNew = async (getHtml) => {
    const name = ti.value.trim() || title;
    const loc = await chooseSaveLocation();
    if (!loc) return;
    const { building: bld, room, shelf: sh } = loc;
    ensureShelves(room);
    if (!sh.items) sh.items = [];
    const id = uniqueId(slug(`${bld.id}-${room.id}-${name}`), takenIds());
    sh.items.push({ id, title: name, desc: '', type, dir: bld.id, color: defaultColorForId(id) });
    try {
      await persist();
      await saveBook(id, name, getHtml());
    } catch (e) {
      await ask('Opslaan mislukt: ' + e, { yes: 'OK' });
      return;
    }
    renderWorld();
    showSection(id);
  };

  if (type === 'pptx') {
    const ed = createSlidesEditor(html, { ask });
    const top = el('div', 'editor-ribbon');
    head.classList.add('editor-title-row');
    top.append(head, ed.bar);
    const sb = document.createElement('button');
    sb.className = 'save'; sb.type = 'button'; sb.textContent = 'Opslaan';
    sb.onclick = () => saveNew(() => ed.getHtml());
    ed.bar.append(sb);
    viewContent.append(top, ed.area);
    home.style.display = 'none'; view.style.display = 'block';
    ed.focus();
    return;
  }

  if (type === 'xlsx') {
    const ed = createSheetEditor(html, { ask });
    head.classList.add('editor-title-row');
    const top = el('div', 'editor-ribbon');
    top.append(head, ed.bar);
    const sb = document.createElement('button');
    sb.className = 'save'; sb.type = 'button'; sb.textContent = 'Opslaan';
    sb.onclick = () => saveNew(() => ed.getHtml());
    ed.bar.append(sb);
    viewContent.append(top, ed.area);
    home.style.display = 'none'; view.style.display = 'block';
    ed.focus();
    return;
  }

  // Document (Word-achtig)
  const ed = createEditor(html, { ask });
  ed.addTool('Opslaan', 'Opslaan in de bibliotheek', async () => {
    await saveNew(() => ed.getHtml());
  }, { cls: 'save', last: true });
  head.classList.add('editor-title-row');
  ed.bar.prepend(head);
  viewContent.append(ed.bar, ed.spacer || document.createComment(''), ed.area);
  home.style.display = 'none'; view.style.display = 'block';
  window.scrollTo(0, 0);
  ed.focus();
  if (ed.syncRibbonH) requestAnimationFrame(() => ed.syncRibbonH());
}

// ===== Header via ui/header.js (fase 1) =====
const MINI_APP_TITLES = MINI_APP_TITLES_MOD;

let headerApi = null;
function wireHeaderApi() {
  if (headerApi) return headerApi;
  headerApi = createHeaderApi({
    allItems: () => allItems(),
    listLeoApps: () => listLeoApps(),
    startCreate: (t) => startCreate(t),
    showMiniApp: (k, p) => showMiniApp(k, p),
    showMediaPlayer: (k) => showMediaPlayer(k),
    showFocus: () => showFocus(),
    guardFocusBlock: (k, fn) => guardFocusBlock(k, fn),
    applyFocusBlockLock: () => { try { applyFocusBlockLock(); } catch (_) {} },
    isStudyBlockActive: () => !!(typeof studyBlock !== 'undefined' && studyBlock.active),
    typeMeta,
    openItem: (it) => openItem(it),
    showSection: (id) => showSection(id),
  });
  return headerApi;
}
function loadOfficeRecent() { return wireHeaderApi().loadOfficeRecent(); }
function rememberOfficeRecent(id) { return wireHeaderApi().rememberOfficeRecent(id); }
function closeHeaderMenu(focusBtn) { return wireHeaderApi().closeHeaderMenu(focusBtn); }
function openOfficeMenu(btn) { return wireHeaderApi().openOfficeMenu(btn); }
function openGroupMenu(btn, key) { return wireHeaderApi().openGroupMenu(btn, key); }
function renderHeaderFavorites() { return wireHeaderApi().renderHeaderFavorites(); }
function wireHeaderTools() { return wireHeaderApi().wireHeaderTools(); }
function loadAppFavorites() { return wireHeaderApi().loadAppFavorites(); }
function saveAppFavorites(list) { return wireHeaderApi().saveAppFavorites(list); }
function isAppFavorite(kind) { return wireHeaderApi().isAppFavorite(kind); }
function toggleAppFavorite(kind) { return wireHeaderApi().toggleAppFavorite(kind); }

/** Alle apps die op het startscherm / favorieten kunnen staan. */
/** Splitscreen: max. twee mini-apps naast elkaar. null = leeg paneel. */
let splitLeft = null;   // { kind, startPos }
let splitRight = null;
let splitRatio = 0.5;   // links-deel van de breedte (0.25–0.75)

/**
 * Android-achtige recente apps (max. 3).
 * Apps blijven in deze lijst staan als je wisselt of naar home gaat;
 * pas bij expliciet sluiten (× in het overzicht) verdwijnen ze.
 */
/** @type {{ id: string, kind: string, iconKind: string, title: string, hint: string, active: boolean, activate: Function, close: Function }[]} */
// Enige bron: recentApi (fase 2). Proxy-array voor legacy code.
function getRecentAppsList() {
  wireUiModules();
  return recentApi.getList();
}
// Compat: code die `recentApps` leest/mutates gebruikt de live lijst
Object.defineProperty(typeof globalThis !== 'undefined' ? globalThis : window, '__lc_recentApps_unused', { value: 1 });
let recentApps = []; // wordt in wireUiModules gesynchroniseerd


function getRecentAppsMax() {
  wireUiModules();
  return recentApi.getRecentAppsMax();
}

/** True als deze id al in de stack zit of er nog ruimte is; anders popup en false. */
function canOpenNewRecent(id) {
  wireUiModules();
  return recentApi.canOpenNewRecent(id);
}

/** Popup bij bereikt app-limiet, met instellingen-knop. */
function showRecentAppsLimitDialog(lim) {
  // Eén dialoog tegelijk
  document.querySelectorAll('.dlg-back.lc-recent-limit-dlg').forEach(n => n.remove());
  const back = el('div', 'dlg-back lc-recent-limit-dlg');
  const box = el('div', 'dlg');
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-label', 'App-limiet bereikt');

  const msgRow = el('div', 'lc-limit-msg-row');
  const p = el('p', '', `Er staan al ${lim} apps open. Sluit 1 app of verhoog je limiet in Instellingen.`);
  const gear = el('button', 'lc-limit-gear');
  gear.type = 'button';
  gear.title = 'Instellingen openen';
  gear.setAttribute('aria-label', 'Instellingen — max. open apps');
  gear.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
  msgRow.append(p, gear);
  box.append(msgRow);

  const row = el('div', 'dlg-row');
  const ok = el('button', 'dlg-ok', 'OK');
  ok.type = 'button';
  row.append(ok);
  box.append(row);
  back.append(box);
  document.body.append(back);

  const close = () => { try { back.remove(); } catch (_) {} };
  ok.onclick = close;
  back.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  gear.onclick = () => {
    close();
    try {
      showSettingsForce();
      // Scroll naar Max. open apps na layout
      setTimeout(() => {
        const target = document.getElementById('settings-recent-apps-max');
        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'center' });
          target.classList.add('settings-highlight');
          setTimeout(() => target.classList.remove('settings-highlight'), 2200);
        }
      }, 80);
    } catch (_) {}
  };
  ok.focus();
}

/** Instellingen openen zonder limiet-check (via gear in limiet-popup). */
function showSettingsForce() {
  showSettings(true);
}

/**
 * Voegt een app toe aan recente apps (alleen als er ruimte is of hij al open stond).
 * @returns {boolean}
 */
function pushRecentApp(entry) {
  wireUiModules();
  const ok = recentApi.pushRecentApp(entry);
  // Direct na openen: app in de header (Windows-taakbalk)
  queueMicrotask(() => { try { renderHeaderOpenApps(); } catch (_) {} });
  try { renderHeaderOpenApps(); } catch (_) {}
  return ok;
}

function removeRecentApp(id) {
  wireUiModules();
  const r = recentApi.removeRecentApp(id);
  queueMicrotask(() => { try { renderHeaderOpenApps(); } catch (_) {} });
  try { renderHeaderOpenApps(); } catch (_) {}
  return r;
}

function isRecentActive(id) {
  wireUiModules();
  return recentApi.isRecentActive(id);
}

function clearSplitState() {
  wireUiModules();
  return miniApi.clearSplitState();
}

function closeSplitSide(side) {
  if (side === 'left') splitLeft = null;
  else splitRight = null;
  if (!splitLeft && !splitRight) {
    showHome();
    return;
  }
  // Eén app/picker over: full-screen opnieuw tekenen
  renderMiniAppView();
}

/** Mini-app-keuze in een leeg split-paneel. */
function createSplitPicker(excludeKind, targetSide) {
  const root = el('div', 'split-picker mini-app-root');
  root.append(el('p', 'split-picker-title', 'Kies een app'));
  root.append(el('p', 'split-picker-hint', 'Deze opent in dit venster naast de andere app.'));
  const grid = el('div', 'split-picker-grid');
  // Zelfde set als de header-tools die een app openen (niet: nieuw document/presentatie/rekenblad)
  const order = [
    'audio', 'video',
    'calendar', 'notes', 'budgetter', 'todo', 'timer', 'calculator', 'browser', 'bible', 'codex', 'xref-map', 'woordenboek',
    'memory', 'snake', 'bke', 'tetris', 'mastermind', 'connect4', 'speeltoestel', 'gallery', 'album', 'maps'
  ];
  for (const kind of order) {
    const card = el('button', 'split-picker-card');
    card.type = 'button';
    card.title = MINI_APP_TITLES[kind] || kind;
    const icWrap = el('span', 'split-picker-icon');
    const svg = miniAppIconSvg(kind);
    if (svg) icWrap.append(svg);
    else icWrap.textContent = '•';
    const lab = el('span', 'split-picker-label', MINI_APP_TITLES[kind] || kind);
    card.append(icWrap, lab);
    if (kind === excludeKind) {
      card.classList.add('is-current');
      card.title = (MINI_APP_TITLES[kind] || kind) + ' (nu open)';
    }
    card.onclick = () => {
      const open = () => {
        const slot = { kind, startPos: null };
        if (targetSide === 'left') splitLeft = slot;
        else splitRight = slot;
        renderMiniAppView();
      };
      if (kind === 'speeltoestel' || kind === 'video') {
        guardFocusBlock(kind === 'video' ? 'video' : kind, open)();
      } else {
        open();
      }
    };
    grid.append(card);
  }
  root.append(grid);
  return { root };
}

function mountMiniPane(paneEl, side, slot) {
  const head = el('div', 'view-head browser-head split-pane-head');
  const isPicker = slot.kind === '__picker__';
  const other = side === 'left' ? splitRight : splitLeft;
  const alone = !other;
  const both = !!(splitLeft && splitRight);
  const otherIsApp = other && other.kind !== '__picker__';
  const thisIsApp = !isPicker;

  // ← alleen pijl (geen "Terug"); × inzelfde stijl als wisselknop
  // Bij apps met handleBack: 1e klik = intern terug, 2e klik = startscherm
  if (alone) {
    const back = el('button', 'back split-back-btn', '←');
    back.type = 'button';
    back.title = 'Terug';
    back.setAttribute('aria-label', back.title);
    back.onclick = () => {
      const appInst = paneEl._miniAppInst;
      if (appInst && typeof appInst.handleBack === 'function' && appInst.handleBack()) {
        back.title = 'Terug naar start';
        back.setAttribute('aria-label', back.title);
        return;
      }
      showHome();
    };
    head.append(back);
  } else {
    const close = el('button', 'split-icon-btn', '×');
    close.type = 'button';
    close.title = 'Dit venster sluiten';
    close.setAttribute('aria-label', close.title);
    close.onclick = () => closeSplitSide(side);
    head.append(close);
  }

  // Splitscreen-knop direct ernaast (alleen bij één echte app, als feature aan staat)
  let allowSplit = true;
  try { allowSplit = loadSettings().splitScreen !== false; } catch (_) {}
  if (alone && thisIsApp && allowSplit) {
    const splitBtn = el('button', 'split-toggle-btn', '◫');
    splitBtn.type = 'button';
    splitBtn.title = 'Splitscreen — tweede app ernaast';
    splitBtn.setAttribute('aria-label', 'Splitscreen openen');
    splitBtn.onclick = () => {
      if (side === 'left' || !splitRight) {
        if (!splitLeft) splitLeft = slot;
        splitRight = { kind: '__picker__' };
      } else {
        splitLeft = { kind: '__picker__' };
        if (!splitRight) splitRight = slot;
      }
      renderMiniAppView();
    };
    head.append(splitBtn);
  }

  // In-app fullscreen (alleen UI — werkt ook samen met splitscreen)
  if (thisIsApp || isPicker) {
    const fsBtn = el('button', 'split-toggle-btn split-fs-btn', '⛶');
    fsBtn.type = 'button';
    const isFsOn = () => document.body.classList.contains('app-fullscreen');
    const syncFsLabel = () => {
      const on = isFsOn();
      fsBtn.classList.toggle('is-fs-active', on);
      fsBtn.title = on ? 'App-scherm verlaten' : 'App op volledig scherm';
      fsBtn.setAttribute('aria-label', fsBtn.title);
    };
    syncFsLabel();
    fsBtn.onclick = (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      const wantOn = !isFsOn();
      document.body.classList.toggle('app-fullscreen', wantOn);
      document.querySelectorAll('.gm-manager, .tg-app, .mem-app, .mini-app-root, .split-pane, .split-pane-single, .split-wrap')
        .forEach(n => n.classList.toggle('is-fs', wantOn));
      syncFsLabel();
    };
    head.append(fsBtn);
  }

  // Titel: klein, niet dominant
  if (!isPicker) {
    const title = el('h1', 'split-app-title', MINI_APP_TITLES[slot.kind] || 'App');
    head.append(title);
  } else {
    head.append(el('h1', 'split-app-title', 'Apps'));
  }

  // Wisselknop: precies één keer (alleen op het linkerpaneel)
  const actions = el('div', 'split-head-actions');
  if (both && side === 'left' && thisIsApp && otherIsApp) {
    const swap = el('button', 'split-icon-btn split-swap-btn', '⇄');
    swap.type = 'button';
    swap.title = 'Vensters wisselen';
    swap.setAttribute('aria-label', 'Vensters wisselen');
    swap.onclick = () => {
      const tmp = splitLeft;
      splitLeft = splitRight;
      splitRight = tmp;
      renderMiniAppView();
    };
    actions.append(swap);
  }
  if (actions.childNodes.length) head.append(actions);
  paneEl.append(head);

  if (isPicker) {
    const otherKind = other && other.kind !== '__picker__' ? other.kind : null;
    const picker = createSplitPicker(otherKind, side);
    paneEl.append(picker.root);
  } else {
    let app = null;
    try {
      app = createMiniAppInstance(slot.kind, slot.startPos);
    } catch (err) {
      console.error('Mini-app starten mislukt:', slot.kind, err);
      const errBox = el('div', 'mini-app-root');
      errBox.style.padding = '24px';
      errBox.append(el('p', '', 'Deze app kon niet worden geopend.'));
      errBox.append(el('p', 'settings-hint', String(err && err.message || err)));
      paneEl.append(errBox);
    }
    paneEl._miniAppInst = app || null;
    const appRoot = app && (app.root || (app.nodeType === 1 ? app : null));
    if (appRoot) {
      appRoot.classList.add('mini-app-root');
      paneEl.append(appRoot);
    } else if (!paneEl.querySelector('.mini-app-root')) {
      const empty = el('div', 'mini-app-root');
      empty.style.padding = '24px';
      empty.append(el('p', '', 'Onbekende of lege app — ga terug met ←'));
      paneEl.append(empty);
    }
    // Header-terugknop: bij apps met handleBack eerst intern, daarna start
    if (alone && app && typeof app.handleBack === 'function') {
      const backBtn = paneEl.querySelector('.split-back-btn');
      if (backBtn) {
        backBtn.title = 'Terug';
        backBtn.setAttribute('aria-label', 'Terug');
      }
    }
  }
}

function wireSplitDivider(divider, wrap) {
  let dragging = false;
  const onMove = (clientX) => {
    const rect = wrap.getBoundingClientRect();
    if (rect.width < 40) return;
    let r = (clientX - rect.left) / rect.width;
    r = Math.max(0.25, Math.min(0.75, r));
    splitRatio = r;
    wrap.style.setProperty('--split-ratio', (r * 100).toFixed(2) + '%');
  };
  const end = () => {
    if (!dragging) return;
    dragging = false;
    document.body.classList.remove('split-dragging');
    window.removeEventListener('pointermove', onPtr);
    window.removeEventListener('pointerup', end);
    window.removeEventListener('pointercancel', end);
  };
  const onPtr = (e) => { if (dragging) onMove(e.clientX); };
  divider.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    dragging = true;
    document.body.classList.add('split-dragging');
    window.addEventListener('pointermove', onPtr);
    window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', end);
  });
  // Toetsenbord: pijltjes
  divider.tabIndex = 0;
  divider.setAttribute('role', 'separator');
  divider.setAttribute('aria-orientation', 'vertical');
  divider.setAttribute('aria-valuenow', Math.round(splitRatio * 100));
  divider.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft') {
      splitRatio = Math.max(0.25, splitRatio - 0.05);
      wrap.style.setProperty('--split-ratio', (splitRatio * 100).toFixed(2) + '%');
      e.preventDefault();
    } else if (e.key === 'ArrowRight') {
      splitRatio = Math.min(0.75, splitRatio + 0.05);
      wrap.style.setProperty('--split-ratio', (splitRatio * 100).toFixed(2) + '%');
      e.preventDefault();
    }
  });
}

/** Tekent 1 of 2 mini-apps in #view-content. */
function renderMiniAppView() {
  wireUiModules();
  return miniApi.renderMiniAppView();
}

/**
 * Open een mini-app full-screen (vervangt de huidige weergave).
 * Splitscreen gebeurt alleen via de ◫-knop naast terug, niet via de werkbalk.
 */
function showMiniApp(kind, startPos) {
  wireUiModules();
  return miniApi.showMiniApp(kind, startPos);
}


/** Woordstudie → woordenboek oorspronkelijke talen */
window.addEventListener('lc-open-woordenboek-origineel', (e) => {
  const q = (e.detail && e.detail.query) || '';
  try { sessionStorage.setItem('lc-wb-origineel-q', q); } catch (_) {}
  showMiniApp('woordenboek');
});

/** Klik op een vers in de Bijbel → splitscreen met Verdieping-app. */
window.addEventListener('lc-open-verse-study', (e) => {
  const d = e.detail || {};
  const biblePos = Object.assign({}, d.biblePos || {
    osis: d.osis,
    chapter: d.chapter,
    from: d.verse,
    to: d.verse,
  }, { q: null }); // nooit zoekmarkering bij verdieping openen
  splitLeft = { kind: 'bible', startPos: biblePos };
  splitRight = {
    kind: 'verse-study',
    startPos: {
      osis: d.osis,
      chapter: d.chapter,
      verse: d.verse,
      bookNl: d.bookNl,
    },
  };
  renderMiniAppView();
});

/** Kruisverwijzing in Verdieping → navigeer de Bijbel (herlaad links). */
window.addEventListener('lc-bible-navigate', (e) => {
  const osis = e.detail && e.detail.osis;
  if (!osis) return;
  const parts = String(osis).split('.');
  if (parts.length < 2) return;
  const bookOsis = parts[0];
  const chapter = parseInt(parts[1], 10) || 1;
  const verse = parts[2] ? parseInt(parts[2], 10) : null;
  const biblePos = {
    osis: bookOsis,
    chapter,
    from: verse || undefined,
    to: verse || undefined,
    q: null,
  };
  // Links blijft Bijbel, rechts blijft Verdieping (desnoods bijwerken)
  if (!splitLeft || splitLeft.kind !== 'bible') {
    splitLeft = { kind: 'bible', startPos: biblePos };
  } else {
    splitLeft = { kind: 'bible', startPos: biblePos };
  }
  if (splitRight && splitRight.kind === 'verse-study' && verse) {
    splitRight = {
      kind: 'verse-study',
      startPos: {
        osis: bookOsis,
        chapter,
        verse,
        bookNl: bookOsis,
      },
    };
  }
  renderMiniAppView();
});

// Audio- en videospeler (src/media/player.js). Vult het scherm zoals de browser.
// Audio: bij wegnavigeren blijft de muziek op de achtergrond spelen (mini-controls in de header).
// Video: stopt en ruimt zichzelf op.
function showMediaPlayer(kind) {
  // Zelfde kader als andere mini-apps: ← terug + ◫ splitscreen
  try { bgStop(); } catch (_) {}
  showMiniApp(kind === 'video' ? 'video' : 'audio');
}

function showInAppBrowser(startUrl) {
  clearSplitState();
  let url = (startUrl || 'https://').trim();
  // Opschonen: per ongeluk geplakte quotes/apostrofs
  url = url.replace(/^['"]+|['"]+$/g, '');
  if (url && !/^https?:\/\//i.test(url) && !url.startsWith('mailto:') && !url.startsWith('about:')) {
    // Geen protocol: als het op een domein lijkt → https, anders → zoeken
    if (/^(localhost|(\d{1,3}\.){3}\d{1,3}|[a-z0-9-]+(\.[a-z0-9-]+)+)([/:].*)?$/i.test(url)) {
      url = 'https://' + url;
    } else if (url && url !== 'https://') {
      url = 'https://duckduckgo.com/?q=' + encodeURIComponent(url);
    }
  }

  currentSection = null;
  document.body.classList.remove('pdf-open');
  document.body.classList.remove('browser-open');
  document.body.classList.add('browser-open');
  viewContent.replaceChildren();

  const head = el('div', 'view-head browser-head');
  const back = el('button', 'back', '← Terug');
  back.type = 'button';
  back.onclick = showHome;
  head.append(back, el('h1', '', 'Browser'));

  const bar = el('div', 'browser-bar');
  const btnBack = el('button', 'browser-nav', '←');
  btnBack.type = 'button';
  btnBack.title = 'Vorige';
  const btnFwd = el('button', 'browser-nav', '→');
  btnFwd.type = 'button';
  btnFwd.title = 'Volgende';
  const btnReload = el('button', 'browser-nav', '↻');
  btnReload.type = 'button';
  btnReload.title = 'Vernieuwen';

  const input = document.createElement('input');
  input.type = 'search';
  input.className = 'browser-url';
  input.value = url;
  input.setAttribute('aria-label', 'Adres of zoekopdracht');
  input.placeholder = 'Zoek of typ een adres…';

  const btnGo = el('button', 'browser-go', '');
  btnGo.type = 'button';
  btnGo.title = 'Zoeken';
  btnGo.setAttribute('aria-label', 'Zoeken');
  btnGo.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>';

  const btnExt = el('button', 'browser-ext', 'Extern');
  btnExt.type = 'button';
  btnExt.title = 'Open in systeembrowser';

  bar.append(btnBack, btnFwd, btnReload, input, btnGo, btnExt);

  // Eén lichte hint, zonder extra knop (Extern staat al in de balk)
  const hint = el('p', 'browser-hint');
  hint.textContent = 'Laadt de pagina niet in de app? Klik op Extern om hem in je gewone browser te openen.';

  const frameWrap = el('div', 'browser-frame-wrap');
  const frame = document.createElement('iframe');
  frame.className = 'browser-frame';
  frame.setAttribute('title', 'Webpagina');
  frame.setAttribute('referrerpolicy', 'no-referrer-when-downgrade');
  frame.setAttribute('allow', 'fullscreen; clipboard-read; clipboard-write');
  frame.src = url;
  frameWrap.appendChild(frame);

  /** Zet invoer om naar URL: adres, of zoekopdracht via DuckDuckGo. */
  const toUrl = (raw) => {
    let next = (raw || '').trim().replace(/^['"]+|['"]+$/g, '');
    if (!next) return '';
    if (/^https?:\/\//i.test(next) || next.startsWith('mailto:') || next.startsWith('about:')) return next;
    // Domein-achtig (voorbeeld.nl, localhost, IP)
    if (/^(localhost|(\d{1,3}\.){3}\d{1,3}|[a-z0-9-]+(\.[a-z0-9-]+)+)([/:].*)?$/i.test(next)) {
      return 'https://' + next;
    }
    // Anders: zoeken
    return 'https://duckduckgo.com/?q=' + encodeURIComponent(next);
  };

  const navigate = (u) => {
    const next = toUrl(u !== undefined ? u : input.value);
    if (!next) return;
    input.value = next;
    frame.src = next;
    setHash('#browser');
  };

  btnGo.onclick = () => navigate(input.value);
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); navigate(input.value); }
  });
  btnReload.onclick = () => {
    try { frame.contentWindow.location.reload(); }
    catch (err) { navigate(input.value); }
  };
  btnBack.onclick = () => { try { frame.contentWindow.history.back(); } catch (err) { /* cross-origin */ } };
  btnFwd.onclick = () => { try { frame.contentWindow.history.forward(); } catch (err) { /* cross-origin */ } };
  btnExt.onclick = () => openInSystemBrowser(toUrl(input.value) || url);

  viewContent.append(head, bar, hint, frameWrap);
  home.style.display = 'none';
  view.style.display = 'block';
  setHash('#browser');
  window.scrollTo(0, 0);
  input.focus();
  input.select();
}

/** Zoek anker in document zonder CSS.escape (bredere webview-ondersteuning). */
function findAnchorIn(root, id) {
  if (!id) return null;
  try {
    if (root.querySelector) {
      const byAttr = root.querySelector('[id="' + id.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"]');
      if (byAttr) return byAttr;
    }
  } catch (e) { /* ignore */ }
  return document.getElementById(id);
}

/**
 * Links in boektekst:
 * - #boek-id → ander boek
 * - #anker → scroll in pagina
 * - http(s)/mailto → extern (Ctrl/Cmd-klik of gewone klik)
 */
function wireBookLinks(root) {
  if (!root || root._lcLinksWired) return;
  root._lcLinksWired = true;

  const onActivate = async (e) => {
    // Alleen primaire knop, of middle-click, of Ctrl/Cmd-klik
    if (e.type === 'click' && e.button != null && e.button !== 0 && e.button !== 1) return;

    const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a || !root.contains(a)) return;

    const href = (a.getAttribute('href') || '').trim();
    if (!href || href === '#') {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    // javascript:void op zoekresultaten: laat de eigen onclick door
    if (href.toLowerCase().startsWith('javascript:')) {
      if (a.classList.contains('gs-result') || a.closest('.gs-results, .gs-suggest')) return;
      e.preventDefault();
      e.stopPropagation();
      return;
    }

    const mod = e.ctrlKey || e.metaKey || e.shiftKey || e.button === 1;

    // Externe links (altijd, ook Ctrl-klik)
    if (/^https?:\/\//i.test(href) || href.startsWith('mailto:') || href.startsWith('//')) {
      e.preventDefault();
      e.stopPropagation();
      const url = href.startsWith('//') ? ('https:' + href) : href;
      await openExternalUrl(url);
      return;
    }

    // Interne hash
    if (href.startsWith('#')) {
      e.preventDefault();
      e.stopPropagation();
      const target = decodeURIComponent(href.slice(1).split('?')[0]);
      if (!target) return;

      const isBook = allItems().some(i => i.id === target);
      if (isBook) {
        // Ctrl/Cmd-klik: zelfde app, wel naar dat boek (SPA heeft geen tweede venster)
        await showSection(target);
        return;
      }

      const elInPage = findAnchorIn(root, target);
      if (elInPage) {
        elInPage.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }

      try {
        const book = await loadBook(target);
        if (book) {
          await showSection(target);
          return;
        }
      } catch (err) { /* ignore */ }

      console.warn('Link niet gevonden:', href);
      return;
    }

    // Relatief pad (bv. stad/kerk/foo.html) — probeer id uit pad
    e.preventDefault();
    e.stopPropagation();
    const m = href.match(/(?:(?:books|stad\/[^/]+)\/)?([a-z0-9-]+)\.html?$/i);
    if (m) {
      const id = m[1];
      if (allItems().some(i => i.id === id) || await loadBook(id).catch(() => null)) {
        await showSection(id);
        return;
      }
    }
    // Ctrl-klik op onbekende link: probeer als URL
    if (mod) await openExternalUrl(href);
    else console.warn('Niet-ondersteunde link in document:', href);
  };

  // Capture-fase: vóór andere handlers; werkt ook als bubblen geblokkeerd is
  root.addEventListener('click', onActivate, true);
  root.addEventListener('auxclick', onActivate, true);
}

/**
 * Eén globale link-handler (document, capture).
 * Werkt onafhankelijk van wireBookLinks op .book — dekt alle gevallen.
 * Focusmodus blokkeert dit niet.
 */
function wireGlobalBookLinks() {
  if (window._lcGlobalLinksWired) return;
  window._lcGlobalLinksWired = true;

  const notifyMissing = (label) => {
    try {
      ask('Deze link leidt nergens naartoe.\n\nDoel: ' + label + '\n\nHet boek of anker bestaat niet (of heeft een andere id).', { yes: 'OK' });
    } catch (err) {
      console.warn('Link niet gevonden:', label);
    }
  };

  const resolveBookId = (target) => {
    const items = allItems();
    if (items.some(i => i.id === target)) return target;
    const lower = String(target).toLowerCase();
    const byId = items.find(i => i.id.toLowerCase() === lower);
    if (byId) return byId.id;
    const byTitle = items.find(i => (i.title || '').toLowerCase() === lower);
    if (byTitle) return byTitle.id;
    const partial = items.filter(i =>
      i.id.includes(lower) || (i.title || '').toLowerCase().includes(lower)
    );
    if (partial.length === 1) return partial[0].id;
    return null;
  };

  const handle = async (e) => {
    const a = e.target && e.target.closest
      ? e.target.closest('#view-content a[href], .book a[href], #view a[href]')
      : null;
    if (!a) return;
    if (a.closest('.wysiwyg, [contenteditable="true"], .editor-bar')) return;

    const href = (a.getAttribute('href') || '').trim();
    if (!href || href === '#') {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    // javascript:void op zoekresultaten: laat de eigen onclick door
    if (href.toLowerCase().startsWith('javascript:')) {
      if (a.classList.contains('gs-result') || a.closest('.gs-results, .gs-suggest')) return;
      e.preventDefault();
      e.stopPropagation();
      return;
    }

    if (/^https?:\/\//i.test(href) || href.startsWith('mailto:') || href.startsWith('//')) {
      e.preventDefault();
      e.stopPropagation();
      const url = href.startsWith('//') ? ('https:' + href) : href;
      // Ctrl/Cmd/Shift of middelklik → systeembrowser; anders in-app browser
      const system = !!(e.ctrlKey || e.metaKey || e.shiftKey || e.button === 1);
      await openExternalUrl(url, { system });
      return;
    }

    // Zoekresultaten hebben eigen handler — niet als boeklink behandelen
    if (a.classList.contains('gs-result') || a.closest('.gs-results, .gs-suggest')) {
      return;
    }

    if (href.startsWith('#')) {
      e.preventDefault();
      e.stopPropagation();
      let target = href.slice(1);
      try { target = decodeURIComponent(target.split('?')[0]); } catch (err) { target = target.split('?')[0]; }
      if (!target) return;

      // App-routes (zoek, bible, …) niet als boek-id interpreteren
      const APP_HASHES = new Set(['zoek', 'search', 'bible', 'bijbel', 'codex', 'woordenboek', 'settings', 'instellingen', 'focus', 'studie', 'audio', 'video', 'calendar', 'notes', 'budgetter', 'todo', 'timer', 'calculator', 'memory', 'snake', 'bke', 'tetris', 'mastermind', 'connect4', 'speeltoestel', 'gallery', 'album', 'maps', 'browser']);
      if (APP_HASHES.has(target.toLowerCase())) {
        route(target);
        return;
      }

      const bookRoot = a.closest('.book') || document.getElementById('view-content');
      const elInPage = findAnchorIn(bookRoot || document, target);
      // Alleen exacte id/titel, geen vage partial match op korte woorden
      const items = allItems();
      let bookId = null;
      if (items.some(i => i.id === target)) bookId = target;
      else {
        const lower = target.toLowerCase();
        const byId = items.find(i => i.id.toLowerCase() === lower);
        if (byId) bookId = byId.id;
        else {
          const byTitle = items.find(i => (i.title || '').toLowerCase() === lower);
          if (byTitle) bookId = byTitle.id;
        }
      }

      if (bookId) {
        await showSection(bookId);
        return;
      }
      if (elInPage) {
        elInPage.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      try {
        const book = await loadBook(target);
        if (book) {
          await showSection(target);
          return;
        }
      } catch (err) { /* ignore */ }

      notifyMissing('#' + target);
      return;
    }

    const m = href.match(/(?:(?:books|stad\/[^/]+)\/)?([a-z0-9-]+)\.html?$/i);
    if (m) {
      e.preventDefault();
      e.stopPropagation();
      const id = resolveBookId(m[1]) || m[1];
      if (allItems().some(i => i.id === id) || await loadBook(id).catch(() => null)) {
        await showSection(id);
        return;
      }
      notifyMissing(href);
    }
  };

  document.addEventListener('click', handle, true);
  document.addEventListener('auxclick', handle, true);
}

// Editor voor één boek (alleen in editor-modus): gewoon schrijven (mini-Word) of de HTML bekijken.
async function startEdit(id) {
  document.body.classList.remove('pdf-open');
  document.body.classList.remove('browser-open');
  const it = allItems().find(i => i.id === id);
  const d = (await withLoading(() => loadBook(id), 'Editor openen…')) || { title: it ? it.title : id, html: '', ref: emptyRef() };
  const type = (it && it.type) || detectType(d.html) || 'doc';
  currentSection = id;
  viewContent.replaceChildren();
  const head = el('div', 'view-head');
  const cancel = el('button', 'back', '← Annuleren');
  cancel.onclick = () => showSection(id);
  const ti = el('input', 'title-edit'); ti.value = (it && it.title) || d.title; ti.setAttribute('aria-label', 'Titel van het boek');
  head.append(cancel, ti);

  const saveCommon = async (getHtml) => {
    const title = ti.value.trim() || d.title;
    if (it) it.title = title;
    try { await persist(); await saveBook(id, title, getHtml()); }
    catch (e) { await ask('Opslaan mislukt: ' + e, { yes: 'OK' }); return; }
    renderWorld(); showSection(id);
  };

  if (type === 'pdf') {
    const ed = createPdfEditor(d.html, { ask });
    const saveBtn = el('button', 'save', 'Opslaan');
    saveBtn.type = 'button';
    saveBtn.onclick = () => saveCommon(() => ed.getHtml());
    head.append(saveBtn);
    viewContent.append(head, ed.area);
    home.style.display = 'none'; view.style.display = 'block';
    ed.focus();
    return;
  }

  if (type === 'pptx') {
    const ed = createSlidesEditor(d.html, { ask });
    const saveBtn = el('button', 'save', 'Opslaan');
    saveBtn.type = 'button';
    saveBtn.onclick = () => saveCommon(() => ed.getHtml());
    const top = el('div', 'editor-ribbon');
    head.classList.add('editor-title-row');
    top.append(head, ed.bar);
    viewContent.append(top, ed.area);
    // save on bar
    const sb = document.createElement('button');
    sb.className = 'save'; sb.type = 'button'; sb.textContent = 'Opslaan';
    sb.onclick = () => saveCommon(() => ed.getHtml());
    ed.bar.append(sb);
    home.style.display = 'none'; view.style.display = 'block';
    ed.focus();
    return;
  }

  if (type === 'xlsx') {
    const ed = createSheetEditor(d.html, { ask });
    head.classList.add('editor-title-row');
    const top = el('div', 'editor-ribbon');
    top.append(head, ed.bar);
    const sb = document.createElement('button');
    sb.className = 'save'; sb.type = 'button'; sb.textContent = 'Opslaan';
    sb.onclick = () => saveCommon(() => ed.getHtml());
    ed.bar.append(sb);
    viewContent.append(top, ed.area);
    home.style.display = 'none'; view.style.display = 'block';
    ed.focus();
    return;
  }

  // Document (Word-editor)
  const ed = createEditor(d.html, { ask });
  if (ed.setTitle) ed.setTitle(ti.value || d.title || id);
  ti.addEventListener('input', () => { if (ed.setTitle) ed.setTitle(ti.value || d.title || id); });
  ed.addTool('Kopieer', 'Kopieer de HTML (om in een AI te plakken)', async () => {
    try { await navigator.clipboard.writeText(ed.getHtml().replace(/src="data:image[^"]+"/g, 'src="afbeelding"')); ed.flash("Gekopieerd (fotos ingekort)"); } catch (e) { ed.flash("Kopieren mislukt"); }
  }, { htmlOnly: true });
  ed.addTool('⬇ .html', 'Dit boek downloaden als los HTML-bestand', () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([bookDocument(ti.value || d.title, ed.getHtml(), getRef(id, d))], { type: 'text/html' }));
    a.download = id + '.html'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }, { htmlOnly: true });
  const file = document.createElement('input'); file.type = 'file'; file.accept = '.html,.htm,text/html'; file.hidden = true;
  file.onchange = async () => {
    const f = file.files[0]; if (!f) return;
    const doc = new DOMParser().parseFromString(await f.text(), 'text/html');
    ed.setHtml((doc.querySelector('main') || doc.body).innerHTML.trim());
    if (doc.title) ti.value = doc.title;
    ed.flash('Bestand ingelezen — klik op Opslaan'); file.value = '';
  };
  ed.addTool('⬆ Inlezen', 'HTML-bestand inlezen (bv. na bewerking met AI)', () => file.click(), { htmlOnly: true });
  ed.addTool('Opslaan', 'Opslaan', async () => {
    await saveCommon(() => ed.getHtml());
  }, { cls: 'save', last: true });

  head.classList.add('editor-title-row');
  ed.bar.prepend(head);
  viewContent.append(ed.bar, ed.spacer || document.createComment(''), ed.area, file);
  home.style.display = 'none'; view.style.display = 'block';
  window.scrollTo(0, 0); ed.focus();
  if (ed.syncRibbonH) requestAnimationFrame(() => ed.syncRibbonH());
}

// Instellingen: volledig scherm met terug-pijl linksboven.
function showSettings(force) {
  wireUiModules();
  return settingsApi.showSettings(force);
}


function wireSettings() {
  const btn = $('#btn-settings');
  if (!btn) return;
  btn.onclick = e => {
    e.stopPropagation();
    showSettings();
  };
}


// ===== Zoeken / mini-apps / focus: via ui-modules (fase 2) =====
function showResults(q = '') {
  wireUiModules();
  return searchApi.showResults(q);
}
function openSearchResult(g, q) {
  wireUiModules();
  return searchApi.openSearchResult(g, q);
}
function showSearchHistoryPanel(opts) {
  wireUiModules();
  return searchApi.showSearchHistoryPanel(opts);
}


/** Developer performance floating window (5× snel klikken op Leo Crucis-logo). */
let _devPerfClicks = [];
let _devPerfTimer = null;
let _devPerfLagTimer = null;
const DEV_PERF_CLICKS = 5;
const DEV_PERF_WINDOW_MS = 2500;
/** Auteursmodus (werkproject): 5× logo → teksten ter plaatse bewerkbaar. */
let authorMode = false;

function isAuthorMode() { return !!authorMode; }

function setAuthorMode(on) {
  authorMode = !!on;
  document.body.classList.toggle('author-mode', authorMode);
  try {
    const brand = document.getElementById('brand') || document.querySelector('#brand');
    if (brand) {
      brand.title = authorMode
        ? 'Auteursmodus AAN · 5× opnieuw: uit · 1×: start'
        : 'Naar startpagina · 5× snel: auteursmodus (teksten bewerken)';
    }
  } catch (_) {}
  // Toon korte status in header of toast
  try {
    let toast = document.getElementById('lc-author-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'lc-author-toast';
      toast.className = 'lc-author-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = authorMode
      ? 'Auteursmodus aan — klik op titels en teksten om te bewerken'
      : 'Auteursmodus uit';
    toast.classList.add('is-visible');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.classList.remove('is-visible'), 2800);
  } catch (_) {}
  // Huidige weergave vernieuwen zodat labels → inputs wisselen
  try {
    const view = document.getElementById('view-content') || document.querySelector('#view-content');
    // Als startscherm zichtbaar is: herteken
    if (typeof showHome === 'function') {
      const home = document.querySelector('.bld-carousel, .home-view, .city-home');
      if (home || !document.querySelector('.mini-app-root')) showHome();
    }
  } catch (_) {}
  try { if (typeof renderWorld === 'function') renderWorld(); } catch (_) {}
}

/** Maak een tekstnode ter plaatse bewerkbaar in auteursmodus. */
function makeInlineEditable(el, getValue, setValue, opts) {
  opts = opts || {};
  if (!authorMode) return el;
  el.classList.add('is-inline-editable');
  el.contentEditable = 'true';
  el.spellcheck = true;
  el.setAttribute('role', 'textbox');
  el.title = (opts.title || 'Klik om te bewerken') + ' (auteursmodus)';
  const stop = (e) => { e.stopPropagation(); };
  el.addEventListener('click', stop);
  el.addEventListener('pointerdown', stop);
  el.addEventListener('mousedown', stop);
  el.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !opts.multiline) {
      e.preventDefault();
      el.blur();
    }
    e.stopPropagation();
  });
  el.addEventListener('blur', async () => {
    const raw = (el.textContent || '').trim();
    const prev = (getValue() || '').trim();
    if (raw === prev) return;
    try {
      await setValue(raw);
      await saveWorld(world);
      el.classList.add('is-saved');
      setTimeout(() => el.classList.remove('is-saved'), 800);
    } catch (err) {
      console.warn('Inline save failed', err);
      el.textContent = prev;
    }
  });
  return el;
}
/** Ringbuffers voor grafieken (~90 s bij 250 ms sample). */
const DEV_HIST_MAX = 360;
const _devHist = { t: [], fps: [], heap: [], nodes: [], lag: [] };
let _devLagMs = 0;
let _devLongTasks = [];
let _devErrors = [];
let _devObsReady = false;
let _devLongTaskObs = null;

function drawDevChart(canvas, series, opts) {
  const o = opts || {};
  const dpr = window.devicePixelRatio || 1;
  const w = Math.max(120, canvas.clientWidth || 300);
  const h = Math.max(48, canvas.clientHeight || 72);
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  const data = series.filter(v => Number.isFinite(v));
  if (data.length < 2) {
    ctx.fillStyle = 'rgba(106,94,82,0.45)';
    ctx.font = '11px system-ui,sans-serif';
    ctx.fillText('Wachten op samples…', 8, h / 2 + 4);
    return;
  }
  const dataMin = Math.min(...data);
  const dataMax = Math.max(...data);
  let min = o.min != null ? o.min : 0;
  let max = Math.max(dataMax, o.floorMax != null ? o.floorMax : 0, min + 1);
  max = max * 1.06;
  const yAt = (v) => {
    const tt = (v - min) / (max - min);
    return Math.max(1, Math.min(h - 2, h - 1 - tt * (h - 2)));
  };
  ctx.strokeStyle = 'rgba(106,94,82,0.15)';
  ctx.lineWidth = 1;
  for (let i = 0; i <= 3; i++) {
    const y = (h - 1) * (i / 3);
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }
  const color = o.color || '#7a1f2b';
  let fillR = 122, fillG = 31, fillB = 43;
  if (color.startsWith('#') && color.length >= 7) {
    fillR = parseInt(color.slice(1, 3), 16);
    fillG = parseInt(color.slice(3, 5), 16);
    fillB = parseInt(color.slice(5, 7), 16);
  }
  ctx.beginPath();
  for (let i = 0; i < data.length; i++) {
    const x = (i / (data.length - 1)) * (w - 1);
    const y = yAt(data[i]);
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.lineTo(w - 1, h); ctx.lineTo(0, h); ctx.closePath();
  ctx.fillStyle = `rgba(${fillR},${fillG},${fillB},0.16)`;
  ctx.fill();
  ctx.beginPath();
  for (let i = 0; i < data.length; i++) {
    const x = (i / (data.length - 1)) * (w - 1);
    const y = yAt(data[i]);
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.stroke();
  ctx.fillStyle = 'rgba(106,94,82,0.75)';
  ctx.font = '10px system-ui,sans-serif';
  const fmt = o.fmt || (v => String(Math.round(v)));
  ctx.fillText(fmt(dataMax), 4, 11);
  ctx.fillText(fmt(min <= 0 ? 0 : min), 4, h - 4);
}

function collectDevPerfSnapshot() {
  const mem = (performance && performance.memory) ? performance.memory : null;
  const nav = (performance && performance.getEntriesByType)
    ? performance.getEntriesByType('navigation')[0]
    : null;
  let lsBytes = 0;
  const lsKeys = [];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      const v = String(localStorage.getItem(k) || '');
      const n = (k ? k.length : 0) + v.length;
      lsBytes += n;
      lsKeys.push({ k: k || '?', n });
    }
  } catch (_) {}
  lsKeys.sort((a, b) => b.n - a.n);
  let st = {};
  try { st = loadSettings() || {}; } catch (_) {}
  const nodes = document.getElementsByTagName('*').length;
  let cache = { indexLoaded: false, indexDocs: 0, bijbelIndex: false, bijbelVerses: 0, wbIndex: false };
  try { if (typeof getSearchCacheStats === 'function') cache = getSearchCacheStats(); } catch (_) {}

  // Resource timing (recente fetches)
  let resCount = 0, resTransfer = 0, resSlow = 0;
  try {
    const res = performance.getEntriesByType('resource') || [];
    resCount = res.length;
    for (const r of res) {
      resTransfer += r.transferSize || 0;
      if ((r.duration || 0) > 200) resSlow++;
    }
  } catch (_) {}

  // Paint timing
  let fcp = null, lcp = null;
  try {
    for (const p of performance.getEntriesByType('paint') || []) {
      if (p.name === 'first-contentful-paint') fcp = Math.round(p.startTime);
    }
  } catch (_) {}

  const imgs = document.images ? document.images.length : 0;
  const media = document.querySelectorAll('audio, video, iframe').length;
  const listenersApprox = document.querySelectorAll('[onclick], button, a, input').length;

  return {
    fps: (typeof getFps === 'function') ? getFps() : 0,
    throttling: (typeof isThrottling === 'function') ? isThrottling() : false,
    heapUsed: mem ? mem.usedJSHeapSize : null,
    heapTotal: mem ? mem.totalJSHeapSize : null,
    heapLimit: mem ? mem.jsHeapSizeLimit : null,
    nodes,
    scripts: document.scripts.length,
    styles: document.styleSheets.length,
    lsKB: Math.round(lsBytes / 1024),
    lsTop: lsKeys.slice(0, 6),
    searchTabs: (typeof searchTabs !== 'undefined' && searchTabs.list) ? searchTabs.list.length : 0,
    studyActive: !!(typeof studyBlock !== 'undefined' && studyBlock.active),
    studyRem: (typeof studyBlock !== 'undefined' && studyBlock.active) ? studyBlock.remainingMs : null,
    loadPower: st.loadPower || 'normal',
    maxFps: st.maxFps || 0,
    loadThrottle: st.loadThrottle !== false,
    reduceMotion: !!st.reduceMotion,
    navDomMs: nav ? Math.round(nav.domContentLoadedEventEnd || 0) : null,
    navLoadMs: nav ? Math.round(nav.loadEventEnd || 0) : null,
    path: (location.hash || '#') + '',
    dpr: window.devicePixelRatio || 1,
    vw: window.innerWidth,
    vh: window.innerHeight,
    lag: _devLagMs,
    cache,
    resCount,
    resTransfer,
    resSlow,
    fcp,
    imgs,
    media,
    listenersApprox,
    online: navigator.onLine !== false,
    hidden: !!document.hidden,
    bodyClasses: (document.body && document.body.className) ? String(document.body.className).split(/\s+/).filter(Boolean).slice(0, 12).join(', ') : '',
    split: !!(typeof splitLeft !== 'undefined' && (splitLeft || splitRight)),
    longTasks: _devLongTasks.length,
    longTaskMax: _devLongTasks.length ? Math.max(..._devLongTasks.map(x => x.d)) : 0,
    errors: _devErrors.slice(-5),
    errorCount: _devErrors.length,
    uptimeMs: Math.round(performance.now()),
  };
}

function pushDevHist(s) {
  const now = Date.now();
  _devHist.t.push(now);
  _devHist.fps.push(s.fps || 0);
  _devHist.heap.push(s.heapUsed != null ? s.heapUsed : 0);
  _devHist.nodes.push(s.nodes || 0);
  _devHist.lag.push(s.lag || 0);
  while (_devHist.t.length > DEV_HIST_MAX) {
    _devHist.t.shift();
    _devHist.fps.shift();
    _devHist.heap.shift();
    _devHist.nodes.shift();
    _devHist.lag.shift();
  }
}

function fmtBytes(n) {
  if (n == null || !Number.isFinite(n)) return '—';
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}

function fmtDur(ms) {
  if (ms == null || !Number.isFinite(ms)) return '—';
  if (ms < 1000) return Math.round(ms) + ' ms';
  const s = Math.floor(ms / 1000);
  if (s < 60) return s + ' s';
  const m = Math.floor(s / 60), r = s % 60;
  return m + 'm ' + r + 's';
}

function ensureDevObservers() {
  if (_devObsReady) return;
  _devObsReady = true;
  try {
    if (typeof PerformanceObserver !== 'undefined') {
      const po = new PerformanceObserver((list) => {
        for (const e of list.getEntries()) {
          _devLongTasks.push({ t: Date.now(), d: Math.round(e.duration || 0) });
          if (_devLongTasks.length > 40) _devLongTasks.shift();
        }
      });
      po.observe({ entryTypes: ['longtask'] });
      _devLongTaskObs = po;
    }
  } catch (_) {}
  try {
    window.addEventListener('error', (ev) => {
      _devErrors.push({ t: Date.now(), msg: String((ev && ev.message) || 'error').slice(0, 120) });
      if (_devErrors.length > 30) _devErrors.shift();
    });
    window.addEventListener('unhandledrejection', (ev) => {
      const m = (ev && ev.reason && (ev.reason.message || ev.reason)) || 'rejection';
      _devErrors.push({ t: Date.now(), msg: String(m).slice(0, 120) });
      if (_devErrors.length > 30) _devErrors.shift();
    });
  } catch (_) {}
}

function closeDevPerfPanel() {
  if (_devPerfTimer) { clearInterval(_devPerfTimer); _devPerfTimer = null; }
  if (_devPerfLagTimer) { clearInterval(_devPerfLagTimer); _devPerfLagTimer = null; }
  const w = document.getElementById('dev-perf-win');
  if (w) w.remove();
}

function openDevPerfPanel() {
  closeDevPerfPanel();
  try { startFpsMonitor(); } catch (_) {}
  ensureDevObservers();

  const win = el('div', 'dev-perf-win');
  win.id = 'dev-perf-win';
  win.setAttribute('role', 'dialog');
  win.setAttribute('aria-label', 'Developer prestaties');

  const head = el('div', 'dev-perf-head');
  head.append(el('span', 'dev-perf-title', 'Developer · prestaties'));
  const headBtns = el('div', 'dev-perf-head-btns');
  const minimize = el('button', 'dev-perf-min', '−');
  minimize.type = 'button';
  minimize.title = 'Minimaliseren';
  minimize.setAttribute('aria-label', 'Minimaliseren');
  const close = el('button', 'dev-perf-close', '×');
  close.type = 'button';
  close.title = 'Sluiten';
  close.setAttribute('aria-label', 'Sluiten');
  close.onclick = () => closeDevPerfPanel();
  minimize.onclick = (e) => {
    e.stopPropagation();
    const collapsed = win.classList.toggle('is-minimized');
    minimize.textContent = collapsed ? '+' : '−';
    minimize.title = collapsed ? 'Uitklappen' : 'Minimaliseren';
    minimize.setAttribute('aria-label', collapsed ? 'Uitklappen' : 'Minimaliseren');
  };
  headBtns.append(minimize, close);
  head.append(headBtns);
  win.append(head);

  const body = el('div', 'dev-perf-body');
  win.append(body);
  document.body.append(win);

  let drag = null;
  head.addEventListener('pointerdown', e => {
    if (e.button !== 0 || e.target.closest('button')) return;
    head.setPointerCapture(e.pointerId);
    const r = win.getBoundingClientRect();
    drag = { x: e.clientX - r.left, y: e.clientY - r.top };
    win.classList.add('is-dragging');
  });
  head.addEventListener('pointermove', e => {
    if (!drag) return;
    const x = Math.max(0, Math.min(window.innerWidth - 80, e.clientX - drag.x));
    const y = Math.max(0, Math.min(window.innerHeight - 40, e.clientY - drag.y));
    win.style.left = x + 'px';
    win.style.top = y + 'px';
    win.style.right = 'auto';
    win.style.bottom = 'auto';
  });
  head.addEventListener('pointerup', () => {
    drag = null;
    win.classList.remove('is-dragging');
  });

  // Formaat wijzigen: sleep aan linker-/rechterrand (en onderkant)
  const MIN_W = 280, MAX_W = () => Math.min(900, window.innerWidth - 16);
  const MIN_H = 220, MAX_H = () => Math.min(window.innerHeight - 16, 900);
  function wireResize(edge) {
    const handle = el('div', 'dev-perf-resize dev-perf-resize-' + edge);
    handle.title = edge === 'b' ? 'Hoogte aanpassen' : 'Breedte aanpassen';
    win.append(handle);
    let rs = null;
    handle.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation();
      handle.setPointerCapture(e.pointerId);
      const r = win.getBoundingClientRect();
      rs = { edge, x: e.clientX, y: e.clientY, w: r.width, h: r.height, l: r.left, t: r.top };
      win.classList.add('is-resizing');
    });
    handle.addEventListener('pointermove', e => {
      if (!rs) return;
      let w = rs.w, h = rs.h, l = rs.l, top = rs.t;
      if (rs.edge === 'r') {
        w = Math.max(MIN_W, Math.min(MAX_W(), rs.w + (e.clientX - rs.x)));
      } else if (rs.edge === 'l') {
        const nw = Math.max(MIN_W, Math.min(MAX_W(), rs.w - (e.clientX - rs.x)));
        l = rs.l + (rs.w - nw);
        w = nw;
      } else if (rs.edge === 'b') {
        h = Math.max(MIN_H, Math.min(MAX_H(), rs.h + (e.clientY - rs.y)));
      }
      win.style.width = Math.round(w) + 'px';
      win.style.height = Math.round(h) + 'px';
      win.style.maxHeight = 'none';
      win.style.left = Math.round(l) + 'px';
      win.style.top = Math.round(top) + 'px';
      win.style.right = 'auto';
      win.style.bottom = 'auto';
    });
    handle.addEventListener('pointerup', () => {
      rs = null;
      win.classList.remove('is-resizing');
    });
  }
  wireResize('l');
  wireResize('r');
  wireResize('b');

  const charts = el('div', 'dev-perf-charts');
  const chartHelp = {
    fps: 'Frames per seconde. Duik bij zoeken/openen = zwaar werk op de hoofdthread.',
    heap: 'JS-geheugen (Chromium). Stijgt bij caches (zoekindex, bijbel, woordenboek).',
    nodes: 'HTML-elementen. Virtuele lijsten houden dit laag; volle lijsten maken het hoog.',
    lag: 'Event-loop lag (ms). Korte pieken normaal; lang aanhoudend = trage UI.'
  };
  const mkChart = (title, id, helpKey) => {
    const box = el('div', 'dev-perf-chart');
    const cap = el('div', 'dev-perf-chart-cap');
    const left = el('span', 'dev-perf-chart-title');
    left.append(document.createTextNode(title + ' '));
    const info = el('button', 'dev-perf-info', 'i');
    info.type = 'button';
    info.title = chartHelp[helpKey] || '';
    info.setAttribute('aria-label', 'Uitleg: ' + title);
    info.onclick = (e) => {
      e.stopPropagation();
      const existing = box.querySelector('.dev-perf-tip');
      if (existing) { existing.remove(); return; }
      document.querySelectorAll('.dev-perf-tip').forEach(t => t.remove());
      box.append(el('div', 'dev-perf-tip', chartHelp[helpKey] || ''));
    };
    left.append(info);
    cap.append(left, el('span', 'dev-perf-chart-now', '—'));
    const canvas = document.createElement('canvas');
    canvas.className = 'dev-perf-canvas';
    canvas.id = id;
    canvas.width = 300;
    canvas.height = 72;
    box.append(cap, canvas);
    charts.append(box);
    return { canvas, now: cap.querySelector('.dev-perf-chart-now') };
  };
  const cFps = mkChart('FPS', 'dev-chart-fps', 'fps');
  const cHeap = mkChart('JS-heap', 'dev-chart-heap', 'heap');
  const cNodes = mkChart('DOM-nodes', 'dev-chart-nodes', 'nodes');
  const cLag = mkChart('Event-loop lag', 'dev-chart-lag', 'lag');
  body.append(charts);

  const grid = el('div', 'dev-perf-grid');
  body.append(grid);
  body.append(el('p', 'dev-perf-hint', 'Sample 250 ms · long tasks & errors worden gelogd · 5× Leo Crucis · sleepbaar'));

  let lagExpected = performance.now() + 100;
  _devPerfLagTimer = setInterval(() => {
    const now = performance.now();
    _devLagMs = Math.max(0, Math.round(now - lagExpected));
    lagExpected = now + 100;
  }, 100);

  function section(title) {
    const h = el('div', 'dev-perf-sec', title);
    grid.append(h);
  }
  function row(label, value, cls) {
    const r = el('div', 'dev-perf-row' + (cls ? ' ' + cls : ''));
    r.append(el('span', 'dev-perf-k', label), el('span', 'dev-perf-v', String(value)));
    grid.append(r);
  }

  function paint() {
    const s = collectDevPerfSnapshot();
    pushDevHist(s);
    const fpsClass = s.fps >= 50 ? 'is-ok' : s.fps >= 30 ? 'is-warn' : 'is-bad';

    drawDevChart(cFps.canvas, _devHist.fps, { min: 0, floorMax: 60, color: '#2e7d4f', fmt: v => Math.round(v) + '' });
    cFps.now.textContent = s.fps + ' fps' + (s.throttling ? ' · thr' : '');
    cFps.now.className = 'dev-perf-chart-now ' + fpsClass;

    drawDevChart(cHeap.canvas, _devHist.heap, { min: 0, color: '#7a1f2b', fmt: v => fmtBytes(v) });
    cHeap.now.textContent = s.heapUsed != null ? fmtBytes(s.heapUsed) : 'n/a';

    drawDevChart(cNodes.canvas, _devHist.nodes, { min: 0, color: '#3b6ea5', fmt: v => Math.round(v) + '' });
    cNodes.now.textContent = String(s.nodes);

    drawDevChart(cLag.canvas, _devHist.lag, { min: 0, floorMax: 16, color: '#c9a227', fmt: v => Math.round(v) + ' ms' });
    cLag.now.textContent = s.lag + ' ms';

    grid.replaceChildren();

    section('Live');
    row('FPS (nu)', s.fps + (s.throttling ? ' · throttle' : ''), fpsClass);
    row('FPS min / max', _devHist.fps.length ? Math.min(..._devHist.fps) + ' / ' + Math.max(..._devHist.fps) : '—');
    row('JS-heap', s.heapUsed != null ? fmtBytes(s.heapUsed) + ' / ' + fmtBytes(s.heapTotal) : 'n/a');
    row('Heap % limiet', s.heapUsed != null && s.heapLimit ? Math.round(100 * s.heapUsed / s.heapLimit) + '%' : '—');
    row('DOM-nodes', s.nodes + (_devHist.nodes.length ? ' (piek ' + Math.max(..._devHist.nodes) + ')' : ''));
    row('Event-loop lag', s.lag + ' ms (piek ' + (_devHist.lag.length ? Math.max(..._devHist.lag) : 0) + ')');
    row('Long tasks (≥50ms)', s.longTasks + (s.longTaskMax ? ' · max ' + s.longTaskMax + ' ms' : ''), s.longTaskMax > 100 ? 'is-warn' : '');
    row('JS-fouten (sessie)', s.errorCount, s.errorCount ? 'is-warn' : 'is-ok');
    if (s.errors && s.errors.length) {
      row('Laatste fout', s.errors[s.errors.length - 1].msg, 'is-bad');
    }

    section('Caches (zoeken)');
    row('Zoekindex', s.cache.indexLoaded ? ('geladen · ' + s.cache.indexDocs + ' docs') : 'niet geladen');
    row('Bijbel-index', s.cache.bijbelIndex ? 'geladen' : 'niet geladen');
    row('Bijbel-verzen in RAM', s.cache.bijbelVerses ? (s.cache.bijbelVerses + ' verzen') : 'leeg');
    row('Woordenboek-index (zoek)', s.cache.wbIndex ? 'geladen' : 'niet geladen');

    section('App-status');
    row('Hash / route', s.path);
    row('Zoektabbladen', s.searchTabs);
    row('Focusblok', s.studyActive ? ('actief · rest ' + fmtDur(s.studyRem)) : 'uit');
    row('Split-scherm', s.split ? 'ja' : 'nee');
    row('Body-classes', s.bodyClasses || '—');
    row('Tab zichtbaar', s.hidden ? 'nee (hidden)' : 'ja');
    row('Online', s.online ? 'ja' : 'nee', s.online ? '' : 'is-warn');
    row('Uptime', fmtDur(s.uptimeMs));

    section('DOM & media');
    row('Scripts / stylesheets', s.scripts + ' / ' + s.styles);
    row('Images', s.imgs);
    row('Audio/video/iframe', s.media);
    row('Interactieve el. (approx.)', s.listenersApprox);

    section('Netwerk (Performance API)');
    row('Resource-entries', s.resCount);
    row('Transfer (geschat)', fmtBytes(s.resTransfer));
    row('Traag (>200 ms)', s.resSlow, s.resSlow > 5 ? 'is-warn' : '');
    if (s.fcp != null) row('First contentful paint', s.fcp + ' ms');
    if (s.navDomMs != null) row('DOMContentLoaded', s.navDomMs + ' ms');
    if (s.navLoadMs != null) row('Load event', s.navLoadMs + ' ms');

    section('localStorage (grootste keys)');
    row('Totaal', s.lsKB + ' KB');
    for (const k of (s.lsTop || [])) {
      row(k.k.length > 28 ? k.k.slice(0, 26) + '…' : k.k, fmtBytes(k.n * 2)); // UTF-16 ~2 bytes
    }

    section('Instellingen (prestatie)');
    row('Laadkracht', s.loadPower);
    row('Max FPS / throttle', (s.maxFps || 'uit') + ' / ' + (s.loadThrottle ? 'aan' : 'uit'));
    row('Minder beweging', s.reduceMotion ? 'aan' : 'uit');
    row('Viewport', s.vw + '×' + s.vh + ' @' + s.dpr + 'x');
  }
  paint();
  _devPerfTimer = setInterval(paint, 250);
}

/** Windows-achtig Start-menu (Leo Crucis) + overzicht open tabbladen. */
let lcStartEl = null;
let lcTabsEl = null;

function closeLcOverlay(which) {
  if ((!which || which === 'start') && lcStartEl) {
    lcStartEl.remove();
    lcStartEl = null;
    const brand = document.getElementById('brand');
    if (brand) brand.setAttribute('aria-expanded', 'false');
  }
  if ((!which || which === 'tabs') && lcTabsEl) {
    try {
      if (lcTabsEl._backdrop) { lcTabsEl._backdrop.remove(); lcTabsEl._backdrop = null; }
    } catch (_) {}
    document.querySelectorAll('.lc-tabs-backdrop').forEach(n => n.remove());
    lcTabsEl.remove();
    lcTabsEl = null;
    try { renderHeaderOpenApps(); } catch (_) {}
  }
}

function positionLcPanel(panel, anchor, preferLeft) {
  const r = anchor.getBoundingClientRect();
  const w = panel.offsetWidth;
  const h = panel.offsetHeight;
  let left = preferLeft
    ? Math.max(8, Math.min(r.left, window.innerWidth - w - 8))
    : Math.max(8, Math.min(r.left + r.width / 2 - w / 2, window.innerWidth - w - 8));
  const above = r.top - h - 10;
  const top = above >= 8 ? above : Math.min(r.bottom + 8, window.innerHeight - h - 8);
  panel.style.left = left + 'px';
  panel.style.top = top + 'px';
}

function onLcOverlayOutside(e) {
  if (lcStartEl && !lcStartEl.contains(e.target) && !e.target.closest('#brand')) {
    closeLcOverlay('start');
  }
  if (lcTabsEl && !lcTabsEl.contains(e.target) && !e.target.closest('#header-open-apps')) {
    closeLcOverlay('tabs');
  }
  if (!lcStartEl && !lcTabsEl) {
    document.removeEventListener('pointerdown', onLcOverlayOutside, true);
  }
}

function onLcOverlayKey(e) {
  if (e.key === 'Escape') {
    closeLcOverlay();
    document.removeEventListener('keydown', onLcOverlayKey, true);
  }
}

function openLeoStartMenu(btn) {
  closeHeaderMenu();
  closeLcOverlay('tabs');
  if (lcStartEl) {
    closeLcOverlay('start');
    return;
  }
  const panel = el('div', 'lc-start');
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', 'Leo Crucis Start');

  const head = el('div', 'lc-start-head');
  const brandWrap = el('div', 'lc-start-brand');
  const logo = document.createElement('img');
  logo.src = 'assets/logo.png';
  logo.alt = '';
  logo.width = 28;
  logo.height = 28;
  brandWrap.append(logo, el('strong', '', 'Leo Crucis'));
  const headActions = el('div', 'lc-start-actions');
  const homeBtn = el('button', 'lc-start-icon-btn');
  homeBtn.type = 'button';
  homeBtn.title = 'Startscherm';
  homeBtn.setAttribute('aria-label', 'Startscherm');
  homeBtn.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11.5 12 4l9 7.5"/><path d="M6 10.5V20h12v-9.5"/></svg>';
  homeBtn.onclick = () => {
    closeLcOverlay('start');
    go(null, null);
    showHome();
  };
  const setBtn = el('button', 'lc-start-icon-btn');
  setBtn.type = 'button';
  setBtn.title = 'Instellingen';
  setBtn.setAttribute('aria-label', 'Instellingen');
  setBtn.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
  setBtn.onclick = () => {
    closeLcOverlay('start');
    showSettings();
  };
  const devBtn = el('button', 'lc-start-icon-btn lc-start-dev-btn');
  devBtn.type = 'button';
  devBtn.title = 'Ontwikkelaarsmodus';
  devBtn.setAttribute('aria-label', 'DEV — ontwikkelaarsmodus en prestaties');
  devBtn.textContent = 'DEV';
  devBtn.onclick = () => {
    closeLcOverlay('start');
    const turningOn = !authorMode;
    setAuthorMode(turningOn);
    openDevPerfPanel();
  };
  headActions.append(homeBtn, setBtn, devBtn);
  head.append(brandWrap, headActions);
  panel.append(head);

  const search = document.createElement('input');
  search.type = 'search';
  search.className = 'lc-start-search';
  search.placeholder = 'Apps zoeken…';
  search.setAttribute('aria-label', 'Apps zoeken');
  search.autocomplete = 'off';
  panel.append(search);

  const body = el('div', 'lc-start-body');
  panel.append(body);

  function paint(q) {
    body.replaceChildren();
    const qq = String(q || '').trim().toLowerCase();
    const favs = (typeof loadAppFavorites === 'function' ? loadAppFavorites() : []);
    const apps = (typeof listLeoApps === 'function' ? listLeoApps() : []);
    const byKind = Object.fromEntries(apps.map(a => [a.kind, a]));

    const match = (kind) => {
      const title = (MINI_APP_TITLES[kind] || kind).toLowerCase();
      return !qq || title.includes(qq) || kind.toLowerCase().includes(qq);
    };

    function addSection(title, kinds) {
      const filtered = kinds.filter(match);
      if (!filtered.length) return;
      body.append(el('div', 'lc-start-sec', title));
      const grid = el('div', 'lc-start-grid');
      for (const kind of filtered) {
        const app = byKind[kind];
        if (!app) continue;
        const titleTxt = MINI_APP_TITLES[kind] || kind;
        const tile = el('button', 'lc-start-tile');
        tile.type = 'button';
        tile.title = titleTxt;
        const ic = (typeof miniAppIconSvg === 'function') ? miniAppIconSvg(kind) : null;
        if (ic) {
          ic.setAttribute('width', '22');
          ic.setAttribute('height', '22');
          tile.append(ic);
        } else {
          tile.append(el('span', 'lc-start-tile-emoji', '◆'));
        }
        tile.append(el('span', 'lc-start-tile-label', titleTxt));
        tile.onclick = () => {
          closeLcOverlay('start');
          try { app.run(); } catch (err) { console.warn(err); }
        };
        grid.append(tile);
      }
      body.append(grid);
    }

    if (favs.length) addSection('Vastgepind', favs);
    const rest = apps.map(a => a.kind).filter(k => !favs.includes(k));
    addSection(favs.length ? 'Alle apps' : 'Apps', rest);

    if (!body.querySelector('.lc-start-tile')) {
      body.append(el('p', 'lc-start-empty', 'Geen apps gevonden'));
    }
  }

  paint('');
  search.addEventListener('input', () => paint(search.value));

  document.body.append(panel);
  lcStartEl = panel;
  btn.setAttribute('aria-expanded', 'true');
  positionLcPanel(panel, btn, true);
  document.addEventListener('pointerdown', onLcOverlayOutside, true);
  document.addEventListener('keydown', onLcOverlayKey, true);
  window.addEventListener('resize', () => { if (lcStartEl) positionLcPanel(lcStartEl, btn, true); }, { once: true });
  try { search.focus(); } catch (_) {}
}

function openOpenTabsPanel(btn) {
  closeHeaderMenu();
  closeLcOverlay('start');
  if (lcTabsEl) {
    closeLcOverlay('tabs');
    return;
  }
  const panel = el('div', 'lc-tabs lc-tabs--stack lc-tabs--fullscreen');
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', 'Recente apps');
  panel.setAttribute('aria-modal', 'true');

  const head = el('div', 'lc-tabs-head');
  head.append(el('strong', '', 'Recente apps'));
  const closeAll = el('button', 'lc-tabs-closeall', 'Alles sluiten');
  closeAll.type = 'button';
  head.append(closeAll);
  panel.append(head);

  const list = el('div', 'lc-tabs-list lc-tabs-stack');
  panel.append(list);

  // Alleen recente apps (max 3). Zoeken is één app, geen losse tabbladen.
  const entries = recentApps.map(r => ({
    id: r.id,
    kind: r.kind,
    iconKind: r.iconKind,
    title: r.title,
    hint: r.hint,
    active: isRecentActive(r.id),
    activate: r.activate,
    close: () => {
      try { r.close(); } catch (_) {}
      removeRecentApp(r.id);
    }
  }));

  const CARD_TONES = {
    bible: 'tone-bible', 'verse-study': 'tone-bible', 'xref-map': 'tone-bible',
    calendar: 'tone-cal', notes: 'tone-notes', budgetter: 'tone-notes', todo: 'tone-notes', timer: 'tone-focus', calculator: 'tone-doc', browser: 'tone-search', woordenboek: 'tone-dict',
    memory: 'tone-games', snake: 'tone-games', bke: 'tone-games', tetris: 'tone-games', mastermind: 'tone-games', connect4: 'tone-games', speeltoestel: 'tone-games', gallery: 'tone-media', album: 'tone-media',
    audio: 'tone-media', video: 'tone-media', maps: 'tone-maps', codex: 'tone-codex',
    doc: 'tone-doc', pptx: 'tone-doc', xlsx: 'tone-doc', focus: 'tone-focus',
    search: 'tone-search', section: 'tone-doc', settings: 'tone-focus'
  };

  function cardIcon(e, size) {
    const k = e.iconKind || e.kind;
    const px = size || 22;
    if (k === 'search') {
      const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      s.setAttribute('viewBox', '0 0 24 24');
      s.setAttribute('width', String(px));
      s.setAttribute('height', String(px));
      s.setAttribute('fill', 'none');
      s.setAttribute('stroke', 'currentColor');
      s.setAttribute('stroke-width', '1.75');
      s.setAttribute('stroke-linecap', 'round');
      s.setAttribute('stroke-linejoin', 'round');
      s.setAttribute('aria-hidden', 'true');
      s.innerHTML = '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>';
      return s;
    }
    const svg = typeof miniAppIconSvg === 'function' ? miniAppIconSvg(k) : null;
    if (svg) {
      svg.setAttribute('width', String(px));
      svg.setAttribute('height', String(px));
      return svg;
    }
    return el('span', 'lc-tabs-card-letter', (e.title || '?').charAt(0).toUpperCase());
  }

  function paintList() {
    list.replaceChildren();
    if (!entries.length) {
      list.append(el('p', 'lc-tabs-empty', 'Geen open apps'));
      closeAll.disabled = true;
      return;
    }
    closeAll.disabled = false;
    entries.forEach((e, idx) => {
      const tone = CARD_TONES[e.iconKind] || CARD_TONES[e.kind] || 'tone-default';
      const card = el('div', 'lc-tabs-stack-card' + (e.active ? ' is-active' : '') + ' ' + tone);
      card.setAttribute('role', 'button');
      card.tabIndex = 0;
      card.style.zIndex = String(20 + (entries.length - idx));

      const bar = el('div', 'lc-tabs-stack-bar');
      const barIcon = el('span', 'lc-tabs-stack-bar-icon');
      barIcon.append(cardIcon(e, 18));
      bar.append(barIcon, el('span', 'lc-tabs-stack-bar-title', e.title));
      const x = el('button', 'lc-tabs-stack-x', '×');
      x.type = 'button';
      x.title = 'Sluiten';
      x.setAttribute('aria-label', e.title + ' sluiten');
      x.onclick = (ev) => {
        ev.stopPropagation();
        try { e.close(); } catch (err) { console.warn(err); }
        const i = entries.indexOf(e);
        if (i >= 0) entries.splice(i, 1);
        removeRecentApp(e.id);
        paintList();
        if (!entries.length) closeLcOverlay('tabs');
      };
      bar.append(x);

      const body = el('div', 'lc-tabs-stack-body');
      const bigIcon = el('div', 'lc-tabs-stack-bigicon');
      bigIcon.append(cardIcon(e, 48));
      body.append(bigIcon);
      if (e.hint) body.append(el('span', 'lc-tabs-stack-hint', e.hint));
      if (e.active) body.append(el('span', 'lc-tabs-stack-now', 'Nu open'));

      const activate = () => {
        closeLcOverlay('tabs');
        try { e.activate(); } catch (err) { console.warn(err); }
      };
      card.onclick = (ev) => {
        if (ev.target.closest('.lc-tabs-stack-x')) return;
        activate();
      };
      card.onkeydown = (ev) => {
        if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); activate(); }
      };

      card.append(bar, body);
      list.append(card);
    });
  }

  paintList();
  closeAll.onclick = () => {
    const copy = entries.slice();
    for (const e of copy) {
      try { e.close(); } catch (_) {}
      removeRecentApp(e.id);
    }
    entries.length = 0;
    recentApps.length = 0;
    closeLcOverlay('tabs');
    try { showHome(); } catch (_) {}
  };

  // Dim achtergrond (fullscreen overlay)
  const backdrop = el('div', 'lc-tabs-backdrop');
  backdrop.onclick = () => closeLcOverlay('tabs');
  document.body.append(backdrop, panel);
  lcTabsEl = panel;
  panel._backdrop = backdrop;
  btn.setAttribute('aria-expanded', 'true');

  document.addEventListener('pointerdown', onLcOverlayOutside, true);
  document.addEventListener('keydown', onLcOverlayKey, true);
}

function wireBrandDevGesture() {
  const brand = $('#brand');
  if (!brand) return;
  // 1× klik → Start-menu (Windows-stijl)
  // 5× snel → auteursmodus + prestatievenster
  brand.setAttribute('aria-haspopup', 'dialog');
  brand.setAttribute('aria-expanded', 'false');
  brand.onclick = (e) => {
    const now = Date.now();
    _devPerfClicks = _devPerfClicks.filter(t => now - t < DEV_PERF_WINDOW_MS);
    _devPerfClicks.push(now);
    if (_devPerfClicks.length >= DEV_PERF_CLICKS) {
      _devPerfClicks = [];
      e.preventDefault();
      e.stopPropagation();
      closeLcOverlay();
      const turningOn = !authorMode;
      setAuthorMode(turningOn);
      openDevPerfPanel();
      return;
    }
    e.stopPropagation();
    openLeoStartMenu(brand);
  };
  brand.title = 'Startmenu · 5× snel: auteursmodus + prestaties';
  brand.setAttribute('aria-label', 'Leo Crucis Startmenu');
}

/**
 * Taakbalk in de header: alle open (recente) apps als pillen.
 * Blijven staan tot je ze sluit (×) of "alles sluiten".
 */
function renderHeaderOpenApps() {
  // exposed for mini-apps-view sync

  const host = document.getElementById('header-open-apps');
  if (!host) return;
  wireUiModules();
  const list = (recentApi && recentApi.getList) ? recentApi.getList() : (recentApps || []);

  host.replaceChildren();
  if (!list.length) {
    host.hidden = true;
    host.setAttribute('aria-hidden', 'true');
    return;
  }
  host.hidden = false;
  host.removeAttribute('aria-hidden');

  for (const entry of list) {
    const active = isRecentActive(entry.id);
    const title = entry.title || entry.id;
    const btn = el('button', 'header-open-app' + (active ? ' is-active' : ''));
    btn.type = 'button';
    btn.title = title + (active ? ' (nu open)' : '');
    btn.setAttribute('aria-label', title);
    btn.setAttribute('aria-current', active ? 'true' : 'false');
    btn.dataset.id = entry.id;
    const k = entry.iconKind || entry.kind;
    if (k) btn.dataset.kind = String(k);

    const ic = el('span', 'header-open-app-icon');
    let svg = null;
    try {
      if (typeof miniAppIconSvg === 'function') svg = miniAppIconSvg(k);
      else if (miniApi && typeof miniApi.miniAppIconSvg === 'function') svg = miniApi.miniAppIconSvg(k);
    } catch (_) {}
    if (svg) {
      svg.setAttribute('width', '16');
      svg.setAttribute('height', '16');
      ic.append(svg);
    } else {
      ic.textContent = '•';
    }
    btn.append(ic);
    // Geen tekstlabel — alleen icoon (naam in title/aria-label)

    const x = el('button', 'header-open-app-close', '×');
    x.type = 'button';
    x.title = title + ' sluiten';
    x.setAttribute('aria-label', title + ' sluiten');
    x.onclick = (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      try { if (typeof entry.close === 'function') entry.close(); } catch (err) { console.warn(err); }
      removeRecentApp(entry.id);
      renderHeaderOpenApps();
    };
    btn.append(x);

    btn.onclick = (ev) => {
      if (ev.target.closest('.header-open-app-close')) return;
      try { if (typeof entry.activate === 'function') entry.activate(); } catch (err) { console.warn(err); }
      try { renderHeaderOpenApps(); } catch (_) {}
    };
    host.append(btn);
  }
}

try { window.renderHeaderOpenApps = renderHeaderOpenApps; } catch (_) {}

function wireHeaderNav() {
  const homeBtn = document.getElementById('btn-nav-home');
  const back = document.getElementById('btn-nav-back');
  const fwd = document.getElementById('btn-nav-forward');
  const splitBtn = document.getElementById('btn-nav-split');
  if (homeBtn) {
    homeBtn.onclick = () => {
      try { closeLcOverlay(); } catch (_) {}
      try { closeHeaderMenu(); } catch (_) {}
      try { showHome(); } catch (_) {}
      try { renderHeaderOpenApps(); } catch (_) {}
    };
  }
  if (back) {
    back.onclick = () => {
      try {
        wireUiModules();
        if (miniApi && typeof miniApi.goBackSmart === 'function') {
          miniApi.goBackSmart();
        } else {
          history.back();
        }
      } catch (_) {
        try { history.back(); } catch (__) {}
      }
      try { renderHeaderOpenApps(); } catch (_) {}
    };
  }
  if (fwd) {
    fwd.onclick = () => {
      try {
        wireUiModules();
        if (miniApi && typeof miniApi.goForwardSmart === 'function') {
          miniApi.goForwardSmart();
        } else {
          history.forward();
        }
      } catch (_) {
        try { history.forward(); } catch (__) {}
      }
    };
  }
  if (splitBtn) {
    splitBtn.onclick = () => {
      try {
        wireUiModules();
        if (miniApi && typeof miniApi.toggleSplitFromHeader === 'function') {
          miniApi.toggleSplitFromHeader();
        }
      } catch (e) { console.warn('split', e); }
      try { renderHeaderOpenApps(); } catch (_) {}
    };
  }
  try {
    wireUiModules();
    if (miniApi && typeof miniApi.syncHeaderNavState === 'function') {
      miniApi.syncHeaderNavState();
    }
  } catch (_) {}
  try { renderHeaderOpenApps(); } catch (_) {}
}

function wireSearch() {
  wireBrandDevGesture();
  // Header-icoon opent de zoekpagina (met leeg zoekveld)
  $('#btn-search').onclick = () => showResults('');
  wireHeaderNav();
  try { wireDnd(); } catch (_) {}
  wireHeaderTools();
  try { initSearchHistoryFromFile(); } catch (_) {}
  wireBackgroundMusic();
  wireTransfers();
  try { wirePhase4Ux(); } catch (e) { console.warn('fase4 ux', e); }
}

// ===== Fase 4: sneltoetsen, breadcrumbs, onboarding =====
let crumbsApi = null;
let shortcutsApi = null;

function wirePhase4Ux() {
  if (!crumbsApi) {
    crumbsApi = createBreadcrumbsApi({
      getNav: () => nav,
      getWorld: () => world,
      getCurrentSection: () => currentSection,
      getMiniAppKind: () => {
        try {
          if (miniApi && miniApi.splitLeft && miniApi.splitLeft.kind && miniApi.splitLeft.kind !== '__picker__') {
            return miniApi.splitLeft.kind;
          }
        } catch (_) {}
        return null;
      },
      getMiniAppTitle: () => {
        try {
          const k = crumbsApi && null;
          const kind = (miniApi && miniApi.splitLeft && miniApi.splitLeft.kind) || null;
          if (!kind || kind === '__picker__') return null;
          return (typeof MINI_APP_TITLES !== 'undefined' && MINI_APP_TITLES[kind]) || kind;
        } catch (_) { return null; }
      },
      go: (b, r) => go(b, r),
      showHome: () => showHome(),
      showSection: (id) => showSection(id),
      whereOf: (id) => whereOf(id),
    });
  }
  try { crumbsApi.render(); } catch (_) {}

  if (!shortcutsApi) {
    shortcutsApi = installShortcuts({
      showSearch: () => showResults(''),
      showHome: () => showHome(),
      showSettings: () => showSettings(),
      goBack: () => {
        try {
          wireUiModules();
          if (miniApi && typeof miniApi.goBackSmart === 'function') miniApi.goBackSmart();
          else history.back();
        } catch (_) { try { history.back(); } catch (__) {} }
      },
      goForward: () => {
        try {
          wireUiModules();
          if (miniApi && typeof miniApi.goForwardSmart === 'function') miniApi.goForwardSmart();
          else history.forward();
        } catch (_) { try { history.forward(); } catch (__) {} }
      },
      closeOverlays: () => {
        try { closeHeaderMenu(); } catch (_) {}
        try {
          const help = document.getElementById('lc-shortcuts-help');
          if (help) help.remove();
        } catch (_) {}
        try {
          const ob = document.getElementById('lc-onboarding');
          if (ob) ob.remove();
        } catch (_) {}
      },
    });
  }
}

function refreshBreadcrumbs() {
  try {
    if (!crumbsApi) wirePhase4Ux();
    else crumbsApi.render();
  } catch (_) {}
}

/** Voor instellingen: rondleiding opnieuw. */
function restartOnboarding() {
  try { resetOnboarding(); } catch (_) {}
  try { startOnboarding(); } catch (_) {}
}


/** Chrome-achtig download-icoon in de header voor achtergrond-overdrachten. */
function wireTransfers() {
  const btn = $('#btn-transfers');
  const panel = $('#xfer-panel');
  const list = $('#xfer-list');
  const empty = $('#xfer-empty');
  const badge = $('#xfer-badge');
  const clearBtn = $('#xfer-clear');
  if (!btn || !panel) return;

  let open = false;

  function render(state) {
    const busy = !!(state && state.busy);
    const count = state ? state.count : 0;
    // Toon icoon zolang er actieve of recente overdrachten zijn
    const hasAny = busy || (state && state.recent && state.recent.length);
    btn.hidden = !hasAny && !open;
    btn.classList.toggle('is-busy', busy);
    if (badge) {
      if (count > 0) {
        badge.hidden = false;
        badge.textContent = count > 9 ? '9+' : String(count);
      } else {
        badge.hidden = true;
      }
    }
    if (!list) return;
    list.replaceChildren();
    const rows = [];
    if (state && state.active) rows.push(...state.active);
    if (state && state.recent) rows.push(...state.recent.slice().reverse());
    if (empty) empty.hidden = rows.length > 0;
    rows.forEach(t => {
      const li = document.createElement('li');
      li.className = 'xfer-item' + (t.status === 'done' ? ' is-done' : t.status === 'error' ? ' is-error' : '');
      const title = document.createElement('div');
      title.className = 'xfer-item-title';
      title.textContent = t.label || 'Overdracht';
      const detail = document.createElement('div');
      detail.className = 'xfer-item-detail';
      detail.textContent = t.detail || '';
      detail.title = t.detail || '';
      li.append(title, detail);
      if (t.total > 0 || t.status === 'running') {
        const bar = document.createElement('div');
        bar.className = 'xfer-item-bar';
        const fill = document.createElement('i');
        const frac = t.total > 0 ? Math.min(1, t.done / t.total) : (t.status === 'done' ? 1 : 0);
        fill.style.width = Math.round(frac * 100) + '%';
        bar.append(fill);
        li.append(bar);
      }
      const eta = document.createElement('div');
      eta.className = 'xfer-item-eta';
      eta.textContent = transferEta(t);
      li.append(eta);
      list.append(li);
    });
  }

  function setOpen(v) {
    open = !!v;
    panel.hidden = !open;
    if (open) btn.hidden = false;
  }

  btn.onclick = e => {
    e.stopPropagation();
    setOpen(panel.hidden);
  };
  if (clearBtn) {
    clearBtn.onclick = e => {
      e.stopPropagation();
      clearFinishedTransfers();
    };
  }
  document.addEventListener('click', e => {
    if (!open) return;
    if (panel.contains(e.target) || btn.contains(e.target)) return;
    setOpen(false);
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && open) setOpen(false);
  });

  onTransfers(render);
}

/** Mini-player in de header: pauze / terug / vooruit + scrollende liedjesnaam. */
function wireBackgroundMusic() {
  const box = $('#bg-music');
  if (!box) return;
  const titleEl = $('#bg-music-title');
  const titleDup = box.querySelector('.bg-music-title-dup');
  const btnToggle = $('#bg-toggle');
  const btnPrev = $('#bg-prev');
  const btnNext = $('#bg-next');
  const iconPlay = btnToggle && btnToggle.querySelector('.bg-icon-play');
  const iconPause = btnToggle && btnToggle.querySelector('.bg-icon-pause');

  function apply(state) {
    if (!state || !state.active) {
      box.hidden = true;
      box.classList.remove('is-playing', 'is-scrolling');
      return;
    }
    box.hidden = false;
    box.classList.toggle('is-playing', !!state.playing);
    const t = state.title || 'Muziek';
    if (titleEl) titleEl.textContent = t;
    if (titleDup) titleDup.textContent = t;
    box.querySelector('.bg-music-marquee').title = t;
    if (iconPlay && iconPause) {
      iconPlay.hidden = !!state.playing;
      iconPause.hidden = !state.playing;
    }
    if (btnToggle) {
      btnToggle.title = state.playing ? 'Pauzeren' : 'Afspelen';
      btnToggle.setAttribute('aria-label', state.playing ? 'Pauzeren' : 'Afspelen');
    }
    // Marquee alleen als de tekst te breed is voor de beschikbare ruimte
    requestAnimationFrame(() => {
      const marquee = box.querySelector('.bg-music-marquee');
      if (!marquee || !titleEl) return;
      box.classList.remove('is-scrolling');
      const need = titleEl.scrollWidth > marquee.clientWidth + 2;
      if (need) box.classList.add('is-scrolling');
    });
  }

  if (btnToggle) btnToggle.onclick = () => bgToggle();
  if (btnPrev) btnPrev.onclick = () => bgPrev();
  if (btnNext) btnNext.onclick = () => bgNext(false);
  // Dubbelklik op titel → open full audiospeler
  const marquee = box.querySelector('.bg-music-marquee');
  if (marquee) {
    marquee.style.cursor = 'pointer';
    marquee.onclick = () => showMediaPlayer('audio');
  }
  onBackgroundMusic(apply);
}

// Eigen boeken en gebouwen: alles wat in de gebruikersmap onder stad/<gebouw>/ (of sectie-submap) staat. Die map hoort niet bij de software
// en wordt dus nooit meegebouwd of meegeleverd.
//  - een map met een gebouw.json (of met nieuwe boeken erin) wordt een gebouw in de stad
//  - een .html-bestand dat nog nergens in de bibliotheek staat, komt als boek in de sectie "Eigen boeken" van dat gebouw
// De bestanden zijn de bron: haal je een bestand weg, dan verdwijnt het boek ook uit de bibliotheek.
const prettyName = dir => dir.replace(/[-_]+/g, ' ').replace(/^./, c => c.toUpperCase());
const okBookId = f => /^[\p{L}\p{N}_ -]+$/u.test(f) && f === f.trim();

// Verwijder boeken uit de wereld waarvoor geen bestand (meer) bestaat.
// Bronnen van "bestaat": bookPaths (meegeleverd), bestanden in de gebruikers-stadsmap, of details{} (browser).
// Gebouwen en lege secties blijven staan — alleen ontbrekende items verdwijnen uit de tellingen/UI.
async function syncWorldWithFiles() {
  // Welke boek-ids hebben echt inhoud?
  // - Tauri: alleen wat op schijf in de gebruikers-stadsmap staat (na exportBundledBooks).
  //   bookPaths alleen is niet genoeg: die kan verouderd zijn na het wissen van HTML-bestanden.
  // - Browser: bookPaths (meegeleverd) + details (eigen wijzigingen).
  const existing = new Set();
  for (const id of Object.keys(details || {})) existing.add(String(id).toLowerCase());

  if (inTauri) {
    try {
      for (const [dir, files] of await listStad()) {
        for (const f of files || []) {
          // f is "id" of "sectie/id"
          const base = String(f).includes('/') ? String(f).split('/').pop() : String(f);
          existing.add(String(base).toLowerCase());
        }
      }
    } catch (e) { console.warn('syncWorldWithFiles: stadsmap niet leesbaar', e); }
  } else {
    for (const k of Object.keys(bookPaths || {})) existing.add(String(k).toLowerCase());
  }

  let removedBooks = 0, removedRooms = 0;
  for (const b of world.buildings || []) {
    const rooms = b.rooms || [];
    const keptRooms = [];
    for (const r of rooms) {
      const filterList = (arr) => {
        if (!Array.isArray(arr)) return arr;
        const keep = [];
        for (const it of arr) {
          if (!it || !it.id) continue;
          if (existing.has(String(it.id).toLowerCase())) keep.push(it);
          else removedBooks++;
        }
        return keep;
      };
      if (r.shelves) {
        for (const sh of r.shelves) {
          if (sh && Array.isArray(sh.items)) sh.items = filterList(sh.items);
        }
        // verwijder lege planken
        r.shelves = r.shelves.filter(sh => sh && Array.isArray(sh.items) && sh.items.length);
        if (!r.shelves.length) delete r.shelves;
      }
      if (Array.isArray(r.items)) r.items = filterList(r.items);

      const n = roomItems(r).length;
      if (n > 0) {
        keptRooms.push(r);
      } else {
        // Geen standaard/lege secties bewaren
        removedRooms++;
      }
    }
    b.rooms = keptRooms;
  }
  if (removedBooks > 0 || removedRooms > 0) {
    console.info(`syncWorldWithFiles: ${removedBooks} boek(en) en ${removedRooms} lege sectie(s) verwijderd`);
    try { await saveWorld(world); } catch (e) { console.warn('world opslaan na sync mislukt', e); }
  }
  return { removedBooks, removedRooms };
}

async function discoverUserStad() {
  const out = { added: [], skipped: [] };
  if (!inTauri) return out;
  let scan;
  try { scan = await listStad(); } catch (e) { console.warn('Stadsmap lezen mislukt', e); return out; }
  const known = new Set([...allItems().map(i => String(i.id).toLowerCase()), ...Object.keys(bookPaths)]);
  for (const [dir, files, gebouwTxt, others = []] of scan) {
    // PDF's die je in de map hebt gezet worden automatisch een boek (<naam>.html naast de pdf)
    const toConvert = others.filter(n => /\.pdf$/i.test(n) && okBookId(n.replace(/\.pdf$/i, '')) && !files.some(f => f.toLowerCase() === n.replace(/\.pdf$/i, '').toLowerCase()));
    for (const n of toConvert) {
      const base = n.replace(/\.pdf$/i, '');
      try {
        await withLoading(async () => {
          const b64 = await readUserPdfB64(dir, n);
          await writeFile(`stad/${dir}/${base}.html`, bookDocument(base, buildPdfHtml('data:application/pdf;base64,' + b64, n), emptyRef()));
        }, `PDF “${n}” omzetten naar boek…`);
        files.push(base);
      } catch (e) { out.skipped.push(`${dir}/${n} (omzetten mislukt)`); console.warn('PDF omzetten mislukt', n, e); }
    }
    for (const n of others) {
      if (toConvert.includes(n) || /\.(png|jpe?g|webp|gif)$/i.test(n)) continue;   // afbeeldingen zijn covers, geen boeken
      if (/\.pdf$/i.test(n)) { if (!files.some(f => f.toLowerCase() === n.replace(/\.pdf$/i, '').toLowerCase())) out.skipped.push(`${dir}/${n} (gebruik alleen letters, cijfers, spatie, - en _ in de naam)`); continue; }
      out.skipped.push(`${dir}/${n} (alleen .html en .pdf worden ondersteund)`);
    }
    let def = {};
    if (gebouwTxt) {
      try { def = JSON.parse(gebouwTxt) || {}; }
      catch (e) { console.warn(`gebouw.json in "${dir}" is geen geldige JSON`, e); def = {}; }
    }
    const defRooms = Array.isArray(def.rooms) ? def.rooms.filter(r => r && typeof r === 'object') : [];
    const ownIds = new Set(defRooms.flatMap(roomItems).map(i => String(i.id).toLowerCase()));
    const candidates = files.filter(f => !known.has(f.toLowerCase()) && !ownIds.has(f.toLowerCase()));
    const newFiles = candidates.filter(okBookId);
    out.skipped.push(...candidates.filter(f => !okBookId(f)).map(f => `${dir}/${f}.html (ongeldige naam)`));

    let bld = world.buildings.find(b => b.id === dir);
    if (!bld) {
      for (const r of defRooms) {
        r.label = r.label || r.id || 'Sectie';
        r.id = r.id || slug(r.label);
        if (!r.shelves && !Array.isArray(r.items)) r.items = [];
        for (const it of roomItems(r)) { it.dir = it.dir || dir; it.title = it.title || it.id; }
      }
      const spot = (typeof def.x === 'number' && typeof def.y === 'number') ? { x: def.x, y: def.y } : findFreeSpot();
      bld = {
        id: dir, label: def.label || prettyName(dir), desc: def.desc || '',
        x: spot.x, y: spot.y, w: Number(def.w) || 18, h: Number(def.h) || 16,
        rooms: defRooms, layer: activeLayerId || 'gebouwen', placed: true,
      };
      world.buildings.push(bld);
      for (const i of defRooms.flatMap(roomItems)) { known.add(String(i.id).toLowerCase()); out.added.push(i.id); }   // ook die moeten zoekbaar worden
    }
    if (!newFiles.length) continue;

    if (!Array.isArray(bld.rooms)) bld.rooms = [];
    let room = bld.rooms.find(r => r.id === 'eigen-boeken');
    if (!room) {
      room = { id: 'eigen-boeken', label: 'Eigen boeken', desc: 'Boeken die je zelf in de map van dit gebouw hebt gezet.', items: [] };
      bld.rooms.push(room);
    }
    let list;
    if (room.shelves) {
      if (!room.shelves.length) room.shelves.push({ label: null, items: [] });
      list = room.shelves[0].items || (room.shelves[0].items = []);
    } else list = room.items || (room.items = []);
    for (const f of newFiles) {
      let title = f;
      try { const t = await readFile(`stad/${dir}/${f}.html`); if (t) title = parseBook(t).title || f; } catch (e) {}
      list.push({ id: f, title, desc: '', dir, color: defaultColorForId(f) });
      known.add(f.toLowerCase());
      out.added.push(f);
    }
  }
  return out;
}
// Gevonden boeken zoekbaar maken (op de achtergrond; één keer opslaan).
async function indexDiscovered(ids) {
  if (!ids.length) return;
  for (const id of ids) { try { const d = await loadBook(id); if (d) reindex(id, d.html, false); } catch (e) {} }
  saveExtra(extra); setOverlay(extra);
}

// Alle meegeleverde boeken ook als bestanden in de gebruikersmap zetten (stad/<gebouw>/<sectie>/<boek>.html), zodat je ze daar kunt
// bekijken, aanpassen en er eigen boeken naast kunt zetten. Bestaande bestanden worden nooit overschreven.
// Gebeurt één keer per appversie, met een laadscherm (voortgang + resterende tijd).
const EXPORT_KEY = 'lc-stad-exported';
async function exportBundledBooks() {
  if (!inTauri) return;
  try { if (localStorage.getItem(EXPORT_KEY) === APP_VERSION) return; } catch (e) {}
  const paths = Object.values(bookPaths);
  if (!paths.length) return;
  let have = new Set();
  // files kan "id" of "sectie/id" bevatten (na sectie-mappen in list_user_stad)
  try { for (const [dir, files] of await listStad()) for (const f of files) have.add(`${dir}/${f}`.toLowerCase()); } catch (e) {}
  const todo = paths.filter(p => !have.has(p.toLowerCase()));
  let failed = 0;
  if (todo.length) {
    await withLoading(async upd => {
      let done = 0, next = 0;
      upd({ total: todo.length, done: 0, detail: 'Boeken worden in je gebruikersmap gezet (eenmalig)' });
      const worker = async () => {
        while (next < todo.length) {
          const p = todo[next++];
          try {
            const res = await fetch(`stad/${p}.html`);
            if (!res.ok) throw new Error(res.status);
            await writeFile(`stad/${p}.html`, await res.text());
          } catch (e) { failed++; console.warn('Boek niet gekopieerd:', p, e); }
          upd({ done: ++done });
        }
      };
      await Promise.all([worker(), worker(), worker(), worker()]);
    }, 'Bibliotheek klaarzetten…');
  }
  if (!failed) { try { localStorage.setItem(EXPORT_KEY, APP_VERSION); } catch (e) {} }
}

// Nieuwe bestanden in de gebruikersmap oppikken zonder de app te herstarten (bij terugkeren naar het venster).
const shownSkips = new Set();
function reportSkipped(list) {
  const fresh = list.filter(x => !shownSkips.has(x));
  if (!fresh.length) return;
  fresh.forEach(x => shownSkips.add(x));
  ask('Deze bestanden in je stadsmap kon de app niet gebruiken:\n' + fresh.join('\n'), { yes: 'OK' });
}
let rescanning = false, lastScan = 0;
/** @param {boolean} [force] handmatige scan: negeert throttle en “achtergrondtaken uit” */
async function rescanStad(force = false) {
  if (!inTauri || rescanning) return;
  if (!force && Date.now() - lastScan < 1500) return;
  if (!force) {
    try { if (loadSettings().backgroundTasks === false) return; } catch (_) {}
  }
  rescanning = true;
  try {
    const count = () => world.buildings.length + allItems().length;
    const before = count();
    const coversChanged = await refreshCovers();
    const { added, skipped } = await discoverUserStad();
    reportSkipped(skipped);
    if (force || coversChanged || count() !== before) {
      if (added.length) indexDiscovered(added);
      if (home.style.display !== 'none') renderWorld();
    }
  } catch (e) { console.warn('Stadsmap opnieuw lezen mislukt', e); }
  finally { rescanning = false; lastScan = Date.now(); }
}


// ========== FASE 2: UI-modules koppelen ==========
let recentApi, miniApi, searchApi, focusApi, worldApi, settingsApi;

function wireUiModules() {
  if (searchApi) return; // al gedaan
  try {
    configureSearchHistory({
      readFile: typeof readFile === 'function' ? readFile : async () => null,
      writeFile: typeof writeFile === 'function' ? writeFile : async () => {},
      inTauri: typeof inTauri !== 'undefined' ? inTauri : false,
    });
  } catch (e) { console.warn('configureSearchHistory', e); }

  recentApi = createRecentAppsApi({
    loadSettings,
    showSettings: (...a) => showSettings(...a),
    getSplitLeft: () => (miniApi ? miniApi.splitLeft : null),
    getSplitRight: () => (miniApi ? miniApi.splitRight : null),
  });
  // Eén lijst: app.js-code die recentApps gebruikt, ziet dezelfde array
  recentApps = recentApi.getList();


  miniApi = createMiniAppsViewApi({
    canOpenNewRecent: (id) => recentApi.canOpenNewRecent(id),
    pushRecentApp: (e) => pushRecentApp(e),
    removeRecentApp: (id) => removeRecentApp(id),
    showHome: () => showHome(),
    guardFocusBlock: (kind, openFn) => guardFocusBlock(kind, openFn),
    viewContent,
    home,
    view,
    setHash: (h) => { try { location.hash = h; } catch (_) {} },
    setCurrentSection: (v) => { currentSection = v; },
    createMiniAppInstance,
    showMediaPlayer: (k) => showMediaPlayer(k),
    loadSettings,
  });
  try { miniApi.wireMiniAppEvents(); } catch (e) { console.warn(e); }

  worldApi = createWorldViewApi({
    getWorld: () => world,
    nav,
    home,
    getDev: () => !!dev,
    ask,
    persist,
    go,
    showSection: (id, edit) => showSection(id, edit),
    setHash,
    roomItems,
    colorOf,
    ensureShelves,
    uniqueId,
    slug,
    listLeoApps,
    MINI_APP_TITLES,
    showResults: (q) => showResults(q),
    inTauri,
    extra,
    listUserCovers,
    readUserImageB64,
    exportUserImage,
    saveBook,
    openItem: (item) => openItem(item),
    renderHeaderFavorites: () => { try { renderHeaderFavorites(); } catch (_) {} },
    typeMeta,
    chooseBookType,
    chooseDocDesign,
    initialDocHtml,
    buildPdfHtml,
    buildSlidesHtml,
    buildSheetHtml,
    getAuthorMode: () => !!authorMode,
  });


  searchApi = createSearchUiApi({
    loadIndex,
    searchAll,
    suggest: typeof suggest === 'function' ? suggest : (async () => []),
    snippet,
    allItems: () => allItems(),
    canOpenNewRecent: (id) => recentApi.canOpenNewRecent(id),
    pushRecentApp: (e) => pushRecentApp(e),
    removeRecentApp: (id) => removeRecentApp(id),
    showHome: () => showHome(),
    showSection: (id) => showSection(id),
    showMiniApp: (k, p) => miniApi.showMiniApp(k, p),
    showFocus: (...a) => showFocus(...a),
    showMediaPlayer: (k) => showMediaPlayer(k),
    startCreate: (k) => startCreate(k),
    ask,
    miniAppIconSvg: (k, s) => miniApi.miniAppIconSvg(k, s),
    viewContent,
    home,
    view,
    setHash: (h) => { try { location.hash = h; } catch (_) {} },
    setCurrentSection: (v) => { currentSection = v; },
    listLeoApps: () => listLeoApps(),
  });


  settingsApi = createSettingsViewApi({
    loadSettings,
    saveSettings,
    applySettings,
    viewContent,
    home,
    view,
    canOpenNewRecent: (id) => canOpenNewRecent(id),
    pushRecentApp: (e) => pushRecentApp(e),
    showHome: () => showHome(),
    restartOnboarding: () => { try { restartOnboarding(); } catch (_) {} },
    showShortcutsHelp: () => { try { showShortcutsHelp(); } catch (_) {} },
    setHash,
    setCurrentSection: (v) => { currentSection = v; },
    getRecentAppsMax: () => getRecentAppsMax(),
    getRecentApps: () => { try { return recentApi ? recentApi.getList() : recentApps; } catch (_) { return recentApps; } },
    ask,
    inTauri,
    clearAppCache,
    getTauriWindow,
    openFolder,
    renderHeaderFavorites: () => { try { renderHeaderFavorites(); } catch (_) {} },
    persist,
    renderWorld: () => renderWorld(),
    clearSplitState: () => clearSplitState(),
    getSplitLeft: () => (miniApi ? miniApi.splitLeft : null),
    getSplitRight: () => (miniApi ? miniApi.splitRight : null),
    setSplitRight: (v) => { if (miniApi) miniApi.splitRight = v; },
    renderMiniAppView: () => { try { if (miniApi) miniApi.renderMiniAppView(); } catch (_) {} },
    getFps: () => { try { return getFps(); } catch (_) { return 0; } },
    openMediaFolder: (...a) => openMediaFolder(...a),
  });

  focusApi = createFocusStudyApi({
    $,
    loadSettings,
    saveSettings,
    ask,
    canOpenNewRecent: (id) => recentApi.canOpenNewRecent(id),
    pushRecentApp: (e) => pushRecentApp(e),
    removeRecentApp: (id) => removeRecentApp(id),
    showHome: () => showHome(),
    viewContent,
    home,
    view,
    setHash: (h) => { try { location.hash = h; } catch (_) {} },
    periodStudySummary,
    weekStudySummary,
    recordStudyBlock,
    evaluateAchievements,
    persistCurrentSession: (f) => persistCurrentSession(f),
    setupPresenceTracking: () => {},
    applyFocusBlockLock: () => { try { applyFocusBlockLock(); } catch (_) {} },
    updatePresenceBadge: () => { try { updatePresenceBadge(); } catch (_) {} },
    setCurrentSection: (v) => { currentSection = v; },
    isPageVisible: () => isPageVisible(),
  });
}



async function init() {
  try { setSplashProgress(1, 'Bibliotheek laden…', 'starten'); } catch (_) {}
  const forceHide = setTimeout(() => {
    console.warn('Opstarten duurde te lang — splash geforceerd gesloten');
    try { hideSplash(); } catch (_) {}
  }, 45000);
  try {
    await initInner();
    try { bootReport(); } catch (_) {}
  } catch (err) {
    try { bootFail('E-INIT', 'Init mislukt', err); } catch (_) {
      console.error('Init mislukt:', err);
    }
    try {
      document.body.insertAdjacentHTML('beforeend',
        '<p style="padding:16px">Fout bij laden: ' + String(err && err.message || err) + '</p>');
    } catch (_) {}
  } finally {
    clearTimeout(forceHide);
    hideSplash();
  }
}

async function withTimeout(promise, ms, label) {
  let t;
  const timeout = new Promise((_, rej) => {
    t = setTimeout(() => rej(new Error((label || 'Stap') + ' time-out na ' + Math.round(ms / 1000) + 's')), ms);
  });
  try {
    return await Promise.race([promise, timeout]);
  } finally {
    clearTimeout(t);
  }
}

async function initInner() {
  const step = (pct, label, detail) => {
    try { setSplashProgress(pct, label, detail || ''); } catch (_) {}
  };
  step(5, 'Bibliotheek laden…', 'wereldkaart');

  let baseWorld;
  try {
    baseWorld = await withTimeout(loadJSON('data/world.json'), 15000, 'world.json');
    world = baseWorld;
    try {
      bookPaths = await withTimeout(loadJSON('data/book-paths.json'), 10000, 'book-paths');
    } catch (e) { console.warn('book-paths.json ontbreekt; draai "npm run index"', e); }
  } catch (err) {
    document.body.insertAdjacentHTML('beforeend',
      '<p style="padding:16px">Fout bij laden van de bibliotheek: ' + err.message + '</p>');
    return;
  }
  step(20, 'Bibliotheek laden…', 'opgeslagen gegevens');
  const saved = loadSaved();
  const isUsableWorld = w => w && Array.isArray(w.buildings) && w.buildings.length > 0;

  if (inTauri) {
    try {
      let t = await withTimeout(readFile('world.json'), 10000, 'user world');
      if (!t && saved.world && isUsableWorld(saved.world)) {
        await writeFile('world.json', JSON.stringify(saved.world, null, 1));
        world = saved.world;
        for (const [id, d] of Object.entries(saved.details || {})) {
          try { await writeBookFile(id, bookDocument(d.title, d.html)); } catch (e) { console.warn('Boek niet verhuisd:', id, e); }
        }
        t = JSON.stringify(saved.world);
      }
      if (t) {
        const parsed = JSON.parse(t);
        if (isUsableWorld(parsed)) world = parsed;
        else console.warn('Gebruikers-world.json is leeg of ongeldig; originele bibliotheek geladen.');
      }
    } catch (e) { console.error('Gebruikersmap lezen mislukt', e); }
  } else {
    if (saved.world && isUsableWorld(saved.world)) world = saved.world;
    else if (saved.world && !isUsableWorld(saved.world)) {
      console.warn('Opgeslagen world in localStorage is leeg; originele bibliotheek geladen.');
    }
    if (saved.details) details = saved.details;
  }
  if (world && world.map) delete world.map;
  try { storeSetWorld(world); } catch (_) {}

  step(35, 'Boeken klaarzetten…', 'gebundelde bestanden');
  try { await withTimeout(exportBundledBooks(), 30000, 'export boeken'); }
  catch (e) { console.warn('exportBundledBooks:', e); }

  step(50, 'Afbeeldingen…', 'gebouwen');
  try { await withTimeout(exportBuildingImages(), 20000, 'export afbeeldingen'); }
  catch (e) { console.warn('exportBuildingImages:', e); }

  step(65, 'Covers laden…', '');
  try { await withTimeout(refreshCovers(), 15000, 'covers'); }
  catch (e) { console.warn('refreshCovers:', e); }

  step(80, 'Eigen boeken zoeken…', 'stadsmap');
  let discovered = [], skipped = [];
  try {
    const r = await withTimeout(discoverUserStad(), 25000, 'stadsmap');
    discovered = r.added || [];
    skipped = r.skipped || [];
  } catch (e) { console.warn('discoverUserStad:', e); }

  step(85, 'Wereld bijwerken…', 'ontbrekende boeken');
  try { await withTimeout(syncWorldWithFiles(), 15000, 'sync wereld'); }
  catch (e) { console.warn('syncWorldWithFiles:', e); }

  step(90, 'Instellingen…', '');
  // Instellingen (thema, lettergrootte, focus) toepassen
  const bootSettings = loadSettings();
  applySettings(bootSettings);
  try { startFpsMonitor(); } catch (_) {}
  try {
    if ((bootSettings.searchIndexMode || 'ondemand') === 'startup') preloadIndexQuiet();
  } catch (_) {}
  // Fase 1: zware mini-apps op de achtergrond voorverwarmen (na splash)
  try {
    const warm = () => {
      try {
        preloadMiniApps(['bible', 'calendar', 'woordenboek', 'notes']);
      } catch (_) {}
    };
    if (typeof requestIdleCallback === 'function') requestIdleCallback(warm, { timeout: 8000 });
    else setTimeout(warm, 2500);
  } catch (_) {}
  // Zorg dat body-klassen van PDF-viewer niet blijven hangen
  document.body.classList.remove('pdf-open');
  document.body.classList.remove('browser-open');
  setOverlay(extra);
  renderWorld();
  wireSearch();
  indexDiscovered(discovered);
  reportSkipped(skipped);
  window.addEventListener('focus', () => {
    try { if (loadSettings().backgroundTasks === false) return; } catch (_) {}
    rescanStad();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) return;
    try { if (loadSettings().backgroundTasks === false) return; } catch (_) {}
    rescanStad();
  });
  wireSettings();
  // Fullscreen + eventuele focusmodus
  await applyFocusMode(bootSettings);
  if (inTauri && !bootSettings.focusMode) {
    try {
      const wantFs = bootSettings.fullscreen !== false;
      const win = getTauriWindow();
      if (win?.setFullscreen) await win.setFullscreen(wantFs);
      if (wantFs && win?.maximize) await win.maximize();
    } catch (e) { console.warn('Fullscreen niet gezet', e); }
  }
  // Focus/studie: eerst documenten laden (focus-study.json / focus-sessions.json)
  await initFocusStorage();
  // Tracken of je op het scherm blijft + studieblokken
  setupPresenceTracking(bootSettings);
  setupSessionHistory(bootSettings);
  try { setSplashProgress(95, 'Bijna klaar…', 'interface'); } catch (_) {}
  wireStudyControls();
  wireGlobalBookLinks();
  try {
    let h = (location.hash || '').slice(1);
    if (!h && bootSettings.restoreSession !== false) {
      h = localStorage.getItem('lc-last-hash') || '';
      if (h) {
        try { history.replaceState(null, '', '#' + h); } catch (_) {}
      }
    }
    if (h) {
      try { localStorage.setItem('lc-last-hash', h); } catch (_) {}
    }
    route(h);
  } catch (_) {
    route((location.hash || '').slice(1));
  }
  // Links tussen boeken (<a href="#id">) werken via de hash.
  window.addEventListener('hashchange', () => {
    const h = (location.hash || '').slice(1);
    try {
      if (loadSettings().restoreSession !== false) localStorage.setItem('lc-last-hash', h);
    } catch (_) {}
    route(h);
    try { refreshBreadcrumbs(); } catch (_) {}
  });
  try { maybeStartOnboarding({ delayMs: 800 }); } catch (_) {}
}

// ---- Aanwezigheid & studie (vernieuwd: betrouwbare opslag + grace period) ----
const presenceSession = {
  id: null,
  started: Date.now(),
  segmentStart: Date.now(),
  focusedMs: 0,
  awayMs: 0,
  awaySince: null,
  leaves: 0
};
let presenceBadgeTimer = null;
let presenceWired = false;
let sessionSaveTimer = null;
let awayGraceTimer = null;
let presenceDirty = false;

/** Gebruikersmodus: study | away | rest (expliciet, niet alleen auto-detectie). */
let userMode = 'study'; // study = ik studeer, away = afwezig, rest = ik rust


function ensureSessionId() {
  if (!presenceSession.id) {
    presenceSession.id = new Date(presenceSession.started).toISOString();
  }
  return presenceSession.id;
}

/** Bouw snapshot van huidige sessie en schrijf weg (localStorage + bestand). */
function persistCurrentSession(forceFlush = false) {
  try {
    const st = loadSettings();
    if (st.saveSessionHistory === false) return;
    if (st.trackPresence === false) return;
    ensureSessionId();
    const now = Date.now();
    let focus = presenceSession.focusedMs;
    let away = presenceSession.awayMs;
    if (presenceSession.awaySince) away += now - presenceSession.awaySince;
    else focus += now - presenceSession.segmentStart;
    upsertSession({
      id: presenceSession.id,
      start: new Date(presenceSession.started).toISOString(),
      end: new Date(now).toISOString(),
      day: todayKey(new Date(presenceSession.started)),
      focusMs: Math.max(0, focus),
      awayMs: Math.max(0, away),
      leaves: presenceSession.leaves || 0
    }, st.sessionHistoryMax);
    presenceDirty = true;
    if (forceFlush) {
      flushFocusStorage().catch(e => console.warn('Sessie flush:', e));
      presenceDirty = false;
    }
  } catch (e) { console.warn('Sessie opslaan:', e); }
}

function setupSessionHistory(st) {
  if (sessionSaveTimer) { clearInterval(sessionSaveTimer); sessionSaveTimer = null; }
  if (!st || st.saveSessionHistory === false) return;
  ensureSessionId();
  persistCurrentSession(true);
  // Elke 3s dirty → flush (betrouwbaarder dan 10s zonder tussentijdse write)
  sessionSaveTimer = setInterval(() => {
    persistCurrentSession(false);
    if (presenceDirty) {
      flushFocusStorage().catch(() => {});
      presenceDirty = false;
    }
  }, 3000);
  const flushNow = () => persistCurrentSession(true);
  window.addEventListener('pagehide', flushNow);
  window.addEventListener('beforeunload', flushNow);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') flushNow();
  });
}





function isPageVisible() {
  return document.visibilityState === 'visible' && document.hasFocus();
}

function markAway() {
  if (presenceSession.awaySince) return;
  const now = Date.now();
  presenceSession.focusedMs += now - presenceSession.segmentStart;
  presenceSession.awaySince = now;
  presenceSession.leaves += 1;
  updatePresenceBadge();
  persistCurrentSession(true);
}

function markPresent() {
  if (awayGraceTimer) { clearTimeout(awayGraceTimer); awayGraceTimer = null; }
  if (!presenceSession.awaySince) return;
  const now = Date.now();
  const awayFor = now - presenceSession.awaySince;
  presenceSession.awayMs += awayFor;
  presenceSession.awaySince = null;
  presenceSession.segmentStart = now;
  updatePresenceBadge();
  persistCurrentSession(true);

  // Geen "Welkom terug"-melding meer bij terugkeer in de bibliotheek
}

/** Grace period: kort wegtappen telt niet meteen als "weg". */
function scheduleAway() {
  if (presenceSession.awaySince || awayGraceTimer) return;
  const st = loadSettings();
  const grace = Number(st.presenceGraceSec);
  const ms = (Number.isFinite(grace) && grace >= 0 ? grace : 8) * 1000;
  if (ms <= 0) { markAway(); return; }
  awayGraceTimer = setTimeout(() => {
    awayGraceTimer = null;
    if (!isPageVisible()) markAway();
  }, ms);
}

function cancelScheduledAway() {
  if (awayGraceTimer) { clearTimeout(awayGraceTimer); awayGraceTimer = null; }
}

function showAwayNotice(_awayFor) {
  // Uitgeschakeld: gebruiker wil deze melding niet
}

function updatePresenceBadge() {
  // Focusblok is een app, niet vast in de header — knop altijd verborgen
  const badge = $('#btn-study');
  if (badge) {
    badge.hidden = true;
    badge.style.display = 'none';
  }
}

function hideModeOverlay() {
  const o = document.getElementById('mode-overlay');
  if (o) {
    if (o._timer) clearInterval(o._timer);
    o.remove();
  }
}

function applyFocusBlockLock() {
  const on = !!(typeof studyBlock !== 'undefined' && studyBlock.active);
  document.body.classList.toggle('focus-block-lock', on);
  const blocked = [
    ['tool-memory', 'Memory'],
    ['tool-snake', 'Slang'],
    ['tool-bke', 'BKE'],
    ['tool-tetris', 'Tetris'],
    ['tool-mastermind', 'Mastermind'],
    ['tool-connect4', '4 op een rij'],
    ['tool-speeltoestel', 'Speeltoestel'],
    ['tool-video', 'Videospeler']
  ];
  blocked.forEach(([id, title]) => {
    const b = document.getElementById(id);
    if (!b) return;
    b.disabled = on;
    b.classList.toggle('tool-locked', on);
    b.title = on ? 'Niet beschikbaar tijdens een focusblok' : title;
  });
  // Muziek blijft altijd beschikbaar
  const audio = document.getElementById('tool-audio');
  if (audio) {
    audio.disabled = false;
    audio.classList.remove('tool-locked');
    audio.title = 'Audiospeler';
  }
  if (on) {
    const hash = (location.hash || '').replace(/^#/, '');
    if (hash === 'memory' || hash === 'snake' || hash === 'bke' || hash === 'tetris' || hash === 'mastermind' || hash === 'connect4' || hash === 'speeltoestel' || hash === 'video') {
      try { showHome(); } catch (_) {}
    }
  }
}

function guardFocusBlock(kind, openFn) {
  return (...args) => {
    if (studyBlock.active) {
      try {
        ask('Tijdens een focusblok kun je dit niet openen.\n\nMuziek mag wel. Stop het blok via Studie als je klaar bent.', { yes: 'OK' });
      } catch (_) {
        alert('Niet beschikbaar tijdens een focusblok.');
      }
      return;
    }
    return openFn(...args);
  };
}

function setupPresenceTracking(st) {
  const on = !st || st.trackPresence !== false;
  if (!on) {
    cancelScheduledAway();
    if (presenceBadgeTimer) { clearInterval(presenceBadgeTimer); presenceBadgeTimer = null; }
    updatePresenceBadge();
    return;
  }
  if (!presenceWired) {
    presenceWired = true;
    document.addEventListener('visibilitychange', () => {
      if (loadSettings().trackPresence === false) return;
      if (document.visibilityState === 'hidden') scheduleAway();
      else { cancelScheduledAway(); markPresent(); }
    });
    window.addEventListener('blur', () => {
      if (loadSettings().trackPresence === false) return;
      // Alleen als tab nog zichtbaar is maar focus kwijt (ander venster)
      if (document.visibilityState === 'visible') scheduleAway();
    });
    window.addEventListener('focus', () => {
      if (loadSettings().trackPresence === false) return;
      cancelScheduledAway();
      if (document.visibilityState === 'visible') markPresent();
    });
  }
  if (!presenceBadgeTimer) {
    presenceBadgeTimer = setInterval(updatePresenceBadge, 1000);
  }
  updatePresenceBadge();
}

// studyBlock: live uit focusApi (fase 2)
function getStudyBlock() {
  try { wireUiModules(); return focusApi.studyBlock; } catch (_) { return { active: false, remainingMs: 0, paused: false }; }
}
const studyBlock = new Proxy({}, {
  get(_t, prop) {
    if (prop === 'active' || prop === 'remainingMs' || prop === 'paused' || prop === 'targetMs' || prop === 'focusedMs' || prop === 'lastTick' || prop === 'timerId') {
      return getStudyBlock()[prop];
    }
    const b = getStudyBlock();
    const v = b[prop];
    return typeof v === 'function' ? v.bind(b) : v;
  },
  set(_t, prop, value) {
    getStudyBlock()[prop] = value;
    return true;
  }
});

function updateStudyUI() {
  try { wireUiModules(); if (focusApi.updateStudyUI) focusApi.updateStudyUI(); } catch (_) {}
}
function startStudyBlock(minutes) {
  wireUiModules();
  return focusApi.startStudyBlock(minutes);
}
function completeStudyBlock() {
  wireUiModules();
  return focusApi.completeStudyBlock();
}
function wireStudyControls() {
  wireUiModules();
  try {
    if (focusApi.wireStudyControls) { focusApi.wireStudyControls(); return; }
  } catch (_) {}
  const btn = document.getElementById('btn-study');
  if (btn) btn.onclick = () => { try { showFocus(); } catch (e) { console.warn(e); } };
}





async function stopStudyBlock() {
  if (!studyBlock.active) return;
  const done = studyBlock.focusedMs;
  const target = studyBlock.targetMs;
  // Bij ≥85%: aanbieden om als voltooid te tellen
  if (done >= target * 0.85) {
    const choice = await ask(
      `Je had ${fmtDuration(done)} van de ${fmtDuration(target)}.\n\nAls voltooid tellen?`,
      { yes: 'Voltooien', no: 'Toch stoppen' }
    );
    if (choice) {
      completeStudyBlock();
      return;
    }
  } else {
    const ok = await ask(
      `Studieblok stoppen?\n\n${fmtDuration(done)} echte focustijd van ${fmtDuration(target)}.`,
      { yes: 'Stoppen', no: 'Doorgaan' }
    );
    if (!ok) return;
  }
  if (studyBlock.timerId) clearInterval(studyBlock.timerId);
  studyBlock.active = false;
  studyBlock.timerId = null;
  updateStudyUI();
  persistCurrentSession(true);
}


function showStudyReward(focusedMs, targetMs, stats) {
  if (document.querySelector('.study-reward')) return;
  const box = el('div', 'study-reward');
  box.setAttribute('role', 'status');
  const title = el('strong', '', 'Blok gehaald');
  const body = el('span', '',
    `${fmtDuration(focusedMs)} focus` +
    (stats.streak > 1 ? ` · streak ${stats.streak} dagen` : ' · goed gedaan!')
  );
  const sub = el('span', 'study-reward-sub',
    `Totaal: ${stats.totalBlocks} blok${stats.totalBlocks === 1 ? '' : 'ken'} · ${fmtDuration(stats.totalFocusMs)}`
  );
  box.append(title, body, sub);
  const newly = stats._newlyUnlocked || [];
  if (newly.length) {
    const achLine = el('div', 'study-reward-ach');
    newly.forEach(a => {
      const chip = el('span', 'study-reward-chip', `${a.icon} ${a.title}`);
      achLine.append(chip);
    });
    box.append(achLine);
  }
  const dismiss = el('button', 'away-notice-x', '×');
  dismiss.type = 'button';
  dismiss.setAttribute('aria-label', 'Sluiten');
  dismiss.onclick = () => box.remove();
  box.append(dismiss);
  document.body.append(box);
  setTimeout(() => { if (box.parentNode) box.remove(); }, 12000);
}



/** Taartdiagram focus vs niet-focus (CSS conic-gradient). */
function makePieChart(focusMs, awayMs, caption) {
  const wrap = el('div', 'focus-pie');
  const tot = Math.max(1, (focusMs || 0) + (awayMs || 0));
  const pct = Math.round(((focusMs || 0) / tot) * 100);
  const chart = el('div', 'focus-pie-chart');
  chart.style.background = `conic-gradient(var(--acc) 0% ${pct}%, var(--line) ${pct}% 100%)`;
  chart.setAttribute('aria-label', `${pct} procent focus`);
  const legend = el('div', 'focus-pie-legend');
  legend.append(
    el('div', 'focus-pie-cap', caption || ''),
    el('div', 'focus-pie-pct', pct + '%'),
    el('div', 'focus-pie-row', `● Focus ${fmtDuration(focusMs || 0)}`),
    el('div', 'focus-pie-row is-mute', `● Weg ${fmtDuration(awayMs || 0)}`)
  );
  wrap.append(chart, legend);
  return wrap;
}

function showSessionDetail(ses) {
  const start = new Date(ses.start || ses.id);
  const title = ses._dayLabel
    || start.toLocaleString('nl-BE', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  const back = document.createElement('div');
  back.className = 'dlg-back';
  const box = document.createElement('div');
  box.className = 'dlg focus-session-dlg';
  box.setAttribute('role', 'dialog');
  const h = document.createElement('p');
  h.style.fontWeight = '700';
  h.textContent = title;
  box.append(h);
  const pie = makePieChart(ses.focusMs || 0, ses.awayMs || 0, ses._dayLabel ? 'Hele dag — focus / niet-focus' : 'Sessie — focus / niet-focus');
  box.append(pie);
  const meta = document.createElement('p');
  meta.className = 'settings-hint';
  meta.textContent = `Weggeklikt: ${ses.leaves || 0}× · Duur: ${fmtDuration((ses.focusMs || 0) + (ses.awayMs || 0))}`;
  box.append(meta);
  const ok = document.createElement('button');
  ok.className = 'dlg-ok';
  ok.textContent = 'Sluiten';
  ok.onclick = () => back.remove();
  const row = document.createElement('div');
  row.className = 'dlg-row';
  row.append(ok);
  box.append(row);
  back.append(box);
  back.addEventListener('click', e => { if (e.target === back) back.remove(); });
  document.body.append(back);
  ok.focus();
}

/** Studie-menu: alles op één scherm (compact dashboard, geen scroll). */
function showFocus() {
  wireUiModules();
  return focusApi.showFocus();
}

// ---- Focusmodus: fullscreen, vooraan, bevestiging bij afsluiten ----
let focusCloseUnlisten = null;
let focusBeforeUnload = null;

async function applyFocusMode(st) {
  const on = !!(st && st.focusMode);
  applySettings(st || loadSettings());

  // Browser: waarschuwing bij tab/venster sluiten
  if (focusBeforeUnload) {
    window.removeEventListener('beforeunload', focusBeforeUnload);
    focusBeforeUnload = null;
  }
  if (on) {
    focusBeforeUnload = e => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', focusBeforeUnload);
  }

  if (!inTauri) return;

  const win = getTauriWindow();
  if (!win) return;

  try {
    if (on) {
      if (win.setFullscreen) await win.setFullscreen(true);
      if (win.setAlwaysOnTop) await win.setAlwaysOnTop(true);
      // Geen vensterknoppen → minder makkelijk per ongeluk wegklikken
      if (win.setDecorations) await win.setDecorations(false);
    } else {
      if (win.setAlwaysOnTop) await win.setAlwaysOnTop(false);
      if (win.setDecorations) await win.setDecorations(true);
      const wantFs = (st || loadSettings()).fullscreen !== false;
      if (win.setFullscreen) await win.setFullscreen(!!wantFs);
    }
  } catch (e) { console.warn('Focusmodus venster:', e); }

  // Afsluiten alleen na bevestiging
  if (focusCloseUnlisten) {
    try { focusCloseUnlisten(); } catch (e) {}
    focusCloseUnlisten = null;
  }
  if (on && typeof win.onCloseRequested === 'function') {
    try {
      focusCloseUnlisten = await win.onCloseRequested(async (event) => {
        event.preventDefault();
        const ok = await ask(
          'Focusmodus staat aan.\n\nWil je Bibliotheek Leo Crucis echt afsluiten?',
          { yes: 'Afsluiten', no: 'Blijven' }
        );
        if (ok) {
          try {
            // Tijdelijk listener loskoppelen zodat close doorgaat
            if (focusCloseUnlisten) { try { focusCloseUnlisten(); } catch (e) {} focusCloseUnlisten = null; }
            if (win.destroy) await win.destroy();
            else if (win.close) await win.close();
          } catch (e) { console.warn(e); }
        }
      });
    } catch (e) { console.warn('onCloseRequested niet beschikbaar:', e); }
  }
}

async function route(hash) {
  if (hash === 'settings' || hash === 'instellingen') { showSettings(); return; }
  if (hash === 'focus' || hash === 'studie') { showFocus(); return; }
  if (hash === 'zoek' || hash === 'search') { showResults(''); return; }
  if (hash === 'audio' || hash === 'video') { showMediaPlayer(hash); return; }
  // Splitscreen-hash: #bible+notes of #notes+woordenboek
  if (hash && hash.includes('+')) {
    const parts = hash.split('+').map(s => s.trim().toLowerCase()).filter(Boolean);
    const norm = k => (k === 'bijbel' ? 'bible' : k);
    const valid = new Set(['calendar', 'notes', 'budgetter', 'todo', 'timer', 'calculator', 'browser', 'bible', 'woordenboek', 'memory', 'snake', 'bke', 'tetris', 'mastermind', 'connect4', 'speeltoestel', 'gallery', 'album', 'maps']);
    const kinds = parts.map(norm).filter(k => valid.has(k));
    if (kinds.length >= 1) {
      wireUiModules();
      if (miniApi) {
        miniApi.splitLeft = { kind: kinds[0], startPos: null };
        miniApi.splitRight = kinds.length >= 2 ? { kind: kinds[1], startPos: null } : null;
      } else {
        splitLeft = { kind: kinds[0], startPos: null };
        splitRight = kinds.length >= 2 ? { kind: kinds[1], startPos: null } : null;
      }
      currentSection = null;
      document.body.classList.remove('pdf-open');
      document.body.classList.add('browser-open');
      renderMiniAppView();
      return;
    }
  }
  if (hash === 'calendar' || hash === 'notes' || hash === 'budgetter' || hash === 'todo' || hash === 'timer' || hash === 'calculator' || hash === 'browser' || hash === 'bible' || hash === 'bijbel' || hash === 'woordenboek' || hash === 'memory' || hash === 'snake' || hash === 'bke' || hash === 'tetris' || hash === 'mastermind' || hash === 'connect4' || hash === 'speeltoestel' || hash === 'gallery' || hash === 'album' || hash === 'maps') {
    const app = hash === 'bijbel' ? 'bible' : hash;
    showMiniApp(app);
    try { refreshBreadcrumbs(); } catch (_) {}
    return;
  }
  if (hash === 'browser' || hash.startsWith('browser?')) {
    const q = hash.includes('?') ? hash.split('?')[1] : '';
    const params = new URLSearchParams(q);
    showInAppBrowser(params.get('url') || 'https://');
    return;
  }
  if (hash && (allItems().some(i => i.id === hash) || await loadBook(hash))) showSection(hash); else showHome();
}

init();
