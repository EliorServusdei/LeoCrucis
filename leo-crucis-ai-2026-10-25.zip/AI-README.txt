Leo Crucis — AI-werkzip
========================
Gegenereerd: 2026-10-25T23:13:54.414Z
Bestanden:   214
Grootte:     ca. 3.78 MB

Bewust weggelaten (te groot / niet nodig voor codewerk):
  - node_modules/
  - src/data/woordenboek/   (volledige woordenboek-JSON's)
  - src/data/bijbel/        (volledige bijbelvertalingen)
  - src/assets/             (afbeeldingen, tilesets, video)
  - src/vendor/             (minified third-party bundles)
  - media/
  - src-tauri/icons/, gen/, target/
  - .png .jpg .mp4 .pdf .icns .node
  - bestanden > 400 KB (zware inhouds-HTML), tenzij --include-large

Bij een bug in laden/parsen van woordenboek of bijbel: stuur
apart een klein sample (1 letter-JSON of 1 bijbelboek) mee.
