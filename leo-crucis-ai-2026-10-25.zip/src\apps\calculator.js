/**
 * Grafische / wetenschappelijke rekenmachine — Leo Crucis.
 * Expressies met cursor, geschiedenis (localStorage), geheugen,
 * meerdere functie-grafieken, nulpunten, tabel, PNG-export.
 */

function el(tag, className, text) {
  const n = document.createElement(tag);
  if (className) n.className = className;
  if (text != null) n.textContent = text;
  return n;
}

function formatNum(n) {
  if (n == null || Number.isNaN(n)) return 'Fout';
  if (!Number.isFinite(n)) return n > 0 ? '∞' : '-∞';
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e10 || abs < 1e-7)) {
    return n.toExponential(6).replace(/\.?0+e/, 'e');
  }
  let s = Number(n.toPrecision(12)).toString();
  if (s.includes('e')) return s;
  if (s.includes('.')) s = s.replace(/\.?0+$/, '');
  return s || '0';
}

function factorial(n) {
  if (n < 0 || !Number.isFinite(n)) return NaN;
  if (Math.abs(n - Math.round(n)) > 1e-9) return NaN;
  n = Math.round(n);
  if (n > 170) return Infinity;
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

function combinations(n, k) {
  if (!Number.isFinite(n) || !Number.isFinite(k)) return NaN;
  n = Math.round(n);
  k = Math.round(k);
  if (n < 0 || k < 0 || k > n) return NaN;
  if (k > n - k) k = n - k;
  let r = 1;
  for (let i = 0; i < k; i++) {
    r = (r * (n - i)) / (i + 1);
  }
  return Math.round(r);
}

const CONSTANTS = {
  pi: Math.PI,
  e: Math.E,
  phi: (1 + Math.sqrt(5)) / 2,
  c: 299792458,
  g: 9.80665,
  h: 6.62607015e-34,
  k: 1.380649e-23,
  na: 6.02214076e23
};

function tokenize(src) {
  const s = String(src)
    .replace(/\s+/g, '')
    .replace(/×/g, '*')
    .replace(/÷/g, '/')
    .replace(/π/g, 'pi')
    .replace(/φ/g, 'phi');
  const tokens = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (/[0-9.]/.test(c)) {
      let j = i + 1;
      while (j < s.length && /[0-9.]/.test(s[j])) j++;
      tokens.push({ type: 'num', value: parseFloat(s.slice(i, j)) });
      i = j;
      continue;
    }
    if (/[a-zA-Z]/.test(c)) {
      let j = i + 1;
      while (j < s.length && /[a-zA-Z0-9]/.test(s[j])) j++;
      tokens.push({ type: 'id', value: s.slice(i, j).toLowerCase() });
      i = j;
      continue;
    }
    if (c === '!') {
      tokens.push({ type: 'op', value: '!' });
      i++;
      continue;
    }
    if ('+-*/^(),%'.includes(c)) {
      tokens.push({ type: 'op', value: c });
      i++;
      continue;
    }
    throw new Error('Onbekend teken: ' + c);
  }
  return tokens;
}

function parseExpression(src, vars = {}) {
  const tokens = tokenize(src);
  let pos = 0;
  const peek = () => tokens[pos];
  const take = () => tokens[pos++];

  function parsePrimary() {
    const t = peek();
    if (!t) throw new Error('Onvolledige expressie');
    if (t.type === 'num') {
      take();
      let v = t.value;
      while (peek() && peek().type === 'op' && peek().value === '!') {
        take();
        v = factorial(v);
      }
      return v;
    }
    if (t.type === 'id') {
      take();
      const name = t.value;
      if (CONSTANTS[name] != null) {
        let v = CONSTANTS[name];
        while (peek() && peek().type === 'op' && peek().value === '!') {
          take();
          v = factorial(v);
        }
        return v;
      }
      if (name === 'x' && vars.x != null) {
        let v = vars.x;
        while (peek() && peek().type === 'op' && peek().value === '!') {
          take();
          v = factorial(v);
        }
        return v;
      }
      if (peek() && peek().type === 'op' && peek().value === '(') {
        take();
        const args = [];
        if (peek() && !(peek().type === 'op' && peek().value === ')')) {
          args.push(parseExpr());
          while (peek() && peek().type === 'op' && peek().value === ',') {
            take();
            args.push(parseExpr());
          }
        }
        if (!peek() || peek().value !== ')') throw new Error('Haakje ontbreekt');
        take();
        let r;
        if (name === 'ncr' || name === 'c') {
          if (args.length !== 2) throw new Error('nCr verwacht 2 argumenten');
          r = combinations(args[0], args[1]);
        } else if (name === 'fact' || name === 'factorial') {
          if (args.length !== 1) throw new Error('fact verwacht 1 argument');
          r = factorial(args[0]);
        } else {
          const fn = {
            sin: Math.sin, cos: Math.cos, tan: Math.tan,
            asin: Math.asin, acos: Math.acos, atan: Math.atan,
            sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh,
            log: Math.log10, ln: Math.log, sqrt: Math.sqrt, abs: Math.abs,
            exp: Math.exp, floor: Math.floor, ceil: Math.ceil, round: Math.round,
            mod: (a, b) => ((a % b) + b) % b
          }[name];
          if (!fn) throw new Error('Onbekende functie: ' + name);
          if (name === 'mod') {
            if (args.length !== 2) throw new Error('mod verwacht 2 argumenten');
            r = fn(args[0], args[1]);
          } else {
            if (args.length !== 1) throw new Error(name + ' verwacht 1 argument');
            const degFns = new Set(['sin', 'cos', 'tan']);
            const invDeg = new Set(['asin', 'acos', 'atan']);
            let a = args[0];
            if (vars.deg && degFns.has(name)) a = (args[0] * Math.PI) / 180;
            r = fn(a);
            if (vars.deg && invDeg.has(name)) r = (r * 180) / Math.PI;
          }
        }
        while (peek() && peek().type === 'op' && peek().value === '!') {
          take();
          r = factorial(r);
        }
        return r;
      }
      throw new Error('Onbekende naam: ' + name);
    }
    if (t.type === 'op' && t.value === '(') {
      take();
      let v = parseExpr();
      if (!peek() || peek().value !== ')') throw new Error('Haakje ontbreekt');
      take();
      while (peek() && peek().type === 'op' && peek().value === '!') {
        take();
        v = factorial(v);
      }
      return v;
    }
    if (t.type === 'op' && t.value === '-') {
      take();
      return -parsePrimary();
    }
    if (t.type === 'op' && t.value === '+') {
      take();
      return parsePrimary();
    }
    throw new Error('Onverwacht: ' + (t.value || t.type));
  }

  function parsePower() {
    let left = parsePrimary();
    while (peek() && peek().type === 'op' && peek().value === '^') {
      take();
      const right = parsePower();
      left = Math.pow(left, right);
    }
    return left;
  }

  function parseMul() {
    let left = parsePower();
    while (peek() && peek().type === 'op' && '*/%'.includes(peek().value)) {
      const o = take().value;
      const right = parsePower();
      if (o === '*') left *= right;
      else if (o === '/') left = left / right;
      else left = ((left % right) + right) % right;
    }
    return left;
  }

  function parseExpr() {
    let left = parseMul();
    while (peek() && peek().type === 'op' && (peek().value === '+' || peek().value === '-')) {
      const o = take().value;
      const right = parseMul();
      left = o === '+' ? left + right : left - right;
    }
    return left;
  }

  const result = parseExpr();
  if (pos < tokens.length) throw new Error('Extra invoer');
  return result;
}

function niceStep(range) {
  const rough = Math.abs(range) / 8;
  if (!rough || !Number.isFinite(rough)) return 1;
  const pow = Math.pow(10, Math.floor(Math.log10(rough)));
  const n = rough / pow;
  let step;
  if (n < 1.5) step = 1;
  else if (n < 3) step = 2;
  else if (n < 7) step = 5;
  else step = 10;
  return step * pow;
}

function formatTick(v) {
  if (!Number.isFinite(v)) return '';
  if (Math.abs(v) < 1e-10) return '0';
  if (Math.abs(v) >= 1e6 || (Math.abs(v) > 0 && Math.abs(v) < 1e-3)) return v.toExponential(1);
  const r = Math.round(v * 1e8) / 1e8;
  return String(r);
}

const HIST_KEY = 'leo-crucis-calc-history';
const CURVE_COLORS = ['#7a1f2b', '#1f5a7a', '#2b7a1f'];

function loadHistory() {
  try {
    const raw = localStorage.getItem(HIST_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.slice(-40) : [];
  } catch (_) {
    return [];
  }
}

function saveHistory(hist) {
  try {
    localStorage.setItem(HIST_KEY, JSON.stringify(hist.slice(-40)));
  } catch (_) {}
}

export function createCalculatorApp() {
  const root = el('div', 'app-panel mini-app-root calc-app calc-app-pro');
  root.setAttribute('data-kind', 'calculator');
  root.setAttribute('aria-label', 'Grafische rekenmachine');

  let memory = 0;
  let deg = true;
  let history = loadHistory();
  let mode = 'calc';
  let destroyed = false;

  // Graph view state
  let gxmin = -360;
  let gxmax = 360;
  let gymin = -1.5;
  let gymax = 1.5;
  let autoY = true;
  let hover = null; // {x, ys: [{y, color}], px, pys}
  let showRoots = true;
  let showTable = false;

  const head = el('div', 'calc-pro-head');
  head.append(el('h1', 'calc-pro-title', 'Rekenmachine'));
  const modeBar = el('div', 'calc-pro-modes');
  const modeCalc = el('button', 'calc-pro-mode is-active', 'Rekenen');
  modeCalc.type = 'button';
  modeCalc.setAttribute('aria-label', 'Rekenmodus');
  const modeGraph = el('button', 'calc-pro-mode', 'Grafiek');
  modeGraph.type = 'button';
  modeGraph.setAttribute('aria-label', 'Grafiekmodus');
  modeBar.append(modeCalc, modeGraph);
  head.append(modeBar);
  root.append(head);

  /* —— CALC —— */
  const calcPanel = el('div', 'calc-pro-panel');
  const layout = el('div', 'calc-pro-layout');
  const mainCol = el('div', 'calc-pro-main');
  const screen = el('div', 'calc-pro-screen');
  const memLine = el('div', 'calc-pro-mem', 'M: —');
  memLine.setAttribute('aria-live', 'polite');

  const exprIn = el('input', 'calc-pro-expr-input');
  exprIn.type = 'text';
  exprIn.value = '';
  exprIn.placeholder = '0';
  exprIn.setAttribute('aria-label', 'Expressie');
  exprIn.setAttribute('autocomplete', 'off');
  exprIn.setAttribute('spellcheck', 'false');
  exprIn.inputMode = 'none';

  screen.append(memLine, exprIn);
  mainCol.append(screen);

  const angleBar = el('div', 'calc-pro-angle');
  const degBtn = el('button', 'calc-pro-angle-btn is-active', 'DEG');
  degBtn.type = 'button';
  degBtn.setAttribute('aria-label', 'Graden');
  const radBtn = el('button', 'calc-pro-angle-btn', 'RAD');
  radBtn.type = 'button';
  radBtn.setAttribute('aria-label', 'Radialen');
  angleBar.append(degBtn, radBtn);
  mainCol.append(angleBar);

  const pad = el('div', 'calc-pro-pad calc-pro-pad-wide');
  mainCol.append(pad);

  const sideCol = el('div', 'calc-pro-side');
  sideCol.append(el('h2', 'calc-pro-side-title', 'Geschiedenis'));
  const histList = el('ul', 'calc-pro-hist');
  sideCol.append(histList);
  const clearHist = el('button', 'calc-pro-link', 'Geschiedenis wissen');
  clearHist.type = 'button';
  clearHist.setAttribute('aria-label', 'Geschiedenis wissen');
  sideCol.append(clearHist);

  layout.append(mainCol, sideCol);
  calcPanel.append(layout);
  root.append(calcPanel);

  /* —— GRAPH —— */
  const graphPanel = el('div', 'calc-pro-panel calc-graph-panel');
  graphPanel.hidden = true;
  graphPanel.style.display = 'none';

  const graphToolbar = el('div', 'calc-graph-toolbar');
  const fxList = el('div', 'calc-graph-fx-list');

  function makeFxRow(idx, defaultVal) {
    const row = el('div', 'calc-graph-fx');
    const lab = el('span', 'calc-graph-yeq', idx === 0 ? 'y₁ =' : idx === 1 ? 'y₂ =' : 'y₃ =');
    lab.style.color = CURVE_COLORS[idx];
    const inp = el('input', 'calc-graph-input');
    inp.type = 'text';
    inp.value = defaultVal;
    inp.placeholder = idx === 0 ? 'sin(x), x^2, …' : 'optioneel';
    inp.setAttribute('aria-label', `Functie y${idx + 1} van x`);
    inp.dataset.idx = String(idx);
    row.append(lab, inp);
    return { row, inp };
  }

  const fxRows = [
    makeFxRow(0, 'sin(x)'),
    makeFxRow(1, ''),
    makeFxRow(2, '')
  ];
  fxRows.forEach((r) => fxList.append(r.row));

  const plotBtn = el('button', 'calc-pro-primary', 'Teken');
  plotBtn.type = 'button';
  plotBtn.setAttribute('aria-label', 'Grafiek tekenen');
  const autoBtn = el('button', 'calc-pro-mode is-active', 'Auto-Y');
  autoBtn.type = 'button';
  autoBtn.title = 'Y-as automatisch schalen';
  autoBtn.setAttribute('aria-label', 'Automatische Y-schaal');
  const resetViewBtn = el('button', 'calc-pro-mode', 'Reset zoom');
  resetViewBtn.type = 'button';
  resetViewBtn.setAttribute('aria-label', 'Zoom resetten');
  const rootsBtn = el('button', 'calc-pro-mode is-active', 'Nulpunten');
  rootsBtn.type = 'button';
  rootsBtn.title = 'Toon nulpunten (y ≈ 0)';
  rootsBtn.setAttribute('aria-label', 'Nulpunten tonen');
  const tableBtn = el('button', 'calc-pro-mode', 'Tabel');
  tableBtn.type = 'button';
  tableBtn.setAttribute('aria-label', 'Waardetabel tonen');
  const exportBtn = el('button', 'calc-pro-mode', 'PNG');
  exportBtn.type = 'button';
  exportBtn.title = 'Grafiek exporteren als PNG';
  exportBtn.setAttribute('aria-label', 'Grafiek als PNG exporteren');

  graphToolbar.append(fxList, plotBtn, autoBtn, resetViewBtn, rootsBtn, tableBtn, exportBtn);

  const presets = el('div', 'calc-graph-presets');
  const PRESETS = [
    ['sin(x)', 'sin'],
    ['cos(x)', 'cos'],
    ['tan(x)', 'tan'],
    ['x^2', 'x²'],
    ['x^3', 'x³'],
    ['abs(x)', '|x|'],
    ['sqrt(x)', '√x'],
    ['ln(x)', 'ln'],
    ['1/x', '1/x'],
    ['x*sin(x)', 'x·sin'],
    ['sin(x),cos(x)', 'sin+cos']
  ];
  for (const [fn, lab] of PRESETS) {
    const b = el('button', 'calc-graph-preset', lab);
    b.type = 'button';
    b.dataset.fn = fn;
    b.setAttribute('aria-label', 'Preset ' + lab);
    presets.append(b);
  }

  const rangeRow = el('div', 'calc-graph-range');
  const xMin = el('input', 'calc-graph-num');
  xMin.type = 'number';
  xMin.step = 'any';
  xMin.setAttribute('aria-label', 'x minimum');
  const xMax = el('input', 'calc-graph-num');
  xMax.type = 'number';
  xMax.step = 'any';
  xMax.setAttribute('aria-label', 'x maximum');
  const yMin = el('input', 'calc-graph-num');
  yMin.type = 'number';
  yMin.step = 'any';
  yMin.setAttribute('aria-label', 'y minimum');
  const yMax = el('input', 'calc-graph-num');
  yMax.type = 'number';
  yMax.step = 'any';
  yMax.setAttribute('aria-label', 'y maximum');
  function syncRangeInputs() {
    xMin.value = String(Number(gxmin.toPrecision(6)));
    xMax.value = String(Number(gxmax.toPrecision(6)));
    yMin.value = String(Number(gymin.toPrecision(6)));
    yMax.value = String(Number(gymax.toPrecision(6)));
    yMin.disabled = autoY;
    yMax.disabled = autoY;
  }
  rangeRow.append(
    el('span', 'calc-graph-rlab', 'x'), xMin, el('span', '', '→'), xMax,
    el('span', 'calc-graph-rlab', 'y'), yMin, el('span', '', '→'), yMax
  );
  const applyRange = el('button', 'calc-pro-mode', 'Pas toe');
  applyRange.type = 'button';
  applyRange.setAttribute('aria-label', 'Bereik toepassen');
  rangeRow.append(applyRange);

  const canvasWrap = el('div', 'calc-graph-canvas-wrap');
  const canvas = el('canvas', 'calc-graph-canvas');
  canvas.setAttribute('aria-label', 'Functiegrafiek');
  canvasWrap.append(canvas);
  const readOut = el('div', 'calc-graph-readout', 'Scroll = zoom · sleep = verschuif · hover = coördinaten');
  const graphMsg = el('div', 'calc-graph-msg', '');

  const tableWrap = el('div', 'calc-graph-table-wrap');
  tableWrap.hidden = true;
  tableWrap.style.display = 'none';
  const tableEl = el('table', 'calc-graph-table');
  tableWrap.append(tableEl);

  graphPanel.append(graphToolbar, presets, rangeRow, canvasWrap, readOut, graphMsg, tableWrap);
  root.append(graphPanel);

  function getExpr() {
    return exprIn.value;
  }
  function setExpr(s) {
    exprIn.value = s;
  }
  function insertAtCursor(tok) {
    const start = exprIn.selectionStart ?? exprIn.value.length;
    const end = exprIn.selectionEnd ?? exprIn.value.length;
    const v = exprIn.value;
    const before = v.slice(0, start);
    const after = v.slice(end);
    // Clear error states
    let base = before;
    if (base === 'Fout' || base === '∞' || base === '-∞') base = '';
    exprIn.value = base + tok + after;
    const pos = base.length + tok.length;
    exprIn.focus();
    exprIn.setSelectionRange(pos, pos);
  }
  function backspaceAtCursor() {
    const start = exprIn.selectionStart ?? 0;
    const end = exprIn.selectionEnd ?? 0;
    const v = exprIn.value;
    if (v === 'Fout' || v === '∞' || v === '-∞') {
      exprIn.value = '';
      return;
    }
    if (start !== end) {
      exprIn.value = v.slice(0, start) + v.slice(end);
      exprIn.setSelectionRange(start, start);
    } else if (start > 0) {
      exprIn.value = v.slice(0, start - 1) + v.slice(start);
      exprIn.setSelectionRange(start - 1, start - 1);
    }
    exprIn.focus();
  }

  function defaultWindow() {
    if (deg) {
      gxmin = -360;
      gxmax = 360;
      gymin = -1.5;
      gymax = 1.5;
    } else {
      gxmin = -2 * Math.PI;
      gxmax = 2 * Math.PI;
      gymin = -1.5;
      gymax = 1.5;
    }
    autoY = true;
    autoBtn.classList.add('is-active');
  }

  function paintMem() {
    memLine.textContent = memory !== 0 ? `M: ${formatNum(memory)}` : 'M: —';
  }
  function paintHist() {
    histList.replaceChildren();
    if (!history.length) {
      histList.append(el('li', 'calc-pro-hist-empty', 'Nog geen berekeningen'));
      return;
    }
    history.slice().reverse().forEach((h) => {
      const li = el('li', 'calc-pro-hist-item');
      const a = el('button', 'calc-pro-hist-btn');
      a.type = 'button';
      a.textContent = `${h.expr} = ${h.result}`;
      a.setAttribute('aria-label', `Gebruik resultaat ${h.result}`);
      a.onclick = () => {
        setExpr(h.result);
        exprIn.focus();
        const len = exprIn.value.length;
        exprIn.setSelectionRange(len, len);
      };
      li.append(a);
      histList.append(li);
    });
  }
  function pushHist(e, r) {
    history.push({ expr: e, result: r });
    if (history.length > 40) history.shift();
    saveHistory(history);
    paintHist();
  }
  function clearAll() {
    setExpr('');
    exprIn.focus();
  }
  function evaluate() {
    const expr = getExpr().trim();
    if (!expr) return;
    try {
      const v = parseExpression(expr, { deg });
      const r = formatNum(v);
      pushHist(expr, r);
      setExpr(r);
      const len = r.length;
      exprIn.setSelectionRange(len, len);
    } catch (_) {
      setExpr('Fout');
    }
  }
  function setMode(m) {
    mode = m;
    modeCalc.classList.toggle('is-active', m === 'calc');
    modeGraph.classList.toggle('is-active', m === 'graph');
    const showCalc = m === 'calc';
    const showGraph = m === 'graph';
    calcPanel.hidden = !showCalc;
    graphPanel.hidden = !showGraph;
    calcPanel.style.display = showCalc ? '' : 'none';
    graphPanel.style.display = showGraph ? 'flex' : 'none';
    if (showGraph) {
      if (!(gxmax > gxmin) || (gxmax - gxmin) < 1e-9) defaultWindow();
      requestAnimationFrame(() => {
        resizeCanvas();
        drawGraph();
      });
    }
  }

  modeCalc.onclick = () => setMode('calc');
  modeGraph.onclick = () => setMode('graph');
  degBtn.onclick = () => {
    deg = true;
    degBtn.classList.add('is-active');
    radBtn.classList.remove('is-active');
    if (mode === 'graph') drawGraph();
  };
  radBtn.onclick = () => {
    deg = false;
    radBtn.classList.add('is-active');
    degBtn.classList.remove('is-active');
    if (mode === 'graph') drawGraph();
  };
  clearHist.onclick = () => {
    history = [];
    saveHistory(history);
    paintHist();
  };

  const keys = [
    { t: 'MC', k: 'memc', cls: 'is-fn', aria: 'Geheugen wissen' },
    { t: 'MR', k: 'memr', cls: 'is-fn', aria: 'Geheugen ophalen' },
    { t: 'M+', k: 'memp', cls: 'is-fn', aria: 'Geheugen optellen' },
    { t: 'M−', k: 'memm', cls: 'is-fn', aria: 'Geheugen aftrekken' },
    { t: 'sin', k: 'fn', v: 'sin(', aria: 'sinus' },
    { t: 'cos', k: 'fn', v: 'cos(', aria: 'cosinus' },
    { t: 'tan', k: 'fn', v: 'tan(', aria: 'tangens' },
    { t: 'π', k: 'tok', v: 'π', aria: 'pi' },
    { t: 'asin', k: 'fn', v: 'asin(', aria: 'arcsinus' },
    { t: 'acos', k: 'fn', v: 'acos(', aria: 'arccosinus' },
    { t: 'atan', k: 'fn', v: 'atan(', aria: 'arctangens' },
    { t: 'e', k: 'tok', v: 'e', aria: 'e' },
    { t: 'ln', k: 'fn', v: 'ln(', aria: 'natuurlijk logaritme' },
    { t: 'log', k: 'fn', v: 'log(', aria: 'logaritme basis 10' },
    { t: '√', k: 'fn', v: 'sqrt(', aria: 'wortel' },
    { t: 'n!', k: 'fn', v: '!', aria: 'faculteit' },
    { t: '(', k: 'tok', v: '(', aria: 'haakje open' },
    { t: ')', k: 'tok', v: ')', aria: 'haakje sluit' },
    { t: '^', k: 'tok', v: '^', aria: 'macht' },
    { t: '÷', k: 'tok', v: '÷', cls: 'is-op', aria: 'delen' },
    { t: 'nCr', k: 'fn', v: 'nCr(', aria: 'combinaties' },
    { t: 'mod', k: 'fn', v: 'mod(', aria: 'modulo' },
    { t: '%', k: 'tok', v: '%', aria: 'procent of modulo' },
    { t: '×', k: 'tok', v: '×', cls: 'is-op', aria: 'vermenigvuldigen' },
    { t: '7', k: 'tok', v: '7' },
    { t: '8', k: 'tok', v: '8' },
    { t: '9', k: 'tok', v: '9' },
    { t: '−', k: 'tok', v: '-', cls: 'is-op', aria: 'min' },
    { t: '4', k: 'tok', v: '4' },
    { t: '5', k: 'tok', v: '5' },
    { t: '6', k: 'tok', v: '6' },
    { t: '+', k: 'tok', v: '+', cls: 'is-op', aria: 'plus' },
    { t: '1', k: 'tok', v: '1' },
    { t: '2', k: 'tok', v: '2' },
    { t: '3', k: 'tok', v: '3' },
    { t: '=', k: 'eq', cls: 'is-eq', aria: 'berekenen' },
    { t: '0', k: 'tok', v: '0' },
    { t: '.', k: 'tok', v: '.', aria: 'punt' },
    { t: '±', k: 'sign', cls: 'is-mute', aria: 'teken wisselen' },
    { t: 'ans', k: 'ans', cls: 'is-fn', aria: 'laatste antwoord' },
    { t: 'C', k: 'clear', cls: 'is-mute', aria: 'wissen' },
    { t: '⌫', k: 'back', cls: 'is-mute', aria: 'backspace' },
    { t: 'φ', k: 'tok', v: 'φ', aria: 'gulden snede' },
    { t: 'c', k: 'tok', v: 'c', aria: 'lichtsnelheid' }
  ];

  for (const def of keys) {
    const b = el('button', 'calc-pro-key' + (def.cls ? ' ' + def.cls : ''), def.t);
    b.type = 'button';
    b.setAttribute('aria-label', def.aria || def.t);
    b.onclick = () => {
      if (def.k === 'tok' || def.k === 'fn') {
        // Special: n! inserts "!" at cursor (postfix)
        if (def.v === '!') {
          insertAtCursor('!');
        } else {
          insertAtCursor(def.v);
        }
      } else if (def.k === 'eq') evaluate();
      else if (def.k === 'clear') clearAll();
      else if (def.k === 'back') backspaceAtCursor();
      else if (def.k === 'sign') {
        const v = getExpr();
        if (v.startsWith('-')) setExpr(v.slice(1));
        else setExpr('-' + (v || '0'));
        exprIn.focus();
        const len = exprIn.value.length;
        exprIn.setSelectionRange(len, len);
      } else if (def.k === 'memc') {
        memory = 0;
        paintMem();
      } else if (def.k === 'memr') {
        insertAtCursor(formatNum(memory));
      } else if (def.k === 'memp' || def.k === 'memm') {
        try {
          const v = parseExpression(getExpr() || '0', { deg });
          memory = def.k === 'memp' ? memory + v : memory - v;
          paintMem();
        } catch (_) {}
      } else if (def.k === 'ans') {
        if (history.length) insertAtCursor(history[history.length - 1].result);
      }
    };
    pad.append(b);
  }

  /* —— Graph rendering —— */
  const PAD = { l: 48, r: 16, t: 16, b: 32 };

  function resizeCanvas() {
    const rect = canvasWrap.getBoundingClientRect();
    const cssW = Math.max(320, Math.floor(rect.width) || 640);
    const cssH = Math.max(280, Math.min(480, Math.floor(cssW * 0.55)));
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.style.width = cssW + 'px';
    canvas.style.height = cssH + 'px';
    canvas.width = Math.floor(cssW * dpr);
    canvas.height = Math.floor(cssH * dpr);
  }

  function getActiveFns() {
    return fxRows
      .map((r, i) => ({ src: r.inp.value.trim(), color: CURVE_COLORS[i], idx: i }))
      .filter((f) => f.src);
  }

  function sampleFunction(fnSrc, xmin, xmax, n) {
    const pts = [];
    for (let i = 0; i <= n; i++) {
      const x = xmin + ((xmax - xmin) * i) / n;
      try {
        const y = parseExpression(fnSrc, { deg, x });
        if (Number.isFinite(y)) pts.push({ x, y, ok: true });
        else pts.push({ x, y: null, ok: false });
      } catch (_) {
        pts.push({ x, y: null, ok: false });
      }
    }
    return pts;
  }

  function findRoots(pts, xmin, xmax) {
    const roots = [];
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1];
      const b = pts[i];
      if (!a.ok || !b.ok) continue;
      if (a.y === 0) {
        roots.push(a.x);
        continue;
      }
      if (a.y * b.y < 0) {
        // linear interpolation
        const t = a.y / (a.y - b.y);
        const x = a.x + t * (b.x - a.x);
        if (x >= xmin && x <= xmax) roots.push(x);
      }
    }
    // dedupe nearby
    const out = [];
    for (const r of roots) {
      if (!out.length || Math.abs(r - out[out.length - 1]) > (xmax - xmin) * 0.002) {
        out.push(r);
      }
    }
    return out.slice(0, 24);
  }

  function buildTable(fns, xmin, xmax) {
    tableEl.replaceChildren();
    if (!fns.length) return;
    const thead = el('thead');
    const hr = el('tr');
    hr.append(el('th', '', 'x'));
    fns.forEach((f, i) => {
      const th = el('th', '', `y${f.idx + 1}`);
      th.style.color = f.color;
      hr.append(th);
    });
    thead.append(hr);
    tableEl.append(thead);
    const tbody = el('tbody');
    const n = 12;
    for (let i = 0; i <= n; i++) {
      const x = xmin + ((xmax - xmin) * i) / n;
      const tr = el('tr');
      tr.append(el('td', '', formatTick(x)));
      for (const f of fns) {
        let cell = '—';
        try {
          const y = parseExpression(f.src, { deg, x });
          if (Number.isFinite(y)) cell = formatNum(y);
        } catch (_) {}
        const td = el('td', '', cell);
        td.style.color = f.color;
        tr.append(td);
      }
      tbody.append(tr);
    }
    tableEl.append(tbody);
  }

  function drawGraph() {
    if (graphPanel.hidden) return;
    if (!canvas.width) resizeCanvas();

    const dpr = canvas.width / (parseFloat(canvas.style.width) || canvas.width);
    const W = canvas.width / dpr;
    const H = canvas.height / dpr;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const cs = getComputedStyle(document.documentElement);
    const bg = cs.getPropertyValue('--panel').trim() || '#f7f1e6';
    const ink = cs.getPropertyValue('--ink').trim() || '#1a1410';
    const line = cs.getPropertyValue('--line').trim() || '#d4c8b8';
    const mute = cs.getPropertyValue('--mute').trim() || '#6a5e52';
    const sel = cs.getPropertyValue('--sel').trim() || '#efe6d6';

    const plotW = W - PAD.l - PAD.r;
    const plotH = H - PAD.t - PAD.b;

    let xmin = gxmin;
    let xmax = gxmax;
    if (!(xmax > xmin)) xmax = xmin + 1;

    const fns = getActiveFns();
    const samples = Math.max(400, Math.floor(plotW * 2));
    const allPts = fns.map((f) => ({ ...f, pts: sampleFunction(f.src, xmin, xmax, samples) }));

    if (autoY) {
      const ys = [];
      for (const f of allPts) {
        for (const p of f.pts) if (p.ok) ys.push(p.y);
      }
      if (ys.length) {
        let lo = Math.min(...ys);
        let hi = Math.max(...ys);
        if (lo === hi) {
          lo -= 1;
          hi += 1;
        }
        const padY = (hi - lo) * 0.08 || 0.1;
        gymin = lo - padY;
        gymax = hi + padY;
        const span = gymax - gymin;
        if (span > 1e6) {
          gymin = -10;
          gymax = 10;
        }
      }
    }
    let ymin = gymin;
    let ymax = gymax;
    if (!(ymax > ymin)) ymax = ymin + 1;

    const toX = (x) => PAD.l + ((x - xmin) / (xmax - xmin)) * plotW;
    const toY = (y) => PAD.t + (1 - (y - ymin) / (ymax - ymin)) * plotH;

    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    ctx.fillStyle = sel;
    ctx.globalAlpha = 0.35;
    ctx.fillRect(PAD.l, PAD.t, plotW, plotH);
    ctx.globalAlpha = 1;

    const xStep = niceStep(xmax - xmin);
    const yStep = niceStep(ymax - ymin);
    ctx.font = '11px system-ui, -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';

    for (let x = Math.ceil(xmin / xStep) * xStep; x <= xmax + xStep * 1e-9; x += xStep) {
      const px = toX(x);
      if (px < PAD.l - 1 || px > PAD.l + plotW + 1) continue;
      ctx.strokeStyle = line;
      ctx.lineWidth = 1;
      ctx.globalAlpha = 0.55;
      ctx.beginPath();
      ctx.moveTo(px, PAD.t);
      ctx.lineTo(px, PAD.t + plotH);
      ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.fillStyle = mute;
      ctx.fillText(formatTick(x), px, PAD.t + plotH + 6);
    }
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    for (let y = Math.ceil(ymin / yStep) * yStep; y <= ymax + yStep * 1e-9; y += yStep) {
      const py = toY(y);
      if (py < PAD.t - 1 || py > PAD.t + plotH + 1) continue;
      ctx.strokeStyle = line;
      ctx.lineWidth = 1;
      ctx.globalAlpha = 0.55;
      ctx.beginPath();
      ctx.moveTo(PAD.l, py);
      ctx.lineTo(PAD.l + plotW, py);
      ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.fillStyle = mute;
      ctx.fillText(formatTick(y), PAD.l - 6, py);
    }

    ctx.strokeStyle = ink;
    ctx.lineWidth = 1.25;
    ctx.globalAlpha = 0.55;
    if (xmin <= 0 && xmax >= 0) {
      const zx = toX(0);
      ctx.beginPath();
      ctx.moveTo(zx, PAD.t);
      ctx.lineTo(zx, PAD.t + plotH);
      ctx.stroke();
    }
    if (ymin <= 0 && ymax >= 0) {
      const zy = toY(0);
      ctx.beginPath();
      ctx.moveTo(PAD.l, zy);
      ctx.lineTo(PAD.l + plotW, zy);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    ctx.save();
    ctx.beginPath();
    ctx.rect(PAD.l, PAD.t, plotW, plotH);
    ctx.clip();

    let totalDrawn = 0;
    let totalGaps = 0;
    const allRoots = [];

    for (const f of allPts) {
      ctx.strokeStyle = f.color;
      ctx.lineWidth = 2.5;
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      let started = false;
      for (const p of f.pts) {
        if (!p.ok) {
          started = false;
          totalGaps++;
          continue;
        }
        const px = toX(p.x);
        const py = toY(p.y);
        if (!Number.isFinite(px) || !Number.isFinite(py)) {
          started = false;
          continue;
        }
        if (!started) {
          ctx.beginPath();
          ctx.moveTo(px, py);
          started = true;
        } else {
          ctx.lineTo(px, py);
        }
        totalDrawn++;
      }
      if (started) ctx.stroke();

      if (showRoots) {
        const roots = findRoots(f.pts, xmin, xmax);
        for (const rx of roots) {
          allRoots.push({ x: rx, color: f.color });
          const px = toX(rx);
          const py = toY(0);
          ctx.fillStyle = f.color;
          ctx.beginPath();
          ctx.arc(px, py, 5, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = bg;
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }
      }
    }
    ctx.restore();

    // root labels (outside clip)
    if (showRoots && allRoots.length) {
      ctx.font = '11px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      const shown = allRoots.slice(0, 8);
      for (const r of shown) {
        const px = toX(r.x);
        if (px < PAD.l || px > PAD.l + plotW) continue;
        ctx.fillStyle = r.color;
        ctx.fillText(formatTick(r.x), px, toY(0) - 8);
      }
    }

    ctx.strokeStyle = line;
    ctx.lineWidth = 1;
    ctx.strokeRect(PAD.l + 0.5, PAD.t + 0.5, plotW - 1, plotH - 1);

    // hover
    if (hover && hover.px >= PAD.l && hover.px <= PAD.l + plotW) {
      ctx.strokeStyle = mute;
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(hover.px, PAD.t);
      ctx.lineTo(hover.px, PAD.t + plotH);
      ctx.stroke();
      ctx.setLineDash([]);
      const labels = [];
      if (hover.ys) {
        for (const item of hover.ys) {
          if (item.y == null) continue;
          ctx.fillStyle = item.color;
          ctx.beginPath();
          ctx.arc(hover.px, item.py, 4, 0, Math.PI * 2);
          ctx.fill();
          labels.push(`y=${formatTick(item.y)}`);
        }
      }
      if (labels.length) {
        const label = `x=${formatTick(hover.x)}  ${labels.join('  ')}`;
        ctx.font = '12px system-ui, sans-serif';
        const tw = ctx.measureText(label).width + 12;
        let lx = hover.px + 10;
        let ly = (hover.ys && hover.ys[0] ? hover.ys[0].py : PAD.t + plotH / 2) - 18;
        if (lx + tw > PAD.l + plotW) lx = hover.px - tw - 10;
        if (ly < PAD.t) ly = PAD.t + 22;
        ctx.fillStyle = bg;
        ctx.strokeStyle = line;
        ctx.lineWidth = 1;
        const rr = 6, rx = lx, ry = ly - 12, rw = tw, rh = 20;
        ctx.beginPath();
        ctx.moveTo(rx + rr, ry);
        ctx.arcTo(rx + rw, ry, rx + rw, ry + rh, rr);
        ctx.arcTo(rx + rw, ry + rh, rx, ry + rh, rr);
        ctx.arcTo(rx, ry + rh, rx, ry, rr);
        ctx.arcTo(rx, ry, rx + rw, ry, rr);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = ink;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(label, lx + 6, ly - 2);
      }
      readOut.textContent = labels.length
        ? `x = ${formatTick(hover.x)} · ${labels.join(' · ')}`
        : `x = ${formatTick(hover.x)} · y = —`;
    } else {
      readOut.textContent = 'Scroll = zoom · sleep = verschuif · hover = coördinaten';
    }

    const rootNote = showRoots && allRoots.length
      ? ` · ${allRoots.length} nulpunt${allRoots.length === 1 ? '' : 'en'}`
      : '';
    const fnLabel = fns.map((f) => f.src).join(', ') || '—';
    graphMsg.textContent = totalDrawn
      ? `y = ${fnLabel}  ·  ${deg ? 'DEG' : 'RAD'}  ·  ${totalDrawn} punten` +
        (totalGaps ? ` · ${totalGaps} onderbrekingen` : '') + rootNote
      : 'Geen geldige punten — controleer de expressie of het bereik.';

    syncRangeInputs();
    if (showTable) buildTable(fns, xmin, xmax);
  }

  function plotXFromPx(px) {
    const W = parseFloat(canvas.style.width) || canvas.width;
    const plotW = W - PAD.l - PAD.r;
    return gxmin + ((px - PAD.l) / plotW) * (gxmax - gxmin);
  }
  function plotYFromPy(py) {
    const H = parseFloat(canvas.style.height) || canvas.height;
    const plotH = H - PAD.t - PAD.b;
    return gymin + (1 - (py - PAD.t) / plotH) * (gymax - gymin);
  }

  let dragging = false;
  let lastPx = 0;
  let lastPy = 0;

  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;
    const factor = e.deltaY > 0 ? 1.15 : 1 / 1.15;
    const x0 = plotXFromPx(px);
    const y0 = plotYFromPy(py);
    let nx0 = x0 - (x0 - gxmin) * factor;
    let nx1 = x0 + (gxmax - x0) * factor;
    let ny0 = y0 - (y0 - gymin) * factor;
    let ny1 = y0 + (gymax - y0) * factor;
    const minX = 1e-6;
    if (nx1 - nx0 < minX) {
      const mid = (nx0 + nx1) / 2;
      nx0 = mid - minX / 2;
      nx1 = mid + minX / 2;
    }
    const maxX = 1e7;
    if (nx1 - nx0 > maxX) {
      const mid = (nx0 + nx1) / 2;
      nx0 = mid - maxX / 2;
      nx1 = mid + maxX / 2;
    }
    gxmin = nx0;
    gxmax = nx1;
    if (!autoY) {
      const minY = 1e-9;
      if (ny1 - ny0 < minY) {
        const mid = (ny0 + ny1) / 2;
        ny0 = mid - minY / 2;
        ny1 = mid + minY / 2;
      }
      gymin = ny0;
      gymax = ny1;
    }
    drawGraph();
  }, { passive: false });

  canvas.addEventListener('pointerdown', (e) => {
    dragging = true;
    lastPx = e.clientX;
    lastPy = e.clientY;
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointerup', (e) => {
    dragging = false;
    try { canvas.releasePointerCapture(e.pointerId); } catch (_) {}
  });
  canvas.addEventListener('pointerleave', () => {
    hover = null;
    if (!dragging) drawGraph();
  });
  canvas.addEventListener('pointermove', (e) => {
    const rect = canvas.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;
    if (dragging) {
      const W = rect.width;
      const H = rect.height;
      const plotW = W - PAD.l - PAD.r;
      const plotH = H - PAD.t - PAD.b;
      const dx = e.clientX - lastPx;
      const dy = e.clientY - lastPy;
      lastPx = e.clientX;
      lastPy = e.clientY;
      const xSpan = gxmax - gxmin;
      const ySpan = gymax - gymin;
      gxmin -= (dx / plotW) * xSpan;
      gxmax -= (dx / plotW) * xSpan;
      if (!autoY) {
        gymin += (dy / plotH) * ySpan;
        gymax += (dy / plotH) * ySpan;
      }
      drawGraph();
      return;
    }
    const x = plotXFromPx(px);
    const fns = getActiveFns();
    const ys = [];
    for (const f of fns) {
      try {
        const y = parseExpression(f.src, { deg, x });
        if (Number.isFinite(y)) {
          const H = rect.height;
          const plotH = H - PAD.t - PAD.b;
          const pyPlot = PAD.t + (1 - (y - gymin) / (gymax - gymin)) * plotH;
          ys.push({ y, py: pyPlot, color: f.color });
        }
      } catch (_) {}
    }
    hover = { x, ys, px };
    drawGraph();
  });

  plotBtn.onclick = () => drawGraph();
  fxRows.forEach((r) => {
    r.inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        drawGraph();
      }
    });
  });
  presets.onclick = (e) => {
    const b = e.target.closest('[data-fn]');
    if (!b) return;
    const parts = b.dataset.fn.split(',');
    fxRows.forEach((r, i) => {
      r.inp.value = parts[i] || '';
    });
    defaultWindow();
    const primary = parts[0] || '';
    if (primary === 'sqrt(x)' || primary === 'ln(x)' || primary === '1/x') {
      gxmin = primary === '1/x' ? -5 : 0.05;
      gxmax = 10;
    } else if (primary.includes('^')) {
      gxmin = -5;
      gxmax = 5;
    }
    drawGraph();
  };
  autoBtn.onclick = () => {
    autoY = !autoY;
    autoBtn.classList.toggle('is-active', autoY);
    drawGraph();
  };
  resetViewBtn.onclick = () => {
    defaultWindow();
    drawGraph();
  };
  rootsBtn.onclick = () => {
    showRoots = !showRoots;
    rootsBtn.classList.toggle('is-active', showRoots);
    drawGraph();
  };
  tableBtn.onclick = () => {
    showTable = !showTable;
    tableBtn.classList.toggle('is-active', showTable);
    tableWrap.hidden = !showTable;
    tableWrap.style.display = showTable ? '' : 'none';
    if (showTable) drawGraph();
  };
  exportBtn.onclick = () => {
    try {
      const url = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = url;
      a.download = 'grafiek-leo-crucis.png';
      a.click();
    } catch (_) {
      graphMsg.textContent = 'Export mislukt (canvas beveiliging).';
    }
  };
  applyRange.onclick = () => {
    const a = parseFloat(xMin.value);
    const b = parseFloat(xMax.value);
    const c = parseFloat(yMin.value);
    const d = parseFloat(yMax.value);
    if (Number.isFinite(a) && Number.isFinite(b) && b > a) {
      gxmin = a;
      gxmax = b;
    }
    if (!autoY && Number.isFinite(c) && Number.isFinite(d) && d > c) {
      gymin = c;
      gymax = d;
    }
    drawGraph();
  };

  defaultWindow();
  syncRangeInputs();

  function onKey(e) {
    if (destroyed || mode !== 'calc') return;
    if (e.target === exprIn) {
      // allow normal typing in the input
      if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        evaluate();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        clearAll();
      }
      return;
    }
    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
    const k = e.key;
    if (k >= '0' && k <= '9') insertAtCursor(k);
    else if (k === '.') insertAtCursor('.');
    else if (k === '+') insertAtCursor('+');
    else if (k === '-') insertAtCursor('-');
    else if (k === '*') insertAtCursor('×');
    else if (k === '/') {
      e.preventDefault();
      insertAtCursor('÷');
    } else if (k === '^') insertAtCursor('^');
    else if (k === '(' || k === ')') insertAtCursor(k);
    else if (k === '!') insertAtCursor('!');
    else if (k === 'Enter' || k === '=') {
      e.preventDefault();
      evaluate();
    } else if (k === 'Escape') clearAll();
    else if (k === 'Backspace') {
      e.preventDefault();
      backspaceAtCursor();
    }
  }
  window.addEventListener('keydown', onKey);
  window.addEventListener('resize', () => {
    if (mode === 'graph' && !destroyed) {
      resizeCanvas();
      drawGraph();
    }
  });

  paintMem();
  paintHist();

  return {
    root,
    el: root,
    kind: 'calculator',
    close() {
      destroyed = true;
      window.removeEventListener('keydown', onKey);
    },
    getState() {
      return {
        expr: getExpr(),
        memory,
        deg,
        history,
        mode,
        fx: fxRows.map((r) => r.inp.value),
        gxmin,
        gxmax,
        gymin,
        gymax,
        autoY,
        showRoots,
        showTable
      };
    },
    setState(s) {
      if (!s) return;
      if (s.expr != null) setExpr(s.expr);
      if (s.memory != null) memory = s.memory;
      if (s.deg != null) deg = s.deg;
      if (Array.isArray(s.history)) {
        history = s.history;
        saveHistory(history);
      }
      if (Array.isArray(s.fx)) {
        s.fx.forEach((v, i) => {
          if (fxRows[i]) fxRows[i].inp.value = v || '';
        });
      } else if (s.fx) {
        fxRows[0].inp.value = s.fx;
      }
      if (s.gxmin != null) gxmin = s.gxmin;
      if (s.gxmax != null) gxmax = s.gxmax;
      if (s.gymin != null) gymin = s.gymin;
      if (s.gymax != null) gymax = s.gymax;
      if (s.autoY != null) autoY = s.autoY;
      if (s.showRoots != null) showRoots = s.showRoots;
      if (s.showTable != null) {
        showTable = s.showTable;
        tableBtn.classList.toggle('is-active', showTable);
        tableWrap.hidden = !showTable;
        tableWrap.style.display = showTable ? '' : 'none';
      }
      if (s.mode) setMode(s.mode);
      degBtn.classList.toggle('is-active', deg);
      radBtn.classList.toggle('is-active', !deg);
      autoBtn.classList.toggle('is-active', autoY);
      rootsBtn.classList.toggle('is-active', showRoots);
      paintMem();
      paintHist();
    }
  };
}
