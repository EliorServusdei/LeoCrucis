/**
 * core/paths.js — padlogica voor boeken (gebundeld + gebruikersmap).
 *
 * Afhankelijk van:
 *   - bookPaths: { [idLower]: "gebouw/sectie/id" | "gebouw/id" }
 *   - world + findItemLoc (via itemOf / findItemLoc uit world-model)
 *
 * Gebruik:
 *   import { createPathApi } from './core/paths.js';
 *   const paths = createPathApi({ getWorld, getBookPaths, findItemLoc, itemOf });
 */

/**
 * @param {object} deps
 * @param {() => object} deps.getWorld
 * @param {() => Record<string,string>} deps.getBookPaths
 * @param {(world, id) => object|null} deps.findItemLoc
 * @param {(world, id) => object|null} deps.itemOf
 */
export function createPathApi(deps) {
  const { getWorld, getBookPaths, findItemLoc, itemOf } = deps;

  /** Relatief pad zonder "stad/" en zonder ".html". */
  function relBookPath(id) {
    const world = getWorld();
    const it = itemOf(world, id);
    if (it && it.dir) {
      const d = String(it.dir).replace(/^\/+|\/+$/g, '');
      return `${d}/${id}`;
    }
    const bookPaths = getBookPaths();
    const p = bookPaths[String(id).toLowerCase()];
    if (p) return p;
    const loc = findItemLoc(world, id);
    if (loc) {
      const sectie = loc.room && loc.room.id ? loc.room.id : null;
      return sectie ? `${loc.building.id}/${sectie}/${id}` : `${loc.building.id}/${id}`;
    }
    return null;
  }

  /** Alleen de gebouwmap (eerste segment). */
  function dirOf(id) {
    const rel = relBookPath(id);
    if (rel) return rel.split('/')[0];
    const loc = findItemLoc(getWorld(), id);
    return loc ? loc.building.id : null;
  }

  /** Pad in gebruikersmap: stad/<rel>.html */
  function userPath(id) {
    const rel = relBookPath(id);
    return rel ? `stad/${rel}.html` : null;
  }

  /** URL/pad van meegeleverd boek. */
  function bundledUrl(id) {
    const bookPaths = getBookPaths();
    const p = bookPaths[String(id).toLowerCase()];
    if (p) return `stad/${p}.html`;
    const rel = relBookPath(id);
    return rel ? `stad/${rel}.html` : null;
  }

  return { relBookPath, dirOf, userPath, bundledUrl };
}
