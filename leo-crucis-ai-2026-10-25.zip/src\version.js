// Automatisch gegenereerd door tools/bump-version.mjs — niet handmatig wijzigen.
export const APP_VERSION = '0.1.15';
export const APP_NAME = 'Bibliotheek Leo Crucis';
