/**
 * core/store.js — lichte centrale state (fase 2)
 *
 * Geen framework: één object + subscribers.
 * Mutaties bij voorkeur via setState/patch of dedicated actions.
 */

/** @typedef {Object} LcState
 * @property {object|null} world
 * @property {{ b: *, r: * }} nav
 * @property {string|null} currentSection
 * @property {object} details
 * @property {object} settings
 * @property {boolean} dev
 */

const listeners = new Set();

/** @type {LcState} */
let state = {
  world: null,
  nav: { b: null, r: null },
  currentSection: null,
  details: {},
  settings: {},
  dev: true,
};

/**
 * @returns {Readonly<LcState>}
 */
export function getState() {
  return state;
}

/**
 * Vervang of merge state.
 * @param {Partial<LcState>|((s: LcState) => Partial<LcState>)} patch
 * @param {{ replace?: boolean }} [opts]
 */
export function setState(patch, opts = {}) {
  const next = typeof patch === 'function' ? patch(state) : patch;
  if (!next || typeof next !== 'object') return state;
  state = opts.replace ? /** @type {LcState} */ ({ ...next }) : { ...state, ...next };
  listeners.forEach(fn => {
    try { fn(state); } catch (e) { console.warn('store subscriber', e); }
  });
  return state;
}

/**
 * @param {(s: LcState) => void} fn
 * @returns {() => void} unsubscribe
 */
export function subscribe(fn) {
  if (typeof fn !== 'function') return () => {};
  listeners.add(fn);
  return () => listeners.delete(fn);
}

/** Gericht: navigatie in de stad */
export function setNav(b, r) {
  return setState({ nav: { b, r: r ?? null } });
}

/** Gericht: actieve sectie/boek-id */
export function setCurrentSection(id) {
  return setState({ currentSection: id || null });
}

/** Gericht: world-object (referentie of nieuwe tree) */
export function setWorld(world) {
  return setState({ world });
}

/** Gericht: details-map */
export function setDetails(details) {
  return setState({ details: details || {} });
}
