/**
 * Takenlijst — Leo Crucis mini-app.
 * Opslag: localStorage (lichtgewicht, zoals notities).
 */

const KEY = 'lc-todo-v1';

function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '[]');
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}

function save(list) {
  try {
    localStorage.setItem(KEY, JSON.stringify(list));
  } catch (e) {
    console.warn(e);
  }
}

function uid() {
  return 't-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function el(tag, className, text) {
  const n = document.createElement(tag);
  if (className) n.className = className;
  if (text != null) n.textContent = text;
  return n;
}

export function createTodoApp() {
  const root = el('div', 'app-panel mini-app-root todo-app');
  root.setAttribute('data-kind', 'todo');
  root.setAttribute('aria-label', 'Takenlijst');

  let tasks = load();
  let filter = 'all'; // all | open | done

  const head = el('div', 'todo-toolbar');
  head.append(el('h1', 'todo-title', 'Taken'));
  const filters = el('div', 'todo-filters');
  const filterBtns = {};
  for (const [k, lab] of [
    ['all', 'Alles'],
    ['open', 'Open'],
    ['done', 'Klaar']
  ]) {
    const b = el('button', 'todo-filter-btn', lab);
    b.type = 'button';
    b.dataset.filter = k;
    if (k === filter) b.classList.add('is-active');
    filterBtns[k] = b;
    filters.append(b);
  }
  head.append(filters);
  root.append(head);

  const form = el('form', 'todo-form');
  const input = el('input', 'todo-input');
  input.type = 'text';
  input.placeholder = 'Nieuwe taak…';
  input.setAttribute('aria-label', 'Nieuwe taak');
  const addBtn = el('button', 'todo-add', 'Toevoegen');
  addBtn.type = 'submit';
  form.append(input, addBtn);
  root.append(form);

  const list = el('ul', 'todo-list');
  root.append(list);

  const meta = el('div', 'todo-meta');
  root.append(meta);

  function persist() {
    save(tasks);
  }

  function visible() {
    if (filter === 'open') return tasks.filter((t) => !t.done);
    if (filter === 'done') return tasks.filter((t) => t.done);
    return tasks.slice();
  }

  function render() {
    list.replaceChildren();
    const items = visible().sort((a, b) => {
      if (a.done !== b.done) return a.done ? 1 : -1;
      return (b.created || 0) - (a.created || 0);
    });
    if (!items.length) {
      list.append(el('li', 'todo-empty', filter === 'done' ? 'Nog geen afgeronde taken' : 'Nog geen taken'));
    } else {
      for (const t of items) {
        const li = el('li', 'todo-item' + (t.done ? ' is-done' : ''));
        const cb = el('input', 'todo-check');
        cb.type = 'checkbox';
        cb.checked = !!t.done;
        cb.setAttribute('aria-label', 'Afgerond');
        const text = el('span', 'todo-text', t.text || '');
        const del = el('button', 'todo-del', '×');
        del.type = 'button';
        del.setAttribute('aria-label', 'Verwijderen');
        li.append(cb, text, del);
        list.append(li);
        cb.onchange = () => {
          t.done = cb.checked;
          t.updated = Date.now();
          persist();
          render();
        };
        del.onclick = () => {
          tasks = tasks.filter((x) => x.id !== t.id);
          persist();
          render();
        };
        text.ondblclick = () => {
          const next = prompt('Taak bewerken:', t.text);
          if (next == null) return;
          t.text = next.trim() || t.text;
          t.updated = Date.now();
          persist();
          render();
        };
      }
    }
    const open = tasks.filter((t) => !t.done).length;
    meta.textContent = `${open} open · ${tasks.length} totaal`;
    Object.entries(filterBtns).forEach(([k, b]) => {
      b.classList.toggle('is-active', k === filter);
    });
  }

  form.onsubmit = (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    tasks.unshift({ id: uid(), text, done: false, created: Date.now(), updated: Date.now() });
    input.value = '';
    persist();
    render();
    input.focus();
  };

  filters.onclick = (e) => {
    const b = e.target.closest('[data-filter]');
    if (!b) return;
    filter = b.dataset.filter;
    render();
  };

  if (!tasks.length) {
    tasks.push({
      id: uid(),
      text: 'Welkom bij je takenlijst in Leo Crucis',
      done: false,
      created: Date.now(),
      updated: Date.now()
    });
    persist();
  }

  render();
  return {
    root,
    el: root,
    kind: 'todo',
    focus() {
      input.focus();
    },
    getState() {
      return { tasks, filter };
    },
    setState(s) {
      if (s && Array.isArray(s.tasks)) tasks = s.tasks;
      if (s && s.filter) filter = s.filter;
      persist();
      render();
    }
  };
}
