/**
 * ui/world-view.js — startscherm, stad, gebouwen, planken (fase 3)
 *
 * Bevat: currentViewMode, village/carousel/map rendering, renderWorld.
 * Navigatie-state (nav) en world-object blijven in app.js; hier alleen weergave.
 */
import { el, $ } from '../core/dom.js';
import { defaultColorForId } from '../core/world-model.js';
import { APP_VERSION } from '../version.js';

/**
 * @param {object} deps
 * @param {() => object} deps.getWorld
 * @param {{b:*, r:*}} deps.nav
 * @param {HTMLElement} deps.home
 * @param {() => boolean} deps.getDev
 * @param {Function} deps.ask
 * @param {Function} deps.persist
 * @param {Function} deps.go
 * @param {Function} deps.showSection
 * @param {Function} deps.setHash
 * @param {Function} deps.roomItems
 * @param {Function} deps.colorOf
 * @param {Function} deps.ensureShelves
 * @param {Function} deps.uniqueId
 * @param {Function} deps.slug
 * @param {Function} deps.listLeoApps
 * @param {object} deps.MINI_APP_TITLES
 * @param {Function} [deps.showResults]
 * @param {Function} [deps.openSpineColorPicker]
 * @param {Function} [deps.wireBookDrag]
 * @param {Function} [deps.moveBook]
 * @param {() => boolean} [deps.inTauri]
 * @param {object} [deps.extra]
 */
export function createWorldViewApi(deps) {
  const {
    getWorld,
    nav,
    home,
    getDev,
    ask,
    persist,
    go,
    showSection,
    setHash,
    roomItems,
    colorOf,
    ensureShelves,
    uniqueId,
    slug,
    listLeoApps,
    MINI_APP_TITLES,
    showResults = () => {},
    inTauri = false,
    extra = {},
    listUserCovers = async () => [],
    readUserImageB64 = async () => '',
    exportUserImage = async () => {},
    saveBook = async () => {},
    openItem = (item) => { try { showSection(item && item.id); } catch (_) {} },
    renderHeaderFavorites = () => {},
    typeMeta = (t) => ({ label: t || 'doc', icon: '📄' }),
    chooseBookType = async () => 'doc',
    chooseDocDesign = async () => null,
    initialDocHtml = () => '<p></p>',
    buildPdfHtml = () => '',
    buildSlidesHtml = () => '',
    buildSheetHtml = () => '',
    getAuthorMode = () => false,
  } = deps;

  let carouselIndex = 0;

  const APP_FAV_KEY = 'lc-app-favorites-v1';

  function makeInlineEditable(el, getValue, setValue, opts) {
    opts = opts || {};
    if (!getAuthorMode()) return el;
    el.classList.add('is-inline-editable');
    el.contentEditable = 'true';
    el.spellcheck = true;
    el.setAttribute('role', 'textbox');
    el.title = (opts.title || 'Klik om te bewerken') + ' (auteursmodus)';
    const stop = (e) => { e.stopPropagation(); };
    el.addEventListener('click', stop);
    el.addEventListener('pointerdown', stop);
    el.addEventListener('mousedown', stop);
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !opts.multiline) {
        e.preventDefault();
        el.blur();
      }
      e.stopPropagation();
    });
    el.addEventListener('blur', async () => {
      const raw = (el.textContent || '').trim();
      const prev = (getValue() || '').trim();
      if (raw === prev) return;
      try {
        await setValue(raw);
        try { await persist(); } catch (_) {}
        el.classList.add('is-saved');
        setTimeout(() => el.classList.remove('is-saved'), 800);
      } catch (err) {
        console.warn('Inline save failed', err);
        el.textContent = prev;
      }
    });
    return el;
  }

  function loadAppFavorites() {
    try {
      const a = JSON.parse(localStorage.getItem(APP_FAV_KEY) || '[]');
      return Array.isArray(a) ? a.filter(x => typeof x === 'string') : [];
    } catch (_) { return []; }
  }

  function saveAppFavorites(list) {
    try { localStorage.setItem(APP_FAV_KEY, JSON.stringify(list.slice(0, 20))); } catch (_) {}
  }

  function isAppFavorite(kind) {
    return loadAppFavorites().includes(kind);
  }

  function toggleAppFavorite(kind) {
    const cur = loadAppFavorites();
    const was = cur.includes(kind);
    const next = was ? cur.filter(x => x !== kind) : [kind, ...cur.filter(x => x !== kind)];
    saveAppFavorites(next);
    try { renderHeaderFavorites(); } catch (_) {}
    return !was;
  }


  const devBtn = (label, title, fn, cls = '') => { const b = el('button', 'dev-btn ' + cls, label); b.type = 'button'; b.title = title; b.setAttribute('aria-label', title); b.onclick = fn; return b; };

  function openSpineColorPicker(item, anchor, fallbackIdx) {
    document.querySelectorAll('.spine-color-pop').forEach(n => n.remove());
    const pop = el('div', 'spine-color-pop');
    const cur = colorOf(item, fallbackIdx);
    for (let i = 0; i < 10; i++) {
      const sw = el('button', 'spine-swatch c' + i + (i === cur ? ' active' : ''));
      sw.type = 'button';
      sw.title = 'Kleur ' + (i + 1);
      sw.setAttribute('aria-label', 'Kleur ' + (i + 1));
      sw.onclick = e => {
        e.preventDefault();
        e.stopPropagation();
        item.color = i;
        persist();
        pop.remove();
        renderWorld();
      };
      pop.append(sw);
    }
    document.body.appendChild(pop);
    const ar = anchor.getBoundingClientRect();
    const pr = pop.getBoundingClientRect();
    let left = ar.left + ar.width / 2 - pr.width / 2;
    let top = ar.top - pr.height - 8;
    if (top < 8) top = ar.bottom + 8;
    if (left < 8) left = 8;
    if (left + pr.width > window.innerWidth - 8) left = window.innerWidth - pr.width - 8;
    pop.style.left = left + 'px';
    pop.style.top = top + 'px';
    const close = ev => {
      if (pop.contains(ev.target) || anchor.contains(ev.target)) return;
      pop.remove();
      document.removeEventListener('pointerdown', close, true);
    };
    setTimeout(() => document.addEventListener('pointerdown', close, true), 0);
  }

  /** Zorg dat een kamer shelves[] gebruikt (i.p.v. losse items[]). */
  function moveBook(itemId, targetRoom, targetShelf, targetIndex) {
    const loc = findItemLoc(itemId);
    if (!loc) return false;
    const [item] = loc.items.splice(loc.index, 1);
    // Doelplank bepalen
    let destItems;
    if (targetShelf) {
      if (!targetShelf.items) targetShelf.items = [];
      destItems = targetShelf.items;
    } else {
      ensureShelves(targetRoom);
      // eerste plank, of nieuwe lege
      if (!targetRoom.shelves.length) targetRoom.shelves.push({ label: null, items: [] });
      destItems = targetRoom.shelves[0].items || (targetRoom.shelves[0].items = []);
    }
    let idx = targetIndex == null ? destItems.length : targetIndex;
    // Zelfde array: index corrigeren als we vóór de oude positie invoegen
    if (destItems === loc.items && loc.index < idx) idx -= 1;
    idx = Math.max(0, Math.min(idx, destItems.length));
    destItems.splice(idx, 0, item);
    return true;
  }

  /**
   * Pointer-gebaseerd slepen (betrouwbaarder dan HTML5 DnD op gedraaide boekruggen).
   * Werkt alleen in editor-modus.
   */
  const dropHandlers = new WeakMap();
  const DND = {
    id: null,
    sourceEl: null,
    ghost: null,
    active: false,
    didDrag: false,
    pending: null,   // { el, item, x, y, pointerId }
    over: null,
    clear() {
      if (DND.ghost) { DND.ghost.remove(); DND.ghost = null; }
      if (DND.sourceEl) DND.sourceEl.classList.remove('dragging');
      document.body.classList.remove('dragging-book');
      document.querySelectorAll('.drag-over').forEach(e => e.classList.remove('drag-over'));
      DND.id = null;
      DND.sourceEl = null;
      DND.active = false;
      DND.pending = null;
      DND.over = null;
    }
  };

  function wireBookDrag(el, item) {
    if (!dev) return;
    el.classList.add('spine-draggable');
    el.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      if (e.target.closest('.dev-x, .spine-color-btn')) return; // knoppen niet starten
      // Geen preventDefault hier — anders blokkeren we scrollen; drempel beslist later
      DND.pending = { el, item, x: e.clientX, y: e.clientY, pointerId: e.pointerId };
      DND.didDrag = false;
    });
  }

  function wireDropTarget(el, { onDrop, hint }) {
    if (!dev) return;
    el.dataset.dropTarget = '1';
    dropHandlers.set(el, onDrop);
    if (hint) el.title = (el.title ? el.title + ' — ' : '') + hint;
  }

  function dndFindTarget(clientX, clientY) {
    const stack = document.elementsFromPoint(clientX, clientY);
    for (const node of stack) {
      if (node === DND.ghost || node === DND.sourceEl) continue;
      const t = node.closest && node.closest('[data-drop-target]');
      if (t && dropHandlers.has(t) && t !== DND.sourceEl) return t;
    }
    return null;
  }

  function dndStart(pending, e) {
    DND.active = true;
    DND.didDrag = true;
    DND.id = pending.item.id;
    DND.sourceEl = pending.el;
    pending.el.classList.add('dragging');
    document.body.classList.add('dragging-book');

    // Ghost: kloon van de rug, volgt de muis
    const rect = pending.el.getBoundingClientRect();
    const ghost = pending.el.cloneNode(true);
    ghost.classList.remove('dragging');
    ghost.classList.add('spine-ghost');
    ghost.style.width = rect.width + 'px';
    ghost.style.height = rect.height + 'px';
    ghost.style.left = (e.clientX - rect.width / 2) + 'px';
    ghost.style.top = (e.clientY - rect.height / 2) + 'px';
    // Verwijder knoppen in de ghost
    ghost.querySelectorAll('.dev-x').forEach(n => n.remove());
    document.body.appendChild(ghost);
    DND.ghost = ghost;

    try { pending.el.setPointerCapture(pending.pointerId); } catch (err) {}
  }

  function dndMove(e) {
    if (DND.ghost) {
      const g = DND.ghost;
      const w = parseFloat(g.style.width) || 40;
      const h = parseFloat(g.style.height) || 40;
      g.style.left = (e.clientX - w / 2) + 'px';
      g.style.top = (e.clientY - h / 2) + 'px';
    }
    const target = dndFindTarget(e.clientX, e.clientY);
    if (DND.over && DND.over !== target) DND.over.classList.remove('drag-over');
    if (target) target.classList.add('drag-over');
    DND.over = target;
  }

  function dndFinish(e) {
    const id = DND.id;
    const target = dndFindTarget(e.clientX, e.clientY);
    const handler = target && dropHandlers.get(target);
    DND.clear();
    if (id && handler) handler(id);
  }

  // Globale pointer-listeners (één keer)
  document.addEventListener('pointermove', e => {
    if (DND.active) {
      e.preventDefault();
      dndMove(e);
      return;
    }
    const p = DND.pending;
    if (!p) return;
    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    if (Math.hypot(dx, dy) < 8) return; // drempel: onderscheid klik vs sleep
    dndStart(p, e);
    dndMove(e);
  }, { passive: false });

  document.addEventListener('pointerup', e => {
    if (DND.active) {
      e.preventDefault();
      dndFinish(e);
    }
    DND.pending = null;
  });
  document.addEventListener('pointercancel', () => DND.clear());



  // compat: veel code leest `dev`
  Object.defineProperty(deps, '_devCompat', { value: true });
  const devProxy = {
    get value() { return getDev(); }
  };
  // Gebruik getDev() inline — vervang `dev` in body

  function currentViewMode() {
    // Startscherm is altijd de gebouw-carrousel; Compact/Lijst zijn verwijderd.
    return 'interactive';
  }





  /** Catalogus kasteelstukken — graphics via CSS/SVG, geen emoji-boxen. */
  const CASTLE_PIECES = [
    { type: 'wall-h',      label: 'Muur ↔',     kind: 'wall',  cls: 'piece-wall piece-wall-h',      defaultLayer: 'muren', paint: false },
    { type: 'wall-v',      label: 'Muur ↕',     kind: 'wall',  cls: 'piece-wall piece-wall-v',      defaultLayer: 'muren', paint: false },
    { type: 'wall-corner', label: 'Muurhoek',   kind: 'wall',  cls: 'piece-wall piece-wall-corner', defaultLayer: 'muren', paint: false },
    { type: 'wall-cell',   label: 'Muur',       kind: 'wall',  cls: 'piece-wall piece-wall-cell',   defaultLayer: 'muren', paint: true },
    { type: 'water-cell',  label: 'Water',      kind: 'water', cls: 'piece-water piece-water-cell', defaultLayer: 'grond', paint: true },
    { type: 'tower',       label: 'Toren',      kind: 'tower', cls: 'piece-tower',                 defaultLayer: 'muren' },
    { type: 'gate',        label: 'Poort',      kind: 'gate',  cls: 'piece-gate',                  defaultLayer: 'muren' },
    { type: 'keep',        label: 'Donjon',     kind: 'tower', cls: 'piece-keep',                  defaultLayer: 'gebouwen' },
    { type: 'banner',      label: 'Banier',     kind: 'deco',  cls: 'piece-banner',                defaultLayer: 'decor' },
    { type: 'bridge',      label: 'Brug',       kind: 'deco',  cls: 'piece-bridge',                defaultLayer: 'grond' },
    { type: 'tree',        label: 'Boom',       kind: 'deco',  cls: 'piece-tree',                  defaultLayer: 'decor' },
    { type: 'fountain',    label: 'Fontein',    kind: 'deco',  cls: 'piece-fountain',              defaultLayer: 'decor' },
    { type: 'statue',      label: 'Standbeeld', kind: 'deco',  cls: 'piece-statue',                defaultLayer: 'decor' },
    { type: 'kasteel',     label: 'Kasteel',    kind: 'deco',  cls: 'piece-kasteel piece-asset',   defaultLayer: 'decor' },
  ];
  const CASTLE_BY_TYPE = Object.fromEntries(CASTLE_PIECES.map(p => [p.type, p]));
  /** Stukken die je klikt-op-grid plaatst (schilderen). */
  const PAINT_TOOLS = {
    wall:  { type: 'wall-cell',  label: 'Muur',  layer: 'muren' },
    water: { type: 'water-cell', label: 'Water', layer: 'grond' },
  };

  const DEFAULT_LAYERS = [
    { id: 'grond',    label: 'Grond',    order: 0 },
    { id: 'muren',    label: 'Muren',    order: 1 },
    { id: 'gebouwen', label: 'Gebouwen', order: 2 },
    { id: 'decor',    label: 'Decor',    order: 3 },
  ];

  /** Actieve laag / selectie / schildermodus (sessie). */
  let activeLayerId = 'gebouwen';
  let selectedPieceKey = null; // 'p:id' of 'b:id'
  let paintTool = null;        // null | 'wall' | 'water'
  let buildMode = false;       // hamermenu: stad bewerken

  function ensureLayers() {
    if (!Array.isArray(getWorld().layers) || !getWorld().layers.length) {
      getWorld().layers = DEFAULT_LAYERS.map(l => ({ ...l }));
    }
    getWorld().layers.sort((a, b) => a.order - b.order);
  }
  function ensurePieces() {
    if (!Array.isArray(getWorld().pieces)) getWorld().pieces = [];
    ensureLayers();
    // Bestaande gebouwen standaard op het veld
    for (const b of (getWorld().buildings || [])) {
      if (b.placed === undefined) b.placed = true;
    }
  }
  function isPlaced(b) {
    return b && b.placed !== false;
  }
  function buildingBookCount(b) {
    let n = 0;
    for (const r of (b.rooms || [])) {
      if (r.shelves) for (const sh of r.shelves) n += (sh.items || []).length;
      else n += (r.items || []).length;
    }
    return n;
  }
  function unplaceBuilding(b) {
    b.placed = false;
    // behoud x/y als "laatste positie" voor terugplaatsen
  }
  function placeBuilding(b, x, y) {
    b.placed = true;
    if (typeof x === 'number') b.x = x;
    if (typeof y === 'number') b.y = y;
    if (typeof b.x !== 'number') b.x = 50;
    if (typeof b.y !== 'number') b.y = 50;
    if (!b.layer) b.layer = activeLayerId || 'gebouwen';
  }
  function layerOrder(id) {
    ensureLayers();
    const l = getWorld().layers.find(x => x.id === id);
    return l ? l.order : 0;
  }
  function zFor(layerId, y) {
    return layerOrder(layerId) * 1000 + Math.round((y || 50) * 5);
  }

  /** Grid-cel grootte in % — muren/water landen op dit raster. */
  const VILLAGE_GRID = 5;
  function snapPct(v) {
    return Math.round(v / VILLAGE_GRID) * VILLAGE_GRID;
  }
  function clampPct(v, min = 2.5, max = 97.5) {
    return Math.max(min, Math.min(max, v));
  }
  function cellKey(x, y) {
    return `${snapPct(x)},${snapPct(y)}`;
  }

  /** Bestaat er al een paint-cel van dit type op deze gridpositie? */
  function pieceAtCell(type, x, y) {
    const k = cellKey(x, y);
    return (getWorld().pieces || []).find(p => p.type === type && cellKey(p.x, p.y) === k);
  }

  /** SVG/HTML graphics voor kasteelstukken. */
  function pieceGraphic(type, piece) {
    const wrap = (inner, extraCls = '') => {
      const d = el('div', 'gfx ' + extraCls);
      d.innerHTML = inner;
      return d;
    };
    // Afbeelding-asset (kasteel, Fan-tasy set, …)
    const assetSrc = PIECE_ASSETS[type] || (FANTASY_BY_TYPE[type] && FANTASY_BY_TYPE[type].asset);
    if (assetSrc) {
      const d = el('div', 'gfx gfx-piece-asset gfx-piece-' + type + (FANTASY_BY_TYPE[type] ? ' gfx-pixel' : ''));
      const img = document.createElement('img');
      img.src = assetSrc;
      img.alt = type;
      img.className = 'piece-asset-img';
      img.draggable = false;
      d.appendChild(img);
      return d;
    }
    // Wall-cell: oriëntatie op basis van buren
    if (type === 'wall-cell') {
      const n = wallNeighbors(piece);
      let cls = 'gfx-wcell';
      if (n.l || n.r) cls += ' conn-h';
      if (n.u || n.d) cls += ' conn-v';
      if (n.l) cls += ' n-l';
      if (n.r) cls += ' n-r';
      if (n.u) cls += ' n-u';
      if (n.d) cls += ' n-d';
      return wrap(`<div class="${cls}"><i></i></div>`, 'gfx-wall');
    }
    if (type === 'water-cell') {
      const n = waterNeighbors(piece);
      let cls = 'gfx-water';
      if (n.l) cls += ' n-l';
      if (n.r) cls += ' n-r';
      if (n.u) cls += ' n-u';
      if (n.d) cls += ' n-d';
      return wrap(`<div class="${cls}"></div>`, 'gfx-ground');
    }
    switch (type) {
      case 'wall-h':
        return wrap(`<div class="gfx-wall-h"><span></span><span></span><span></span><span></span></div>`, 'gfx-wall');
      case 'wall-v':
        return wrap(`<div class="gfx-wall-v"><span></span><span></span><span></span><span></span></div>`, 'gfx-wall');
      case 'wall-corner':
        return wrap(`<div class="gfx-wall-corner"></div>`, 'gfx-wall');
      case 'tower':
        return wrap(`
          <div class="gfx-tower">
            <div class="gfx-crenel"><i></i><i></i><i></i></div>
            <div class="gfx-tower-body"><div class="gfx-window"></div><div class="gfx-window"></div></div>
            <div class="gfx-tower-base"></div>
          </div>`, 'gfx-struct');
      case 'keep':
        return wrap(`
          <div class="gfx-keep">
            <div class="gfx-keep-roof"></div>
            <div class="gfx-crenel gfx-crenel-wide"><i></i><i></i><i></i><i></i><i></i></div>
            <div class="gfx-keep-body">
              <div class="gfx-window"></div><div class="gfx-window"></div><div class="gfx-window"></div>
            </div>
            <div class="gfx-tower-base"></div>
          </div>`, 'gfx-struct');
      case 'gate':
        return wrap(`
          <div class="gfx-gate">
            <div class="gfx-gate-top"></div>
            <div class="gfx-gate-body"><div class="gfx-arch"></div></div>
            <div class="gfx-gate-posts"><i></i><i></i></div>
          </div>`, 'gfx-struct');
      case 'banner':
        return wrap(`<div class="gfx-banner"><div class="gfx-pole"></div><div class="gfx-flag"></div></div>`, 'gfx-deco');
      case 'bridge':
        return wrap(`<div class="gfx-bridge"><i></i><i></i><i></i></div>`, 'gfx-struct');
      case 'moat':
        return wrap(`<div class="gfx-moat"></div>`, 'gfx-ground');
      case 'tree':
        return wrap(`
          <div class="gfx-tree">
            <div class="gfx-canopy"></div>
            <div class="gfx-canopy gfx-canopy-2"></div>
            <div class="gfx-trunk"></div>
          </div>`, 'gfx-deco');
      case 'fountain':
        return wrap(`
          <div class="gfx-fountain">
            <div class="gfx-spray"></div>
            <div class="gfx-basin"></div>
            <div class="gfx-basin-base"></div>
          </div>`, 'gfx-deco');
      case 'statue':
        return wrap(`
          <div class="gfx-statue">
            <div class="gfx-statue-head"></div>
            <div class="gfx-statue-body"></div>
            <div class="gfx-plinth"></div>
          </div>`, 'gfx-deco');
      default:
        return wrap(`<div class="gfx-fallback"></div>`);
    }
  }

  function wallNeighbors(piece) {
    if (!piece) return { l: 0, r: 0, u: 0, d: 0 };
    const x = snapPct(piece.x), y = snapPct(piece.y);
    const isW = p => p.type === 'wall-cell' || p.type === 'wall-h' || p.type === 'wall-v' || p.type === 'wall-corner';
    const at = (dx, dy) => (getWorld().pieces || []).some(p => isW(p) && snapPct(p.x) === x + dx && snapPct(p.y) === y + dy);
    return { l: at(-VILLAGE_GRID, 0), r: at(VILLAGE_GRID, 0), u: at(0, -VILLAGE_GRID), d: at(0, VILLAGE_GRID) };
  }
  function waterNeighbors(piece) {
    if (!piece) return { l: 0, r: 0, u: 0, d: 0 };
    const x = snapPct(piece.x), y = snapPct(piece.y);
    const at = (dx, dy) => (getWorld().pieces || []).some(p => p.type === 'water-cell' && snapPct(p.x) === x + dx && snapPct(p.y) === y + dy);
    return { l: at(-VILLAGE_GRID, 0), r: at(VILLAGE_GRID, 0), u: at(0, -VILLAGE_GRID), d: at(0, VILLAGE_GRID) };
  }

  /** Optionele afbeelding-assets per gebouw-id (src/assets/buildings/<id>.png). */
  const BUILDING_ASSETS = {
    kerk: 'assets/buildings/kerk.png',
    school: 'assets/buildings/school.png',
    academie: 'assets/buildings/academie.png',
    bibliotheek: 'assets/buildings/bibliotheek.png',
    werkplaats: 'assets/buildings/werkplaats.png',
    tuin: 'assets/buildings/tuin.png',
    // optioneel cottage
    huis: 'assets/buildings/huis.png',
  };
  const PIECE_ASSETS = {
    kasteel: 'assets/buildings/kasteel.png',
  };

  /** Fan-tasy Tileset (Free) — pixel-art building set. */
  const FANTASY_SET = [
    { type: 'ft-house-1', label: 'Huis 1',     asset: 'assets/tilesets/fantasy/buildings/House_Hay_1.png', layer: 'gebouwen' },
    { type: 'ft-house-2', label: 'Huis 2',     asset: 'assets/tilesets/fantasy/buildings/House_Hay_2.png', layer: 'gebouwen' },
    { type: 'ft-house-3', label: 'Huis 3',     asset: 'assets/tilesets/fantasy/buildings/House_Hay_3.png', layer: 'gebouwen' },
    { type: 'ft-house-4', label: 'Huis paars', asset: 'assets/tilesets/fantasy/buildings/House_Hay_4_Purple.png', layer: 'gebouwen' },
    { type: 'ft-well',    label: 'Put',        asset: 'assets/tilesets/fantasy/buildings/Well_Hay_1.png', layer: 'decor' },
    { type: 'ft-gate',    label: 'Stadspoort', asset: 'assets/tilesets/fantasy/buildings/CityWall_Gate_1.png', layer: 'muren' },
    { type: 'ft-tree-1',  label: 'Boom 1',     asset: 'assets/tilesets/fantasy/trees/Tree_Emerald_1.png', layer: 'decor' },
    { type: 'ft-tree-2',  label: 'Boom 2',     asset: 'assets/tilesets/fantasy/trees/Tree_Emerald_2.png', layer: 'decor' },
    { type: 'ft-tree-3',  label: 'Boom 3',     asset: 'assets/tilesets/fantasy/trees/Tree_Emerald_3.png', layer: 'decor' },
    { type: 'ft-tree-4',  label: 'Boom 4',     asset: 'assets/tilesets/fantasy/trees/Tree_Emerald_4.png', layer: 'decor' },
    { type: 'ft-bush-1',  label: 'Struik 1',   asset: 'assets/tilesets/fantasy/trees/Bush_Emerald_1.png', layer: 'decor' },
    { type: 'ft-bush-2',  label: 'Struik 2',   asset: 'assets/tilesets/fantasy/trees/Bush_Emerald_2.png', layer: 'decor' },
    { type: 'ft-banner',  label: 'Banier',     asset: 'assets/tilesets/fantasy/props/Banner_Stick_1_Purple.png', layer: 'decor' },
    { type: 'ft-lamp',    label: 'Lantaarn',   asset: 'assets/tilesets/fantasy/props/LampPost_3.png', layer: 'decor' },
    { type: 'ft-bench',   label: 'Bank',       asset: 'assets/tilesets/fantasy/props/Bench_1.png', layer: 'decor' },
    { type: 'ft-sign',    label: 'Bord',       asset: 'assets/tilesets/fantasy/props/Sign_1.png', layer: 'decor' },
    { type: 'ft-crate',   label: 'Kist',       asset: 'assets/tilesets/fantasy/props/Crate_Medium_Closed.png', layer: 'decor' },
    { type: 'ft-barrel',  label: 'Vat',        asset: 'assets/tilesets/fantasy/props/Barrel_Small_Empty.png', layer: 'decor' },
    { type: 'ft-hay',     label: 'Hooi',       asset: 'assets/tilesets/fantasy/props/HayStack_2.png', layer: 'decor' },
    { type: 'ft-fire',    label: 'Open haard', asset: 'assets/tilesets/fantasy/props/Fireplace_1.png', layer: 'decor' },
  ];
  const FANTASY_BY_TYPE = Object.fromEntries(FANTASY_SET.map(p => [p.type, p]));


  // Eigen cover-afbeeldingen uit de gebruikersmap: stad/<gebouw>/<gebouw>.png (of los stad/<gebouw>.png) vervangt de standaardafbeelding.
  let userCovers = {};   // gebouw-id (kleine letters) -> data-URL
  let coverSig = {};     // gebouw-id -> pad|datum|grootte van de ingelezen afbeelding
  const MIME = { png: 'image/png', webp: 'image/webp', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif' };
  // Geeft true als er iets veranderd is.
  async function refreshCovers() {
    if (!inTauri) return false;
    let list;
    try { list = await listUserCovers(); } catch (e) { console.warn('Covers lezen mislukt', e); return false; }
    const next = {}, nextSig = {};
    for (const [dir, rel, mtime, size] of list || []) {
      const key = String(dir).toLowerCase(), sig = `${rel}|${mtime}|${size}`;
      nextSig[key] = sig;
      if (coverSig[key] === sig && userCovers[key]) { next[key] = userCovers[key]; continue; }   // ongewijzigd: niet opnieuw inlezen
      try {
        const ext = rel.split('.').pop().toLowerCase();
        next[key] = `data:${MIME[ext] || 'image/png'};base64,` + await readUserImageB64(rel);
      } catch (e) { console.warn('Cover niet gelezen:', rel, e); delete nextSig[key]; }
    }
    const same = Object.keys(next).length === Object.keys(userCovers).length && Object.keys(next).every(k => userCovers[k] === next[k]);
    userCovers = next; coverSig = nextSig;
    return !same;
  }
  // De meegeleverde gebouwafbeeldingen ook als bestanden in stad/<gebouw>/<gebouw>.png zetten (eenmalig per appversie, nooit overschrijven).
  const IMG_EXPORT_KEY = 'lc-stad-img-exported';
  async function exportBuildingImages() {
    if (!inTauri) return;
    try { if (localStorage.getItem(IMG_EXPORT_KEY) === APP_VERSION) return; } catch (e) {}
    let failed = 0;
    for (const [id, url] of Object.entries(BUILDING_ASSETS)) {
      if (!(getWorld().buildings || []).some(b => b.id === id)) continue;
      try {
        const res = await fetch(url);
        if (!res.ok) throw new Error(res.status);
        const blob = await res.blob();
        const b64 = await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(',')[1]); r.onerror = no; r.readAsDataURL(blob); });
        await exportUserImage(id, `${id}.png`, b64);
      } catch (e) { failed++; console.warn('Gebouwafbeelding niet gekopieerd:', id, e); }
    }
    if (!failed) { try { localStorage.setItem(IMG_EXPORT_KEY, APP_VERSION); } catch (e) {} }
  }

  function buildingGraphic(b) {
    const style = b.id || 'default';
    const asset = userCovers[String(b.id).toLowerCase()] || b.asset || BUILDING_ASSETS[style];
    if (asset) {
      const d = el('div', 'gfx gfx-building gfx-bld-asset gfx-bld-' + style);
      const img = document.createElement('img');
      img.src = asset;
      img.alt = b.label || style;
      img.className = 'bld-asset-img';
      img.draggable = false;
      d.appendChild(img);
      return d;
    }
    // Speciale kerk-graphic (fallback zonder asset)
    if (style === 'kerk') {
      const d = el('div', 'gfx gfx-building gfx-bld-kerk gfx-church');
      d.innerHTML = `
        <div class="church">
          <div class="church-cross"></div>
          <div class="church-spire"></div>
          <div class="church-tower">
            <div class="church-belfry"></div>
            <div class="church-clock"></div>
          </div>
          <div class="church-nave">
            <div class="church-roof"></div>
            <div class="church-body">
              <div class="church-window rose"></div>
              <div class="church-window"></div>
              <div class="church-door"></div>
              <div class="church-window"></div>
            </div>
          </div>
        </div>
      `;
      return d;
    }
    const d = el('div', 'gfx gfx-building gfx-bld-' + style);
    d.innerHTML = `
      <div class="gfx-bld-roof"></div>
      <div class="gfx-bld-body">
        <div class="gfx-bld-door"></div>
        <div class="gfx-bld-win"></div>
        <div class="gfx-bld-win"></div>
      </div>
    `;
    return d;
  }

  function findFreeSpot(exclude = []) {
    ensurePieces();
    const used = new Set([
      ...getWorld().buildings.map(b => cellKey(b.x | 0, b.y | 0)),
      ...getWorld().pieces.map(p => cellKey(p.x | 0, p.y | 0)),
      ...exclude,
    ]);
    // Kies de vrije plek die het verst van bestaande gebouwen en stukken ligt (zodat een nieuw gebouw niet over een ander heen valt).
    const taken = [...getWorld().buildings, ...getWorld().pieces].map(o => [Number(o.x) || 0, Number(o.y) || 0]);
    let best = null, bestD = -1;
    for (let i = 0; i < 63; i++) {
      const x = snapPct(10 + (i % 9) * 10);
      const y = snapPct(15 + Math.floor(i / 9) * 10);
      if (used.has(cellKey(x, y))) continue;
      const d = taken.reduce((m, [tx, ty]) => Math.min(m, Math.hypot(tx - x, (ty - y) * 1.3)), 999);
      if (d > bestD) { bestD = d; best = { x, y }; }
    }
    if (best) return best;
    return { x: 50, y: 50 };
  }

  function wireVillageDrag(el, field, onCommit, onTap) {
    el.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      if (e.target.closest('.vb-del, .vb-layer-btn, .layer-pick')) return;
      if (paintTool) return; // schilderen heeft voorrang
      e.preventDefault();
      e.stopPropagation();
      el.setPointerCapture(e.pointerId);
      el.classList.add('dragging', 'selected', 'glow-red');
      field.classList.add('is-dragging');
      selectedPieceKey = el.dataset.key || null;
      // deselect others
      field.querySelectorAll('.selected').forEach(n => { if (n !== el) n.classList.remove('selected', 'glow-red'); });
      let moved = false;
      const rect = field.getBoundingClientRect();
      const onMove = ev => {
        moved = true;
        const x = clampPct(((ev.clientX - rect.left) / rect.width) * 100);
        const y = clampPct(((ev.clientY - rect.top) / rect.height) * 100);
        el.style.left = x + '%';
        el.style.top = y + '%';
        const lid = el.dataset.layer || 'gebouwen';
        el.style.zIndex = String(zFor(lid, y));
      };
      const onUp = ev => {
        el.releasePointerCapture(ev.pointerId);
        el.removeEventListener('pointermove', onMove);
        el.removeEventListener('pointerup', onUp);
        el.removeEventListener('pointercancel', onUp);
        el.classList.remove('dragging');
        // blijft selected + glow-red
        field.classList.remove('is-dragging');
        if (!moved) {
          if (onTap) onTap();
          return;
        }
        const x = snapPct(parseFloat(el.style.left));
        const y = snapPct(parseFloat(el.style.top));
        el.style.left = x + '%';
        el.style.top = y + '%';
        onCommit(x, y);
      };
      el.addEventListener('pointermove', onMove);
      el.addEventListener('pointerup', onUp);
      el.addEventListener('pointercancel', onUp);
    });
  }

  function openLayerPicker(anchor, currentId, onPick) {
    document.querySelectorAll('.layer-pick').forEach(n => n.remove());
    ensureLayers();
    const pop = el('div', 'layer-pick');
    pop.append(el('div', 'layer-pick-title', 'Naar laag'));
    for (const l of getWorld().layers) {
      const row = el('button', 'layer-pick-row' + (l.id === currentId ? ' active' : ''), l.label);
      row.type = 'button';
      row.onclick = e => {
        e.stopPropagation();
        pop.remove();
        onPick(l.id);
      };
      pop.append(row);
    }
    document.body.appendChild(pop);
    const ar = anchor.getBoundingClientRect();
    let left = ar.left;
    let top = ar.bottom + 4;
    if (top + 160 > window.innerHeight) top = ar.top - 160;
    if (left + 140 > window.innerWidth) left = window.innerWidth - 148;
    pop.style.left = left + 'px';
    pop.style.top = top + 'px';
    const close = ev => {
      if (!pop.contains(ev.target) && ev.target !== anchor) {
        pop.remove();
        document.removeEventListener('pointerdown', close, true);
      }
    };
    setTimeout(() => document.addEventListener('pointerdown', close, true), 0);
  }

  /** Set van cellen geraakt in huidige paint-stroke (voorkomt dubbels). */
  let paintStrokeKeys = new Set();

  /** Plaats of gum een paint-cel. dirty=true als getWorld() wijzigde (geen re-render). */
  function paintCellAt(field, clientX, clientY, erase) {
    if (!paintTool || !PAINT_TOOLS[paintTool]) return false;
    const tool = PAINT_TOOLS[paintTool];
    const rect = field.getBoundingClientRect();
    const x = snapPct(clampPct(((clientX - rect.left) / rect.width) * 100));
    const y = snapPct(clampPct(((clientY - rect.top) / rect.height) * 100));
    const k = tool.type + ':' + cellKey(x, y);
    if (paintStrokeKeys.has(k)) return false;
    paintStrokeKeys.add(k);
    ensurePieces();
    const existing = pieceAtCell(tool.type, x, y);
    if (erase) {
      if (!existing) return false;
      getWorld().pieces = getWorld().pieces.filter(p => p !== existing);
      return true;
    }
    if (existing) return false;
    const id = uniqueId(tool.type, new Set(getWorld().pieces.map(p => p.id)));
    getWorld().pieces.push({
      id, type: tool.type, x, y,
      layer: activeLayerId || tool.layer,
    });
    return true;
  }



  /** Volledig bouwmenu: gebouwen, onderdelen, lagen — alles hier. */
  function openBuildingMenu() {
    openBuildMenu();
  }
  function openBuildMenu(focusSec) {
    document.querySelectorAll('.bld-menu-back').forEach(n => n.remove());
    ensurePieces();
    ensureLayers();
    buildMode = true;

    const back = el('div', 'bld-menu-back');
    const panel = el('div', 'bld-menu bld-menu-full');
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'Bouwen');

    const head = el('div', 'bld-menu-head');
    head.append(el('h2', '', 'Bouwen'));
    const close = el('button', 'bld-menu-close', '×');
    close.type = 'button';
    close.setAttribute('aria-label', 'Sluiten');
    close.onclick = () => back.remove();
    head.append(close);
    panel.append(head);

    // Tabs
    const tabs = el('div', 'bld-tabs');
    const sections = { gebouwen: null, onderdelen: null, lagen: null };
    let activeTab = focusSec || 'onderdelen';
    const tabBtns = {};
    const body = el('div', 'bld-menu-body');

    function showTab(name) {
      activeTab = name;
      for (const [k, btn] of Object.entries(tabBtns)) {
        btn.classList.toggle('active', k === name);
      }
      for (const [k, sec] of Object.entries(sections)) {
        if (sec) sec.style.display = k === name ? '' : 'none';
      }
    }

    for (const [id, label] of [['onderdelen', 'Onderdelen'], ['gebouwen', 'Gebouwen'], ['lagen', 'Lagen']]) {
      const t = el('button', 'bld-tab' + (id === activeTab ? ' active' : ''), label);
      t.type = 'button';
      t.onclick = () => showTab(id);
      tabBtns[id] = t;
      tabs.append(t);
    }
    panel.append(tabs);

    // ===== ONDERDELEN =====
    const ond = el('div', 'bld-menu-sec');
    sections.onderdelen = ond;
    ond.append(el('p', 'bld-menu-intro', 'Kies een onderdeel. Muur en water schilder je op het raster; andere stukken worden geplaatst.'));

    // Paint tools
    ond.append(el('h3', '', 'Schilderen op raster'));
    const paintGrid = el('div', 'bld-menu-grid bld-tools-grid');
    for (const [key, tool] of Object.entries(PAINT_TOOLS)) {
      const card = el('button', 'bld-card bld-tool-card' + (paintTool === key ? ' selected' : ''));
      card.type = 'button';
      const preview = el('div', 'bld-card-preview');
      preview.append(pieceGraphic(tool.type, null));
      card.append(preview);
      card.append(el('span', 'bld-card-title', tool.label));
      card.append(el('span', 'bld-card-meta', paintTool === key ? 'Actief — sleep op het veld' : 'Klik om te schilderen'));
      card.onclick = () => {
        paintTool = paintTool === key ? null : key;
        back.remove();
        renderWorld();
      };
      paintGrid.append(card);
    }
    ond.append(paintGrid);

    // Structures & deco
    ond.append(el('h3', '', 'Structuren & decor'));
    const decoGrid = el('div', 'bld-menu-grid bld-tools-grid');
    for (const piece of CASTLE_PIECES) {
      if (piece.paint) continue;
      if (piece.type.startsWith('wall-') || piece.type === 'moat') continue;
      const card = el('button', 'bld-card bld-tool-card');
      card.type = 'button';
      const preview = el('div', 'bld-card-preview');
      preview.append(pieceGraphic(piece.type));
      card.append(preview);
      card.append(el('span', 'bld-card-title', piece.label));
      card.append(el('span', 'bld-card-meta', 'Op veld plaatsen'));
      card.onclick = () => {
        paintTool = null;
        ensurePieces();
        const spot = findFreeSpot();
        const id = uniqueId(piece.type, new Set(getWorld().pieces.map(p => p.id)));
        getWorld().pieces.push({
          id, type: piece.type, x: spot.x, y: spot.y,
          layer: activeLayerId || piece.defaultLayer,
        });
        persist();
        back.remove();
        renderWorld();
      };
      decoGrid.append(card);
    }
    ond.append(decoGrid);

    // Fan-tasy Tileset (Free)
    ond.append(el('h3', '', 'Fan-tasy set (pixel)'));
    ond.append(el('p', 'bld-menu-empty', 'Losse gebouwen, bomen en props uit The Fan-tasy Tileset (Free).'));
    const ftGrid = el('div', 'bld-menu-grid bld-tools-grid');
    for (const piece of FANTASY_SET) {
      const card = el('button', 'bld-card bld-tool-card');
      card.type = 'button';
      const preview = el('div', 'bld-card-preview');
      preview.append(pieceGraphic(piece.type));
      card.append(preview);
      card.append(el('span', 'bld-card-title', piece.label));
      card.append(el('span', 'bld-card-meta', 'Op veld plaatsen'));
      card.onclick = () => {
        paintTool = null;
        ensurePieces();
        const spot = findFreeSpot();
        const id = uniqueId(piece.type, new Set(getWorld().pieces.map(p => p.id)));
        getWorld().pieces.push({
          id, type: piece.type, x: spot.x, y: spot.y,
          layer: activeLayerId || piece.layer || 'decor',
        });
        persist();
        back.remove();
        renderWorld();
      };
      ftGrid.append(card);
    }
    ond.append(ftGrid);
    body.append(ond);

    // ===== GEBOUWEN =====
    const geb = el('div', 'bld-menu-sec');
    sections.gebouwen = geb;
    geb.append(el('p', 'bld-menu-intro',
      'Haal een gebouw van het veld zonder inhoud te verliezen. Zet het later terug via Voorraad.'));

    const placed = getWorld().buildings.filter(isPlaced);
    const stock = getWorld().buildings.filter(b => !isPlaced(b));

    geb.append(el('h3', '', 'Voorraad — terugplaatsen'));
    if (!stock.length) {
      geb.append(el('p', 'bld-menu-empty', 'Geen gebouwen in voorraad. Haal er een van het veld met × of “Van veld”.'));
    } else {
      const grid = el('div', 'bld-menu-grid');
      for (const b of stock) {
        const card = el('button', 'bld-card');
        card.type = 'button';
        const preview = el('div', 'bld-card-preview');
        preview.append(buildingGraphic(b));
        card.append(preview);
        card.append(el('span', 'bld-card-title', b.label));
        const rooms = (b.rooms || []).length;
        const books = buildingBookCount(b);
        card.append(el('span', 'bld-card-meta',
          `${rooms} sectie${rooms === 1 ? '' : 's'}` + (books ? ` · ${books} boek${books === 1 ? '' : 'en'}` : '')));
        card.append(el('span', 'bld-card-action', 'Op veld zetten'));
        card.onclick = () => {
          const spot = findFreeSpot();
          placeBuilding(b, b.x ?? spot.x, b.y ?? spot.y);
          const clash = getWorld().buildings.some(o => isPlaced(o) && o.id !== b.id && cellKey(o.x, o.y) === cellKey(b.x, b.y));
          if (clash) { b.x = spot.x; b.y = spot.y; }
          persist();
          back.remove();
          renderWorld();
        };
        grid.append(card);
      }
      geb.append(grid);
    }

    geb.append(el('h3', '', 'Op het veld'));
    if (!placed.length) {
      geb.append(el('p', 'bld-menu-empty', 'Nog geen gebouwen op het veld.'));
    } else {
      const grid = el('div', 'bld-menu-grid');
      for (const b of placed) {
        const card = el('div', 'bld-card bld-card-on');
        const preview = el('div', 'bld-card-preview');
        preview.append(buildingGraphic(b));
        card.append(preview);
        card.append(el('span', 'bld-card-title', b.label));
        const rooms = (b.rooms || []).length;
        const books = buildingBookCount(b);
        card.append(el('span', 'bld-card-meta',
          `${rooms} sectie${rooms === 1 ? '' : 's'}` + (books ? ` · ${books} boek${books === 1 ? '' : 'en'}` : '')));
        const actions = el('div', 'bld-card-actions');
        const goBtn = el('button', 'bld-card-btn', 'Openen');
        goBtn.type = 'button';
        goBtn.onclick = () => { back.remove(); go(b.id, null); };
        const takeBtn = el('button', 'bld-card-btn danger', 'Van veld');
        takeBtn.type = 'button';
        takeBtn.onclick = async () => {
          if (!await ask(`“${b.label}” van het veld halen? Inhoud blijft in de voorraad.`, { yes: 'Van veld halen' })) return;
          unplaceBuilding(b);
          persist();
          back.remove();
          openBuildMenu('gebouwen');
          renderWorld();
        };
        actions.append(goBtn, takeBtn);
        card.append(actions);
        grid.append(card);
      }
      geb.append(grid);
    }

    const newBtn = el('button', 'bld-menu-new', '+ Nieuw leeg gebouw');
    newBtn.type = 'button';
    newBtn.onclick = async () => {
      const v = await ask('Naam van het nieuwe gebouw', { input: true, yes: 'Aanmaken' });
      if (!v) return;
      const id = uniqueId(slug(v), new Set(getWorld().buildings.map(b => b.id)));
      const spot = findFreeSpot();
      getWorld().buildings.push({
        id, label: v, desc: '', x: spot.x, y: spot.y, w: 18, h: 16, rooms: [],
        layer: activeLayerId || 'gebouwen', placed: true,
      });
      persist();
      back.remove();
      renderWorld();
    };
    geb.append(newBtn);
    body.append(geb);

    // ===== LAGEN =====
    const lag = el('div', 'bld-menu-sec');
    sections.lagen = lag;
    lag.append(el('p', 'bld-menu-intro', 'Bepaal de volgorde van lagen. Hogere lagen liggen bovenop.'));
    const layerList = el('div', 'bld-layer-list');
    for (const l of getWorld().layers) {
      const row = el('div', 'bld-layer-row' + (l.id === activeLayerId ? ' active' : ''));
      const nameBtn = el('button', 'bld-layer-name', l.label);
      nameBtn.type = 'button';
      nameBtn.onclick = () => {
        activeLayerId = l.id;
        persist();
        back.remove();
        openBuildMenu('lagen');
        renderWorld();
      };
      row.append(nameBtn);
      const nB = getWorld().buildings.filter(b => isPlaced(b) && (b.layer || 'gebouwen') === l.id).length;
      const nP = getWorld().pieces.filter(p => (p.layer || 'muren') === l.id).length;
      row.append(el('span', 'bld-layer-meta', `${nB + nP} stuks`));

      const up = el('button', 'bld-card-btn', '↑');
      up.type = 'button';
      up.title = 'Naar voren';
      up.onclick = () => {
        const i = getWorld().layers.findIndex(x => x.id === l.id);
        if (i >= getWorld().layers.length - 1) return;
        const a = getWorld().layers[i], b = getWorld().layers[i + 1];
        const t = a.order; a.order = b.order; b.order = t;
        persist();
        back.remove();
        openBuildMenu('lagen');
        renderWorld();
      };
      const down = el('button', 'bld-card-btn', '↓');
      down.type = 'button';
      down.onclick = () => {
        const i = getWorld().layers.findIndex(x => x.id === l.id);
        if (i <= 0) return;
        const a = getWorld().layers[i], b = getWorld().layers[i - 1];
        const t = a.order; a.order = b.order; b.order = t;
        persist();
        back.remove();
        openBuildMenu('lagen');
        renderWorld();
      };
      const del = el('button', 'bld-card-btn danger', '×');
      del.type = 'button';
      del.onclick = async () => {
        if (getWorld().layers.length <= 1) return;
        if (!await ask(`Laag “${l.label}” verwijderen?`, { yes: 'Verwijderen' })) return;
        const fallback = getWorld().layers.find(x => x.id !== l.id).id;
        getWorld().buildings.forEach(b => { if ((b.layer || 'gebouwen') === l.id) b.layer = fallback; });
        getWorld().pieces.forEach(p => { if ((p.layer || 'muren') === l.id) p.layer = fallback; });
        getWorld().layers = getWorld().layers.filter(x => x.id !== l.id);
        if (activeLayerId === l.id) activeLayerId = fallback;
        persist();
        back.remove();
        openBuildMenu('lagen');
        renderWorld();
      };
      row.append(up, down, del);
      layerList.append(row);
    }
    lag.append(layerList);
    const addLayer = el('button', 'bld-menu-new', '+ Nieuwe laag');
    addLayer.type = 'button';
    addLayer.onclick = async () => {
      const v = await ask('Naam van de nieuwe laag', { input: true, value: 'Laag ' + (getWorld().layers.length + 1), yes: 'Toevoegen' });
      if (!v) return;
      const id = uniqueId(slug(v), new Set(getWorld().layers.map(l => l.id)));
      const maxOrder = Math.max(...getWorld().layers.map(l => l.order), -1);
      getWorld().layers.push({ id, label: v, order: maxOrder + 1 });
      activeLayerId = id;
      persist();
      back.remove();
      openBuildMenu('lagen');
      renderWorld();
    };
    lag.append(addLayer);
    body.append(lag);

    panel.append(body);
    back.append(panel);
    back.addEventListener('click', e => { if (e.target === back) back.remove(); });
    document.body.append(back);
    showTab(activeTab);
  }


  /** Cache voor geladen startscherm-achtergrond (URL of data-URL). */
  let _startBgUrl = null;
  let _startBgTried = false;

  /**
   * Zet #home --carousel-bg-image vanuit assets/ of (in Tauri) de gebruikersmap.
   * Bestandsnaam: startschermachtergrond.(jpg|jpeg|png|webp)
   */
  function setStartscreenBackground() {
    if (_startBgUrl) {
      home.style.setProperty('--carousel-bg-image', "url('" + _startBgUrl + "')");
      home.classList.add('has-start-bg');
      return;
    }
    if (_startBgTried) return;
    _startBgTried = true;

    const names = [
      'startschermachtergrond.jpg',
      'startschermachtergrond.jpeg',
      'startschermachtergrond.png',
      'startschermachtergrond.webp',
    ];
    const candidates = [];
    for (const n of names) {
      candidates.push('assets/' + n);
      candidates.push('./assets/' + n);
    }

    const apply = (url) => {
      _startBgUrl = url;
      home.style.setProperty('--carousel-bg-image', "url('" + url + "')");
      home.classList.add('has-start-bg');
    };

    let i = 0;
    const tryNext = () => {
      if (i >= candidates.length) {
        // Laatste kans: gebruikersmap (Tauri) — stad/startschermachtergrond.*
        tryUserStartBg();
        return;
      }
      const url = candidates[i++];
      const img = new Image();
      img.onload = () => apply(url);
      img.onerror = tryNext;
      img.src = url;
    };

    async function tryUserStartBg() {
      if (!inTauri || typeof readUserImageB64 !== 'function') return;
      for (const n of names) {
        const rels = [n, 'stad/' + n, n.replace(/^/, '')];
        for (const rel of ['stad/' + n, n]) {
          try {
            const b64 = await readUserImageB64(rel);
            if (!b64) continue;
            const ext = n.split('.').pop().toLowerCase();
            const mime = ({ png: 'image/png', webp: 'image/webp', jpg: 'image/jpeg', jpeg: 'image/jpeg' })[ext] || 'image/jpeg';
            apply('data:' + mime + ';base64,' + b64);
            return;
          } catch (_) { /* volgende */ }
        }
      }
    }

    tryNext();
  }

  /**
   * Startscherm (interactief): carrousel van gebouw-tegels.
   * Blader horizontaal tussen gebouwen; elke tegel toont cover, korte bib (secties) en open-knop.
   */
  function renderBuildingCarousel(c) {
    home.classList.remove('has-map');
    home.classList.remove('village-home');
    home.classList.add('carousel-home');
    home.style.removeProperty('--header-h');

    const buildings = (getWorld().buildings || []).slice();
    if (!buildings.length) {
      const empty = el('div', 'bld-carousel-empty');
      empty.append(el('p', '', 'Nog geen gebouwen in de stad.'));
      c.appendChild(empty);
      return;
    }
    const n = buildings.length;
    if (carouselIndex < 0 || carouselIndex >= n) carouselIndex = 0;
    const loop = n > 1; // endless: 3× de rij, midden is de “echte” set

    const root = el('div', 'bld-carousel');
    root.setAttribute('role', 'region');
    root.setAttribute('aria-label', 'Gebouwen van de stad');

    // Achtergrond: startschermachtergrond (assets/ of gebruikersmap)
    setStartscreenBackground();

    const head = el('div', 'bld-carousel-head');
    head.append(el('h2', 'bld-carousel-title', 'Kies een gebouw'));
    head.append(el('p', 'bld-carousel-sub', 'Sleep met de muis, veeg, of gebruik de pijlen — oneindig doorlopend'));
    root.append(head);

    const stage = el('div', 'bld-carousel-stage');
    const track = el('div', 'bld-carousel-track');
    track.setAttribute('tabindex', '0');
    track.setAttribute('aria-roledescription', 'carrousel');

    const cardNodes = []; // alle DOM-kaarten (eventueel 3× n)
    const reps = loop ? 3 : 1;

    function makeCard(b, realIndex, slotIndex) {
      const nRooms = (b.rooms || []).length;
      const nBooks = (b.rooms || []).reduce((s, r) => s + roomItems(r).length, 0);
      const card = el('article', 'bld-carousel-card' + (realIndex === carouselIndex ? ' is-active' : ''));
      card.dataset.real = String(realIndex);
      card.dataset.slot = String(slotIndex);
      card.setAttribute('role', 'group');
      card.setAttribute('aria-label', (b.label || b.id) + (realIndex === carouselIndex ? ' (geselecteerd)' : ''));

      const media = el('div', 'bld-carousel-media');
      // Inline: voorkomt dat andere CSS het mediavlak leeg laat
      media.style.cssText = 'position:relative;overflow:hidden;width:100%;height:280px;min-height:280px;margin:0;padding:0;flex-shrink:0;background:#1a1612;line-height:0;';
      const style = String(b.id || '').toLowerCase();
      const asset = userCovers[style] || b.asset || BUILDING_ASSETS[style] || BUILDING_ASSETS[b.id];
      if (asset) {
        const img = document.createElement('img');
        img.src = asset;
        img.alt = b.label || style;
        img.draggable = false;
        img.className = 'bld-carousel-img';
        // Alles vult het kader 100% — geen randen, geen letterbox
        img.style.cssText = [
          'position:absolute',
          'top:0',
          'left:0',
          'right:0',
          'bottom:0',
          'width:100%',
          'height:100%',
          'max-width:none',
          'max-height:none',
          'object-fit:cover',
          'object-position:center',
          'padding:0',
          'margin:0',
          'border:0',
          'display:block',
          'box-sizing:border-box',
        ].join(';');
        media.appendChild(img);
      } else {
        const gfx = buildingGraphic(b);
        gfx.classList.add('bld-carousel-gfx');
        media.appendChild(gfx);
      }
      card.append(media);

      const body = el('div', 'bld-carousel-body');
      const nameEl = el('h3', 'bld-carousel-name', b.label || b.id);
      makeInlineEditable(nameEl, () => b.label || '', async (v) => { b.label = v || b.id; });
      body.append(nameEl);
      if (b.desc || getAuthorMode()) {
        const descEl = el('p', 'bld-carousel-desc', b.desc || '');
        if (!b.desc && getAuthorMode()) descEl.classList.add('is-placeholder');
        if (!b.desc && getAuthorMode()) descEl.textContent = 'Beschrijving toevoegen…';
        makeInlineEditable(descEl, () => b.desc || '', async (v) => {
          b.desc = v === 'Beschrijving toevoegen…' ? '' : v;
          if (!b.desc) descEl.textContent = getAuthorMode() ? 'Beschrijving toevoegen…' : '';
        }, { multiline: true, title: 'Beschrijving bewerken' });
        body.append(descEl);
      }
      const stats = el('p', 'bld-carousel-stats');
      const parts = [];
      if (nRooms) parts.push(nRooms + ' sectie' + (nRooms === 1 ? '' : 's'));
      if (nBooks) parts.push(nBooks + ' boek' + (nBooks === 1 ? '' : 'en'));
      stats.textContent = parts.length ? parts.join(' · ') : 'Nog leeg';
      body.append(stats);

      const rooms = b.rooms || [];
      if (rooms.length) {
        const lib = el('ul', 'bld-carousel-lib');
        const show = rooms.slice(0, 6);
        for (const r of show) {
          const li = el('li', 'bld-carousel-chip');
          const rn = roomItems(r).length;
          if (getAuthorMode()) {
            const lab = document.createElement('span');
            lab.textContent = r.label || r.id;
            lab.className = 'bld-carousel-chip-label';
            makeInlineEditable(lab, () => r.label || '', async (v) => { r.label = v || r.id; }, { title: 'Sectienaam bewerken' });
            li.append(lab);
            if (rn) li.append(el('span', 'bld-carousel-chip-n', String(rn)));
            li.title = 'Sectienaam bewerken (auteursmodus)';
          } else {
            li.textContent = r.label || r.id;
            if (rn) li.append(el('span', 'bld-carousel-chip-n', String(rn)));
            li.title = (r.desc || r.label || '') + (rn ? ' (' + rn + ' boeken)' : '');
            li.onclick = (e) => { e.stopPropagation(); go(b.id, r.id); };
          }
          lib.append(li);
        }
        if (rooms.length > show.length) {
          const more = el('li', 'bld-carousel-chip is-more');
          more.textContent = '+' + (rooms.length - show.length);
          more.title = 'Meer secties in dit gebouw';
          lib.append(more);
        }
        body.append(lib);
      }

      const openBtn = el('button', 'bld-carousel-open', 'Openen');
      openBtn.type = 'button';
      openBtn.onclick = (e) => { e.stopPropagation(); go(b.id, null); };
      body.append(openBtn);
      card.append(body);

      card.onclick = () => {
        if (track._dragMoved) return;
        if (realIndex === carouselIndex) go(b.id, null);
        else goToCarousel(realIndex);
      };
      return card;
    }

    let slot = 0;
    for (let rep = 0; rep < reps; rep++) {
      for (let i = 0; i < n; i++) {
        const card = makeCard(buildings[i], i, slot);
        track.append(card);
        cardNodes.push(card);
        slot++;
      }
    }

    stage.append(track);

    // Pijlen horen bij de stadstegels (in de stage) — niet op body, niet in Instellingen
    const prev = el('button', 'bld-carousel-arrow bld-carousel-arrow-prev', '‹');
    prev.type = 'button';
    prev.setAttribute('aria-label', 'Vorig gebouw');
    prev.disabled = n < 2;
    const next = el('button', 'bld-carousel-arrow bld-carousel-arrow-next', '›');
    next.type = 'button';
    next.setAttribute('aria-label', 'Volgend gebouw');
    next.disabled = n < 2;
    stage.append(prev, next);
    root.append(stage);

    const navBar = el('div', 'bld-carousel-nav');
    const dots = el('div', 'bld-carousel-dots');
    dots.setAttribute('role', 'tablist');
    dots.setAttribute('aria-label', 'Gebouwen');
    const dotBtns = buildings.map((b, i) => {
      const d = el('button', 'bld-carousel-dot' + (i === carouselIndex ? ' is-active' : ''));
      d.type = 'button';
      d.setAttribute('role', 'tab');
      d.setAttribute('aria-label', b.label || b.id);
      d.setAttribute('aria-selected', i === carouselIndex ? 'true' : 'false');
      d.onclick = () => goToCarousel(i);
      dots.append(d);
      return d;
    });
    navBar.append(dots);
    root.append(navBar);

    // Grote zoekbalk onder de stadstegels
    const searchWrap = el('div', 'bld-carousel-search');
    const searchForm = el('form', 'bld-carousel-search-form');
    searchForm.setAttribute('role', 'search');
    const searchInput = document.createElement('input');
    searchInput.type = 'search';
    searchInput.className = 'bld-carousel-search-input';
    searchInput.placeholder = 'Zoeken in de bibliotheek…';
    searchInput.setAttribute('aria-label', 'Zoeken in de bibliotheek');
    searchInput.autocomplete = 'off';
    searchInput.enterKeyHint = 'search';
    const searchBtn = el('button', 'bld-carousel-search-btn', 'Zoeken');
    searchBtn.type = 'submit';
    searchForm.onsubmit = (e) => {
      e.preventDefault();
      const q = (searchInput.value || '').trim();
      try { showResults(q); } catch (err) { console.warn(err); }
    };
    searchForm.append(searchInput, searchBtn);
    searchWrap.append(searchForm);
    // Recente zoekopdrachten als snelle chips
    try {
      const recent = (typeof loadSearchRecent === 'function' ? loadSearchRecent() : []).slice(0, 5);
      if (recent.length) {
        const chips = el('div', 'bld-carousel-search-recent');
        for (const r of recent) {
          const chip = el('button', 'bld-carousel-search-chip', r);
          chip.type = 'button';
          chip.title = 'Zoek: ' + r;
          chip.onclick = () => { try { showResults(r); } catch (_) {} };
          chips.append(chip);
        }
        searchWrap.append(chips);
      }
    } catch (_) {}
    root.append(searchWrap);

    // App-grid onder de zoekbalk (alfabetisch + zoekfilter + favorieten)
    const GAME_KINDS_HOME = new Set(['memory', 'snake', 'bke', 'tetris', 'mastermind', 'connect4', 'speeltoestel']);
    const allHomeItems = listLeoApps().slice().sort((a, b) => {
      return (MINI_APP_TITLES[a.kind] || a.kind).localeCompare(MINI_APP_TITLES[b.kind] || b.kind, 'nl');
    });
    const homeApps = allHomeItems.filter(a => !GAME_KINDS_HOME.has(a.kind));
    const homeGames = allHomeItems.filter(a => GAME_KINDS_HOME.has(a.kind));

    function buildGridSection(titleText, items, emptyMsg, filterPlaceholder, ariaLabel) {
      const wrap = el('div', 'bld-carousel-apps');
      wrap.append(el('h2', 'bld-carousel-apps-title', titleText));
      const filter = document.createElement('input');
      filter.type = 'search';
      filter.className = 'bld-carousel-apps-filter';
      filter.placeholder = filterPlaceholder;
      filter.setAttribute('aria-label', ariaLabel);
      filter.autocomplete = 'off';
      wrap.append(filter);
      const grid = el('div', 'bld-carousel-apps-grid');
      function paint(filterText) {
        grid.replaceChildren();
        const q = String(filterText || '').trim().toLowerCase();
        const list = items.filter(app => {
          if (!q) return true;
          const title = (MINI_APP_TITLES[app.kind] || app.kind).toLowerCase();
          return title.includes(q) || app.kind.toLowerCase().includes(q);
        });
        if (!list.length) {
          grid.append(el('p', 'bld-carousel-apps-empty', emptyMsg));
          return;
        }
        for (const app of list) {
          const cell = el('div', 'bld-carousel-app-cell');
          const btn = el('button', 'bld-carousel-app');
          btn.type = 'button';
          const title = MINI_APP_TITLES[app.kind] || app.kind;
          btn.title = title;
          btn.setAttribute('aria-label', title);
          const ic = (typeof miniAppIconSvg === 'function') ? miniAppIconSvg(app.kind) : null;
          if (ic) {
            ic.setAttribute('width', '32');
            ic.setAttribute('height', '32');
            btn.append(ic);
          }
          btn.append(el('span', 'bld-carousel-app-label', title));
          btn.onclick = () => { try { app.run(); } catch (e) { console.warn(e); } };
          const star = el('button', 'bld-carousel-app-star' + (isAppFavorite(app.kind) ? ' is-on' : ''), isAppFavorite(app.kind) ? '★' : '☆');
          star.type = 'button';
          star.title = isAppFavorite(app.kind) ? 'Verwijder uit favorieten' : 'Zet in header als favoriet';
          star.setAttribute('aria-label', star.title);
          star.onclick = (e) => {
            e.stopPropagation();
            const on = toggleAppFavorite(app.kind);
            star.textContent = on ? '★' : '☆';
            star.classList.toggle('is-on', on);
            star.title = on ? 'Verwijder uit favorieten' : 'Zet in header als favoriet';
            star.setAttribute('aria-label', star.title);
          };
          cell.append(btn, star);
          grid.append(cell);
        }
      }
      paint('');
      filter.addEventListener('input', () => paint(filter.value));
      wrap.append(grid);
      return wrap;
    }

    root.append(buildGridSection('Apps', homeApps, 'Geen apps gevonden.', 'Zoek een app…', 'Zoek een app in Leo Crucis'));
    if (homeGames.length) {
      root.append(buildGridSection('Spellen', homeGames, 'Geen spellen gevonden.', 'Zoek een spel…', 'Zoek een spel in Leo Crucis'));
    }

    c.appendChild(root);

    /** Huidige “fysieke” slot in de track (0 … reps*n-1). */
    let activeSlot = loop ? n + carouselIndex : carouselIndex;
    let suppressScroll = false;

    function syncActiveUI() {
      cardNodes.forEach((node) => {
        const real = Number(node.dataset.real);
        const on = real === carouselIndex;
        node.classList.toggle('is-active', on);
        node.setAttribute('aria-label', (buildings[real].label || buildings[real].id) + (on ? ' (geselecteerd)' : ''));
      });
      dotBtns.forEach((d, i) => {
        d.classList.toggle('is-active', i === carouselIndex);
        d.setAttribute('aria-selected', i === carouselIndex ? 'true' : 'false');
      });
    }

    function scrollToSlot(s, smooth) {
      const node = cardNodes[s];
      if (!node) return;
      activeSlot = s;
      const trackRect = track.getBoundingClientRect();
      const cardRect = node.getBoundingClientRect();
      const offset = cardRect.left - trackRect.left - (trackRect.width - cardRect.width) / 2;
      suppressScroll = true;
      track.scrollTo({ left: track.scrollLeft + offset, behavior: smooth ? 'smooth' : 'auto' });
      // na jump scroll-events weer toe laten
      requestAnimationFrame(() => {
        requestAnimationFrame(() => { suppressScroll = false; });
      });
    }

    /** Zonder animatie naar equivalente kaart in de middelste set springen. */
    function normalizeLoop() {
      if (!loop) return;
      if (activeSlot < n) {
        activeSlot += n;
        scrollToSlot(activeSlot, false);
      } else if (activeSlot >= 2 * n) {
        activeSlot -= n;
        scrollToSlot(activeSlot, false);
      }
    }

    function goToCarousel(realIndex, smooth = true) {
      if (realIndex < 0 || realIndex >= n) return;
      carouselIndex = realIndex;
      // blijf bij voorkeur in de middelste set
      activeSlot = loop ? n + realIndex : realIndex;
      syncActiveUI();
      scrollToSlot(activeSlot, smooth);
    }

    function nearestSlot() {
      const center = track.scrollLeft + track.clientWidth / 2;
      let best = 0, bestDist = Infinity;
      cardNodes.forEach((node, i) => {
        const mid = node.offsetLeft + node.offsetWidth / 2;
        const dist = Math.abs(mid - center);
        if (dist < bestDist) { bestDist = dist; best = i; }
      });
      return best;
    }

    function onSettle() {
      if (suppressScroll) return;
      activeSlot = nearestSlot();
      carouselIndex = Number(cardNodes[activeSlot].dataset.real);
      syncActiveUI();
      normalizeLoop();
    }

    prev.onclick = () => {
      if (n < 2) return;
      const nextReal = (carouselIndex - 1 + n) % n;
      if (loop) {
        activeSlot -= 1;
        if (activeSlot < 0) activeSlot = cardNodes.length - 1;
        carouselIndex = nextReal;
        syncActiveUI();
        scrollToSlot(activeSlot, true);
        setTimeout(normalizeLoop, 320);
      } else {
        goToCarousel(nextReal);
      }
    };
    next.onclick = () => {
      if (n < 2) return;
      const nextReal = (carouselIndex + 1) % n;
      if (loop) {
        activeSlot += 1;
        if (activeSlot >= cardNodes.length) activeSlot = 0;
        carouselIndex = nextReal;
        syncActiveUI();
        scrollToSlot(activeSlot, true);
        setTimeout(normalizeLoop, 320);
      } else {
        goToCarousel(nextReal);
      }
    };

    track.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft') { e.preventDefault(); prev.onclick(); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); next.onclick(); }
      else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const b = buildings[carouselIndex];
        if (b) go(b.id, null);
      }
    });

    let scrollTimer = null;
    track.addEventListener('scroll', () => {
      if (suppressScroll) return;
      clearTimeout(scrollTimer);
      scrollTimer = setTimeout(onSettle, 90);
    }, { passive: true });

    // Muis / pen: slepen
    let dragActive = false;
    let dragStartX = 0;
    let dragStartScroll = 0;
    track._dragMoved = false;
    track.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'touch') return;
      if (e.button != null && e.button !== 0) return;
      if (e.target.closest('button, a, .bld-carousel-chip')) return;
      dragActive = true;
      track._dragMoved = false;
      dragStartX = e.clientX;
      dragStartScroll = track.scrollLeft;
      track.classList.add('is-dragging');
      try { track.setPointerCapture(e.pointerId); } catch (_) {}
    });
    track.addEventListener('pointermove', (e) => {
      if (!dragActive) return;
      const dx = e.clientX - dragStartX;
      if (Math.abs(dx) > 6) track._dragMoved = true;
      track.scrollLeft = dragStartScroll - dx;
    });
    const endDrag = (e) => {
      if (!dragActive) return;
      dragActive = false;
      track.classList.remove('is-dragging');
      try { if (e && e.pointerId != null) track.releasePointerCapture(e.pointerId); } catch (_) {}
      onSettle();
      setTimeout(() => { track._dragMoved = false; }, 40);
    };
    track.addEventListener('pointerup', endDrag);
    track.addEventListener('pointercancel', endDrag);

    // Start in de middelste set (endless) of op index 0
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        goToCarousel(carouselIndex, false);
      });
    });
  }

  /** Dorp fullscreen + hamer-bouwmenu. */
  /** Vaste pixel-stad: achtergrond + klikbare zones (niet bewerkbaar). */
  const CITY_MAP_SRC = 'assets/stad.jpg';
  /** Hotspots als % van de kaart (left, top, width, height) — afgestemd op stad.jpg */
  const CITY_HOTSPOTS = [
    { id: 'school',      label: 'School',      left: 6,  top: 14, w: 24, h: 24 },
    { id: 'kerk',        label: 'Kerk',        left: 34, top: 10, w: 32, h: 42 },
    { id: 'bibliotheek', label: 'Bibliotheek', left: 66, top: 10, w: 26, h: 28 },
    { id: 'academie',    label: 'Academie',    left: 4,  top: 50, w: 26, h: 26 },
    { id: 'werkplaats',  label: 'Werkplaats',  left: 34, top: 56, w: 26, h: 28 },
    { id: 'tuin',        label: 'Tuin',        left: 64, top: 46, w: 26, h: 30 },
  ];

  function renderCityMap(c) {
    home.classList.remove('has-map');
    home.classList.add('village-home');
    // De kaart begint precies onder de (echte) header en loopt door tot onderaan het scherm
    const fitCityMap = () => {
      const h = document.querySelector('header');
      if (h) home.style.setProperty('--header-h', h.offsetHeight + 'px');
    };
    fitCityMap();
    if (!window.__cityMapFit) { window.__cityMapFit = true; window.addEventListener('resize', () => { if (home.classList.contains('village-home') && home.querySelector('.city-map-wrap')) fitCityMap(); }); }
    if (!document.getElementById('city-map-css')) {
      const st = document.createElement('style');
      st.id = 'city-map-css';
      st.textContent = `
  .city-map-wrap{position:relative;height:100%;width:fit-content;max-width:100%;margin:0 auto;line-height:0;
    overflow:hidden;background:var(--panel,#f5f0e8)}
  .city-map-img{display:block;height:100%;width:auto;max-width:100%;user-select:none;-webkit-user-drag:none}
  .city-map-hotspots{position:absolute;inset:0}
  .city-hotspot{position:absolute;border:0;padding:0;margin:0;background:transparent;cursor:pointer;
    border-radius:12px;outline:none;box-shadow:none;-webkit-tap-highlight-color:transparent}
  /* Selectie bewust onzichtbaar: alleen de muiscursor (pointer) toont dat het klikbaar is */
  .city-hotspot:hover,.city-hotspot:focus,.city-hotspot:focus-visible,.city-hotspot:active{
    background:transparent;box-shadow:none;outline:none}
  @media (max-width:700px){
    .city-map-wrap{height:auto;width:100%;max-width:none}
    .city-map-img{height:auto;width:100%}
  }
  `;
      document.head.appendChild(st);
    }
    const wrap = el('div', 'city-map-wrap');
    wrap.setAttribute('role', 'navigation');
    wrap.setAttribute('aria-label', 'Stad van Leo Crucis');

    const img = document.createElement('img');
    img.className = 'city-map-img';
    img.src = CITY_MAP_SRC;
    img.alt = 'Plattegrond van de stad';
    img.draggable = false;
    img.decoding = 'async';
    wrap.appendChild(img);

    const layer = el('div', 'city-map-hotspots');
    for (const hs of CITY_HOTSPOTS) {
      const b = getWorld().buildings.find(x => x.id === hs.id);
      const btn = el('button', 'city-hotspot');
      btn.type = 'button';
      btn.style.left = hs.left + '%';
      btn.style.top = hs.top + '%';
      btn.style.width = hs.w + '%';
      btn.style.height = hs.h + '%';
      const title = (b && b.label) || hs.label;
      btn.setAttribute('aria-label', title + ' openen');
      btn.onclick = () => {
        if (b) go(b.id, null);
        else console.warn('Gebouw niet gevonden in getWorld():', hs.id);
      };
      layer.appendChild(btn);
    }
    wrap.appendChild(layer);
    c.appendChild(wrap);

    // Eigen gebouwen (via stad-map) die niet op de vaste plattegrond staan: ook in interactieve weergave bereikbaar
    const hotspotIds = new Set(CITY_HOTSPOTS.map(h => h.id));
    const extraBlds = (getWorld().buildings || []).filter(b => b && b.id && !hotspotIds.has(b.id));
    if (extraBlds.length) {
      if (!document.getElementById('city-extra-css')) {
        const st = document.createElement('style');
        st.id = 'city-extra-css';
        st.textContent = `
  .city-extra-buildings{margin:10px 12px 16px;padding:10px 12px;border:1px solid var(--line,#ddd);
    border-radius:10px;background:color-mix(in srgb,var(--panel,#f5f0e8) 92%,transparent)}
  .city-extra-title{margin:0 0 8px;font-size:13px;font-weight:700;color:var(--ink,#222);letter-spacing:.02em}
  .city-extra-list{display:flex;flex-wrap:wrap;gap:8px}
  .city-extra-btn{appearance:none;border:1px solid var(--line,#ccc);background:var(--panel,#fff);
    color:var(--ink,#222);border-radius:8px;padding:8px 12px;cursor:pointer;font:inherit;font-size:13px;
    text-align:left;min-width:120px;max-width:220px}
  .city-extra-btn:hover,.city-extra-btn:focus-visible{border-color:var(--accent,#6b5);outline:none;
    box-shadow:0 0 0 2px color-mix(in srgb,var(--accent,#6b5) 35%,transparent)}
  .city-extra-btn .city-extra-meta{display:block;font-size:11px;color:var(--mute,#666);margin-top:2px}
  `;
        document.head.appendChild(st);
      }
      const box = el('div', 'city-extra-buildings');
      box.append(el('h3', 'city-extra-title', 'Eigen gebouwen'));
      const list = el('div', 'city-extra-list');
      for (const b of extraBlds) {
        const btn = el('button', 'city-extra-btn');
        btn.type = 'button';
        btn.append(document.createTextNode(b.label || b.id));
        const nRooms = (b.rooms || []).length;
        const nBooks = (b.rooms || []).reduce((s, r) => s + roomItems(r).length, 0);
        const meta = [];
        if (nRooms) meta.push(nRooms + ' sectie' + (nRooms === 1 ? '' : 's'));
        if (nBooks) meta.push(nBooks + ' boek' + (nBooks === 1 ? '' : 'en'));
        if (meta.length) btn.append(el('span', 'city-extra-meta', meta.join(' · ')));
        btn.title = b.desc || b.label || b.id;
        btn.setAttribute('aria-label', (b.label || b.id) + ' openen');
        btn.onclick = () => go(b.id, null);
        list.append(btn);
      }
      box.append(list);
      c.appendChild(box);
    }
  }

  function renderVillage(c) {
    home.style.removeProperty('--header-h');
    home.classList.remove('has-map');
    home.classList.add('village-home');
    ensurePieces();
    ensureLayers();
    if (!getWorld().layers.some(l => l.id === activeLayerId)) {
      activeLayerId = getWorld().layers[getWorld().layers.length - 1].id;
    }

    // Bouwen alleen in editormodus (getDev())
    if (!getDev()) {
      buildMode = false;
      paintTool = null;
    }
    const editing = !!(getDev() && buildMode);
    const village = el('div',
      'village village-fullscreen'
      + (editing ? ' village-edit' : '')
      + (paintTool ? ' paint-mode paint-' + paintTool : '')
    );
    const field = el('div', 'village-field');
    field.setAttribute('role', 'application');
    field.setAttribute('aria-label', 'Stad');

    // --- Potloodknop (rechtsonder) — alleen in editormodus ---
    if (getDev()) {
      const fab = el('button', 'build-fab' + (editing ? ' active' : ''));
      fab.type = 'button';
      fab.title = editing ? 'Bouwen afsluiten' : 'Stad bewerken';
      fab.setAttribute('aria-label', fab.title);
      // Potlood-icoon (of kruis als bouwmenu actief)
      fab.innerHTML = editing
        ? '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>'
        : '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>';
      fab.onclick = () => {
        if (buildMode) {
          buildMode = false;
          paintTool = null;
          document.querySelectorAll('.bld-menu-back').forEach(n => n.remove());
          renderWorld();
        } else {
          buildMode = true;
          renderWorld();
          openBuildMenu();
        }
      };
      village.appendChild(fab);
    }

    // --- Bouwmodus: statusbalk + menu-knop (alles zit in het menu) ---
    if (editing) {
      const bar = el('div', 'build-bar');
      const status = el('span', 'build-bar-status',
        paintTool
          ? 'Actief: ' + PAINT_TOOLS[paintTool].label + ' — sleep op het raster (Shift = gummen)'
          : 'Sleep objecten · × haalt van het veld'
      );
      const menuBtn = el('button', 'build-bar-menu', 'Bouwmenu');
      menuBtn.type = 'button';
      menuBtn.onclick = () => openBuildMenu();
      const stopPaint = el('button', 'build-bar-menu ghost', paintTool ? 'Stop schilderen' : 'Onderdelen');
      stopPaint.type = 'button';
      stopPaint.onclick = () => {
        if (paintTool) { paintTool = null; renderWorld(); }
        else openBuildMenu('onderdelen');
      };
      bar.append(status, stopPaint, menuBtn);
      village.appendChild(bar);

      if (paintTool) {
        field.classList.add('paint-cursor');
        let painting = false, erasing = false, dirty = false;
        field.addEventListener('pointerdown', e => {
          if (e.button !== 0) return;
          if (e.target.closest('.village-piece, .village-building, .vb-tools, .build-bar, .build-fab')) return;
          e.preventDefault();
          field.setPointerCapture(e.pointerId);
          painting = true;
          erasing = e.shiftKey;
          dirty = false;
          paintStrokeKeys = new Set();
          if (paintCellAt(field, e.clientX, e.clientY, erasing)) dirty = true;
        });
        field.addEventListener('pointermove', e => {
          if (!painting) return;
          if (paintCellAt(field, e.clientX, e.clientY, erasing || e.shiftKey)) dirty = true;
        });
        const endPaint = () => {
          if (!painting) return;
          painting = false;
          if (dirty) { persist(); renderWorld(); }
        };
        field.addEventListener('pointerup', endPaint);
        field.addEventListener('pointercancel', endPaint);
      } else {
        field.addEventListener('pointerdown', e => {
          if (e.target === field) {
            selectedPieceKey = null;
            field.querySelectorAll('.selected').forEach(n => n.classList.remove('selected', 'glow-red'));
          }
        });
      }
    }

    // --- Stukken ---
    for (const p of getWorld().pieces) {
      if (typeof p.x !== 'number') p.x = 50;
      if (typeof p.y !== 'number') p.y = 50;
      if (!p.layer) p.layer = (CASTLE_BY_TYPE[p.type] || {}).defaultLayer || 'muren';
      const meta = CASTLE_BY_TYPE[p.type]
        || (FANTASY_BY_TYPE[p.type] && { label: FANTASY_BY_TYPE[p.type].label, cls: 'piece-asset piece-fantasy', kind: 'deco', defaultLayer: FANTASY_BY_TYPE[p.type].layer })
        || { label: p.type, cls: 'piece-deco', kind: 'deco' };
      const key = 'p:' + p.id;
      const isPaintCell = p.type === 'wall-cell' || p.type === 'water-cell';

      const tile = el('div', 'village-piece ' + (meta.cls || 'piece-deco') + (selectedPieceKey === key ? ' selected glow-red' : '') + (isPaintCell ? ' paint-cell' : ''));
      tile.dataset.id = p.id;
      tile.dataset.key = key;
      tile.dataset.layer = p.layer;
      if (isPaintCell) {
        const cx = snapPct(p.x) - VILLAGE_GRID / 2;
        const cy = snapPct(p.y) - VILLAGE_GRID / 2;
        tile.style.left = cx + '%';
        tile.style.top = cy + '%';
        tile.style.width = VILLAGE_GRID + '%';
        tile.style.height = VILLAGE_GRID + '%';
        tile.style.transform = 'none';
      } else {
        tile.style.left = p.x + '%';
        tile.style.top = p.y + '%';
      }
      tile.style.zIndex = String(zFor(p.layer, p.y));
      tile.title = meta.label;
      tile.setAttribute('aria-label', meta.label);
      tile.append(pieceGraphic(p.type, p));

      if (editing && !paintTool) {
        wireVillageDrag(tile, field, (x, y) => {
          if (isPaintCell && pieceAtCell(p.type, x, y) && cellKey(x, y) !== cellKey(p.x, p.y)) {
            tile.style.left = (snapPct(p.x) - VILLAGE_GRID / 2) + '%';
            tile.style.top = (snapPct(p.y) - VILLAGE_GRID / 2) + '%';
            return;
          }
          p.x = x; p.y = y;
          tile.style.zIndex = String(zFor(p.layer, p.y));
          persist();
          if (isPaintCell) renderWorld();
        });
        const tools = el('div', 'vb-tools');
        const layerBtn = el('span', 'vb-layer-btn', '☰');
        layerBtn.title = 'Naar andere laag';
        layerBtn.onclick = e => {
          e.stopPropagation();
          openLayerPicker(layerBtn, p.layer, id => {
            p.layer = id;
            persist();
            renderWorld();
          });
        };
        const del = el('span', 'vb-del', '×');
        del.title = 'Verwijderen';
        del.onclick = e => {
          e.stopPropagation();
          getWorld().pieces = getWorld().pieces.filter(x => x.id !== p.id);
          if (selectedPieceKey === key) selectedPieceKey = null;
          persist();
          renderWorld();
        };
        tools.append(layerBtn, del);
        tile.append(tools);
      }
      field.appendChild(tile);
    }

    // --- Gebouwen ---
    for (const b of getWorld().buildings) {
      if (!isPlaced(b)) continue;
      if (typeof b.x !== 'number') b.x = 50;
      if (typeof b.y !== 'number') b.y = 50;
      if (!b.layer) b.layer = 'gebouwen';
      const key = 'b:' + b.id;

      const tile = el('button', 'village-building' + (selectedPieceKey === key ? ' selected glow-red' : ''));
      tile.type = 'button';
      tile.dataset.id = b.id;
      tile.dataset.key = key;
      tile.dataset.layer = b.layer;
      tile.style.left = b.x + '%';
      tile.style.top = b.y + '%';
      tile.style.zIndex = String(zFor(b.layer, b.y));
      tile.title = b.desc || b.label;
      tile.setAttribute('aria-label', b.label);
      tile.append(buildingGraphic(b));
      tile.append(el('span', 'vb-name', b.label));
      const nRooms = (b.rooms || []).length;
      tile.append(el('span', 'vb-meta', nRooms ? nRooms + ' sectie' + (nRooms === 1 ? '' : 's') : 'leeg'));

      if (editing && !paintTool) {
        wireVillageDrag(tile, field, (x, y) => {
          b.x = x; b.y = y;
          tile.style.zIndex = String(zFor(b.layer, b.y));
          persist();
        }, () => go(b.id, null));
        const toolsEl = el('div', 'vb-tools');
        const layerBtn = el('span', 'vb-layer-btn', '☰');
        layerBtn.title = 'Naar andere laag';
        layerBtn.onclick = e => {
          e.stopPropagation();
          openLayerPicker(layerBtn, b.layer, id => {
            b.layer = id;
            persist();
            renderWorld();
          });
        };
        const del = el('span', 'vb-del', '×');
        del.title = 'Van het veld halen (inhoud blijft bewaard)';
        del.onclick = async e => {
          e.stopPropagation();
          const books = buildingBookCount(b);
          const rooms = (b.rooms || []).length;
          const msg = `"${b.label}" van het veld halen?\nInhoud blijft bewaard (${rooms} sectie${rooms === 1 ? '' : 's'}${books ? `, ${books} boek${books === 1 ? '' : 'en'}` : ''}) en kun je later terugplaatsen.`;
          if (!await ask(msg, { yes: 'Van veld halen' })) return;
          unplaceBuilding(b);
          if (selectedPieceKey === key) selectedPieceKey = null;
          persist();
          renderWorld();
        };
        toolsEl.append(layerBtn, del);
        tile.append(toolsEl);
      } else if (!editing && !paintTool) {
        tile.onclick = () => go(b.id, null);
      }
      field.appendChild(tile);
    }

    village.appendChild(field);
    c.appendChild(village);
  }

  /** Achtergrondafbeelding per gebouw, getoond op het niveau waar de kamers staan (src/assets/interieur/<id>.jpg). */
  const BUILDING_BACKDROPS = {
    kerk: 'assets/interieur/kerk.jpg',
  };

  function applyBuildingBackdrop(bld, room) {
    const src = bld && !room ? BUILDING_BACKDROPS[bld.id] : null;
    if (!document.getElementById('backdrop-css')) {
      const st = document.createElement('style');
      st.id = 'backdrop-css';
      st.textContent = `
  #home.has-backdrop{
    background:linear-gradient(rgba(10,8,18,.35),rgba(10,8,18,.55)),var(--backdrop) center/cover no-repeat;
  }
  #home.has-backdrop .crumbs{
    display:inline-flex;padding:8px 16px;border-radius:12px;
    background:color-mix(in srgb,var(--panel) 88%,transparent);
    box-shadow:0 4px 18px rgba(0,0,0,.35);
  }
  #home.has-backdrop .room{
    background:color-mix(in srgb,var(--panel) 45%,transparent);
    backdrop-filter:blur(4px);
    box-shadow:0 4px 18px rgba(0,0,0,.35);
  }
  #home.has-backdrop .room h3{text-shadow:0 0 8px rgba(255,255,255,.7)}
  #home.has-backdrop .room p{color:var(--ink);text-shadow:0 0 8px rgba(255,255,255,.7)}
  #home.has-backdrop .room:hover{background:color-mix(in srgb,var(--panel) 70%,transparent)}
  `;
      document.head.appendChild(st);
    }
    if (src) {
      home.style.setProperty('--backdrop', `url("${src}")`);
      home.classList.add('has-backdrop');
    } else {
      home.style.removeProperty('--backdrop');
      home.classList.remove('has-backdrop');
    }
  }

  function renderWorld() {
    const c = $('#halls');
    c.replaceChildren();
    const viewMode = currentViewMode(); // interactive | compact | list
    const bld = getWorld().buildings.find(x => x.id === nav.b);
    home.classList.toggle('has-map', false);
    home.classList.remove('carousel-home');
    if (bld || viewMode !== 'interactive') home.classList.remove('village-home');
    if (bld || viewMode !== 'interactive') {
      home.style.removeProperty('--carousel-bg-image');
      home.classList.remove('has-start-bg');
    }
    const room = bld && bld.rooms.find(x => x.id === nav.r);
    applyBuildingBackdrop(bld, room);

    if (!bld) {                                   // niveau 1: startscherm = gebouw-carrousel
      renderBuildingCarousel(c);
      return;
    }
    const bar = el('div', 'crumbs');
    const up = el('button', 'back', room ? `← ${bld.label}` : '← Naar de stad');
    up.onclick = () => room ? go(bld.id, null) : go(null, null);
    bar.append(up, el('h2', 'crumb-title', room ? room.label : bld.label));
    if (getDev() && room) bar.append(devBtn('✎', 'Sectie hernoemen', async () => {
      const v = await ask('Nieuwe naam van deze sectie', { input: true, value: room.label, yes: 'Opslaan' });
      if (v) { room.label = v; persist(); renderWorld(); }
    }, 'pencil'));
    c.appendChild(bar);

    if (!room) {                                  // niveau 2: kamers
      const g = el('div', viewMode === 'list' ? 'view-list rooms-list' : (viewMode === 'compact' ? 'view-tiles rooms-tiles' : 'rooms'));
      for (const r of bld.rooms) {
        let t;
        if (viewMode === 'list') {
          t = el('button', 'list-row room-row');
          const main = el('div', 'list-main');
          main.append(el('span', 'list-title', r.label));
          if (r.desc) main.append(el('span', 'list-desc', r.desc));
          const n = roomItems(r).length;
          if (n) main.append(el('span', 'list-meta', n + ' boek' + (n === 1 ? '' : 'en')));
          t.append(main);
          t.append(el('span', 'list-chevron', '›'));
        } else if (viewMode === 'compact') {
          t = el('button', 'tile room-tile');
          t.append(el('span', 'tile-title', r.label));
          if (r.desc) t.append(el('span', 'tile-desc', r.desc));
          const n = roomItems(r).length;
          if (n) t.append(el('span', 'tile-meta', n + ' boek' + (n === 1 ? '' : 'en')));
        } else {
          t = el('button', 'room');
          t.append(el('h3', '', r.label), el('p', '', r.desc || ''));
        }
        t.onclick = () => go(bld.id, r.id);
        if (!getDev()) { g.appendChild(t); continue; }
        const wrap = el('div', 'room-wrap');
        wrap.append(t, xBtn('Sectie verwijderen', async () => {
          const n = roomItems(r).length;
          if (!await ask(`Sectie "${r.label}" verwijderen${n ? ` met ${n} boek${n === 1 ? '' : 'en'}` : ''}?`, { yes: 'Verwijderen' })) return;
          roomItems(r).forEach(dropItem);
          bld.rooms.splice(bld.rooms.indexOf(r), 1); persist(); renderWorld();
        }));
        // Boek hierheen slepen → verplaatsen naar deze sectie
        wireDropTarget(wrap, {
          hint: 'Boek hierheen slepen om te verplaatsen',
          onDrop: id => {
            if (moveBook(id, r, null, null)) { persist(); renderWorld(); }
          }
        });
        g.appendChild(wrap);
      }
      if (getDev()) {
        const add = el('button', viewMode === 'list' ? 'list-row add' : (viewMode === 'compact' ? 'tile add' : 'room add'), '+ Nieuwe sectie');
        add.onclick = async () => {
          const v = await ask('Naam van de nieuwe sectie', { input: true, yes: 'Toevoegen' }); if (!v) return;
          const id = uniqueId(slug(v), new Set(bld.rooms.map(r => r.id)));
          bld.rooms.push({ id, label: v, desc: '', items: [] }); persist(); renderWorld();
        };
        g.appendChild(add);
      }
      c.appendChild(g);
      return;
    }
    // niveau 3: één of meerdere planken met boeken
    // Bij te veel boeken voor één plank worden automatisch extra planken (rijen) aangemaakt.
    const MAX_PER_SHELF = 12;
    if (!room.shelves && !room.items) room.items = [];
    const shelves = room.shelves
      ? room.shelves
      : [{ label: null, items: room.items || [] }];
    let colorBase = bld.rooms.indexOf(room) * 3;

    // Tijdens slepen: balk om boek naar een andere sectie te verplaatsen
    if (getDev()) {
      const moveBar = el('div', 'book-move-bar');
      moveBar.append(el('span', 'book-move-label', 'Sleep naar andere sectie:'));
      const chips = el('div', 'book-move-chips');
      for (const r of bld.rooms) {
        if (r.id === room.id) continue;
        const chip = el('button', 'book-move-chip', r.label);
        chip.type = 'button';
        wireDropTarget(chip, {
          onDrop: id => {
            if (moveBook(id, r, null, null)) { persist(); renderWorld(); }
          }
        });
        chips.append(chip);
      }
      if (chips.childNodes.length) {
        moveBar.append(chips);
        c.appendChild(moveBar);
      }
    }

    // Helper: maak één boek-knop in de gekozen weergave (spine / tile / list)
    function makeBookBtn(item, sh, items) {
      const col = (typeof item.color === 'number')
        ? colorOf(item, 0)
        : defaultColorForId(item.id);
      const tm = typeMeta(item.type || 'doc');
      let b;
      if (viewMode === 'list') {
        b = el('button', 'list-row book-row c' + col);
        b.title = item.desc || item.title;
        const main = el('div', 'list-main');
        if (item.type && item.type !== 'doc') main.append(el('span', 'type-badge', tm.icon));
        main.append(el('span', 'list-title', item.title));
        if (item.desc) main.append(el('span', 'list-desc', item.desc));
        b.append(main);
        b.append(el('span', 'list-chevron', '›'));
      } else if (viewMode === 'compact') {
        b = el('button', 'tile book-tile c' + col);
        b.title = item.desc || item.title;
        if (item.type && item.type !== 'doc') b.appendChild(el('span', 'type-badge', tm.icon));
        b.appendChild(el('span', 'tile-title', item.title));
        if (item.desc) b.appendChild(el('span', 'tile-desc', item.desc));
      } else {
        const long = (item.title || '').length > 18;
        const cls = 'spine c' + col + (long ? ' wide' : '');
        b = el('button', cls);
        b.title = item.desc || item.title;
        if (item.type && item.type !== 'doc') b.appendChild(el('span', 'type-badge', tm.icon));
        b.appendChild(el('span', 'title', item.title));
      }
      b.onclick = () => { if (DND.didDrag || DND.active) { DND.didDrag = false; return; } openItem(item); };
      if (getDev()) {
        if (viewMode === 'interactive') {
          const colBtn = el('span', 'spine-color-btn', '');
          colBtn.title = 'Boekkleur wijzigen';
          colBtn.setAttribute('role', 'button');
          colBtn.setAttribute('aria-label', 'Boekkleur wijzigen');
          colBtn.onclick = e => {
            e.preventDefault();
            e.stopPropagation();
            openSpineColorPicker(item, colBtn, col);
          };
          b.appendChild(colBtn);
        }
        b.appendChild(xBtn('Boek verwijderen', async () => {
          if (!await ask(`Boek "${item.title}" verwijderen?`, { yes: 'Verwijderen' })) return;
          dropItem(item); sh.items.splice(sh.items.indexOf(item), 1); persist(); renderWorld();
        }));
        wireBookDrag(b, item);
        wireDropTarget(b, {
          onDrop: id => {
            if (id === item.id) return;
            ensureShelves(room);
            const destIdx = items.indexOf(item);
            if (moveBook(id, room, sh, destIdx >= 0 ? destIdx : null)) { persist(); renderWorld(); }
          }
        });
      }
      return b;
    }

    shelves.forEach((sh, si) => {
      if (sh.label != null && sh.label !== '') {
        const lab = el('div', 'shelf-label', sh.label);
        if (getDev()) {
          lab.append(devBtn('✎', 'Plank hernoemen', async () => {
            const v = await ask('Nieuwe naam van de plank', { input: true, value: sh.label || '', yes: 'Opslaan' });
            if (v == null) return;
            sh.label = v.trim() || null;
            persist(); renderWorld();
          }, 'pencil'));
          lab.append(devBtn('✕ plank', 'Plank verwijderen', async () => {
            const n = (sh.items || []).length;
            if (!await ask(`Plank "${sh.label || 'zonder naam'}" verwijderen${n ? ` met ${n} boek${n === 1 ? '' : 'en'}` : ''}?`, { yes: 'Verwijderen' })) return;
            // Boeken niet wissen: verplaatsen naar eerste overblijvende plank of room.items
            ensureShelves(room);
            const left = (sh.items || []).splice(0);
            room.shelves.splice(room.shelves.indexOf(sh), 1);
            if (left.length) {
              if (!room.shelves.length) room.shelves.push({ label: null, items: [] });
              room.shelves[0].items = room.shelves[0].items || [];
              room.shelves[0].items.push(...left);
            }
            persist(); renderWorld();
          }));
        }
        // Drop op label = achteraan op deze plank
        if (getDev()) wireDropTarget(lab, {
          onDrop: id => {
            ensureShelves(room);
            if (moveBook(id, room, sh, null)) { persist(); renderWorld(); }
          }
        });
        c.appendChild(lab);
      }
      const items = sh.items || (sh.items = []);

      // Compact: tegels; List: rijen; Interactive: klassieke boekruggen
      if (viewMode === 'compact' || viewMode === 'list') {
        const container = el('div', viewMode === 'list' ? 'view-list books-list' : 'view-tiles books-tiles');
        if (getDev() && items.length === 0) {
          const ph = el('div', 'shelf-drop-hint', 'Sleep hier een boek naartoe');
          container.appendChild(ph);
        }
        items.forEach(item => container.appendChild(makeBookBtn(item, sh, items)));
        if (getDev()) {
          const add = el('button', viewMode === 'list' ? 'list-row add' : 'tile add', viewMode === 'list' ? '+ Boek toevoegen' : '+');
          add.title = 'Boek toevoegen'; add.setAttribute('aria-label', 'Boek toevoegen');
          add.onclick = async () => {
            const type = await chooseBookType();
            if (!type) return;
            const v = await ask('Titel van het nieuwe boek', { input: true, yes: 'Toevoegen' }); if (!v) return;
            let html = '';
            if (type === 'doc') {
              const design = await chooseDocDesign();
              if (design === null) return;
              html = initialDocHtml(design);
            } else if (type === 'pdf') {
              html = buildPdfHtml('', '');
            } else if (type === 'pptx') {
              html = buildSlidesHtml([
                { title: v, bullets: ['Eerste punt', 'Tweede punt'], notes: '' },
                { title: 'Inhoud', bullets: ['Onderwerp 1', 'Onderwerp 2'], notes: '' }
              ]);
            } else if (type === 'xlsx') {
              html = buildSheetHtml({ cells: Array.from({ length: 20 }, () => Array(10).fill('')) });
            }
            const id = uniqueId(slug(`${bld.id}-${room.id}-${v}`), takenIds());
            if (!sh.items) sh.items = [];
            sh.items.push({ id, title: v, desc: '', type, dir: bld.id, color: defaultColorForId(id) });
            await persist();
            await saveBook(id, v, html);
            renderWorld(); showSection(id, true);
          };
          wireDropTarget(add, {
            onDrop: id => {
              ensureShelves(room);
              if (moveBook(id, room, sh, null)) { persist(); renderWorld(); }
            }
          });
          container.appendChild(add);
          wireDropTarget(container, {
            onDrop: id => {
              ensureShelves(room);
              if (moveBook(id, room, sh, null)) { persist(); renderWorld(); }
            }
          });
        }
        c.appendChild(container);
        return; // per plank één container; bij meerdere planken herhaalt forEach
      }

      for (let start = 0; start < items.length || start === 0; start += MAX_PER_SHELF) {
        const chunk = items.slice(start, start + MAX_PER_SHELF);
        const shelf = el('div', 'bookshelf');
        if (getDev() && items.length === 0) shelf.classList.add('bookshelf-empty');
        const row = el('div', 'spine-row');
        // Lege plank: duidelijke dropzone
        if (getDev() && items.length === 0) {
          const ph = el('div', 'shelf-drop-hint', 'Sleep hier een boek naartoe');
          row.appendChild(ph);
        }
        chunk.forEach((item, i) => {
          row.appendChild(makeBookBtn(item, sh, items));
        });
        if (getDev() && start + MAX_PER_SHELF >= items.length) {          // plus-knop achteraan de plank
          const add = el('button', 'spine add', '+');
          add.title = 'Boek toevoegen'; add.setAttribute('aria-label', 'Boek toevoegen');
          add.onclick = async () => {
            const type = await chooseBookType();
            if (!type) return;
            const v = await ask('Titel van het nieuwe boek', { input: true, yes: 'Toevoegen' }); if (!v) return;
            let html = '';
            if (type === 'doc') {
              const design = await chooseDocDesign();
              if (design === null) return;
              html = initialDocHtml(design);
            } else if (type === 'pdf') {
              html = buildPdfHtml('', '');
            } else if (type === 'pptx') {
              html = buildSlidesHtml([
                { title: v, bullets: ['Eerste punt', 'Tweede punt'], notes: '' },
                { title: 'Inhoud', bullets: ['Onderwerp 1', 'Onderwerp 2'], notes: '' }
              ]);
            } else if (type === 'xlsx') {
              html = buildSheetHtml({ cells: Array.from({ length: 20 }, () => Array(10).fill('')) });
            }
            const id = uniqueId(slug(`${bld.id}-${room.id}-${v}`), takenIds());
            if (!sh.items) sh.items = [];
            sh.items.push({ id, title: v, desc: '', type, dir: bld.id, color: defaultColorForId(id) });
            await persist();
            await saveBook(id, v, html);
            renderWorld(); showSection(id, true);
          };
          // Drop op de +-knop = achteraan op deze plank
          wireDropTarget(add, {
            onDrop: id => {
              ensureShelves(room);
              if (moveBook(id, room, sh, null)) { persist(); renderWorld(); }
            }
          });
          row.appendChild(add);
        }
        // Drop op de rij / plank = achteraan
        if (getDev()) {
          wireDropTarget(row, {
            onDrop: id => {
              ensureShelves(room);
              if (moveBook(id, room, sh, null)) { persist(); renderWorld(); }
            }
          });
          wireDropTarget(shelf, {
            onDrop: id => {
              ensureShelves(room);
              if (moveBook(id, room, sh, null)) { persist(); renderWorld(); }
            }
          });
        }
        shelf.appendChild(row);
        c.appendChild(shelf);
        if (items.length === 0) break; // lege plank: één keer tonen
      }
    });
    if (getDev()) {
      const tools = el('div', 'shelf-tools');
      tools.append(devBtn('+ Nieuwe plank', 'Lege boekenkast / plank toevoegen', async () => {
        const v = await ask('Naam van de nieuwe plank (leeg = zonder naam)', { input: true, value: '', yes: 'Toevoegen' });
        if (v === null) return; // geannuleerd
        ensureShelves(room);
        // Als er nog een naamloze eerste plank met items is, geef die een label
        if (room.shelves.length === 1 && (room.shelves[0].label == null || room.shelves[0].label === '')) {
          room.shelves[0].label = 'Overzicht';
        }
        room.shelves.push({ label: (v && v.trim()) || null, items: [] });
        persist(); renderWorld();
      }));
      // Extra: lege plank zonder dialoog
      tools.append(devBtn('+ Lege kast', 'Direct een lege boekenkast toevoegen', () => {
        ensureShelves(room);
        if (room.shelves.length === 1 && (room.shelves[0].label == null || room.shelves[0].label === '')) {
          room.shelves[0].label = 'Overzicht';
        }
        const n = room.shelves.filter(s => !s.label || /^Plank/.test(s.label)).length + 1;
        room.shelves.push({ label: 'Plank ' + n, items: [] });
        persist(); renderWorld();
      }));
      c.appendChild(tools);
    }
  }

  return {
    renderWorld,
    currentViewMode,
    renderBuildingCarousel,
    renderCityMap,
    renderVillage,
    applyBuildingBackdrop,
    ensureLayers,
    ensurePieces,
    refreshCovers,
    exportBuildingImages,
    findFreeSpot,
    openBuildMenu,
    openBuildingMenu,
  };
}
